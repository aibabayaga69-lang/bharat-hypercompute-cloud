import React, { useState, useEffect } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/common/Header';
import { Sidebar } from './components/common/Sidebar';
import { CommandPalette } from './components/common/CommandPalette';
import { LandingPage } from './components/landing/LandingPage';
import { OverviewDashboard } from './components/dashboard/OverviewDashboard';
import { NotebookView } from './components/notebook/NotebookView';
import { ComputeBrainView } from './components/compute/ComputeBrainView';
import { ExperimentLabView } from './components/experiments/ExperimentLabView';
import { DatasetCenterView } from './components/datasets/DatasetCenterView';
import { ModelRegistryView } from './components/models/ModelRegistryView';
import { DeploymentsView } from './components/deployments/DeploymentsView';
import { UsageCenterView } from './components/usage/UsageCenterView';
import { ComputeMapView } from './components/compute_map/ComputeMapView';
import { ResearchAutopilotView } from './components/autopilot/ResearchAutopilotView';
import { CompanyBrainView } from './components/company_brain/CompanyBrainView';
import { AiOrganizationOSView } from './components/ai_org/AiOrganizationOSView';
import { GrowthMarketingView } from './components/growth/GrowthMarketingView';
import { FreeResourceRadarView } from './components/radar/FreeResourceRadarView';
import { ResearchRadarView } from './components/radar/ResearchRadarView';
import { KnowledgeEngineView } from './components/knowledge/KnowledgeEngineView';
import { BenchmarkLabView } from './components/benchmark/BenchmarkLabView';
import { CryptoGatewayView } from './components/crypto/CryptoGatewayView';
import { ExpertAuditView } from './components/audit/ExpertAuditView';
import { LaunchCenterView } from './components/launch/LaunchCenterView';
import { AdminView } from './components/admin/AdminView';
import { SettingsView } from './components/settings/SettingsView';
import { CheckCircle2, AlertTriangle, Info, X } from 'lucide-react';

const AppContent: React.FC = () => {
  const { currentView, notification } = useApp();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Render view
  const renderCurrentView = () => {
    switch (currentView) {
      case 'landing':
        return <LandingPage />;
      case 'overview':
        return <OverviewDashboard />;
      case 'notebook':
      case 'notebooks':
        return <NotebookView />;
      case 'compute_brain':
        return <ComputeBrainView />;
      case 'experiments':
        return <ExperimentLabView />;
      case 'datasets':
        return <DatasetCenterView />;
      case 'models':
        return <ModelRegistryView />;
      case 'deployments':
        return <DeploymentsView />;
      case 'usage':
        return <UsageCenterView />;
      case 'compute_map':
        return <ComputeMapView />;
      case 'autopilot':
        return <ResearchAutopilotView />;
      case 'company_brain':
        return <CompanyBrainView />;
      case 'ai_org_os':
        return <AiOrganizationOSView />;
      case 'growth_marketing':
        return <GrowthMarketingView />;
      case 'resource_radar':
        return <FreeResourceRadarView />;
      case 'research_radar':
        return <ResearchRadarView />;
      case 'knowledge_engine':
        return <KnowledgeEngineView />;
      case 'benchmark_lab':
        return <BenchmarkLabView />;
      case 'crypto_gateway':
        return <CryptoGatewayView />;
      case 'expert_audit':
        return <ExpertAuditView />;
      case 'launch_center':
        return <LaunchCenterView />;
      case 'admin':
      case 'organization':
        return <AdminView />;
      case 'settings':
        return <SettingsView />;
      default:
        return <OverviewDashboard />;
    }
  };

  // If on landing page, display landing without inner dashboard shell
  if (currentView === 'landing') {
    return (
      <div className="min-h-screen bg-[#07090e] text-gray-100 font-sans selection:bg-orange-500/30 selection:text-orange-200">
        <LandingPage />
        <CommandPalette />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#07090e] text-gray-100 font-sans selection:bg-orange-500/30 selection:text-orange-200 flex flex-col">
      {/* Top Header */}
      <Header onToggleMobileMenu={() => setMobileMenuOpen(prev => !prev)} />

      {/* Main Workspace Layout */}
      <div className="flex-1 flex overflow-hidden">
        {/* Persistent Collapsible Sidebar */}
        <Sidebar mobileOpen={mobileMenuOpen} onCloseMobile={() => setMobileMenuOpen(false)} />

        {/* Dynamic Content View Area */}
        <main className="flex-1 overflow-y-auto min-h-0 bg-radial from-[#0d121f]/40 to-[#07090e]">
          {renderCurrentView()}
        </main>
      </div>

      {/* Command Palette (Cmd+K / Ctrl+K) */}
      <CommandPalette />

      {/* Toast Notification Stack */}
      {notification && (
        <div className="fixed bottom-4 right-4 z-50 max-w-sm pointer-events-auto">
          <div
            className={`p-3.5 rounded-xl border shadow-2xl flex items-start space-x-3 text-xs font-mono transition-all duration-200 ${
              notification.type === 'success'
                ? 'bg-[#0a1612] border-emerald-500/40 text-emerald-300'
                : notification.type === 'warning'
                ? 'bg-[#181206] border-amber-500/40 text-amber-300'
                : 'bg-[#0e1320] border-sky-500/40 text-sky-300'
            }`}
          >
            {notification.type === 'success' && <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400 mt-0.5" />}
            {notification.type === 'warning' && <AlertTriangle className="w-4 h-4 shrink-0 text-amber-400 mt-0.5" />}
            {notification.type === 'info' && <Info className="w-4 h-4 shrink-0 text-sky-400 mt-0.5" />}

            <div className="flex-1 leading-snug">{notification.message}</div>
          </div>
        </div>
      )}
    </div>
  );
};

export const App: React.FC = () => {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
};

export default App;
