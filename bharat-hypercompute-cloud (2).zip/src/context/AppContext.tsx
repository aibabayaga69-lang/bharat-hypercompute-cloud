import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  User,
  Organization,
  Project,
  Notebook,
  Dataset,
  Experiment,
  Model,
  Deployment,
  Accelerator,
  ResearchTimelineEvent,
  ResearchMemoryEntry,
  AuditLog,
  ComputeIntentPlan,
  NotebookCell,
  Checkpoint,
  Entitlement
} from '../types';
import {
  AIAgent,
  AgentTask,
  ApprovalItem,
  GrowthExperiment,
  MarketingCampaign,
  FreeResourceRadarItem,
  ResearchRadarItem,
  FutureUpgradeProposal,
  HyperComputeProvider
} from '../types/aiCompany';
import {
  ModelKnowledgeManifest,
  KnowledgeGraphNode,
  ScientificClaim,
  MIIModelSpec,
  TournamentMatch,
  CryptoTokenConfig,
  CryptoPaymentSession,
  HumanExpert,
  AIAuditorSpecialist,
  PlatformAuditFinding,
  LaunchPhasePlan,
  DataPrivacyClass,
  AuditArchitectureStats,
  CircularAuditLoop,
  ProductGapItem,
  HumanSimulationPersona,
  FinalLaunchCertificateData
} from '../types/platformKnowledge';
import {
  INITIAL_AUDIT_ARCHITECTURE_STATS,
  INITIAL_CIRCULAR_AUDIT_LOOPS,
  INITIAL_PRODUCT_GAPS,
  INITIAL_HUMAN_SIMULATION_PERSONAS,
  INITIAL_FINAL_LAUNCH_CERTIFICATE
} from '../data/oneBillionAuditData';
import {
  INITIAL_USER_FREE,
  INITIAL_USER_FOUNDER,
  INITIAL_ORG,
  INITIAL_PROJECT,
  INITIAL_ACCELERATORS,
  INITIAL_NOTEBOOK,
  INITIAL_DATASET,
  INITIAL_EXPERIMENTS,
  INITIAL_MODELS,
  INITIAL_DEPLOYMENT,
  INITIAL_TIMELINE,
  INITIAL_RESEARCH_MEMORY,
  INITIAL_AUDIT_LOGS
} from '../data/mockData';
import {
  INITIAL_AI_AGENTS,
  INITIAL_AGENT_TASKS,
  INITIAL_APPROVAL_ITEMS,
  INITIAL_GROWTH_EXPERIMENTS,
  INITIAL_MARKETING_CAMPAIGNS,
  INITIAL_FREE_RESOURCE_RADAR,
  INITIAL_RESEARCH_RADAR,
  INITIAL_FUTURE_UPGRADES,
  INITIAL_HYPERCOMPUTE_PROVIDERS
} from '../data/aiCompanyData';
import {
  INITIAL_KNOWLEDGE_MANIFESTS,
  INITIAL_KNOWLEDGE_GRAPH_NODES,
  INITIAL_SCIENTIFIC_CLAIMS,
  INITIAL_MII_MODEL_FAMILY,
  INITIAL_TOURNAMENT_MATCHES,
  INITIAL_CRYPTO_TOKENS,
  INITIAL_CRYPTO_SESSIONS,
  INITIAL_HUMAN_EXPERTS,
  INITIAL_AI_AUDITORS,
  INITIAL_AUDIT_FINDINGS,
  INITIAL_LAUNCH_PLAN
} from '../data/platformKnowledgeData';
import {
  DetailedAIAgent,
  DepartmentAllocationInfo,
  OrchestrationTaskItem,
  OwnerApprovalRequest,
  ImmutableAuditLogRecord,
  AutonomousSelfOptimizationProposal,
  CompanyKnowledgeMemoryItem,
  AiOrganizationState,
  TaskLifecycleStage
} from '../types/aiOrganization';
import {
  INITIAL_DEPARTMENTS,
  generateExactThousandAgents,
  INITIAL_ORCHESTRATION_TASKS,
  INITIAL_OWNER_APPROVALS,
  INITIAL_AUDIT_LOG_RECORDS,
  INITIAL_SELF_OPTIMIZATIONS,
  INITIAL_COMPANY_KNOWLEDGE_MEMORY,
  INITIAL_AI_ORG_STATE
} from '../data/aiOrganizationData';
import { routeTaskExecution } from '../services/freeResourceRouter';
import { UserRole } from '../types';

export type AppView =
  | 'landing'
  | 'overview'
  | 'notebook'
  | 'notebooks'
  | 'compute_brain'
  | 'experiments'
  | 'datasets'
  | 'models'
  | 'deployments'
  | 'usage'
  | 'compute_map'
  | 'autopilot'
  | 'company_brain'
  | 'ai_org_os'
  | 'growth_marketing'
  | 'research_radar'
  | 'resource_radar'
  | 'future_lab'
  | 'knowledge_engine'
  | 'benchmark_lab'
  | 'crypto_gateway'
  | 'expert_audit'
  | 'launch_center'
  | 'organization'
  | 'admin'
  | 'settings';

interface SelfHealingState {
  isActive: boolean;
  status: 'idle' | 'running' | 'interrupted' | 'recovering' | 'completed';
  currentStep: number;
  totalSteps: number;
  currentLoss: number;
  logs: string[];
  lastCheckpointStep: number;
}

interface AppContextType {
  currentView: AppView;
  setCurrentView: (view: AppView) => void;
  user: User;
  setUser: React.Dispatch<React.SetStateAction<User>>;
  toggleEntitlement: () => void;
  org: Organization;
  project: Project;
  notebook: Notebook;
  setNotebook: React.Dispatch<React.SetStateAction<Notebook>>;
  updateCell: (cellId: string, updates: Partial<NotebookCell>) => void;
  runCell: (cellId: string) => Promise<void>;
  runAllCells: () => Promise<void>;
  addCell: (type: 'code' | 'markdown') => void;
  deleteCell: (cellId: string) => void;
  datasets: Dataset[];
  addDatasetVersion: (datasetId: string, versionData: any) => void;
  experiments: Experiment[];
  addExperiment: (exp: Experiment) => void;
  reproduceExperiment: (expId: string) => void;
  forkExperiment: (expId: string) => void;
  models: Model[];
  deployModel: (modelId: string, version: string) => void;
  deployments: Deployment[];
  accelerators: Accelerator[];
  timeline: ResearchTimelineEvent[];
  addTimelineEvent: (event: Omit<ResearchTimelineEvent, 'id'>) => void;
  researchMemory: ResearchMemoryEntry[];
  clearResearchMemory: () => void;
  auditLogs: AuditLog[];
  // AI Company Brain & Multi-Agent Org
  aiAgents: AIAgent[];
  agentTasks: AgentTask[];
  approvalQueue: ApprovalItem[];
  handleApproveItem: (id: string) => void;
  handleRejectItem: (id: string) => void;
  growthExperiments: GrowthExperiment[];
  marketingCampaigns: MarketingCampaign[];
  freeResources: FreeResourceRadarItem[];
  researchRadar: ResearchRadarItem[];
  futureUpgrades: FutureUpgradeProposal[];
  providers: HyperComputeProvider[];
  // 1,000-AI Organization & Autonomous OS
  aiOrgState: AiOrganizationState;
  orgDepartments: DepartmentAllocationInfo[];
  detailedAgents: DetailedAIAgent[];
  orchestrationTasks: OrchestrationTaskItem[];
  ownerApprovals: OwnerApprovalRequest[];
  immutableAuditLogs: ImmutableAuditLogRecord[];
  selfOptimizations: AutonomousSelfOptimizationProposal[];
  companyKnowledgeMemory: CompanyKnowledgeMemoryItem[];
  triggerEmergencyStop: (reason?: string) => void;
  toggleGlobalAiPause: () => void;
  resumeAllAgents: () => void;
  approveOwnerRequest: (id: string, notes?: string) => void;
  rejectOwnerRequest: (id: string, reason: string) => void;
  escalateOwnerRequest: (id: string, notes: string) => void;
  modifyApprovalLimits: (id: string, newLimitUSD: number) => void;
  stepAutonomousTaskLoop: (taskId: string) => void;
  canAccessAiOrgOS: (role: UserRole) => boolean;
  // Collective Knowledge Engine
  knowledgeManifests: ModelKnowledgeManifest[];
  knowledgeGraphNodes: KnowledgeGraphNode[];
  scientificClaims: ScientificClaim[];
  addKnowledgeCandidate: (manifest: Omit<ModelKnowledgeManifest, 'id' | 'checksum' | 'createdAt'>) => void;
  // Model Family & Benchmark Lab
  modelFamily: MIIModelSpec[];
  tournamentMatches: TournamentMatch[];
  runTournamentMatch: (candidateAId: string, candidateBId: string, suite: string) => void;
  // Global Crypto & Fiat Payment Gateway
  cryptoTokens: CryptoTokenConfig[];
  cryptoSessions: CryptoPaymentSession[];
  activeCryptoSession: CryptoPaymentSession | null;
  createCryptoPaymentSession: (planId: string, tokenSymbol: string, fiatAmountINR: number) => CryptoPaymentSession;
  simulateBlockchainConfirmation: (sessionId: string) => void;
  // Expert Council & AI Auditor Force
  humanExperts: HumanExpert[];
  aiAuditors: AIAuditorSpecialist[];
  auditFindings: PlatformAuditFinding[];
  addAuditFinding: (finding: Omit<PlatformAuditFinding, 'id' | 'date'>) => void;
  // Launch Command Center
  launchPlans: LaunchPhasePlan[];
  // Checkpoints & Rollbacks
  savedCheckpoints: Checkpoint[];
  activeRestoredCheckpoint: Checkpoint | null;
  saveNotebookCheckpoint: (title?: string, description?: string) => void;
  restoreCheckpoint: (checkpointId: string, options?: { target?: 'notebook' | 'training' | 'model'; silent?: boolean }) => void;
  rollbackTrainingToCheckpoint: (step: number, loss?: number) => void;
  // Self Healing State
  selfHealingState: SelfHealingState;
  startSelfHealingDemo: () => void;
  simulateWorkerFailure: () => void;
  resetSelfHealingDemo: () => void;
  // Compute Intent state
  activeIntent: ComputeIntentPlan | null;
  setActiveIntent: (intent: ComputeIntentPlan | null) => void;
  executeIntentPlan: (intent: ComputeIntentPlan) => void;
  // Command palette
  isCommandPaletteOpen: boolean;
  setCommandPaletteOpen: (open: boolean) => void;
  // 1B-Perspective Audit & Circular Loops
  auditArchitectureStats: AuditArchitectureStats;
  circularAuditLoops: CircularAuditLoop[];
  productGaps: ProductGapItem[];
  humanSimulationPersonas: HumanSimulationPersona[];
  finalLaunchCertificate: FinalLaunchCertificateData;
  runCircularAuditLoop: (loopNumber: number) => void;
  autoFixGapItem: (gapId: string) => void;
  triggerOneBillionCapacitySweep: () => void;
  // Customer Data Firewall & DPDP Consent
  customerDataFirewallConsent: boolean;
  setCustomerDataFirewallConsent: (consent: boolean) => void;
  // Notifications
  notification: { message: string; type: 'info' | 'success' | 'warning' | 'error' } | null;
  showNotification: (message: string, type?: 'info' | 'success' | 'warning' | 'error') => void;
  // Reset demo
  resetWorkspaceData: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentView, setCurrentView] = useState<AppView>('landing');
  const [user, setUser] = useState<User>(INITIAL_USER_FREE);
  const [org] = useState<Organization>(INITIAL_ORG);
  const [project] = useState<Project>(INITIAL_PROJECT);
  const [notebook, setNotebook] = useState<Notebook>(INITIAL_NOTEBOOK);
  const [datasets, setDatasets] = useState<Dataset[]>([INITIAL_DATASET]);
  const [experiments, setExperiments] = useState<Experiment[]>(INITIAL_EXPERIMENTS);
  const [models, setModels] = useState<Model[]>(INITIAL_MODELS);
  const [deployments, setDeployments] = useState<Deployment[]>([INITIAL_DEPLOYMENT]);
  const [accelerators] = useState<Accelerator[]>(INITIAL_ACCELERATORS);
  const [timeline, setTimeline] = useState<ResearchTimelineEvent[]>(INITIAL_TIMELINE);
  const [researchMemory, setResearchMemory] = useState<ResearchMemoryEntry[]>(INITIAL_RESEARCH_MEMORY);
  const [auditLogs] = useState<AuditLog[]>(INITIAL_AUDIT_LOGS);

  // Checkpoint & Rollback Management
  const [savedCheckpoints, setSavedCheckpoints] = useState<Checkpoint[]>(() => [
    ...INITIAL_EXPERIMENTS.flatMap(e =>
      e.checkpoints.map(c => ({
        ...c,
        experimentId: e.id,
        experimentName: e.name,
        path: `bsy://checkpoints/${e.id.toLowerCase()}/step_${c.step}.pt`,
        sha256: `sha256:e8f9${c.step}a12${c.id.toLowerCase()}`,
        notes: `Automated convergence checkpoint during ${e.name}`
      }))
    ),
    {
      id: 'ckpt_manual_01',
      epoch: 3,
      step: 6000,
      loss: 0.318,
      valAccuracy: 92.4,
      timestamp: '16:50',
      sizeMB: 14200,
      isAutomatic: false,
      experimentId: 'EXP-04',
      experimentName: 'Bharat-7B 4x H100 Distributed DDP',
      path: 'bsy://checkpoints/manual_snapshot_01.pt',
      sha256: 'sha256:a1b2c3d4e5f67890123456789abcdef012345678',
      notes: 'Manual snapshot of fine-tuned Indic instruct weights prior to quantization'
    },
    {
      id: 'ckpt_manual_02',
      epoch: 2,
      step: 4000,
      loss: 0.412,
      valAccuracy: 89.2,
      timestamp: '15:35',
      sizeMB: 14200,
      isAutomatic: false,
      experimentId: 'EXP-04',
      experimentName: 'Bharat-7B 4x H100 Distributed DDP',
      path: 'bsy://checkpoints/epoch2_stable_weights.pt',
      sha256: 'sha256:9f8e7d6c5b4a3210fedcba987654321012345678',
      notes: 'Stable baseline checkpoint before learning rate decay warm-restart'
    }
  ]);
  const [activeRestoredCheckpoint, setActiveRestoredCheckpoint] = useState<Checkpoint | null>(null);

  // AI Company Brain & Ecosystem state
  const [aiAgents] = useState<AIAgent[]>(INITIAL_AI_AGENTS);
  const [agentTasks] = useState<AgentTask[]>(INITIAL_AGENT_TASKS);
  const [approvalQueue, setApprovalQueue] = useState<ApprovalItem[]>(INITIAL_APPROVAL_ITEMS);
  const [growthExperiments] = useState<GrowthExperiment[]>(INITIAL_GROWTH_EXPERIMENTS);
  const [marketingCampaigns] = useState<MarketingCampaign[]>(INITIAL_MARKETING_CAMPAIGNS);
  const [freeResources] = useState<FreeResourceRadarItem[]>(INITIAL_FREE_RESOURCE_RADAR);
  const [researchRadar] = useState<ResearchRadarItem[]>(INITIAL_RESEARCH_RADAR);
  const [futureUpgrades] = useState<FutureUpgradeProposal[]>(INITIAL_FUTURE_UPGRADES);
  const [providers] = useState<HyperComputeProvider[]>(INITIAL_HYPERCOMPUTE_PROVIDERS);

  // MII Collective AI Knowledge Engine
  const [knowledgeManifests, setKnowledgeManifests] = useState<ModelKnowledgeManifest[]>(INITIAL_KNOWLEDGE_MANIFESTS);
  const [knowledgeGraphNodes, setKnowledgeGraphNodes] = useState<KnowledgeGraphNode[]>(INITIAL_KNOWLEDGE_GRAPH_NODES);
  const [scientificClaims, setScientificClaims] = useState<ScientificClaim[]>(INITIAL_SCIENTIFIC_CLAIMS);

  const addKnowledgeCandidate = (candidate: Omit<ModelKnowledgeManifest, 'id' | 'checksum' | 'createdAt'>) => {
    // Privacy firewall check
    if (candidate.privacyClassification === 'PRIVATE' || candidate.privacyClassification === 'ORGANIZATION') {
      showNotification('Privacy Firewall: Private customer data isolated and excluded from collective learning.', 'warning');
      return;
    }
    const newManifest: ModelKnowledgeManifest = {
      ...candidate,
      id: `mkm_${Date.now()}`,
      checksum: `sha256:${Math.random().toString(16).substring(2, 10)}${Math.random().toString(16).substring(2, 10)}`,
      createdAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) + ' IST'
    };
    setKnowledgeManifests(prev => [newManifest, ...prev]);
    showNotification('Model Knowledge Manifest ingested into MII Collective Knowledge Engine.', 'success');
  };

  // MII Model Family & Benchmark Lab
  const [modelFamily] = useState<MIIModelSpec[]>(INITIAL_MII_MODEL_FAMILY);
  const [tournamentMatches, setTournamentMatches] = useState<TournamentMatch[]>(INITIAL_TOURNAMENT_MATCHES);

  const runTournamentMatch = (candidateAId: string, candidateBId: string, suite: string) => {
    const candA = modelFamily.find(m => m.id === candidateAId)?.name || candidateAId;
    const candB = modelFamily.find(m => m.id === candidateBId)?.name || candidateBId;
    const scoreA = 80 + Math.floor(Math.random() * 15);
    const scoreB = 75 + Math.floor(Math.random() * 14);
    const winner = scoreA >= scoreB ? candA : candB;

    const newMatch: TournamentMatch = {
      id: `match_${Date.now()}`,
      benchmarkSuite: suite,
      candidateA: candA,
      candidateB: candB,
      metricJudged: 'Multidimensional Accuracy & Efficiency',
      scoreA,
      scoreB,
      winner,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      hardwarePlatform: 'BHARAT H100 SXM5 80GB (Reproducible Harness)',
      dimensions: {
        accuracy: `${winner} demonstrated higher precision (${Math.max(scoreA, scoreB)} pts)`,
        latency: '24ms/token benchmarked on vLLM runtime',
        cost: 'Zero loss drift during test-time evaluation',
        safety: '100% compliant with National Indic AI Safety Standards'
      }
    };
    setTournamentMatches(prev => [newMatch, ...prev]);
    showNotification(`Benchmark tournament executed: ${winner} won on ${suite}`, 'success');
  };

  // Global Crypto & Fiat Payment Gateway
  const [cryptoTokens] = useState<CryptoTokenConfig[]>(INITIAL_CRYPTO_TOKENS);
  const [cryptoSessions, setCryptoSessions] = useState<CryptoPaymentSession[]>(INITIAL_CRYPTO_SESSIONS);
  const [activeCryptoSession, setActiveCryptoSession] = useState<CryptoPaymentSession | null>(INITIAL_CRYPTO_SESSIONS[0]);

  const createCryptoPaymentSession = (planId: string, tokenSymbol: string, fiatAmountINR: number): CryptoPaymentSession => {
    const token = cryptoTokens.find(t => t.symbol === tokenSymbol) || cryptoTokens[0];
    const discountRate = (token.discountPct || 0) / 100;
    const discountApplied = fiatAmountINR * discountRate;
    const finalINR = fiatAmountINR - discountApplied;
    // Conversion rate simulation (e.g. YGO ~ 100 INR, YUSD ~ 88 INR, YAGYX ~ 120 INR, ETH ~ 280,000 INR)
    const ratePerToken = token.symbol === 'YGO' ? 108 : token.symbol === 'YUSD' ? 88.5 : token.symbol === 'YAGYX' ? 124 : token.symbol === 'USDC' ? 88.5 : 285000;
    const cryptoAmount = Number((finalINR / ratePerToken).toFixed(4));

    const newSession: CryptoPaymentSession = {
      id: `pay_${Date.now()}`,
      planId,
      planName: planId === 'founder_monthly' ? 'MII Founder Unlimited Compute Tier' : 'HyperCompute Credit Bundle',
      fiatAmountINR,
      cryptoSymbol: token.symbol,
      cryptoAmount,
      discountAppliedINR: discountApplied,
      depositAddress: '0x8849b2fE3d88E91219b13Eb518Fa0313c4943E19',
      network: token.network,
      status: 'AWAITING_PAYMENT',
      confirmations: 0,
      requiredConfirmations: token.minConfirmations,
      expiresAt: 'In 30 mins',
      riskScore: 'LOW',
      serverVerified: false
    };

    setCryptoSessions(prev => [newSession, ...prev]);
    setActiveCryptoSession(newSession);
    showNotification(`Payment session created for ${token.symbol}. ${token.discountPct}% priority token discount applied.`, 'info');
    return newSession;
  };

  const simulateBlockchainConfirmation = (sessionId: string) => {
    setCryptoSessions(prev =>
      prev.map(s => {
        if (s.id === sessionId) {
          return {
            ...s,
            status: 'CONFIRMED',
            confirmations: s.requiredConfirmations + 2,
            txHash: `0x${Math.random().toString(16).substring(2, 10)}${Math.random().toString(16).substring(2, 10)}b8712a4b87612c78912ba091c`,
            serverVerified: true
          };
        }
        return s;
      })
    );
    if (activeCryptoSession?.id === sessionId) {
      setActiveCryptoSession(prev => prev ? {
        ...prev,
        status: 'CONFIRMED',
        confirmations: prev.requiredConfirmations + 2,
        txHash: `0x${Math.random().toString(16).substring(2, 10)}${Math.random().toString(16).substring(2, 10)}b8712a4b87612c78912ba091c`,
        serverVerified: true
      } : null);
    }
    // Grant founder entitlement if founder tier was paid
    setUser(INITIAL_USER_FOUNDER);
    showNotification('Blockchain transaction verified server-side. Founder entitlement activated!', 'success');
  };

  // Expert Council & AI Auditor Force
  const [humanExperts] = useState<HumanExpert[]>(INITIAL_HUMAN_EXPERTS);
  const [aiAuditors] = useState<AIAuditorSpecialist[]>(INITIAL_AI_AUDITORS);
  const [auditFindings, setAuditFindings] = useState<PlatformAuditFinding[]>(INITIAL_AUDIT_FINDINGS);

  const addAuditFinding = (finding: Omit<PlatformAuditFinding, 'id' | 'date'>) => {
    const newFinding: PlatformAuditFinding = {
      ...finding,
      id: `fnd_${Date.now()}`,
      date: '2026-09-18'
    };
    setAuditFindings(prev => [newFinding, ...prev]);
    showNotification(`Audit finding logged by ${finding.auditorName}.`, 'info');
  };

  // Launch Plans
  const [launchPlans] = useState<LaunchPhasePlan[]>(INITIAL_LAUNCH_PLAN);

  // 1B-Perspective Audit Architecture, Circular Loops & Product Gap Engine
  const [auditArchitectureStats, setAuditArchitectureStats] = useState<AuditArchitectureStats>(INITIAL_AUDIT_ARCHITECTURE_STATS);
  const [circularAuditLoops, setCircularAuditLoops] = useState<CircularAuditLoop[]>(INITIAL_CIRCULAR_AUDIT_LOOPS);
  const [productGaps, setProductGaps] = useState<ProductGapItem[]>(INITIAL_PRODUCT_GAPS);
  const [humanSimulationPersonas, setHumanSimulationPersonas] = useState<HumanSimulationPersona[]>(INITIAL_HUMAN_SIMULATION_PERSONAS);
  const [finalLaunchCertificate, setFinalLaunchCertificate] = useState<FinalLaunchCertificateData>(INITIAL_FINAL_LAUNCH_CERTIFICATE);
  const [customerDataFirewallConsent, setCustomerDataFirewallConsent] = useState<boolean>(false);

  const runCircularAuditLoop = (loopNumber: number) => {
    setCircularAuditLoops(prev =>
      prev.map(loop =>
        loop.loopNumber === loopNumber
          ? { ...loop, status: 'IN_PROGRESS' }
          : loop
      )
    );
    showNotification(`Running Loop ${loopNumber} circular re-audit sweep across 1B architecture...`, 'info');

    setTimeout(() => {
      setCircularAuditLoops(prev =>
        prev.map(loop =>
          loop.loopNumber === loopNumber
            ? {
                ...loop,
                status: 'COMPLETED_VERIFIED',
                verdict: 'PASS',
                blockersFound: 0,
                blockersResolved: loop.blockersResolved + (loop.blockersFound > 0 ? 1 : 0),
                evidenceSummary: `Verified Loop ${loopNumber}: Zero blockers remaining. All scientific and security constraints satisfied.`
              }
            : loop
        )
      );
      showNotification(`Loop ${loopNumber} circular audit completed with 0 blockers!`, 'success');
    }, 1200);
  };

  const autoFixGapItem = (gapId: string) => {
    const gap = productGaps.find(g => g.id === gapId);
    if (!gap) return;

    setProductGaps(prev =>
      prev.map(g =>
        g.id === gapId
          ? {
              ...g,
              status: 'AUTO_FIXED',
              validationResult: `Auto-fix verified at ${new Date().toLocaleTimeString()}: Solution implemented & passed regression tests.`
            }
          : g
      )
    );

    setCircularAuditLoops(prev =>
      prev.map(loop => ({
        ...loop,
        blockersResolved: loop.blockersResolved + 1
      }))
    );

    showNotification(`Auto-Fix verified for ${gap.id} (${gap.category}): ${gap.userPersona}`, 'success');
  };

  const triggerOneBillionCapacitySweep = () => {
    setAuditArchitectureStats(prev => ({
      ...prev,
      status: 'SWEEP_IN_PROGRESS'
    }));
    showNotification('Executing event-driven sampling sweep across 1B perspective parameter space...', 'info');

    setTimeout(() => {
      setAuditArchitectureStats(prev => ({
        ...prev,
        status: 'ONLINE_EVENT_DRIVEN',
        sampledPanelPerspectives: prev.sampledPanelPerspectives + 120,
        lastSweepTimestamp: new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' }) + ' IST'
      }));
      showNotification('1B capacity sampling sweep completed. 120 new perspective evaluations ingested.', 'success');
    }, 1500);
  };

  const handleApproveItem = (id: string) => {
    setApprovalQueue(prev =>
      prev.map(item => (item.id === id ? { ...item, status: 'APPROVED' } : item))
    );
    showNotification('Action authorized by user policy. Recorded in immutable audit log.', 'success');
  };

  const handleRejectItem = (id: string) => {
    setApprovalQueue(prev =>
      prev.map(item => (item.id === id ? { ...item, status: 'REJECTED' } : item))
    );
    showNotification('Action rejected. Agent returned to draft standby.', 'warning');
  };

  // 1,000-AI Organization & Autonomous OS State
  const [aiOrgState, setAiOrgState] = useState<AiOrganizationState>(INITIAL_AI_ORG_STATE);
  const [orgDepartments] = useState<DepartmentAllocationInfo[]>(INITIAL_DEPARTMENTS);
  const [detailedAgents, setDetailedAgents] = useState<DetailedAIAgent[]>(() => generateExactThousandAgents());
  const [orchestrationTasks, setOrchestrationTasks] = useState<OrchestrationTaskItem[]>(INITIAL_ORCHESTRATION_TASKS);
  const [ownerApprovals, setOwnerApprovals] = useState<OwnerApprovalRequest[]>(INITIAL_OWNER_APPROVALS);
  const [immutableAuditLogs, setImmutableAuditLogs] = useState<ImmutableAuditLogRecord[]>(INITIAL_AUDIT_LOG_RECORDS);
  const [selfOptimizations] = useState<AutonomousSelfOptimizationProposal[]>(INITIAL_SELF_OPTIMIZATIONS);
  const [companyKnowledgeMemory, setCompanyKnowledgeMemory] = useState<CompanyKnowledgeMemoryItem[]>(INITIAL_COMPANY_KNOWLEDGE_MEMORY);

  const canAccessAiOrgOS = (role: UserRole): boolean => {
    return role === 'Owner' || role === 'Admin';
  };

  const triggerEmergencyStop = (reason: string = 'Owner manual fail-safe trigger') => {
    const timestamp = new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' }) + ' IST';
    setAiOrgState(prev => ({
      ...prev,
      emergencyStop: true,
      emergencyStopTimestamp: timestamp,
      emergencyStopReason: reason,
      executiveOrchestratorStatus: 'EMERGENCY_STOPPED',
      currentlyActive: 0
    }));

    setDetailedAgents(prev =>
      prev.map(a => (a.current_state === 'ACTIVE' || a.current_state === 'EXECUTING' || a.current_state === 'VERIFYING'
        ? { ...a, current_state: 'PAUSED' }
        : a))
    );

    const auditEntry: ImmutableAuditLogRecord = {
      id: `log_imm_${Date.now()}`,
      timestamp,
      who: `${user.name} (${user.role})`,
      roleOrSeniority: user.role,
      what: 'TRIGGERED GLOBAL EMERGENCY STOP',
      why: reason,
      resultStatus: 'SUCCESS',
      approvalRequirementMet: true,
      costUSD: 0,
      immutableHash: `sha256:${Math.random().toString(16).substring(2)}${Math.random().toString(16).substring(2)}`
    };

    setImmutableAuditLogs(prev => [auditEntry, ...prev]);
    showNotification('GLOBAL EMERGENCY STOP ACTIVATED: All autonomous agent tasks halted. Audit log preserved.', 'error');
  };

  const toggleGlobalAiPause = () => {
    const timestamp = new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' }) + ' IST';
    setAiOrgState(prev => {
      const nextPaused = !prev.globalAiPause;
      return {
        ...prev,
        globalAiPause: nextPaused,
        executiveOrchestratorStatus: nextPaused ? 'PAUSED' : 'HEALTHY'
      };
    });

    const auditEntry: ImmutableAuditLogRecord = {
      id: `log_imm_${Date.now()}`,
      timestamp,
      who: `${user.name} (${user.role})`,
      roleOrSeniority: user.role,
      what: aiOrgState.globalAiPause ? 'RESUMED GLOBAL AI EXECUTION' : 'PAUSED GLOBAL AI EXECUTION',
      why: 'Owner manual pause toggle',
      resultStatus: 'SUCCESS',
      approvalRequirementMet: true,
      costUSD: 0,
      immutableHash: `sha256:${Math.random().toString(16).substring(2)}${Math.random().toString(16).substring(2)}`
    };

    setImmutableAuditLogs(prev => [auditEntry, ...prev]);
    showNotification(aiOrgState.globalAiPause ? 'Global AI execution resumed.' : 'Global AI execution paused.', 'info');
  };

  const resumeAllAgents = () => {
    const timestamp = new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' }) + ' IST';
    setAiOrgState(prev => ({
      ...prev,
      emergencyStop: false,
      globalAiPause: false,
      emergencyStopTimestamp: null,
      emergencyStopReason: null,
      executiveOrchestratorStatus: 'HEALTHY',
      currentlyActive: 38
    }));

    setDetailedAgents(prev =>
      prev.map((a, i) => (i < 38 && a.current_state === 'PAUSED' ? { ...a, current_state: 'ACTIVE' } : a))
    );

    const auditEntry: ImmutableAuditLogRecord = {
      id: `log_imm_${Date.now()}`,
      timestamp,
      who: `${user.name} (${user.role})`,
      roleOrSeniority: user.role,
      what: 'RESUMED ALL AGENTS AFTER EMERGENCY STOP CLEARANCE',
      why: 'Owner verified safety clearance',
      resultStatus: 'SUCCESS',
      approvalRequirementMet: true,
      costUSD: 0,
      immutableHash: `sha256:${Math.random().toString(16).substring(2)}${Math.random().toString(16).substring(2)}`
    };

    setImmutableAuditLogs(prev => [auditEntry, ...prev]);
    showNotification('Safety clearance verified. Autonomous operations resumed.', 'success');
  };

  const approveOwnerRequest = (id: string, notes?: string) => {
    if (user.role !== 'Owner') {
      showNotification('Access Denied: Only users with the Owner role can authorize compute budget spend.', 'error');
      return;
    }

    const req = ownerApprovals.find(r => r.id === id);
    if (!req) {
      showNotification('Approval request not found.', 'error');
      return;
    }
    if (req.status === 'APPROVED') {
      showNotification('Duplicate Approval Ignored: This request is already approved.', 'warning');
      return;
    }

    const timestamp = new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' }) + ' IST';
    setOwnerApprovals(prev =>
      prev.map(item => (item.id === id ? { ...item, status: 'APPROVED', escalationNotes: notes } : item))
    );

    setOrchestrationTasks(prev =>
      prev.map(t => (t.id === req.taskId ? { ...t, approvalState: 'APPROVED_BY_OWNER', status: 'IN_PROGRESS' } : t))
    );

    const auditEntry: ImmutableAuditLogRecord = {
      id: `log_imm_${Date.now()}`,
      timestamp,
      who: `${user.name} (${user.role})`,
      roleOrSeniority: user.role,
      what: `APPROVED L5 RESTRICTED OPERATION: ${req.title || id}`,
      why: req.justification || 'Owner policy clearance',
      resultStatus: 'SUCCESS',
      approvalRequirementMet: true,
      costUSD: req.estimatedCostUSD || 0,
      immutableHash: `sha256:${Math.random().toString(16).substring(2)}${Math.random().toString(16).substring(2)}`
    };

    setImmutableAuditLogs(prev => [auditEntry, ...prev]);
    showNotification(`Operation approved by Owner. Signed into immutable audit log.`, 'success');
  };

  const rejectOwnerRequest = (id: string, reason: string) => {
    const timestamp = new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' }) + ' IST';
    setOwnerApprovals(prev =>
      prev.map(item => (item.id === id ? { ...item, status: 'REJECTED', escalationNotes: reason } : item))
    );

    const req = ownerApprovals.find(r => r.id === id);
    if (req) {
      setOrchestrationTasks(prev =>
        prev.map(t => (t.id === req.taskId ? { ...t, approvalState: 'REJECTED', status: 'BLOCKED' } : t))
      );
    }

    const auditEntry: ImmutableAuditLogRecord = {
      id: `log_imm_${Date.now()}`,
      timestamp,
      who: `${user.name} (${user.role})`,
      roleOrSeniority: user.role,
      what: `REJECTED L5 OPERATION: ${req?.title || id}`,
      why: reason,
      resultStatus: 'REJECTED',
      approvalRequirementMet: true,
      costUSD: 0,
      immutableHash: `sha256:${Math.random().toString(16).substring(2)}${Math.random().toString(16).substring(2)}`
    };

    setImmutableAuditLogs(prev => [auditEntry, ...prev]);
    showNotification(`Operation rejected. Agent returned to draft standby.`, 'warning');
  };

  const escalateOwnerRequest = (id: string, notes: string) => {
    const timestamp = new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' }) + ' IST';
    setOwnerApprovals(prev =>
      prev.map(item => (item.id === id ? { ...item, status: 'ESCALATED', escalationNotes: notes } : item))
    );

    const auditEntry: ImmutableAuditLogRecord = {
      id: `log_imm_${Date.now()}`,
      timestamp,
      who: `${user.name} (${user.role})`,
      roleOrSeniority: user.role,
      what: `ESCALATED L5 OPERATION: ${id}`,
      why: notes,
      resultStatus: 'ESCALATED',
      approvalRequirementMet: false,
      costUSD: 0,
      immutableHash: `sha256:${Math.random().toString(16).substring(2)}${Math.random().toString(16).substring(2)}`
    };

    setImmutableAuditLogs(prev => [auditEntry, ...prev]);
    showNotification(`Operation escalated for external review.`, 'info');
  };

  const modifyApprovalLimits = (id: string, newLimitUSD: number) => {
    if (user.role !== 'Owner') {
      showNotification('Access Denied: Only the Owner can modify spending limits.', 'error');
      return;
    }
    if (typeof newLimitUSD !== 'number' || isNaN(newLimitUSD) || newLimitUSD < 0) {
      showNotification('Invalid Limit: Spending limit must be a non-negative number.', 'error');
      return;
    }

    const timestamp = new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' }) + ' IST';
    setOwnerApprovals(prev =>
      prev.map(item => (item.id === id ? { ...item, estimatedCostUSD: newLimitUSD, status: 'LIMITS_MODIFIED' } : item))
    );

    const auditEntry: ImmutableAuditLogRecord = {
      id: `log_imm_${Date.now()}`,
      timestamp,
      who: `${user.name} (${user.role})`,
      roleOrSeniority: user.role,
      what: `MODIFIED APPROVAL LIMITS for ${id} to $${newLimitUSD}`,
      why: 'Owner spending bounds constraint',
      resultStatus: 'SUCCESS',
      approvalRequirementMet: true,
      costUSD: 0,
      immutableHash: `sha256:${Math.random().toString(16).substring(2)}${Math.random().toString(16).substring(2)}`
    };

    setImmutableAuditLogs(prev => [auditEntry, ...prev]);
    showNotification(`Spending limit updated to $${newLimitUSD}.`, 'info');
  };

  const stepAutonomousTaskLoop = (taskId: string) => {
    const stages: TaskLifecycleStage[] = [
      'CLASSIFY',
      'DECOMPOSE',
      'SELECT_AGENTS',
      'CHECK_PERMISSIONS',
      'CHECK_BUDGET',
      'EXECUTE',
      'VERIFY',
      'ESCALATE',
      'COMMIT',
      'LEARN'
    ];

    setOrchestrationTasks(prev =>
      prev.map(task => {
        if (task.id === taskId) {
          const currentIndex = stages.indexOf(task.currentStage);
          const nextIndex = (currentIndex + 1) % stages.length;
          const nextStage = stages[nextIndex];

          // Zero-Cost Policy Enforcement: Block unapproved paid execution
          if (nextStage === 'EXECUTE') {
            const isOwnerApproved = task.approvalState === 'APPROVED_BY_OWNER';
            const routeDecision = routeTaskExecution(
              {
                id: task.id,
                taskTitle: task.title,
                category: task.department,
                department: task.department,
                estimatedCostUSD: task.estimatedCostUSD,
                requiresExternalApi: (task.estimatedCostUSD || 0) > 0,
                requiresPaidCompute: (task.estimatedCostUSD || 0) > 0,
                ownerApproved: isOwnerApproved
              },
              0 // Global spend limit is $0.00 by default
            );

            if (routeDecision.status === 'OWNER_APPROVAL_REQUIRED') {
              showNotification(
                `Zero-Cost Policy: Task "${task.title}" requires explicit Owner approval for paid compute ($${task.estimatedCostUSD}). Held at CHECK_BUDGET.`,
                'warning'
              );
              return {
                ...task,
                currentStage: 'CHECK_BUDGET',
                status: 'AWAITING_APPROVAL',
                approvalState: 'PENDING_OWNER'
              };
            }
          }

          const nextStatus = nextStage === 'LEARN' ? 'COMPLETED' : 'IN_PROGRESS';

          if (nextStage === 'LEARN') {
            const memoryItem: CompanyKnowledgeMemoryItem = {
              id: `mem_${Date.now().toString().slice(-4)}`,
              category: 'SUCCESSFUL_WORKFLOW',
              title: `Completed Lifecycle for: ${task.title}`,
              contentSummary: `Orchestrated across ${task.assignedAgentNames.join(', ')} with verification by ${task.verifierAgentId || 'Independent Agent'} at ${task.confidenceScorePct}% confidence.`,
              provenance: `Autonomous OS Task ${task.id}`,
              confidenceScorePct: task.confidenceScorePct,
              source: task.department,
              timestamp: new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' }) + ' IST',
              owner: 'MII Executive Orchestrator',
              sensitivity: 'INTERNAL_CONFIDENTIAL',
              retentionPolicy: 'PERMANENT',
              validationState: 'EMPIRICALLY_VERIFIED'
            };
            setCompanyKnowledgeMemory(m => [memoryItem, ...m]);
          }

          return {
            ...task,
            currentStage: nextStage,
            status: nextStatus
          };
        }
        return task;
      })
    );

    showNotification(`Advanced autonomous task loop to stage for ${taskId}.`, 'info');
  };

  const clearResearchMemory = () => {
    setResearchMemory([]);
    showNotification('Sovereign research memory cleared.', 'info');
  };
  const [activeIntent, setActiveIntent] = useState<ComputeIntentPlan | null>(null);
  const [isCommandPaletteOpen, setCommandPaletteOpen] = useState<boolean>(false);
  const [notification, setNotification] = useState<{ message: string; type: 'info' | 'success' | 'warning' | 'error' } | null>(null);

  // Self-Healing Demo Training Job
  const [selfHealingState, setSelfHealingState] = useState<SelfHealingState>({
    isActive: false,
    status: 'idle',
    currentStep: 0,
    totalSteps: 2000,
    currentLoss: 0.89,
    logs: [
      '[System] Self-Healing Trainer initialized. Cluster: 4x BHARAT H100 SXM5 [Demo Allocation].',
      '[Storage] Checkpoint path attached: bsy://checkpoints/self_healing_run/'
    ],
    lastCheckpointStep: 0
  });

  const showNotification = (message: string, type: 'info' | 'success' | 'warning' | 'error' = 'info') => {
    setNotification({ message, type });
    setTimeout(() => {
      setNotification(null);
    }, 4500);
  };

  // Keyboard shortcut for Cmd+K
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setCommandPaletteOpen(prev => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const toggleEntitlement = () => {
    if (user.entitlement === 'free') {
      setUser(INITIAL_USER_FOUNDER);
      showNotification('Switched to MII FOUNDER Entitlement: Unlimited Compute Credits & Priority Scheduling enabled.', 'success');
    } else {
      setUser(INITIAL_USER_FREE);
      showNotification('Switched to FREE PLAN: 2 Compute-Hours / Day quota enabled.', 'info');
    }
  };

  const addTimelineEvent = (evt: Omit<ResearchTimelineEvent, 'id'>) => {
    const newEvt: ResearchTimelineEvent = {
      ...evt,
      id: `evt_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`
    };
    setTimeline(prev => [newEvt, ...prev]);
  };

  const updateCell = (cellId: string, updates: Partial<NotebookCell>) => {
    setNotebook(prev => ({
      ...prev,
      cells: prev.cells.map(c => c.id === cellId ? { ...c, ...updates } : c)
    }));
  };

  const runCell = async (cellId: string) => {
    updateCell(cellId, { status: 'running' });
    await new Promise(res => setTimeout(res, 600));

    const cell = notebook.cells.find(c => c.id === cellId);
    let mockOutput = 'Execution successful [0.38s]';
    if (cell?.content.includes('torch')) {
      mockOutput = `PyTorch 2.5.1+cu124 | GPU Devices: 4x BHARAT H100 SXM5 (80GB HBM3)\nCUDA Memory Allocated: 14.2 GB / 80.0 GB [Simulated Environment]`;
    } else if (cell?.content.includes('load_dataset')) {
      mockOutput = `Loaded dataset: mii/bhasha-instruct-v3\nRecords: 850,000 verified prompts\nLanguages: Hindi (35%), Tamil (18%), Bengali (16%), Telugu (12%), Sanskrit (8%), Others (11%)`;
    } else if (cell?.content.includes('training_args')) {
      mockOutput = `[Compute Brain] Strategy: Balanced (DDP 4x H100)\nEstimated Step Time: 114ms | Estimated Epoch: ~42m\nCheckpoint target: bsy://checkpoints/indic7b/run_05/`;
    }

    updateCell(cellId, {
      status: 'completed',
      output: mockOutput,
      executionTimeMs: 380,
      lastExecuted: 'Just now'
    });
    showNotification('Cell executed successfully in connected compute kernel.', 'success');
  };

  const runAllCells = async () => {
    showNotification('Executing notebook on connected BHARAT H100 pod...', 'info');
    for (const cell of notebook.cells) {
      if (cell.type === 'code') {
        await runCell(cell.id);
      }
    }
    showNotification('All notebook cells executed.', 'success');
  };

  const addCell = (type: 'code' | 'markdown') => {
    const newCell: NotebookCell = {
      id: `cell_${Date.now()}`,
      type,
      content: type === 'code' ? `# Python AI Research Code\nimport torch\nprint("Cluster ready.")` : `## Research Notes\nWrite methodology and experimental hypotheses here.`,
      status: 'idle'
    };
    setNotebook(prev => ({
      ...prev,
      cells: [...prev.cells, newCell]
    }));
  };

  const deleteCell = (cellId: string) => {
    setNotebook(prev => ({
      ...prev,
      cells: prev.cells.filter(c => c.id !== cellId)
    }));
  };

  const addDatasetVersion = (datasetId: string, versionData: any) => {
    setDatasets(prev => prev.map(ds => {
      if (ds.id === datasetId) {
        return {
          ...ds,
          currentVersion: versionData.version,
          versions: [versionData, ...ds.versions]
        };
      }
      return ds;
    }));
    addTimelineEvent({
      projectId: project.id,
      type: 'dataset',
      title: `Dataset Updated (${versionData.version})`,
      description: versionData.changeSummary || 'New dataset version recorded.',
      timestamp: 'Just now',
      trustTag: 'EXECUTED'
    });
    showNotification(`Dataset version ${versionData.version} registered.`, 'success');
  };

  const addExperiment = (exp: Experiment) => {
    let finalId = exp.id;
    setExperiments(prev => {
      // Ensure unique experiment ID even if edge cases occur
      if (prev.some(e => e.id === exp.id)) {
        const existingNums = prev.map(e => {
          const match = e.id.match(/^EXP-0*(\d+)$/);
          return match ? parseInt(match[1], 10) : 0;
        });
        const nextNum = Math.max(4, ...existingNums) + 1;
        finalId = `EXP-${nextNum < 10 ? '0' : ''}${nextNum}`;
        return [{ ...exp, id: finalId }, ...prev];
      }
      return [exp, ...prev];
    });
    addTimelineEvent({
      projectId: project.id,
      type: 'experiment',
      title: `Experiment ${finalId} Created`,
      description: exp.objective,
      timestamp: 'Just now',
      trustTag: 'EXECUTED'
    });
  };

  const reproduceExperiment = (expId: string) => {
    const target = experiments.find(e => e.id === expId);
    if (!target) return;
    const repExp: Experiment = {
      ...target,
      id: `EXP-REP-${Date.now().toString().slice(-4)}-${Math.random().toString(36).slice(2, 5)}`,
      name: `Reproduced: ${target.name}`,
      status: 'queued',
      createdAt: 'Just now'
    };
    addExperiment(repExp);
    showNotification(`Reproducibility Engine: Loaded exact DNA (${target.dna.dnaHash}), seed (${target.seed}), and dependencies.`, 'success');
  };

  const forkExperiment = (expId: string) => {
    const target = experiments.find(e => e.id === expId);
    if (!target) return;
    const forkedExp: Experiment = {
      ...target,
      id: `EXP-FORK-${Date.now().toString().slice(-4)}-${Math.random().toString(36).slice(2, 5)}`,
      name: `Fork of ${target.name}`,
      status: 'queued',
      createdAt: 'Just now'
    };
    addExperiment(forkedExp);
    showNotification(`Experiment forked into workspace with inherited checkpoints and DNA.`, 'info');
  };

  const deployModel = (modelId: string, version: string) => {
    const targetModel = models.find(m => m.id === modelId);
    if (!targetModel) return;

    const newDep: Deployment = {
      id: `dep_${Date.now()}`,
      modelId: targetModel.id,
      modelName: targetModel.name,
      modelVersion: version,
      endpoint: `https://api.bharat-hypercompute.in/v1/models/${targetModel.name.toLowerCase().replace(/[^a-z0-9]/g, '-')}:generate`,
      status: 'active',
      compute: '2× BHARAT L40S vLLM Engine (Demo Endpoint)',
      apiKeyMasked: `bhc_live_${Math.random().toString(36).slice(2, 6)}••••••••••••${Math.random().toString(36).slice(2, 6)}`,
      requests24h: 1,
      avgLatencyMs: 22,
      errorRatePct: 0.0,
      createdAt: 'Just now'
    };

    setDeployments(prev => [newDep, ...prev]);
    setModels(prev => prev.map(m => m.id === modelId ? { ...m, deploymentStatus: 'active', activeDeploymentId: newDep.id } : m));
    addTimelineEvent({
      projectId: project.id,
      type: 'deployment',
      title: `Model Deployed to API (${version})`,
      description: `Production inference endpoint active at ${newDep.endpoint}`,
      timestamp: 'Just now',
      trustTag: 'EXECUTED'
    });
    showNotification(`Model → API deployment complete! Test it in the API Playground.`, 'success');
  };

  const executeIntentPlan = (intent: ComputeIntentPlan) => {
    // Check cost guardian
    if (user.entitlement === 'free' && intent.estimatedCredits > 60) {
      showNotification('Cost Guardian: Job exceeds standard free quota. Switch to Lowest Cost or Founder Entitlement.', 'warning');
      return;
    }

    // Derive the next strictly unique numeric ID based on maximum existing EXP index
    const existingNums = experiments.map(e => {
      const match = e.id.match(/^EXP-0*(\d+)$/);
      return match ? parseInt(match[1], 10) : 0;
    });
    const nextNum = Math.max(4, ...existingNums) + 1;
    const expId = `EXP-${nextNum < 10 ? '0' : ''}${nextNum}`;
    const newExp: Experiment = {
      id: expId,
      projectId: project.id,
      name: `${intent.parsedWorkload} (${intent.recommendedCompute})`,
      objective: intent.query,
      status: 'running',
      modelName: intent.modelSize || 'IndicLLM-7B',
      datasetVersion: 'v3.0.0',
      hyperparameters: {
        learningRate: 0.00002,
        batchSize: 64,
        epochs: 3,
        warmupRatio: 0.03,
        optimizer: 'AdamW',
        precision: 'bf16'
      },
      seed: 42,
      computeAlloc: {
        acceleratorId: 'acc_h100',
        acceleratorName: intent.recommendedCompute,
        count: intent.acceleratorCount,
        distributionMode: 'Data-Parallel (DDP)',
        priority: user.entitlement === 'founder' ? 'Founder Priority' : 'Standard',
        isDemo: true
      },
      metrics: {
        trainLoss: 0.74,
        valLoss: 0.78,
        perplexity: 2.18,
        tokensPerSec: 12500,
        evalAccuracy: 78.5
      },
      runtimeSeconds: 360,
      estimatedCredits: intent.estimatedCredits,
      dna: {
        dnaHash: `DNA-${Math.random().toString(36).slice(2, 10)}`,
        codeHash: 'git:main-head',
        datasetVersion: 'v3.0.0',
        modelBase: 'bharat-7b-v0.9',
        environment: 'PyTorch 2.5 + CUDA 12.4',
        seed: 42,
        computeConfig: `${intent.recommendedCompute} / DDP / bf16`
      },
      checkpoints: [
        { id: `ckpt_${expId}_1`, epoch: 1, step: 500, loss: 0.74, valAccuracy: 78.5, timestamp: 'Just now', sizeMB: 14200, isAutomatic: true }
      ],
      reproducible: true,
      isPublic: true,
      author: user.name,
      createdAt: 'Just now'
    };

    addExperiment(newExp);
    setActiveIntent({ ...intent, status: 'executed' });
    showNotification(`Job dispatched to Demo Compute Provider: ${intent.recommendedCompute}`, 'success');
  };

  // Self Healing Loop
  useEffect(() => {
    let interval: any;
    if (selfHealingState.isActive && selfHealingState.status === 'running') {
      interval = setInterval(() => {
        setSelfHealingState(prev => {
          if (prev.currentStep >= prev.totalSteps) {
            return {
              ...prev,
              status: 'completed',
              logs: [...prev.logs, '[Self-Healing Trainer] Training run completed successfully. Final loss: 0.312. Checkpoint saved.']
            };
          }
          const nextStep = prev.currentStep + 100;
          const nextLoss = Math.max(0.31, prev.currentLoss - 0.04);
          const isCheckpointStep = nextStep % 500 === 0;
          const newLogs = [...prev.logs, `[Step ${nextStep}/${prev.totalSteps}] Loss: ${nextLoss.toFixed(3)} | Token throughput: 14,210 tok/s`];
          if (isCheckpointStep) {
            newLogs.push(`[Checkpoint Guardian] Automatic checkpoint saved at Step ${nextStep} (bsy://checkpoints/step_${nextStep}.pt)`);
          }
          return {
            ...prev,
            currentStep: nextStep,
            currentLoss: nextLoss,
            logs: newLogs.slice(-12),
            lastCheckpointStep: isCheckpointStep ? nextStep : prev.lastCheckpointStep
          };
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [selfHealingState.isActive, selfHealingState.status]);

  const startSelfHealingDemo = () => {
    setSelfHealingState({
      isActive: true,
      status: 'running',
      currentStep: 100,
      totalSteps: 2000,
      currentLoss: 0.82,
      logs: [
        '[Self-Healing Trainer] Worker pool allocated: 4x BHARAT H100 (Demo)',
        '[Self-Healing Trainer] DDP synchronization verified across all 4 ranks',
        '[Self-Healing Trainer] Training started. Auto-checkpoint frequency: every 500 steps'
      ],
      lastCheckpointStep: 0
    });
    showNotification('Self-Healing training job started. Use "Simulate Failure" to test fault tolerance.', 'info');
  };

  const simulateWorkerFailure = () => {
    if (!selfHealingState.isActive || selfHealingState.status !== 'running') {
      showNotification('Start the training run first to simulate failure.', 'warning');
      return;
    }

    setSelfHealingState(prev => ({
      ...prev,
      status: 'interrupted',
      logs: [
        ...prev.logs,
        '⚠️ [CLUSTER ALERT] Worker node #2 (Rank 1) heartbeat loss detected! Hardware fault simulated.',
        '⚠️ [TRAINER] Training loop interrupted. Preserving state...',
        `🔍 [SELF-HEALING] Locating latest verified checkpoint: Step ${prev.lastCheckpointStep || 0}...`
      ].slice(-12)
    }));

    showNotification('Simulated failure triggered: Worker node #2 stopped responding.', 'error');

    // Auto-recover after 2 seconds
    setTimeout(() => {
      setSelfHealingState(prev => ({
        ...prev,
        status: 'recovering',
        logs: [
          ...prev.logs,
          '🔄 [SCHEDULER] Slicing replacement worker from spare accelerator pool...',
          `📦 [RESTORE] Restoring model weights & optimizer state from checkpoint (Step ${prev.lastCheckpointStep || 0})...`,
          '✅ [VALIDATION] Gradient sanity check passed. Re-synchronizing DDP ring...'
        ].slice(-12)
      }));

      setTimeout(() => {
        setSelfHealingState(prev => ({
          ...prev,
          status: 'running',
          currentStep: prev.lastCheckpointStep || 0,
          logs: [
            ...prev.logs,
            '🚀 [SELF-HEALING COMPLETE] Training resumed seamlessly from checkpoint! Zero data loss.'
          ].slice(-12)
        }));
        showNotification('Self-Healing Training successfully recovered and resumed!', 'success');
      }, 2200);
    }, 2000);
  };

  const resetSelfHealingDemo = () => {
    setSelfHealingState({
      isActive: false,
      status: 'idle',
      currentStep: 0,
      totalSteps: 2000,
      currentLoss: 0.89,
      logs: [
        '[System] Self-Healing Trainer ready. Attach to any multi-GPU training workload.'
      ],
      lastCheckpointStep: 0
    });
  };

  const saveNotebookCheckpoint = (title?: string, description?: string) => {
    const newId = `ckpt_manual_${Date.now().toString().slice(-4)}`;
    const newCkpt: Checkpoint = {
      id: newId,
      epoch: 3,
      step: 6500,
      loss: 0.311,
      valAccuracy: 93.1,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      sizeMB: 14200,
      isAutomatic: false,
      experimentId: 'EXP-04',
      experimentName: notebook.title || 'Research Notebook Snapshot',
      path: `bsy://checkpoints/notebook_${newId}.pt`,
      sha256: `sha256:${Math.random().toString(36).substring(2)}${Date.now().toString(16)}`,
      notes: description || 'Manual snapshot of research notebook code, state, and weights'
    };

    setSavedCheckpoints(prev => [newCkpt, ...prev]);

    addTimelineEvent({
      projectId: project.id,
      type: 'checkpoint',
      title: title || 'Manual Research Checkpoint Saved',
      description: description || `Saved ${newId} (${newCkpt.path}) with SHA-256 validation.`,
      timestamp: 'Just now',
      trustTag: 'EXECUTED'
    });

    showNotification(`Manual checkpoint ${newId} saved to ${newCkpt.path}`, 'success');
  };

  const rollbackTrainingToCheckpoint = (step: number, loss?: number) => {
    const targetLoss = loss ?? Math.max(0.31, 0.82 - (step / 2000) * 0.5);
    setSelfHealingState(prev => ({
      ...prev,
      isActive: true,
      status: 'running',
      currentStep: step,
      currentLoss: targetLoss,
      lastCheckpointStep: step,
      logs: [
        ...prev.logs,
        `🔄 [ROLLBACK] Operator rolled back cluster training to Step ${step}.`,
        `📦 [RESTORE] Restored model weights & optimizer tensors from bsy://checkpoints/step_${step}.pt`,
        `✅ [HOT-SWAP] Worker ring synchronized at Step ${step} (Loss: ${targetLoss.toFixed(3)}). Resuming DDP step loop.`
      ].slice(-12)
    }));

    addTimelineEvent({
      projectId: project.id,
      type: 'checkpoint',
      title: `Training Rolled Back to Step ${step}`,
      description: `Cluster weights reverted to Step ${step} (Loss: ${targetLoss.toFixed(3)}).`,
      timestamp: 'Just now',
      trustTag: 'EXECUTED'
    });

    showNotification(`Training successfully rolled back to Step ${step}!`, 'success');
  };

  const restoreCheckpoint = (checkpointId: string, options?: { target?: 'notebook' | 'training' | 'model'; silent?: boolean }) => {
    const ckpt = savedCheckpoints.find(c => c.id === checkpointId);
    if (!ckpt) {
      showNotification(`Checkpoint ${checkpointId} not found.`, 'error');
      return;
    }

    setActiveRestoredCheckpoint(ckpt);
    const target = options?.target || 'notebook';

    if (target === 'notebook') {
      setNotebook(prev => {
        const restoreCellId = `cell_restore_${Date.now()}`;
        const restoreCell: NotebookCell = {
          id: restoreCellId,
          type: 'code',
          content: `# [RESTORE] Model Checkpoint Weights Loaded\n# Checkpoint ID: ${ckpt.id} | Step: ${ckpt.step} | Epoch: ${ckpt.epoch}\n# Path: ${ckpt.path || `bsy://checkpoints/${ckpt.id}.pt`}\n# Loss: ${ckpt.loss} | Validation Accuracy: ${ckpt.valAccuracy}%\nimport torch\nfrom mii_hypercompute import load_checkpoint\n\nmodel_weights = load_checkpoint(\n    "${ckpt.path || `bsy://checkpoints/${ckpt.id}.pt`}",\n    verify_sha256="${ckpt.sha256 || 'sha256:verified'}"\n)\nprint("Checkpoint ${ckpt.id} (Step ${ckpt.step}) restored successfully into active PyTorch kernel.")`,
          output: `[Kernel] Loaded weights from: ${ckpt.path || `bsy://checkpoints/${ckpt.id}.pt`}\nIntegrity Check: SHA-256 Verified (${ckpt.sha256 || 'verified'})\nTensors: 14.2 GB | Loss: ${ckpt.loss} | Val Accuracy: ${ckpt.valAccuracy}%\nKernel Status: Ready for fine-tuning or evaluation`,
          status: 'completed',
          lastExecuted: 'Just now'
        };
        return {
          ...prev,
          cells: [...prev.cells, restoreCell]
        };
      });

      addTimelineEvent({
        projectId: project.id,
        type: 'checkpoint',
        title: `Checkpoint Restored to Notebook: ${ckpt.id}`,
        description: `Restored Step ${ckpt.step} weights (Loss: ${ckpt.loss}, Acc: ${ckpt.valAccuracy}%) into active notebook kernel.`,
        timestamp: 'Just now',
        trustTag: 'EXECUTED'
      });

      if (!options?.silent) {
        showNotification(`Restored checkpoint ${ckpt.id} (Step ${ckpt.step}) into research notebook kernel!`, 'success');
      }
    } else if (target === 'training') {
      rollbackTrainingToCheckpoint(ckpt.step, ckpt.loss);
    } else if (target === 'model') {
      addTimelineEvent({
        projectId: project.id,
        type: 'model',
        title: `Checkpoint Promoted for Serving: ${ckpt.id}`,
        description: `Weights from ${ckpt.path} staged for vLLM inference engine.`,
        timestamp: 'Just now',
        trustTag: 'EXECUTED'
      });
      showNotification(`Checkpoint ${ckpt.id} staged for model serving!`, 'success');
    }
  };

  const resetWorkspaceData = () => {
    setUser(INITIAL_USER_FREE);
    setNotebook(INITIAL_NOTEBOOK);
    setDatasets([INITIAL_DATASET]);
    setExperiments(INITIAL_EXPERIMENTS);
    setModels(INITIAL_MODELS);
    setDeployments([INITIAL_DEPLOYMENT]);
    setTimeline(INITIAL_TIMELINE);
    resetSelfHealingDemo();
    showNotification('Workspace data restored to verified initial state.', 'info');
  };

  return (
    <AppContext.Provider
      value={{
        currentView,
        setCurrentView,
        user,
        setUser,
        toggleEntitlement,
        org,
        project,
        notebook,
        setNotebook,
        updateCell,
        runCell,
        runAllCells,
        addCell,
        deleteCell,
        datasets,
        addDatasetVersion,
        experiments,
        addExperiment,
        reproduceExperiment,
        forkExperiment,
        models,
        deployModel,
        deployments,
        accelerators,
        timeline,
        addTimelineEvent,
        researchMemory,
        clearResearchMemory,
        auditLogs,
        aiAgents,
        agentTasks,
        approvalQueue,
        handleApproveItem,
        handleRejectItem,
        growthExperiments,
        marketingCampaigns,
        freeResources,
        researchRadar,
        futureUpgrades,
        providers,
        // 1,000-AI Organization & Autonomous OS
        aiOrgState,
        orgDepartments,
        detailedAgents,
        orchestrationTasks,
        ownerApprovals,
        immutableAuditLogs,
        selfOptimizations,
        companyKnowledgeMemory,
        triggerEmergencyStop,
        toggleGlobalAiPause,
        resumeAllAgents,
        approveOwnerRequest,
        rejectOwnerRequest,
        escalateOwnerRequest,
        modifyApprovalLimits,
        stepAutonomousTaskLoop,
        canAccessAiOrgOS,
        knowledgeManifests,
        knowledgeGraphNodes,
        scientificClaims,
        addKnowledgeCandidate,
        modelFamily,
        tournamentMatches,
        runTournamentMatch,
        cryptoTokens,
        cryptoSessions,
        activeCryptoSession,
        createCryptoPaymentSession,
        simulateBlockchainConfirmation,
        humanExperts,
        aiAuditors,
        auditFindings,
        addAuditFinding,
        launchPlans,
        auditArchitectureStats,
        circularAuditLoops,
        productGaps,
        humanSimulationPersonas,
        finalLaunchCertificate,
        runCircularAuditLoop,
        autoFixGapItem,
        triggerOneBillionCapacitySweep,
        customerDataFirewallConsent,
        setCustomerDataFirewallConsent,
        savedCheckpoints,
        activeRestoredCheckpoint,
        saveNotebookCheckpoint,
        restoreCheckpoint,
        rollbackTrainingToCheckpoint,
        selfHealingState,
        startSelfHealingDemo,
        simulateWorkerFailure,
        resetSelfHealingDemo,
        activeIntent,
        setActiveIntent,
        executeIntentPlan,
        isCommandPaletteOpen,
        setCommandPaletteOpen,
        notification,
        showNotification,
        resetWorkspaceData
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
