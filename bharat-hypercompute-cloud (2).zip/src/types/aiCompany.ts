import { TrustType } from '../components/common/TrustBadge';

// Agent Levels (L0 to L5)
export type AgentLevel = 'L0_OBSERVE' | 'L1_SUGGEST' | 'L2_DRAFT' | 'L3_REVERSIBLE' | 'L4_APPROVED_WORKFLOW' | 'L5_RESTRICTED_HIGH_IMPACT';

export type AgentDepartment =
  | 'EXECUTIVE_BRAIN'
  | 'RESEARCH_DIVISION'
  | 'COMPUTE_DIVISION'
  | 'PRODUCT_DIVISION'
  | 'SECURITY_DIVISION'
  | 'DATA_SOVEREIGNTY'
  | 'GROWTH_DIVISION'
  | 'BRAND_DIVISION'
  | 'MARKETING_DIVISION'
  | 'CUSTOMER_INTELLIGENCE'
  | 'TESTING_DIVISION'
  | 'MODEL_SERVING'
  | 'FINANCE_ECONOMICS'
  | 'DEVELOPER_PLATFORM'
  | 'REGULATORY_COMPLIANCE';

export interface AIAgent {
  id: string;
  name: string;
  role: string;
  department: AgentDepartment;
  model: 'gemini-1.5-flash' | 'gemini-1.5-pro' | 'gemini-2.0-flash' | 'local-specialized-7b';
  level: AgentLevel;
  status: 'active' | 'sleeping' | 'executing' | 'awaiting_approval';
  tasksCompleted: number;
  totalTokensUsed: number;
  estimatedCostUSD: number;
  successRatePct: number;
  permissions: string[];
  requiresApprovalFor: string[];
  lastAction: string;
  lastActive: string;
}

export interface AgentTask {
  id: string;
  agentId: string;
  agentName: string;
  department: AgentDepartment;
  title: string;
  description: string;
  status: 'pending' | 'running' | 'completed' | 'blocked' | 'requires_approval';
  trustTag: TrustType;
  outputSummary?: string;
  impactScore?: number;
  timestamp: string;
  risk: 'Low' | 'Medium' | 'High' | 'Critical';
}

export interface ApprovalItem {
  id: string;
  category: 'FINANCIAL' | 'PUBLIC_PUBLISH' | 'PRODUCTION_DEPLOY' | 'MASS_COMMUNICATION' | 'SECURITY' | 'HIGH_COST_COMPUTE';
  title: string;
  description: string;
  requestedByAgent: string;
  department: AgentDepartment;
  estimatedCost?: string;
  risk: 'Medium' | 'High' | 'Critical';
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
  timestamp: string;
  evidence: string;
  undoable: boolean;
}

export interface GrowthExperiment {
  id: string;
  name: string;
  hypothesis: string;
  variantA: string;
  variantB: string;
  channel: 'LinkedIn' | 'Research Paper Sharing' | 'Developer Community' | 'WhatsApp Business' | 'Organic Radar' | 'X/Social';
  metric: string;
  sampleSize: number;
  variantAConversionPct: number;
  variantBConversionPct: number;
  confidence: number;
  status: 'RUNNING' | 'CONCLUDED' | 'DRAFT';
  verdict?: string;
  trustTag: TrustType;
}

export interface MarketingCampaign {
  id: string;
  title: string;
  channel: 'LinkedIn' | 'WhatsApp' | 'Email' | 'Ads' | 'Organic Radar';
  audience: string;
  objective: string;
  status: 'ACTIVE' | 'DRAFT' | 'PAUSED' | 'SCHEDULED' | 'AWAITING_APPROVAL';
  budgetUSD: number;
  spentUSD: number;
  optInCompliant: boolean;
  spamProtectionActive: boolean;
  performanceMetric: string;
  metricValue: string;
  trustTag: TrustType;
}

export interface FreeResourceRadarItem {
  id: string;
  title: string;
  category: 'Model' | 'Dataset' | 'Research Paper' | 'Cloud Credit' | 'API Tool' | 'Benchmark';
  source: string;
  url: string;
  license: string;
  verificationStatus: 'Verified Open' | 'Academic Only' | 'Requires Attribution';
  confidence: number;
  dateDiscovered: string;
  summary: string;
  isSimulated: boolean;
}

export interface ResearchRadarItem {
  id: string;
  category: 'Foundation Models' | 'Compute Efficiency' | 'Sovereign Indic AI' | 'Checkpoint Systems' | 'Quantization';
  title: string;
  arxivOrSource: string;
  authors: string;
  keyFinding: string;
  impactOnBharatCloud: string;
  date: string;
  trustTag: TrustType;
}

export interface FutureUpgradeProposal {
  id: string;
  title: string;
  department: AgentDepartment;
  problem: string;
  evidence: string;
  proposal: string;
  expectedImpact: string;
  estimatedComputeCostUSD: number;
  risk: 'Low' | 'Medium' | 'High';
  status: 'Proposed' | 'Under Review' | 'Approved for Testing' | 'Shipped';
  submittedBy: string;
}

export interface HyperComputeProvider {
  id: string;
  name: string;
  tier: 'DEMO' | 'REQUIRES_PROVIDER' | 'CONNECTED_REAL' | 'REQUIRES_CREDENTIAL';
  region: string;
  accelerator: string;
  vramGB: number;
  wholesaleCostPerHour: number;
  publicMarketBenchmarkPerHour: number;
  customerPricePerHour: number;
  grossMarginPct: number;
  capacityStatus: 'AVAILABLE' | 'BUSY' | 'QUEUE' | 'OFFLINE';
  queueTimeMinutes: number;
  reliabilityPct: number;
  carbonScore: 'A+' | 'A' | 'B+';
  dataResidency: 'India (MeitY/Govt Compliant)' | 'Global / Edge';
}
