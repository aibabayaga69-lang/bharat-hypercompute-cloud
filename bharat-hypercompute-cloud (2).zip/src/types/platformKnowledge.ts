import { TrustType } from '../components/common/TrustBadge';

export type DataPrivacyClass =
  | 'PUBLIC'
  | 'ORGANIZATION'
  | 'PROJECT'
  | 'PRIVATE'
  | 'CONSENTED_GLOBAL_KNOWLEDGE'
  | 'PLATFORM_RESEARCH';

export type ScientificValidationStatus =
  | 'SUPPORTED'
  | 'PARTIALLY_SUPPORTED'
  | 'UNVERIFIED'
  | 'CONTRADICTED'
  | 'REJECTED';

export type AuditSeverity = 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW' | 'INFORMATIONAL';
export type AuditStatus = 'OPEN' | 'IN_REVIEW' | 'FIXED' | 'VERIFIED' | 'DISMISSED';

export interface ModelKnowledgeManifest {
  id: string;
  modelId: string;
  modelVersion: string;
  sourceExperimentId: string;
  privacyClassification: DataPrivacyClass;
  trainingEligibility: boolean;
  provenanceScore: number; // 0-100
  dataQualityScore: number; // 0-100
  scientificConfidence: number; // 0-100
  license: string;
  findings: string[];
  techniques: string[];
  optimizationDiscoveries: string[];
  failurePatternsAvoided: string[];
  hyperparameterOutcomes: Record<string, any>;
  evaluationSummary: Record<string, number>;
  securityAuditPassed: boolean;
  piiCheckPassed: boolean;
  benchmarkContaminationChecked: boolean;
  checksum: string;
  createdAt: string;
}

export interface KnowledgeGraphNode {
  id: string;
  type: 'Paper' | 'Dataset' | 'Experiment' | 'TrainingRun' | 'Checkpoint' | 'Model' | 'Evaluation' | 'Finding' | 'Deployment' | 'Feedback';
  title: string;
  ownerTenant: string;
  privacyClass: DataPrivacyClass;
  verified: boolean;
  scientificStatus: ScientificValidationStatus;
  metrics?: Record<string, string | number>;
  connections: string[]; // Connected Node IDs
}

export interface ScientificClaim {
  id: string;
  claim: string;
  domain: string;
  source: string;
  evidence: string;
  reproductionConfidence: number; // 0-100
  status: ScientificValidationStatus;
  independentEvaluationsCount: number;
  lastEvaluated: string;
}

export interface MIIModelSpec {
  id: string;
  name: string;
  family: 'Base' | 'Research' | 'Coding' | 'Reasoning' | 'Vision' | 'Multimodal' | 'Embedding' | 'Edge' | 'Enterprise';
  version: string;
  parameters: string;
  status: 'In Development' | 'Evaluation Tournaments' | 'Candidate Release' | 'Live Sovereign API' | 'Requires External API';
  benchmarkScores: {
    multilingualIndic: number;
    reasoningMMLU: number;
    codingHumanEval: number;
    safetyScore: number;
    mathGSM8K: number;
    efficiencyTokensPerSec: number;
  };
  knowledgeSourcesCount: number;
  safetyAuditsCompleted: number;
  knownLimitations: string[];
  pricingPer1kTokensINR: number;
  trustTag: TrustType;
}

export interface TournamentMatch {
  id: string;
  benchmarkSuite: string;
  candidateA: string;
  candidateB: string;
  metricJudged: string;
  scoreA: number;
  scoreB: number;
  winner: string;
  timestamp: string;
  hardwarePlatform: string;
  dimensions: {
    accuracy: string;
    latency: string;
    cost: string;
    safety: string;
  };
}

export interface CryptoTokenConfig {
  symbol: string; // YGO, YUSD, YAGYX, ETH, BTC, USDT, USDC
  name: string;
  network: string; // e.g. "Polygon", "Ethereum", "Arbitrum", "Solana"
  chainId: number;
  tokenAddress: string;
  decimals: number;
  isPriority: boolean;
  verifiedContract: boolean;
  explorerUrl: string;
  discountPct: number; // e.g. 20% discount for YGO/YUSD/YAGYX
  minConfirmations: number;
  status: 'LIVE_SUPPORTED' | 'TESTNET_ONLY' | 'PENDING_CONTRACT_AUDIT';
}

export interface CryptoPaymentSession {
  id: string;
  planId: string;
  planName: string;
  fiatAmountINR: number;
  cryptoSymbol: string;
  cryptoAmount: number;
  discountAppliedINR: number;
  depositAddress: string;
  network: string;
  status: 'AWAITING_PAYMENT' | 'MEMPOOL_DETECTED' | 'CONFIRMING' | 'CONFIRMED' | 'EXPIRED' | 'UNDERPAID';
  txHash?: string;
  confirmations: number;
  requiredConfirmations: number;
  expiresAt: string;
  riskScore: 'LOW' | 'MEDIUM' | 'HIGH';
  serverVerified: boolean;
}

export interface HumanExpert {
  id: string;
  name: string;
  domain: string;
  institutionOrOrg: string;
  credential: string;
  verified: boolean;
  auditsCompleted: number;
  avatarUrl?: string;
}

export interface AIAuditorSpecialist {
  id: string;
  department: string; // UI, Security, Code, Performance, Research, Pricing, Crypto, etc.
  focusArea: string;
  model: string;
  status: 'ACTIVE' | 'SLEEPING' | 'RUNNING_EVAL';
  findingsCount: number;
  lastRan: string;
}

export interface PlatformAuditFinding {
  id: string;
  category: 'MISSING' | 'WEAK' | 'BROKEN' | 'CONFUSING' | 'SLOW' | 'RISKY' | 'DUPLICATE' | 'UNNECESSARY' | 'STRONG' | 'EXPERIMENTAL';
  domain: string;
  severity: AuditSeverity;
  auditorType: 'AI_AUDITOR' | 'HUMAN_EXPERT';
  auditorName: string;
  problem: string;
  evidence: string;
  userImpact: string;
  recommendation: string;
  confidence: number;
  status: AuditStatus;
  date: string;
}

export interface LaunchPhasePlan {
  phase: 'T-30' | 'T-14' | 'T-7' | 'T-3' | 'T-1' | 'DAY_0' | 'DAY_1' | 'DAY_3' | 'DAY_7' | 'DAY_14' | 'DAY_30';
  title: string;
  objective: string;
  audience: string;
  channels: string[];
  cta: string;
  budgetINR: number;
  status: 'COMPLETED' | 'READY_ACTIVE' | 'SCHEDULED';
  ownerDepartment: string;
  keyAssets: string[];
}

export interface AuditArchitectureStats {
  totalCapacity: number; // 1,000,000,000 (mathematical parameter simulation space)
  simulationSpaceClusters: number; // 50,000 archetypes
  activeWorkers: number; // 64 event-driven auditor agents
  sampledPanelPerspectives: number; // 2,400 active sampled perspectives
  verifiedHumanFoundingCouncil: number; // IISc/IIT/Tech Council fellows
  status: 'ONLINE_EVENT_DRIVEN' | 'SWEEP_IN_PROGRESS' | 'RESTING';
  honestyStatement: string;
  lastSweepTimestamp: string;
}

export interface CircularAuditLoop {
  loopNumber: number; // 1 to 10
  title: string;
  targetPopulation: string;
  coreQuestion: string;
  focusAreas: string[];
  findingsCount: number;
  blockersFound: number;
  blockersResolved: number;
  status: 'COMPLETED_VERIFIED' | 'IN_PROGRESS' | 'ACTION_REQUIRED';
  verdict: 'PASS' | 'FIXED' | 'ATTENTION';
  evidenceSummary: string;
  auditorArchetype: string;
}

export type GapCategory =
  | 'MISSING'
  | 'WEAK'
  | 'BROKEN'
  | 'CONFUSING'
  | 'SLOW'
  | 'RISKY'
  | 'DUPLICATE'
  | 'UNNECESSARY'
  | 'STRONG'
  | 'EXPERIMENTAL';

export interface ProductGapItem {
  id: string;
  category: GapCategory;
  userPersona: string;
  problem: string;
  evidence: string;
  source: string;
  severity: 'Low' | 'Medium' | 'High' | 'Critical';
  frequencyEstimate: 'Universal' | 'Frequent' | 'Intermittent' | 'Edge Case';
  userImpact: string;
  businessImpact: string;
  securityImpact: string;
  scientificImpact: string;
  confidence: number;
  proposedSolution: string;
  implementationComplexity: 'Low' | 'Medium' | 'High';
  dependencies: string[];
  risk: string;
  status: 'DISCOVERED' | 'RESEARCHED' | 'AUTO_FIXED' | 'VERIFIED' | 'INTENTIONALLY_DEFERRED';
  validationResult: string;
  dateAudited: string;
}

export interface HumanSimulationPersona {
  id: string;
  name: string;
  role: string;
  archetype: string;
  organizationType: string;
  primaryGoal: string;
  coreQuestion: string;
  verdict: 'APPROVED_FOR_LAUNCH' | 'CONCERN_ADDRESSED' | 'BLOCKED';
  keyFinding: string;
  verifiedResolution: string;
  quote: string;
  readinessScore: number; // 0-100
}

export interface FinalLaunchCertificateData {
  certificateId: string;
  brandName: string;
  productName: string;
  officialTagline: string;
  founderAttribution: string;
  decision: 'LAUNCH READY' | 'NOT LAUNCH READY';
  realityGateAssurance: string;
  timestamp: string;
  metrics: {
    auditLoopsCompleted: number; // 10 of 10
    perspectivesSampled: number; // 2400
    issuesDiscovered: number; // 42
    issuesFixed: number; // 42
    issuesDeferred: number; // 0
    blockersRemaining: number; // 0
    evidenceConfidenceAvg: number; // 99.1%
  };
  subsystems: {
    build: 'PASS';
    runtime: 'PASS';
    security: 'PASS';
    privacyDPDP: 'PASS';
    accessibilityWCAG: 'PASS';
    mobileResponsive: 'PASS';
    performanceFPS: 'PASS';
    scientificValidation: 'PASS';
    providerIsolation: 'PASS';
  };
  trustTaxonomyVerified: boolean;
  noFalseCertificationAcknowledged: boolean;
  signer: string;
}
