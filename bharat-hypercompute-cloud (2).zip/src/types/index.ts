export type UserRole = 'Owner' | 'Admin' | 'Researcher' | 'Developer' | 'Viewer';
export type Entitlement = 'free' | 'founder' | 'pro' | 'team' | 'enterprise';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  entitlement: Entitlement;
  dailyComputeHoursUsed: number; // e.g. 1.25 hrs used out of 2.0
  dailyComputeHoursLimit: number; // 2 for free, unlimited (-1) for founder
  resetTime: string; // e.g. "04:00 UTC (in 7 hrs)"
  activeOrgId: string;
}

export interface Organization {
  id: string;
  name: string;
  tier: 'Free Tier' | 'Founder Tier' | 'Pro' | 'Enterprise';
  membersCount: number;
  monthlyBudgetCredits: number;
  usedCredits: number;
}

export interface Project {
  id: string;
  name: string;
  description: string;
  tags: string[];
  createdAt: string;
  updatedAt: string;
  notebooksCount: number;
  experimentsCount: number;
  modelsCount: number;
  deploymentsCount: number;
}

export type CellType = 'code' | 'markdown' | 'dataset' | 'model' | 'experiment' | 'metrics';

export interface NotebookCell {
  id: string;
  type: CellType;
  content: string;
  output?: string;
  status: 'idle' | 'running' | 'completed' | 'error';
  executionTimeMs?: number;
  lastExecuted?: string;
}

export interface Notebook {
  id: string;
  projectId: string;
  title: string;
  cells: NotebookCell[];
  lastSaved: string;
  runtimeState: 'idle' | 'connected' | 'busy';
  activeAccelerator?: string;
}

export interface DatasetVersion {
  version: string;
  sizeMB: number;
  recordsCount: number;
  createdAt: string;
  schemaHealth: 'Optimal' | 'Warnings' | 'Critical';
  missingValuesPct: number;
  duplicatesEstimatePct: number;
  changeSummary: string;
}

export interface Dataset {
  id: string;
  projectId: string;
  name: string;
  format: 'Parquet' | 'JSONL' | 'Arrow' | 'HuggingFace' | 'CSV';
  description: string;
  currentVersion: string;
  versions: DatasetVersion[];
  owner: string;
  createdAt: string;
}

export interface ExperimentDNA {
  dnaHash: string;
  codeHash: string;
  datasetVersion: string;
  modelBase: string;
  environment: string;
  seed: number;
  computeConfig: string;
}

export interface Checkpoint {
  id: string;
  epoch: number;
  step: number;
  loss: number;
  valAccuracy: number;
  timestamp: string;
  sizeMB: number;
  isAutomatic: boolean;
  sha256?: string;
  path?: string;
  experimentId?: string;
  experimentName?: string;
  notes?: string;
}

export type JobStatus = 'queued' | 'running' | 'completed' | 'failed' | 'paused' | 'cancelled';

export interface Accelerator {
  id: string;
  name: string;
  category: 'GPU' | 'TPU' | 'Multi-GPU' | 'Multi-TPU' | 'CPU';
  vramGB: number;
  teraflops: number;
  costPerHourCredits: number;
  provider: 'Bharat Cloud (Demo)' | 'MII SuperPod (Simulated)' | 'Connected Node (Real)';
  isDemo: boolean;
  status: 'Available' | 'Busy' | 'Queue' | 'Offline';
}

export interface ComputeAllocation {
  acceleratorId: string;
  acceleratorName: string;
  count: number;
  distributionMode: 'Single-Node' | 'Data-Parallel (DDP)' | 'Pipeline-Parallel' | 'Tensor-Parallel';
  priority: 'Standard' | 'High' | 'Founder Priority';
  isDemo: boolean;
}

export interface Experiment {
  id: string;
  projectId: string;
  name: string;
  objective: string;
  status: JobStatus;
  modelName: string;
  datasetVersion: string;
  hyperparameters: {
    learningRate: number;
    batchSize: number;
    epochs: number;
    warmupRatio: number;
    optimizer: string;
    precision: 'bf16' | 'fp16' | 'fp32';
  };
  seed: number;
  computeAlloc: ComputeAllocation;
  metrics: {
    trainLoss: number;
    valLoss: number;
    perplexity: number;
    tokensPerSec: number;
    evalAccuracy?: number;
  };
  runtimeSeconds: number;
  estimatedCredits: number;
  dna: ExperimentDNA;
  checkpoints: Checkpoint[];
  reproducible: boolean;
  isPublic: boolean;
  author: string;
  createdAt: string;
}

export interface ModelVersion {
  version: string;
  experimentId: string;
  datasetVersion: string;
  paramsCount: string;
  sizeMB: number;
  framework: 'PyTorch' | 'JAX' | 'vLLM' | 'ONNX';
  status: 'Registered' | 'Validated' | 'Deployed' | 'Archived';
  metrics: {
    valLoss: number;
    accuracy: number;
    latencyP95Ms: number;
  };
  createdAt: string;
}

export interface Model {
  id: string;
  projectId: string;
  name: string;
  currentVersion: string;
  versions: ModelVersion[];
  description: string;
  deploymentStatus: 'undeployed' | 'deploying' | 'active' | 'archived';
  activeDeploymentId?: string;
  owner: string;
}

export interface Deployment {
  id: string;
  modelId: string;
  modelName: string;
  modelVersion: string;
  endpoint: string;
  status: 'active' | 'scaling' | 'idle';
  compute: string;
  apiKeyMasked: string;
  requests24h: number;
  avgLatencyMs: number;
  errorRatePct: number;
  createdAt: string;
}

export interface ComputeIntentPlan {
  query: string;
  parsedWorkload: string;
  modelSize: string;
  recommendedCompute: string;
  acceleratorCount: number;
  estimatedRuntime: string;
  estimatedCredits: number;
  costImpactPct: number;
  reason: string;
  strategy: 'auto' | 'fastest' | 'balanced' | 'lowest_cost' | 'custom';
  status: 'suggested' | 'approved' | 'executed';
}

export interface ResearchTimelineEvent {
  id: string;
  projectId: string;
  type: 'project' | 'notebook' | 'dataset' | 'compute' | 'experiment' | 'checkpoint' | 'model' | 'deployment' | 'self_healing';
  title: string;
  description: string;
  timestamp: string;
  trustTag: 'REAL' | 'DEMO' | 'ESTIMATED' | 'SUGGESTED' | 'APPROVED' | 'EXECUTED' | 'BLOCKED' | 'REQUIRES_PROVIDER';
}

export interface ResearchMemoryEntry {
  id: string;
  projectId: string;
  key: string;
  finding: string;
  evidence: string;
  confidence: 'High' | 'Empirical' | 'Inconclusive';
  timestamp: string;
}

export interface AuditLog {
  id: string;
  action: string;
  actor: string;
  target: string;
  timestamp: string;
  ip: string;
}
