export type OrgDepartmentId =
  | 'dept_executive_orchestration'     // 20
  | 'dept_aiml_research'               // 80
  | 'dept_software_engineering'        // 120
  | 'dept_compute_hpc_infra'           // 100
  | 'dept_security_privacy_trust'      // 90
  | 'dept_qa_testing_reliability'      // 80
  | 'dept_product_ux_ui'               // 80
  | 'dept_marketing_advertising_growth'// 80
  | 'dept_brand_creative_media'        // 50
  | 'dept_customer_intel_support'      // 50
  | 'dept_finance_pricing_economics'   // 50
  | 'dept_payments_crypto_blockchain'  // 50
  | 'dept_data_knowledge_collective'   // 50
  | 'dept_scientific_validation'       // 50
  | 'dept_legal_compliance_governance'; // 30

export type AgentSeniority =
  | 'Executive Orchestrator'
  | 'Department Director'
  | 'Principal Fellow'
  | 'Lead Specialist'
  | 'Senior Specialist'
  | 'Specialist'
  | 'Associate Specialist';

export type AgentState =
  | 'ACTIVE'
  | 'SLEEPING'
  | 'QUEUED'
  | 'BLOCKED'
  | 'AWAITING_APPROVAL'
  | 'EXECUTING'
  | 'VERIFYING'
  | 'COMPLETED'
  | 'FAILED'
  | 'PAUSED'
  | 'DISABLED';

export type GovernanceLevel =
  | 'L0_OBSERVE'
  | 'L1_SUGGEST'
  | 'L2_DRAFT'
  | 'L3_REVERSIBLE_EXECUTION'
  | 'L4_APPROVED_WORKFLOW'
  | 'L5_RESTRICTED_HIGH_IMPACT';

export type DataAccessLevel =
  | 'L0_PUBLIC'
  | 'L1_INTERNAL_METRICS'
  | 'L2_ANONYMIZED_RESEARCH'
  | 'L3_TENANT_ISOLATED'
  | 'L4_RESTRICTED_VAULT';

export type RiskLevel = 'Low' | 'Medium' | 'High' | 'Critical';

export type ApprovalRequirement =
  | 'AUTOMATIC'
  | 'SUPERVISOR_VERIFY'
  | 'DIRECTOR_APPROVAL'
  | 'OWNER_ADMIN_REQUIRED';

export interface AgentAuditHistoryEntry {
  timestamp: string;
  action: string;
  toolUsed?: string;
  outcome: string;
  costUSD: number;
  verifier?: string;
}

export interface DetailedAIAgent {
  agent_id: string;
  department: OrgDepartmentId;
  role: string;
  specialty: string;
  seniority: AgentSeniority;
  capabilities: string[];
  model_provider: string; // e.g. "Gemini 2.0 Flash / Google AI" or "Gemini 1.5 Pro / Google AI"
  tools_allowed: string[];
  data_access_level: DataAccessLevel;
  permissions: string[];
  budget: number; // Max per-task budget USD
  token_budget: number; // Max tokens per call
  task_types: string[];
  risk_level: RiskLevel;
  approval_requirement: ApprovalRequirement;
  governance_level: GovernanceLevel;
  current_state: AgentState;
  current_task: string | null;
  parent_agent: string | null; // e.g. "agent_exec_orchestrator" or Director
  dependencies: string[];
  performance: {
    evalScorePct: number;
    rating: number; // 1-5
  };
  success_rate: number; // %
  average_latency: number; // ms
  estimated_cost: number; // USD spent to date
  last_active_timestamp: string;
  audit_history: AgentAuditHistoryEntry[];
}

export interface DepartmentAllocationInfo {
  id: OrgDepartmentId;
  number: number;
  name: string;
  shortName: string;
  targetCapacity: number;
  activeCount: number;
  sleepingCount: number;
  queuedCount: number;
  blockedCount: number;
  directorName: string;
  directorAgentId: string;
  purpose: string;
  keySpecialties: string[];
  budgetCapUSD: number;
  spentUSD: number;
}

export type TaskLifecycleStage =
  | 'CLASSIFY'
  | 'DECOMPOSE'
  | 'SELECT_AGENTS'
  | 'CHECK_PERMISSIONS'
  | 'CHECK_BUDGET'
  | 'EXECUTE'
  | 'VERIFY'
  | 'ESCALATE'
  | 'COMMIT'
  | 'LEARN';

export interface OrchestrationTaskItem {
  id: string;
  title: string;
  description: string;
  department: OrgDepartmentId;
  requester: string; // e.g. "Executive Orchestrator" or "Owner"
  assignedAgentIds: string[];
  assignedAgentNames: string[];
  currentStage: TaskLifecycleStage;
  status: 'PENDING' | 'IN_PROGRESS' | 'AWAITING_APPROVAL' | 'VERIFYING' | 'COMPLETED' | 'BLOCKED' | 'FAILED';
  riskLevel: RiskLevel;
  governanceLevel: GovernanceLevel;
  estimatedCostUSD: number;
  actualCostUSD: number;
  tokensConsumed: number;
  modelUsed: string;
  subtasks: {
    id: string;
    title: string;
    assignedTo: string;
    status: 'DONE' | 'DOING' | 'QUEUED';
  }[];
  verificationNotes?: string;
  verifierAgentId?: string;
  confidenceScorePct: number;
  approvalState: 'NONE_NEEDED' | 'PENDING_OWNER' | 'APPROVED_BY_OWNER' | 'REJECTED';
  startedAt: string;
  completedAt?: string;
  provenanceCitations: string[];
}

export interface OwnerApprovalRequest {
  id: string;
  taskId: string;
  title: string;
  category:
    | 'FINANCIAL_SPEND'
    | 'AD_SPEND'
    | 'PAYMENT_CONFIG'
    | 'WALLET_OPERATIONS'
    | 'PRODUCTION_DELETION'
    | 'SECURITY_POLICY'
    | 'AUTHENTICATION_CHANGE'
    | 'CREDENTIAL_CHANGE'
    | 'CUSTOMER_DATA_ACCESS'
    | 'CROSS_TENANT_ACCESS'
    | 'LEGAL_COMMITMENT'
    | 'PUBLIC_RELEASE'
    | 'DESTRUCTIVE_INFRA'
    | 'MASS_COMMUNICATION'
    | 'IRREVERSIBLE_MIGRATION';
  description: string;
  requestedByAgentId: string;
  requestedByAgentName: string;
  department: OrgDepartmentId;
  estimatedCostUSD?: number;
  risk: RiskLevel;
  status: 'PENDING' | 'APPROVED' | 'REJECTED' | 'ESCALATED' | 'LIMITS_MODIFIED';
  timestamp: string;
  justification: string;
  reversible: boolean;
  blastRadius: string;
  escalationNotes?: string;
}

export interface ImmutableAuditLogRecord {
  id: string;
  timestamp: string;
  who: string; // User or Agent
  roleOrSeniority: string;
  what: string; // Action description
  why: string; // Objective / reason
  agentId?: string;
  taskId?: string;
  toolUsed?: string;
  dataAccessed?: string;
  resultStatus: 'SUCCESS' | 'BLOCKED' | 'FAILED' | 'ESCALATED' | 'REJECTED';
  approvalRequirementMet: boolean;
  costUSD: number;
  immutableHash: string;
}

export interface AutonomousSelfOptimizationProposal {
  id: string;
  type:
    | 'AGENT_RETIREMENT'
    | 'AGENT_SPECIALIZATION'
    | 'MODEL_ROUTING_CHANGE'
    | 'WORKLOAD_REDISTRIBUTION'
    | 'BUDGET_ADJUSTMENT'
    | 'DEPARTMENT_SCALING'
    | 'PROMPT_OPTIMIZATION'
    | 'WORKFLOW_SIMPLIFICATION';
  title: string;
  department: OrgDepartmentId;
  currentBottleneck: string;
  proposedChange: string;
  projectedCostSavingsPct: number;
  projectedLatencyImprovementPct: number;
  risk: RiskLevel;
  governanceStatus: 'L1_PROPOSED' | 'APPROVED_READY' | 'REJECTED';
  submittedBy: string;
  timestamp: string;
}

export interface CompanyKnowledgeMemoryItem {
  id: string;
  category:
    | 'APPROVED_DECISION'
    | 'VERIFIED_RESEARCH'
    | 'PRODUCT_FINDING'
    | 'BENCHMARK_RESULT'
    | 'ENGINEERING_LESSON'
    | 'INCIDENT_LESSON'
    | 'MARKETING_EXPERIMENT'
    | 'CUSTOMER_FEEDBACK'
    | 'SUCCESSFUL_WORKFLOW';
  title: string;
  contentSummary: string;
  provenance: string;
  confidenceScorePct: number;
  source: string;
  timestamp: string;
  owner: string;
  sensitivity: 'INTERNAL_CONFIDENTIAL' | 'ANONYMIZED_PUBLIC' | 'RESTRICTED_GOVERNANCE';
  retentionPolicy: 'PERMANENT' | '1_YEAR' | '3_YEARS';
  validationState: 'EMPIRICALLY_VERIFIED' | 'PEER_REVIEWED' | 'SUPERVISOR_SIGNED';
}

export interface AiOrganizationState {
  totalCapacity: 1000;
  currentlyActive: number;
  currentlySleeping: number;
  currentlyQueued: number;
  currentlyBlocked: number;
  currentlyAwaitingApproval: number;
  dailyCostUSD: number;
  monthlyCostUSD: number;
  globalAiPause: boolean;
  emergencyStop: boolean;
  emergencyStopTimestamp: string | null;
  emergencyStopReason: string | null;
  executiveOrchestratorStatus: 'HEALTHY' | 'PAUSED' | 'CONSTRAINED_BY_BUDGET' | 'EMERGENCY_STOPPED';
}
