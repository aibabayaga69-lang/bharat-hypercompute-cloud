/**
 * BHARAT HYPERCOMPUTE CLOUD — MII
 * FREE RESOURCE ROUTER & ZERO-COST EXECUTION ENGINE
 *
 * Strict Execution Priority:
 * 1. DETERMINISTIC           (rule-based heuristics, AST checks, lookup tables, regex)
 * 2. CACHE                   (hash-based in-memory / session memoization)
 * 3. LOCAL                   (local client CPU / memory computation)
 * 4. BROWSER_WASM            (in-browser WebAssembly parsers / tokenizers)
 * 5. OPEN_SOURCE             (permissive open-source models / algorithms)
 * 6. FREE_RESOURCE           (verified sovereign grants, free tier quotas, academic credits)
 * 7. APPROVED_EXISTING_CREDIT (pre-approved credits explicitly authorized by Owner)
 * 8. PAID_RESOURCE           (BLOCKED BY DEFAULT. Requires explicit Owner authorization)
 *
 * MANDATORY POLICY:
 * - Default external spend: ₹0 / $0.
 * - Paid resources are BLOCKED by default.
 * - Failed free routes MUST NEVER silently convert to a paid request.
 * - A paid fallback MUST become: OWNER_APPROVAL_REQUIRED.
 * - Sleeping and inactive agents generate exactly 0 external API calls.
 */

export type RoutingTier =
  | 'DETERMINISTIC'
  | 'CACHE'
  | 'LOCAL'
  | 'BROWSER_WASM'
  | 'OPEN_SOURCE'
  | 'FREE_RESOURCE'
  | 'APPROVED_EXISTING_CREDIT'
  | 'PAID_RESOURCE';

export type RouteStatus =
  | 'ROUTED_FREE'
  | 'ROUTED_CREDIT'
  | 'BLOCKED_ZERO_COST'
  | 'OWNER_APPROVAL_REQUIRED';

export interface RouteRequest {
  id: string;
  taskTitle: string;
  category?: string;
  department?: string;
  estimatedCostUSD?: number;
  deterministicEligible?: boolean;
  cacheKey?: string;
  canUseLocal?: boolean;
  canUseBrowserWasm?: boolean;
  openSourceAvailable?: boolean;
  freeTierAvailable?: boolean;
  approvedCreditUSD?: number;
  requiresExternalApi?: boolean;
  requiresPaidCompute?: boolean;
  ownerApproved?: boolean;
  isSleepingAgent?: boolean;
  isInactiveAgent?: boolean;
}

export interface RouteDecision {
  requestId: string;
  tier: RoutingTier;
  status: RouteStatus;
  allowedCostUSD: number;
  reason: string;
  isZeroCost: boolean;
  routeTrace: string[];
}

export interface ZeroCostAudit {
  totalRequestsRouted: number;
  zeroCostRequests: number;
  blockedPaidAttempts: number;
  approvedPaidExecutions: number;
  totalSpendUSD: number;
  complianceRatePct: number;
}

// Global Zero-Cost state ledger
let globalZeroCostAudit: ZeroCostAudit = {
  totalRequestsRouted: 0,
  zeroCostRequests: 0,
  blockedPaidAttempts: 0,
  approvedPaidExecutions: 0,
  totalSpendUSD: 0,
  complianceRatePct: 100
};

// In-memory memoization cache for CACHE tier
const routeMemoryCache = new Map<string, { timestamp: number; result: string }>();

/**
 * Evaluates and routes a task through the strict Zero-Cost Hierarchy.
 *
 * @param request The task routing request
 * @param globalSpendLimitUSD The current global spend limit set by the Owner (defaults to $0.00)
 */
export function routeTaskExecution(
  request: RouteRequest,
  globalSpendLimitUSD: number = 0
): RouteDecision {
  globalZeroCostAudit.totalRequestsRouted++;
  const trace: string[] = [];

  // INVARIANT 1: Sleeping or inactive agents generate zero external calls
  if (request.isSleepingAgent || request.isInactiveAgent) {
    trace.push('[INVARIANT_PASS] Agent is sleeping/inactive. Zero external model calls permitted.');
    globalZeroCostAudit.zeroCostRequests++;
    return {
      requestId: request.id,
      tier: 'DETERMINISTIC',
      status: 'ROUTED_FREE',
      allowedCostUSD: 0,
      reason: 'Agent is dormant/sleeping. Zero external compute consumed.',
      isZeroCost: true,
      routeTrace: trace
    };
  }

  // TIER 1: DETERMINISTIC
  trace.push('Evaluating Tier 1: DETERMINISTIC');
  if (request.deterministicEligible !== false && isDeterministicCandidate(request)) {
    trace.push('[MATCH] Handled by deterministic heuristics/AST/lookup table. Cost: $0.00');
    globalZeroCostAudit.zeroCostRequests++;
    return {
      requestId: request.id,
      tier: 'DETERMINISTIC',
      status: 'ROUTED_FREE',
      allowedCostUSD: 0,
      reason: 'Resolved deterministically without calling any LLM or paid API.',
      isZeroCost: true,
      routeTrace: trace
    };
  }

  // TIER 2: CACHE
  trace.push('Evaluating Tier 2: CACHE');
  if (request.cacheKey && routeMemoryCache.has(request.cacheKey)) {
    trace.push(`[MATCH] Cache hit for key "${request.cacheKey}". Cost: $0.00`);
    globalZeroCostAudit.zeroCostRequests++;
    return {
      requestId: request.id,
      tier: 'CACHE',
      status: 'ROUTED_FREE',
      allowedCostUSD: 0,
      reason: 'Served from verified in-memory execution cache.',
      isZeroCost: true,
      routeTrace: trace
    };
  }

  // TIER 3: LOCAL
  trace.push('Evaluating Tier 3: LOCAL');
  if (request.canUseLocal !== false && isLocalExecutionCandidate(request)) {
    trace.push('[MATCH] Handled by client-side JavaScript engine/local memory. Cost: $0.00');
    globalZeroCostAudit.zeroCostRequests++;
    return {
      requestId: request.id,
      tier: 'LOCAL',
      status: 'ROUTED_FREE',
      allowedCostUSD: 0,
      reason: 'Executed locally in browser runtime.',
      isZeroCost: true,
      routeTrace: trace
    };
  }

  // TIER 4: BROWSER_WASM
  trace.push('Evaluating Tier 4: BROWSER_WASM');
  if (request.canUseBrowserWasm) {
    trace.push('[MATCH] Handled by client WebAssembly binary. Cost: $0.00');
    globalZeroCostAudit.zeroCostRequests++;
    return {
      requestId: request.id,
      tier: 'BROWSER_WASM',
      status: 'ROUTED_FREE',
      allowedCostUSD: 0,
      reason: 'Computed via client-side WebAssembly parser/kernel.',
      isZeroCost: true,
      routeTrace: trace
    };
  }

  // TIER 5: OPEN_SOURCE
  trace.push('Evaluating Tier 5: OPEN_SOURCE');
  if (request.openSourceAvailable) {
    trace.push('[MATCH] Handled via permissive open-source library/endpoint. Cost: $0.00');
    globalZeroCostAudit.zeroCostRequests++;
    return {
      requestId: request.id,
      tier: 'OPEN_SOURCE',
      status: 'ROUTED_FREE',
      allowedCostUSD: 0,
      reason: 'Dispatched to verified open-source permissive resource.',
      isZeroCost: true,
      routeTrace: trace
    };
  }

  // TIER 6: FREE_RESOURCE
  trace.push('Evaluating Tier 6: FREE_RESOURCE');
  if (request.freeTierAvailable !== false) {
    trace.push('[MATCH] Covered by sovereign academic/free-tier quota. Cost: $0.00');
    globalZeroCostAudit.zeroCostRequests++;
    return {
      requestId: request.id,
      tier: 'FREE_RESOURCE',
      status: 'ROUTED_FREE',
      allowedCostUSD: 0,
      reason: 'Allocated within zero-cost educational/sovereign research quota.',
      isZeroCost: true,
      routeTrace: trace
    };
  }

  // TIER 7: APPROVED_EXISTING_CREDIT
  trace.push('Evaluating Tier 7: APPROVED_EXISTING_CREDIT');
  const reqCost = request.estimatedCostUSD || 0;
  if (request.approvedCreditUSD && request.approvedCreditUSD >= reqCost && reqCost > 0) {
    trace.push(`[MATCH] Covered by pre-approved credit balance ($${request.approvedCreditUSD}).`);
    globalZeroCostAudit.approvedPaidExecutions++;
    return {
      requestId: request.id,
      tier: 'APPROVED_EXISTING_CREDIT',
      status: 'ROUTED_CREDIT',
      allowedCostUSD: reqCost,
      reason: `Authorized against pre-approved credit balance of $${request.approvedCreditUSD}.`,
      isZeroCost: false,
      routeTrace: trace
    };
  }

  // TIER 8: PAID_RESOURCE — BLOCKED BY DEFAULT
  trace.push('Evaluating Tier 8: PAID_RESOURCE');
  trace.push('[SECURITY_ALERT] Free tiers exhausted or paid external compute requested.');

  // Check if owner explicitly approved this exact task AND global spend limit accommodates it
  if (request.ownerApproved && globalSpendLimitUSD >= reqCost && reqCost > 0) {
    trace.push(`[AUTHORIZED] Explicit Owner approval granted for $${reqCost}.`);
    globalZeroCostAudit.approvedPaidExecutions++;
    globalZeroCostAudit.totalSpendUSD += reqCost;
    return {
      requestId: request.id,
      tier: 'PAID_RESOURCE',
      status: 'ROUTED_CREDIT',
      allowedCostUSD: reqCost,
      reason: `Owner explicitly authorized paid compute for $${reqCost}.`,
      isZeroCost: false,
      routeTrace: trace
    };
  }

  // MANDATORY POLICY: NEVER silently convert a failed free route into a paid request.
  // Must become: OWNER_APPROVAL_REQUIRED with execution BLOCKED.
  trace.push('[BLOCKED] Global spend limit is $0.00 or Owner approval not present. Execution BLOCKED.');
  globalZeroCostAudit.blockedPaidAttempts++;

  return {
    requestId: request.id,
    tier: 'PAID_RESOURCE',
    status: 'OWNER_APPROVAL_REQUIRED',
    allowedCostUSD: 0,
    reason: 'Zero-Cost Default Policy: Paid resource blocked. Requires explicit Owner sign-off in Approval Center.',
    isZeroCost: true,
    routeTrace: trace
  };
}

/**
 * Checks if a task can be satisfied deterministically without calling external models.
 */
function isDeterministicCandidate(request: RouteRequest): boolean {
  const title = (request.taskTitle || '').toLowerCase();
  const cat = (request.category || '').toLowerCase();

  const deterministicKeywords = [
    'audit',
    'validate',
    'format',
    'regex',
    'hash',
    'checksum',
    'compare',
    'diff',
    'count',
    'sort',
    'filter',
    'schema',
    'inspect',
    'rbac',
    'permission',
    'budget',
    'classify',
    'verify'
  ];

  return (
    deterministicKeywords.some(kw => title.includes(kw) || cat.includes(kw)) ||
    !request.requiresExternalApi
  );
}

/**
 * Checks if a task can be evaluated purely in local JavaScript state.
 */
function isLocalExecutionCandidate(request: RouteRequest): boolean {
  return (
    !request.requiresPaidCompute &&
    !request.requiresExternalApi &&
    (request.estimatedCostUSD === undefined || request.estimatedCostUSD === 0)
  );
}

/**
 * Registers an item into the in-memory memoization cache.
 */
export function registerRouteCache(key: string, result: string): void {
  routeMemoryCache.set(key, { timestamp: Date.now(), result });
}

/**
 * Retrieves the strict routing priority array.
 */
export function getRoutingPriorityOrder(): RoutingTier[] {
  return [
    'DETERMINISTIC',
    'CACHE',
    'LOCAL',
    'BROWSER_WASM',
    'OPEN_SOURCE',
    'FREE_RESOURCE',
    'APPROVED_EXISTING_CREDIT',
    'PAID_RESOURCE'
  ];
}

/**
 * Returns current audit statistics on zero-cost routing.
 */
export function getZeroCostAuditSummary(): ZeroCostAudit {
  const total = globalZeroCostAudit.totalRequestsRouted || 1;
  const compliant = total - globalZeroCostAudit.blockedPaidAttempts;
  globalZeroCostAudit.complianceRatePct = Math.round((compliant / total) * 100);
  return { ...globalZeroCostAudit };
}
