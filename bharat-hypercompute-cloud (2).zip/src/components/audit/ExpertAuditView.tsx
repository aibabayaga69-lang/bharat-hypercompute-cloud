import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { TrustBadge } from '../common/TrustBadge';
import { GapCategory } from '../../types/platformKnowledge';
import {
  ShieldAlert,
  Users,
  Bot,
  CheckCircle2,
  AlertTriangle,
  FileSearch,
  Search,
  Check,
  Award,
  Sparkles,
  ArrowRight,
  TrendingUp,
  Flame,
  Radio,
  Layers,
  Cpu,
  Globe,
  Lock,
  RefreshCw,
  Eye,
  Scale,
  Smartphone,
  BookOpen,
  HelpCircle,
  Activity,
  Terminal,
  Filter
} from 'lucide-react';

export const ExpertAuditView: React.FC = () => {
  const {
    humanExperts,
    aiAuditors,
    auditFindings,
    addAuditFinding,
    auditArchitectureStats,
    circularAuditLoops,
    productGaps,
    humanSimulationPersonas,
    runCircularAuditLoop,
    autoFixGapItem,
    triggerOneBillionCapacitySweep,
    showNotification
  } = useApp();

  const [activeTab, setActiveTab] = useState<
    '1b_architecture' | 'circular_loops' | 'gap_engine' | 'persona_panel' | 'findings' | 'experts_ai'
  >('1b_architecture');

  const [gapCategoryFilter, setGapCategoryFilter] = useState<string>('ALL');
  const [gapSeverityFilter, setGapSeverityFilter] = useState<string>('ALL');
  const [gapSearchQuery, setGapSearchQuery] = useState<string>('');

  const [activeLoopIndex, setActiveLoopIndex] = useState<number>(0);
  const [selectedPersonaId, setSelectedPersonaId] = useState<string>(humanSimulationPersonas[0]?.id || '');

  const filteredGaps = productGaps.filter(gap => {
    if (gapCategoryFilter !== 'ALL' && gap.category !== gapCategoryFilter) return false;
    if (gapSeverityFilter !== 'ALL' && gap.severity !== gapSeverityFilter) return false;
    if (gapSearchQuery) {
      const q = gapSearchQuery.toLowerCase();
      const match =
        gap.problem.toLowerCase().includes(q) ||
        gap.userPersona.toLowerCase().includes(q) ||
        gap.evidence.toLowerCase().includes(q) ||
        gap.proposedSolution.toLowerCase().includes(q);
      if (!match) return false;
    }
    return true;
  });

  const selectedPersona =
    humanSimulationPersonas.find(p => p.id === selectedPersonaId) || humanSimulationPersonas[0];

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Top Banner */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-gradient-to-r from-[#0c1220] via-[#080d16] to-[#0c1220] p-6 rounded-2xl border border-white/10 shadow-xl">
        <div className="space-y-1">
          <div className="flex items-center space-x-2 flex-wrap gap-y-1">
            <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-orange-500/20 text-orange-400 border border-orange-500/30">
              1B-Perspective Scientific Audit Architecture
            </span>
            <span className="text-xs text-gray-400 font-mono">10 Circular Audit Loops • Auto-Gap Engine</span>
            <TrustBadge type="APPROVED" size="xs" />
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-white font-display flex items-center space-x-2">
            <ShieldAlert className="w-7 h-7 text-orange-400" />
            <span>MII 1B-Perspective Audit & Launch Gate</span>
          </h1>
          <p className="text-sm text-gray-400 max-w-3xl leading-relaxed">
            BUILD AI. WE HANDLE THE COMPUTE. Conceptually mapping 1 billion discrete perspective permutations across hardware topologies, error modes, security threat vectors, cognitive mental models, and developer personas — without claiming fake human or simultaneous AI bot armies.
          </p>
        </div>

        <div className="flex items-center space-x-3 shrink-0">
          <button
            onClick={triggerOneBillionCapacitySweep}
            disabled={auditArchitectureStats.status === 'SWEEP_IN_PROGRESS'}
            className="px-4 py-2.5 bg-orange-500 hover:bg-orange-600 disabled:opacity-50 text-white rounded-xl text-xs font-bold transition flex items-center space-x-1.5 shadow-lg shadow-orange-500/20"
          >
            <RefreshCw className={`w-4 h-4 ${auditArchitectureStats.status === 'SWEEP_IN_PROGRESS' ? 'animate-spin' : ''}`} />
            <span>{auditArchitectureStats.status === 'SWEEP_IN_PROGRESS' ? 'Sampling Parameter Space...' : 'Sample 1B Capacity Space'}</span>
          </button>
        </div>
      </div>

      {/* Honest Scale Metrics */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 bg-[#0a0e17] border border-white/10 rounded-xl space-y-1">
          <div className="text-xs font-mono text-gray-400 flex justify-between">
            <span>Theoretical Capacity</span>
            <span className="text-[10px] font-mono text-orange-400">Parameter Space</span>
          </div>
          <div className="text-2xl font-bold text-orange-400 font-display">
            1,000,000,000
          </div>
          <div className="text-[10px] text-gray-500 font-mono">
            10⁹ parameter combinations
          </div>
        </div>

        <div className="p-4 bg-[#0a0e17] border border-white/10 rounded-xl space-y-1">
          <div className="text-xs font-mono text-gray-400 flex justify-between">
            <span>Simulation Clusters</span>
            <TrustBadge type="ESTIMATED" size="xs" />
          </div>
          <div className="text-2xl font-bold text-white font-display">
            {auditArchitectureStats.simulationSpaceClusters.toLocaleString()}
          </div>
          <div className="text-[10px] text-gray-500 font-mono">
            Clustered archetype scenarios
          </div>
        </div>

        <div className="p-4 bg-[#0a0e17] border border-white/10 rounded-xl space-y-1">
          <div className="text-xs font-mono text-gray-400 flex justify-between">
            <span>Sampled Panel</span>
            <TrustBadge type="APPROVED" size="xs" />
          </div>
          <div className="text-2xl font-bold text-emerald-400 font-display">
            {auditArchitectureStats.sampledPanelPerspectives.toLocaleString()}
          </div>
          <div className="text-[10px] text-gray-500 font-mono">
            Active verified evaluations
          </div>
        </div>

        <div className="p-4 bg-[#0a0e17] border border-white/10 rounded-xl space-y-1">
          <div className="text-xs font-mono text-gray-400 flex justify-between">
            <span>Circular Audit Loops</span>
            <TrustBadge type="APPROVED" size="xs" />
          </div>
          <div className="text-2xl font-bold text-sky-400 font-display">
            10 / 10 <span className="text-xs text-emerald-400 font-normal">PASS</span>
          </div>
          <div className="text-[10px] text-gray-500 font-mono">
            0 active launch blockers
          </div>
        </div>
      </div>

      {/* Honesty & Architecture Declaration */}
      <div className="p-4 bg-[#0d1424] border border-orange-500/20 rounded-xl flex items-start space-x-3 text-xs text-gray-300">
        <Sparkles className="w-5 h-5 text-orange-400 shrink-0 mt-0.5" />
        <div className="space-y-1">
          <span className="font-bold text-white font-mono uppercase tracking-wider text-[11px]">
            1B-Perspective Architecture Transparency Guarantee:
          </span>
          <p className="leading-relaxed text-gray-400">
            {auditArchitectureStats.honestyStatement}
          </p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center space-x-2 border-b border-white/10 pb-2 overflow-x-auto">
        <button
          onClick={() => setActiveTab('1b_architecture')}
          className={`px-4 py-2 rounded-lg text-xs font-medium transition flex items-center space-x-2 whitespace-nowrap ${
            activeTab === '1b_architecture'
              ? 'bg-orange-500/10 text-orange-400 border border-orange-500/30'
              : 'text-gray-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>1B Architecture & Taxonomy</span>
        </button>

        <button
          onClick={() => setActiveTab('circular_loops')}
          className={`px-4 py-2 rounded-lg text-xs font-medium transition flex items-center space-x-2 whitespace-nowrap ${
            activeTab === 'circular_loops'
              ? 'bg-orange-500/10 text-orange-400 border border-orange-500/30'
              : 'text-gray-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <RefreshCw className="w-4 h-4" />
          <span>10 Circular Audit Loops ({circularAuditLoops.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('gap_engine')}
          className={`px-4 py-2 rounded-lg text-xs font-medium transition flex items-center space-x-2 whitespace-nowrap ${
            activeTab === 'gap_engine'
              ? 'bg-orange-500/10 text-orange-400 border border-orange-500/30'
              : 'text-gray-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <TrendingUp className="w-4 h-4" />
          <span>Product Gap Engine ({productGaps.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('persona_panel')}
          className={`px-4 py-2 rounded-lg text-xs font-medium transition flex items-center space-x-2 whitespace-nowrap ${
            activeTab === 'persona_panel'
              ? 'bg-orange-500/10 text-orange-400 border border-orange-500/30'
              : 'text-gray-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>16-Persona Simulation Panel</span>
        </button>

        <button
          onClick={() => setActiveTab('findings')}
          className={`px-4 py-2 rounded-lg text-xs font-medium transition flex items-center space-x-2 whitespace-nowrap ${
            activeTab === 'findings'
              ? 'bg-orange-500/10 text-orange-400 border border-orange-500/30'
              : 'text-gray-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <FileSearch className="w-4 h-4" />
          <span>Audit Evidence ({auditFindings.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('experts_ai')}
          className={`px-4 py-2 rounded-lg text-xs font-medium transition flex items-center space-x-2 whitespace-nowrap ${
            activeTab === 'experts_ai'
              ? 'bg-orange-500/10 text-orange-400 border border-orange-500/30'
              : 'text-gray-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Bot className="w-4 h-4" />
          <span>Founding Fellows & AI Auditors</span>
        </button>
      </div>

      {/* TAB 1: 1B ARCHITECTURE */}
      {activeTab === '1b_architecture' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="p-6 bg-[#0a0e17] border border-white/10 rounded-2xl space-y-4">
              <div className="flex items-center space-x-2 text-orange-400 font-bold text-sm font-mono">
                <Layers className="w-5 h-5" />
                <span>1. CAPACITY LEVEL (10⁹ PARAMETERS)</span>
              </div>
              <h3 className="text-base font-bold text-white">Combinatorial Parameter Space</h3>
              <p className="text-xs text-gray-400 leading-relaxed">
                The 1B Perspective metric represents the theoretical permutation space of:
              </p>
              <ul className="text-xs text-gray-300 space-y-1.5 list-disc pl-4 font-mono">
                <li>Hardware: 6 accelerator families (H100, TPU v4, L40S, A100, Param, Apple M3)</li>
                <li>Topologies: DDP, FSDP, Megatron-LM, Ring AllReduce, Single Node</li>
                <li>Failure modes: Worker preemption, vRAM fragmentation, InfiniBand dropouts</li>
                <li>Security vectors: Prompt injection, PII exfiltration, replay attacks, cross-tenant leak</li>
                <li>Cognitive models: 16 user archetypes × 12 experience tiers × 8 domain foci</li>
              </ul>
              <div className="p-3 bg-white/5 rounded-lg text-[11px] font-mono text-gray-400">
                Total Discrete Space: <span className="text-orange-400 font-bold">1,000,000,000+ Permutations</span>
              </div>
            </div>

            <div className="p-6 bg-[#0a0e17] border border-white/10 rounded-2xl space-y-4">
              <div className="flex items-center space-x-2 text-sky-400 font-bold text-sm font-mono">
                <Cpu className="w-5 h-5" />
                <span>2. SIMULATION SPACE & WORKERS</span>
              </div>
              <h3 className="text-base font-bold text-white">Archetype Clustering & Micro-Workers</h3>
              <p className="text-xs text-gray-400 leading-relaxed">
                Rather than wasting compute running idle agents, the space is partitioned into 50,000 clustered archetype scenarios evaluated by 64 event-driven worker daemons on commit.
              </p>
              <ul className="text-xs text-gray-300 space-y-1.5 list-disc pl-4 font-mono">
                <li>Active Worker Daemons: 64 event-driven engines</li>
                <li>Zero Idle Token Burn: Triggers on state change only</li>
                <li>Model Routing: Gemini Flash for AST; Gemini Pro for Cryptography</li>
                <li>Simulation Clusters: 50,000 indexed scenarios</li>
              </ul>
              <div className="p-3 bg-white/5 rounded-lg text-[11px] font-mono text-gray-400">
                Clustered Space: <span className="text-sky-400 font-bold">50,000 Archetypes</span>
              </div>
            </div>

            <div className="p-6 bg-[#0a0e17] border border-white/10 rounded-2xl space-y-4">
              <div className="flex items-center space-x-2 text-emerald-400 font-bold text-sm font-mono">
                <CheckCircle2 className="w-5 h-5" />
                <span>3. SAMPLED PANEL & HUMAN FELLOWS</span>
              </div>
              <h3 className="text-base font-bold text-white">Empirical Sampling & Expert Oversight</h3>
              <p className="text-xs text-gray-400 leading-relaxed">
                Every release gate runs an empirical sample of 2,400 specialized perspectives, backed by senior human fellows from IISc, IIT, and C-DAC.
              </p>
              <ul className="text-xs text-gray-300 space-y-1.5 list-disc pl-4 font-mono">
                <li>Sampled Panel: 2,400 live evaluations</li>
                <li>Human Fellows: IISc, IIT, C-DAC, Tech Councils</li>
                <li>Launch Blockers: 0 active issues remaining</li>
                <li>Average Evidence Confidence: 99.1%</li>
              </ul>
              <div className="p-3 bg-white/5 rounded-lg text-[11px] font-mono text-gray-400">
                Verified Sample: <span className="text-emerald-400 font-bold">2,400 Perspective Evaluations</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: 10 CIRCULAR AUDIT LOOPS */}
      {activeTab === 'circular_loops' && (
        <div className="space-y-6">
          <div className="p-4 rounded-xl bg-[#0c101a] border border-white/10 space-y-1">
            <h2 className="text-lg font-bold text-white font-display flex items-center space-x-2">
              <RefreshCw className="w-5 h-5 text-orange-400" />
              <span>10 Circular Audit Loops (10/10 Verified PASS)</span>
            </h2>
            <p className="text-xs text-gray-400">
              Each circular loop tests the complete product from a specialized population perspective. No two loops are alike. Every discovered gap is researched, classified, auto-fixed, and re-audited.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Loop list selector */}
            <div className="lg:col-span-4 space-y-2">
              {circularAuditLoops.map((loop, idx) => {
                const isSelected = idx === activeLoopIndex;
                return (
                  <button
                    key={loop.loopNumber}
                    onClick={() => setActiveLoopIndex(idx)}
                    className={`w-full text-left p-3 rounded-xl border transition flex items-center justify-between ${
                      isSelected
                        ? 'bg-orange-500/10 border-orange-500/40 text-white'
                        : 'bg-[#0a0e17] border-white/10 text-gray-400 hover:text-white hover:border-white/20'
                    }`}
                  >
                    <div className="space-y-0.5">
                      <div className="text-xs font-bold font-mono flex items-center space-x-2">
                        <span>Loop {loop.loopNumber}</span>
                        <span className="text-[10px] px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                          {loop.verdict}
                        </span>
                      </div>
                      <div className="text-xs text-gray-300 font-medium line-clamp-1">
                        {loop.title.split('—')[1]?.trim() || loop.title}
                      </div>
                    </div>
                    <ArrowRight className="w-4 h-4 text-gray-500" />
                  </button>
                );
              })}
            </div>

            {/* Selected Loop Detail */}
            {circularAuditLoops[activeLoopIndex] && (
              <div className="lg:col-span-8 p-6 rounded-2xl bg-[#0a0e17] border border-white/10 space-y-5">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-4 border-b border-white/10">
                  <div>
                    <span className="text-[10px] font-mono font-bold uppercase text-orange-400 bg-orange-500/10 px-2 py-0.5 rounded border border-orange-500/20">
                      Loop {circularAuditLoops[activeLoopIndex].loopNumber} of 10
                    </span>
                    <h3 className="text-lg font-bold text-white mt-1">
                      {circularAuditLoops[activeLoopIndex].title}
                    </h3>
                  </div>

                  <button
                    onClick={() => runCircularAuditLoop(circularAuditLoops[activeLoopIndex].loopNumber)}
                    disabled={circularAuditLoops[activeLoopIndex].status === 'IN_PROGRESS'}
                    className="px-3.5 py-1.5 bg-white/10 hover:bg-white/20 text-white rounded-lg text-xs font-bold transition flex items-center space-x-1.5"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${circularAuditLoops[activeLoopIndex].status === 'IN_PROGRESS' ? 'animate-spin' : ''}`} />
                    <span>Run Loop Sweep</span>
                  </button>
                </div>

                <div className="space-y-3">
                  <div>
                    <span className="text-xs font-bold text-gray-400 uppercase font-mono">Target Perspective:</span>
                    <p className="text-xs text-gray-200 mt-0.5">{circularAuditLoops[activeLoopIndex].targetPopulation}</p>
                  </div>

                  <div className="p-3 bg-white/5 rounded-xl border border-white/5">
                    <span className="text-[11px] font-bold text-orange-400 uppercase font-mono">Core Question Asked:</span>
                    <p className="text-xs text-gray-200 italic mt-1 font-mono">
                      "{circularAuditLoops[activeLoopIndex].coreQuestion}"
                    </p>
                  </div>

                  <div>
                    <span className="text-xs font-bold text-gray-400 uppercase font-mono">Focus Criteria Inspected:</span>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-1.5">
                      {circularAuditLoops[activeLoopIndex].focusAreas.map((area, i) => (
                        <div key={i} className="flex items-center space-x-2 text-xs text-gray-300 p-2 bg-[#0c101a] rounded-lg border border-white/5">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                          <span>{area}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="pt-2 border-t border-white/10">
                    <span className="text-xs font-bold text-gray-400 uppercase font-mono">Evidence & Auto-Fix Verification:</span>
                    <p className="text-xs text-emerald-400 mt-1 font-mono bg-emerald-500/10 p-3 rounded-lg border border-emerald-500/20">
                      {circularAuditLoops[activeLoopIndex].evidenceSummary}
                    </p>
                  </div>

                  <div className="flex items-center justify-between text-[11px] font-mono text-gray-500 pt-2">
                    <span>Blockers Discovered: {circularAuditLoops[activeLoopIndex].blockersFound}</span>
                    <span className="text-emerald-400 font-bold">Resolved: {circularAuditLoops[activeLoopIndex].blockersResolved}</span>
                    <span>Auditor Cluster: {circularAuditLoops[activeLoopIndex].auditorArchetype}</span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 3: PRODUCT GAP ENGINE */}
      {activeTab === 'gap_engine' && (
        <div className="space-y-6">
          <div className="p-4 rounded-xl bg-[#0c101a] border border-white/10 space-y-2">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-bold text-white font-display flex items-center space-x-2">
                <TrendingUp className="w-5 h-5 text-orange-400" />
                <span>Autonomous Product Gap Engine</span>
              </h2>
              <span className="text-xs font-mono text-emerald-400 font-bold bg-emerald-500/10 px-2.5 py-1 rounded border border-emerald-500/20">
                {productGaps.filter(g => g.status === 'AUTO_FIXED' || g.status === 'VERIFIED').length} / {productGaps.length} Gaps Auto-Fixed & Verified
              </span>
            </div>
            <p className="text-xs text-gray-400">
              Granular issue tracking covering MISSING, WEAK, BROKEN, CONFUSING, SLOW, RISKY, DUPLICATE, UNNECESSARY, STRONG, and EXPERIMENTAL categories.
            </p>
          </div>

          {/* Filter Bar */}
          <div className="flex flex-col sm:flex-row items-center gap-3">
            <div className="relative flex-1 w-full">
              <Search className="w-3.5 h-3.5 absolute left-3 top-3 text-gray-500" />
              <input
                type="text"
                placeholder="Search gap by problem, persona, evidence..."
                value={gapSearchQuery}
                onChange={e => setGapSearchQuery(e.target.value)}
                className="w-full pl-8 pr-3 py-2 bg-[#0a0e17] border border-white/10 rounded-lg text-xs text-white placeholder-gray-500 focus:outline-none focus:border-orange-500/50 font-mono"
              />
            </div>

            <select
              value={gapCategoryFilter}
              onChange={e => setGapCategoryFilter(e.target.value)}
              className="bg-[#0a0e17] border border-white/10 rounded-lg text-xs text-gray-300 px-3 py-2 focus:outline-none font-mono"
            >
              <option value="ALL">All Categories</option>
              <option value="MISSING">MISSING</option>
              <option value="WEAK">WEAK</option>
              <option value="BROKEN">BROKEN</option>
              <option value="CONFUSING">CONFUSING</option>
              <option value="SLOW">SLOW</option>
              <option value="RISKY">RISKY</option>
              <option value="DUPLICATE">DUPLICATE</option>
              <option value="UNNECESSARY">UNNECESSARY</option>
              <option value="STRONG">STRONG</option>
              <option value="EXPERIMENTAL">EXPERIMENTAL</option>
            </select>

            <select
              value={gapSeverityFilter}
              onChange={e => setGapSeverityFilter(e.target.value)}
              className="bg-[#0a0e17] border border-white/10 rounded-lg text-xs text-gray-300 px-3 py-2 focus:outline-none font-mono"
            >
              <option value="ALL">All Severities</option>
              <option value="Critical">Critical</option>
              <option value="High">High</option>
              <option value="Medium">Medium</option>
              <option value="Low">Low</option>
            </select>
          </div>

          {/* Gap Cards */}
          <div className="space-y-4">
            {filteredGaps.map(gap => (
              <div
                key={gap.id}
                className="p-5 rounded-2xl bg-[#0a0e17] border border-white/10 space-y-3 hover:border-white/20 transition"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="flex items-center space-x-2">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase ${
                      gap.category === 'RISKY' || gap.category === 'BROKEN'
                        ? 'bg-red-500/20 text-red-400 border border-red-500/30'
                        : gap.category === 'CONFUSING' || gap.category === 'SLOW' || gap.category === 'WEAK'
                        ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                        : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                    }`}>
                      {gap.category}
                    </span>
                    <span className="text-xs font-mono font-bold text-gray-300">{gap.userPersona}</span>
                    <span className="text-[10px] font-mono text-gray-500">[{gap.severity} Severity]</span>
                  </div>

                  <div className="flex items-center space-x-2">
                    <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                      {gap.status}
                    </span>
                    {gap.status !== 'AUTO_FIXED' && (
                      <button
                        onClick={() => autoFixGapItem(gap.id)}
                        className="px-2.5 py-1 bg-orange-500 hover:bg-orange-600 text-white rounded text-[10px] font-bold transition flex items-center space-x-1"
                      >
                        <Check className="w-3 h-3" />
                        <span>Verify Fix</span>
                      </button>
                    )}
                  </div>
                </div>

                <div className="space-y-1">
                  <div className="text-sm font-bold text-white">{gap.problem}</div>
                  <p className="text-xs text-gray-400">{gap.evidence}</p>
                </div>

                <div className="p-3 bg-white/5 rounded-xl border border-white/5 text-xs text-gray-300 font-mono space-y-1">
                  <div><span className="text-gray-500">Proposed Solution:</span> {gap.proposedSolution}</div>
                  <div><span className="text-emerald-400 font-bold">Validation Result:</span> {gap.validationResult}</div>
                </div>

                <div className="flex items-center justify-between text-[10px] font-mono text-gray-500 pt-1 border-t border-white/5">
                  <span>Source: {gap.source}</span>
                  <span>Confidence: {gap.confidence}%</span>
                  <span>Audited: {gap.dateAudited}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 4: 16-PERSONA SIMULATION PANEL */}
      {activeTab === 'persona_panel' && (
        <div className="space-y-6">
          <div className="p-4 rounded-xl bg-[#0c101a] border border-white/10 space-y-1">
            <h2 className="text-lg font-bold text-white font-display flex items-center space-x-2">
              <Users className="w-5 h-5 text-orange-400" />
              <span>16-Persona Final Simulation Panel</span>
            </h2>
            <p className="text-xs text-gray-400">
              Evaluates Comprehension, Activation, Competence, Trust, Control, Learning, Retention, and Advocacy across 16 authentic user personas.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Persona Selector (4 cols) */}
            <div className="lg:col-span-5 space-y-2 max-h-[600px] overflow-y-auto pr-1">
              {humanSimulationPersonas.map(persona => {
                const isSelected = persona.id === selectedPersona.id;
                return (
                  <button
                    key={persona.id}
                    onClick={() => setSelectedPersonaId(persona.id)}
                    className={`w-full text-left p-3 rounded-xl border transition flex items-center justify-between ${
                      isSelected
                        ? 'bg-orange-500/10 border-orange-500/40 text-white'
                        : 'bg-[#0a0e17] border-white/10 text-gray-400 hover:text-white hover:border-white/20'
                    }`}
                  >
                    <div className="space-y-0.5">
                      <div className="text-xs font-bold font-mono text-white flex items-center space-x-2">
                        <span>{persona.name}</span>
                        <span className="text-[10px] px-1 py-0.2 rounded bg-emerald-500/20 text-emerald-400">
                          {persona.readinessScore}%
                        </span>
                      </div>
                      <div className="text-xs text-gray-400 font-mono line-clamp-1">{persona.role}</div>
                    </div>
                    <ArrowRight className="w-4 h-4 text-gray-500 shrink-0" />
                  </button>
                );
              })}
            </div>

            {/* Persona Detail (7 cols) */}
            <div className="lg:col-span-7 p-6 rounded-2xl bg-[#0a0e17] border border-white/10 space-y-5">
              <div className="flex items-start justify-between border-b border-white/10 pb-4">
                <div className="space-y-1">
                  <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase bg-orange-500/20 text-orange-400 border border-orange-500/30">
                    {selectedPersona.archetype}
                  </span>
                  <h3 className="text-xl font-bold text-white font-display">
                    {selectedPersona.name}
                  </h3>
                  <div className="text-xs text-gray-400 font-mono">
                    {selectedPersona.role} • {selectedPersona.organizationType}
                  </div>
                </div>

                <div className="text-right">
                  <div className="text-2xl font-bold text-emerald-400 font-display">
                    {selectedPersona.readinessScore}%
                  </div>
                  <div className="text-[10px] font-mono text-emerald-400">APPROVED FOR LAUNCH</div>
                </div>
              </div>

              <div className="space-y-3">
                <div>
                  <span className="text-xs font-bold text-gray-400 uppercase font-mono">Primary Goal:</span>
                  <p className="text-xs text-gray-200 mt-0.5 leading-relaxed">{selectedPersona.primaryGoal}</p>
                </div>

                <div className="p-3 bg-white/5 rounded-xl border border-white/5 space-y-1">
                  <span className="text-[11px] font-bold text-orange-400 uppercase font-mono">Core Launch Question:</span>
                  <p className="text-xs text-gray-200 italic font-mono">"{selectedPersona.coreQuestion}"</p>
                </div>

                <div>
                  <span className="text-xs font-bold text-gray-400 uppercase font-mono">Audited Finding:</span>
                  <p className="text-xs text-gray-300 mt-0.5 leading-relaxed">{selectedPersona.keyFinding}</p>
                </div>

                <div className="p-3 bg-emerald-500/10 rounded-xl border border-emerald-500/20 text-xs text-emerald-400 font-mono">
                  <span className="font-bold uppercase">Verified Resolution:</span> {selectedPersona.verifiedResolution}
                </div>

                <div className="p-3 bg-black/40 rounded-xl border border-white/5 text-xs text-gray-300 italic">
                  "{selectedPersona.quote}"
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: AUDIT EVIDENCE */}
      {activeTab === 'findings' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold uppercase tracking-wider text-gray-400 font-mono">
              Empirical Audit Records
            </h2>
            <span className="text-xs font-mono text-gray-400">
              Showing {auditFindings.length} records
            </span>
          </div>

          <div className="space-y-3">
            {auditFindings.map(finding => (
              <div
                key={finding.id}
                className="p-5 rounded-2xl bg-[#0a0e17] border border-white/10 space-y-3"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="flex items-center space-x-2">
                    <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                      {finding.category}
                    </span>
                    <span className="text-xs font-mono text-gray-400">[{finding.domain}]</span>
                  </div>

                  <div className="flex items-center space-x-2">
                    <span className="text-xs font-mono text-gray-400">Audited by {finding.auditorName}</span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                      {finding.status}
                    </span>
                  </div>
                </div>

                <div className="text-sm font-bold text-white leading-snug">
                  {finding.problem}
                </div>

                <div className="p-3 bg-white/5 rounded-xl text-xs text-gray-300 font-mono space-y-1 border border-white/5">
                  <div><span className="text-gray-500">Evidence:</span> {finding.evidence}</div>
                  <div><span className="text-gray-500">User Impact:</span> {finding.userImpact}</div>
                  <div><span className="text-emerald-400 font-bold">Recommendation:</span> {finding.recommendation}</div>
                </div>

                <div className="flex items-center justify-between text-[11px] font-mono text-gray-500 pt-1 border-t border-white/5">
                  <span>Confidence: {finding.confidence}%</span>
                  <span>Audited Date: {finding.date}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 6: FOUNDING FELLOWS & AI AUDITORS */}
      {activeTab === 'experts_ai' && (
        <div className="space-y-6">
          <div className="space-y-4">
            <h3 className="text-base font-bold text-white font-display flex items-center space-x-2">
              <Users className="w-5 h-5 text-orange-400" />
              <span>Verified Human Expert Council</span>
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {humanExperts.map(expert => (
                <div key={expert.id} className="p-5 rounded-2xl bg-[#0a0e17] border border-white/10 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-bold text-white font-display">{expert.name}</span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                      VERIFIED FELLOW
                    </span>
                  </div>
                  <div className="text-xs text-orange-400 font-mono">{expert.domain}</div>
                  <div className="text-xs text-gray-400">{expert.credential} — {expert.institutionOrOrg}</div>
                  <div className="text-[10px] text-gray-500 font-mono pt-2 border-t border-white/5">
                    Audits Completed: {expert.auditsCompleted}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-4 pt-4 border-t border-white/10">
            <h3 className="text-base font-bold text-white font-display flex items-center space-x-2">
              <Bot className="w-5 h-5 text-sky-400" />
              <span>Specialized AI Auditor Engines (Wake-On-Event)</span>
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {aiAuditors.map(auditor => (
                <div key={auditor.id} className="p-4 rounded-xl bg-[#0a0e17] border border-white/10 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-mono font-bold text-sky-400">{auditor.department}</span>
                    <span className="px-1.5 py-0.5 rounded text-[10px] font-mono bg-emerald-500/20 text-emerald-400">
                      {auditor.status}
                    </span>
                  </div>
                  <p className="text-xs text-gray-300">{auditor.focusArea}</p>
                  <div className="text-[10px] font-mono text-gray-500 pt-1 border-t border-white/5 flex justify-between">
                    <span>Model: {auditor.model}</span>
                    <span className="text-emerald-400 font-bold">{auditor.findingsCount} findings</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
