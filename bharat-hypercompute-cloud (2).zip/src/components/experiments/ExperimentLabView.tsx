import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { TrustBadge } from '../common/TrustBadge';
import { Experiment } from '../../types';
import { ExperimentDNA3DGraph } from './ExperimentDNA3DGraph';
import {
  FlaskConical,
  GitFork,
  RotateCcw,
  Dna,
  CheckCircle2,
  Filter,
  ArrowUpDown,
  Search,
  Sliders,
  Sparkles,
  Layers,
  ChevronRight,
  Bookmark,
  Share2,
  History,
  HardDrive,
  ShieldCheck,
  Check,
  ExternalLink,
  FileCode,
  ArrowRight
} from 'lucide-react';

export const ExperimentLabView: React.FC = () => {
  const {
    experiments,
    reproduceExperiment,
    forkExperiment,
    showNotification,
    savedCheckpoints,
    activeRestoredCheckpoint,
    restoreCheckpoint,
    rollbackTrainingToCheckpoint,
    setCurrentView
  } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedExpIds, setSelectedExpIds] = useState<string[]>([experiments[0]?.id, experiments[1]?.id].filter(Boolean));
  const [activeTab, setActiveTab] = useState<'matrix' | '3d_dna' | 'dna_compare' | 'checkpoints'>('matrix');
  const [checkpointFilter, setCheckpointFilter] = useState<'all' | 'auto' | 'manual'>('all');

  const filteredExperiments = experiments.filter(e =>
    e.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    e.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
    e.modelName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const toggleSelectExp = (id: string) => {
    if (selectedExpIds.includes(id)) {
      setSelectedExpIds(selectedExpIds.filter(x => x !== id));
    } else {
      if (selectedExpIds.length >= 3) {
        setSelectedExpIds([...selectedExpIds.slice(1), id]);
      } else {
        setSelectedExpIds([...selectedExpIds, id]);
      }
    }
  };

  const selectedList = experiments.filter(e => selectedExpIds.includes(e.id));

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center space-x-2">
            <span className="text-xs font-mono text-orange-400 font-bold uppercase tracking-wider">
              SCIENTIFIC RIGOR
            </span>
            <span className="text-gray-600">/</span>
            <span className="text-xs font-mono text-gray-400">{experiments.length} Runs Tracked</span>
            <TrustBadge type="EXECUTED" size="xs" />
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white font-display flex items-center space-x-2">
            <FlaskConical className="w-7 h-7 text-indigo-400" />
            <span>Experiment Lab & DNA Matrix</span>
          </h1>
          <p className="text-xs sm:text-sm text-gray-400">
            Cryptographically fingerprinted Experiment DNA. Compare hyperparameters, loss curves, and credit consumption with full 1-click reproducibility.
          </p>
        </div>

        {/* Action Tabs */}
        <div className="flex items-center rounded-xl bg-[#0a0e17] p-1 border border-white/10 text-xs font-mono">
          <button
            onClick={() => setActiveTab('matrix')}
            className={`px-3 py-1.5 rounded-lg transition ${
              activeTab === 'matrix' ? 'bg-orange-500/20 text-orange-300 font-bold border border-orange-500/30' : 'text-gray-400 hover:text-white'
            }`}
          >
            Experiment Matrix
          </button>
          <button
            onClick={() => setActiveTab('3d_dna')}
            className={`px-3 py-1.5 rounded-lg transition flex items-center space-x-1 ${
              activeTab === '3d_dna' ? 'bg-orange-500/20 text-orange-300 font-bold border border-orange-500/30' : 'text-gray-400 hover:text-white'
            }`}
          >
            <Dna className="w-3.5 h-3.5" />
            <span>3D Experiment DNA Helix</span>
          </button>
          <button
            onClick={() => setActiveTab('dna_compare')}
            className={`px-3 py-1.5 rounded-lg transition ${
              activeTab === 'dna_compare' ? 'bg-orange-500/20 text-orange-300 font-bold border border-orange-500/30' : 'text-gray-400 hover:text-white'
            }`}
          >
            DNA Diff ({selectedList.length})
          </button>
          <button
            onClick={() => setActiveTab('checkpoints')}
            className={`px-3 py-1.5 rounded-lg transition flex items-center space-x-1.5 ${
              activeTab === 'checkpoints' ? 'bg-sky-500/20 text-sky-300 font-bold border border-sky-500/40' : 'text-gray-400 hover:text-white'
            }`}
          >
            <History className="w-3.5 h-3.5 text-sky-400" />
            <span>Checkpoints & Rollbacks ({savedCheckpoints.length})</span>
          </button>
        </div>
      </div>

      {/* Search & Filter Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-[#0a0e17] p-3 rounded-xl border border-white/10">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search runs by ID, model, or dataset..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="w-full bg-black/40 border border-white/10 rounded-lg pl-9 pr-3 py-1.5 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-orange-500/50"
          />
        </div>

        <div className="text-xs text-gray-400 font-mono flex items-center space-x-2">
          <span>Selected for comparison: </span>
          <span className="text-orange-400 font-bold">{selectedExpIds.join(', ') || 'None'}</span>
        </div>
      </div>

      {/* VIEW 1: EXPERIMENT MATRIX TABLE */}
      {activeTab === 'matrix' && (
        <div className="rounded-xl bg-[#0a0e17] border border-white/10 overflow-hidden shadow-xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead className="bg-black/60 text-gray-400 uppercase text-[10px] border-b border-white/10">
                <tr>
                  <th className="p-3 w-10">Compare</th>
                  <th className="p-3">Run ID / Name</th>
                  <th className="p-3">Model Base</th>
                  <th className="p-3">Dataset Version</th>
                  <th className="p-3">Compute Allocation</th>
                  <th className="p-3">Hyperparams</th>
                  <th className="p-3 text-right">Train Loss</th>
                  <th className="p-3 text-right">Perplexity</th>
                  <th className="p-3 text-right">Val Acc</th>
                  <th className="p-3 text-center">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 text-gray-300">
                {filteredExperiments.map((exp, idx) => {
                  const isSelected = selectedExpIds.includes(exp.id);
                  return (
                    <tr
                      key={`${exp.id}-${idx}`}
                      className={`hover:bg-white/5 transition ${isSelected ? 'bg-orange-500/5' : ''}`}
                    >
                      <td className="p-3">
                        <input
                          type="checkbox"
                          checked={isSelected}
                          onChange={() => toggleSelectExp(exp.id)}
                          className="rounded border-white/20 bg-black text-orange-500 focus:ring-orange-500/20"
                        />
                      </td>

                      <td className="p-3">
                        <div className="font-bold text-white flex items-center space-x-1.5">
                          <span>{exp.id}</span>
                          <TrustBadge type="EXECUTED" size="xs" />
                        </div>
                        <div className="text-[11px] text-gray-400 truncate max-w-[180px] font-sans">
                          {exp.name}
                        </div>
                        <div className="text-[10px] text-gray-500 font-mono mt-0.5">
                          DNA: {exp.dna.dnaHash}
                        </div>
                      </td>

                      <td className="p-3 text-gray-300">{exp.modelName}</td>
                      <td className="p-3">
                        <span className="px-1.5 py-0.5 rounded bg-white/5 text-emerald-400 border border-emerald-900/30">
                          {exp.datasetVersion}
                        </span>
                      </td>

                      <td className="p-3">
                        <div className="text-white">{exp.computeAlloc.acceleratorName}</div>
                        <div className="text-[10px] text-gray-500">{exp.computeAlloc.distributionMode}</div>
                      </td>

                      <td className="p-3 text-[11px] text-gray-400">
                        <div>lr={exp.hyperparameters.learningRate}</div>
                        <div>batch={exp.hyperparameters.batchSize} • {exp.hyperparameters.precision}</div>
                      </td>

                      <td className="p-3 text-right text-emerald-400 font-bold">
                        {exp.metrics.trainLoss.toFixed(3)}
                      </td>

                      <td className="p-3 text-right text-sky-400">
                        {exp.metrics.perplexity.toFixed(2)}
                      </td>

                      <td className="p-3 text-right text-amber-400 font-bold">
                        {exp.metrics.evalAccuracy ? `${exp.metrics.evalAccuracy}%` : 'N/A'}
                      </td>

                      <td className="p-3">
                        <div className="flex items-center justify-center space-x-1.5">
                          <button
                            onClick={() => reproduceExperiment(exp.id)}
                            title="Reproduce with identical DNA & seed"
                            className="p-1.5 rounded bg-white/5 hover:bg-orange-500/20 text-gray-300 hover:text-orange-400 transition"
                          >
                            <RotateCcw className="w-3.5 h-3.5" />
                          </button>

                          <button
                            onClick={() => forkExperiment(exp.id)}
                            title="Fork into new experiment"
                            className="p-1.5 rounded bg-white/5 hover:bg-indigo-500/20 text-gray-300 hover:text-indigo-400 transition"
                          >
                            <GitFork className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* VIEW 1.5: 3D EXPERIMENT DNA HELIX LINEAGE GRAPH */}
      {activeTab === '3d_dna' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between text-xs font-mono text-gray-400">
            <span>FULL CRYPTOGRAPHIC LINEAGE: DATASET ➔ CODE ➔ ENV ➔ HP ➔ COMPUTE ➔ RUN ➔ CKPT ➔ MODEL ➔ DEPLOYMENT</span>
            <TrustBadge type="SIMULATED" size="xs" />
          </div>
          <ExperimentDNA3DGraph />
        </div>
      )}

      {/* VIEW 2: EXPERIMENT DNA DIFF COMPARISON */}
      {activeTab === 'dna_compare' && (
        <div className="space-y-6">
          {selectedList.length < 2 ? (
            <div className="p-8 text-center bg-[#0a0e17] rounded-xl border border-white/10 text-xs text-gray-400 font-mono">
              Please select at least two experiments from the Matrix table above to perform DNA differential analysis.
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* DNA Details Cards */}
              {selectedList.slice(0, 2).map((exp, idx) => (
                <div key={`${exp.id}-${idx}`} className="p-5 rounded-xl bg-[#0a0e17] border border-white/10 space-y-4">
                  <div className="flex items-center justify-between border-b border-white/10 pb-3">
                    <div className="flex items-center space-x-2">
                      <Dna className="w-4 h-4 text-orange-400" />
                      <span className="font-bold text-white text-sm">{exp.id}: {exp.name}</span>
                    </div>
                    <span className="text-xs font-mono text-orange-400 bg-orange-500/10 px-2 py-0.5 rounded border border-orange-500/20">
                      {exp.dna.dnaHash}
                    </span>
                  </div>

                  <div className="space-y-2 text-xs font-mono">
                    <div className="flex justify-between p-2 bg-white/5 rounded">
                      <span className="text-gray-400">Code Commit</span>
                      <span className="text-white">{exp.dna.codeHash}</span>
                    </div>
                    <div className="flex justify-between p-2 bg-white/5 rounded">
                      <span className="text-gray-400">Dataset Version</span>
                      <span className="text-emerald-400">{exp.dna.datasetVersion}</span>
                    </div>
                    <div className="flex justify-between p-2 bg-white/5 rounded">
                      <span className="text-gray-400">Model Foundation</span>
                      <span className="text-white">{exp.dna.modelBase}</span>
                    </div>
                    <div className="flex justify-between p-2 bg-white/5 rounded">
                      <span className="text-gray-400">Random Seed</span>
                      <span className="text-amber-400">{exp.dna.seed}</span>
                    </div>
                    <div className="flex justify-between p-2 bg-white/5 rounded">
                      <span className="text-gray-400">Compute Topology</span>
                      <span className="text-orange-400">{exp.dna.computeConfig}</span>
                    </div>
                    <div className="flex justify-between p-2 bg-white/5 rounded">
                      <span className="text-gray-400">Convergence Metric</span>
                      <span className="text-emerald-400 font-bold">Val Loss: {exp.metrics.valLoss} (Perplexity: {exp.metrics.perplexity})</span>
                    </div>
                  </div>

                  <div className="pt-2 flex gap-2">
                    <button
                      onClick={() => reproduceExperiment(exp.id)}
                      className="flex-1 py-1.5 bg-orange-500 hover:bg-orange-600 text-white rounded text-xs font-mono font-bold transition flex items-center justify-center space-x-1"
                    >
                      <RotateCcw className="w-3 h-3" />
                      <span>Reproduce Exactly</span>
                    </button>
                    <button
                      onClick={() => forkExperiment(exp.id)}
                      className="px-3 py-1.5 bg-white/10 hover:bg-white/15 text-gray-200 rounded text-xs font-mono transition flex items-center space-x-1"
                    >
                      <GitFork className="w-3 h-3" />
                      <span>Fork</span>
                    </button>
                  </div>
                </div>
              ))}

              {/* DNA Delta Analysis Panel */}
              <div className="lg:col-span-2 p-5 rounded-xl bg-[#0c101a] border border-orange-500/30 space-y-4">
                <div className="flex items-center space-x-2 text-xs font-mono text-orange-400 font-bold">
                  <Sparkles className="w-4 h-4" />
                  <span>Experiment DNA Differential Analysis ({selectedList[0].id} vs {selectedList[1].id})</span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs font-mono">
                  <div className="p-3 bg-black/50 rounded-lg border border-white/5 space-y-1">
                    <div className="text-gray-400 text-[11px]">What Changed:</div>
                    <ul className="text-gray-200 list-disc list-inside space-y-1">
                      <li>Compute: {selectedList[0].computeAlloc.acceleratorName} vs {selectedList[1].computeAlloc.acceleratorName}</li>
                      <li>Dataset: {selectedList[0].datasetVersion} vs {selectedList[1].datasetVersion}</li>
                      <li>Precision: {selectedList[0].hyperparameters.precision} vs {selectedList[1].hyperparameters.precision}</li>
                    </ul>
                  </div>

                  <div className="p-3 bg-black/50 rounded-lg border border-white/5 space-y-1">
                    <div className="text-gray-400 text-[11px]">What Remained Identical:</div>
                    <ul className="text-gray-200 list-disc list-inside space-y-1">
                      <li>Base Model: {selectedList[0].modelName}</li>
                      <li>Random Seed: {selectedList[0].seed}</li>
                      <li>Tokenizer & Embeddings vocab</li>
                    </ul>
                  </div>

                  <div className="p-3 bg-black/50 rounded-lg border border-white/5 space-y-1">
                    <div className="text-gray-400 text-[11px]">Empirical Metric Delta:</div>
                    <div className="text-emerald-400 font-bold">
                      Validation Loss: {selectedList[0].metrics.valLoss} vs {selectedList[1].metrics.valLoss} (Δ {Math.abs(selectedList[0].metrics.valLoss - selectedList[1].metrics.valLoss).toFixed(3)})
                    </div>
                    <div className="text-sky-400">
                      Token Speed: {selectedList[0].metrics.tokensPerSec} tok/s vs {selectedList[1].metrics.tokensPerSec} tok/s
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Checkpoints & Rollback Lineage View */}
      {activeTab === 'checkpoints' && (
        <div className="space-y-6">
          {/* Top Level Checkpoint Governance Stats */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="p-4 bg-[#0a0e17] rounded-xl border border-white/10 space-y-1">
              <div className="flex items-center justify-between text-gray-400 text-xs font-mono">
                <span>Stored Checkpoints</span>
                <History className="w-4 h-4 text-sky-400" />
              </div>
              <div className="text-2xl font-bold text-white font-mono">
                {savedCheckpoints.length}
              </div>
              <div className="text-[11px] text-gray-500 font-mono">
                {savedCheckpoints.filter(c => c.isAutomatic).length} Auto-steps • {savedCheckpoints.filter(c => !c.isAutomatic).length} Manual
              </div>
            </div>

            <div className="p-4 bg-[#0a0e17] rounded-xl border border-white/10 space-y-1">
              <div className="flex items-center justify-between text-gray-400 text-xs font-mono">
                <span>Storage Footprint</span>
                <HardDrive className="w-4 h-4 text-orange-400" />
              </div>
              <div className="text-2xl font-bold text-white font-mono">
                {(savedCheckpoints.reduce((acc, c) => acc + c.sizeMB, 0) / 1024).toFixed(1)} GB
              </div>
              <div className="text-[11px] text-emerald-400 font-mono">
                Deduplicated NVMe BSY Storage
              </div>
            </div>

            <div className="p-4 bg-[#0a0e17] rounded-xl border border-white/10 space-y-1">
              <div className="flex items-center justify-between text-gray-400 text-xs font-mono">
                <span>Active Kernel Weights</span>
                <FileCode className="w-4 h-4 text-emerald-400" />
              </div>
              <div className="text-sm font-bold text-emerald-300 font-mono truncate">
                {activeRestoredCheckpoint ? activeRestoredCheckpoint.id : 'Base Pretrained (FP16)'}
              </div>
              <div className="text-[11px] text-gray-400 font-mono truncate">
                {activeRestoredCheckpoint ? `Step ${activeRestoredCheckpoint.step} (Loss: ${activeRestoredCheckpoint.loss})` : 'No rollback active'}
              </div>
            </div>

            <div className="p-4 bg-[#0a0e17] rounded-xl border border-white/10 space-y-1">
              <div className="flex items-center justify-between text-gray-400 text-xs font-mono">
                <span>Integrity Assurance</span>
                <ShieldCheck className="w-4 h-4 text-sky-400" />
              </div>
              <div className="text-2xl font-bold text-sky-300 font-mono">
                100%
              </div>
              <div className="text-[11px] text-gray-400 font-mono">
                SHA-256 Content-Addressed
              </div>
            </div>
          </div>

          {/* Active Restored Banner */}
          {activeRestoredCheckpoint && (
            <div className="p-4 bg-sky-950/30 border border-sky-600/40 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs font-mono text-sky-200">
              <div className="flex items-center space-x-2">
                <span className="w-2 h-2 rounded-full bg-sky-400 animate-ping" />
                <span className="font-bold text-white">Active Restored Checkpoint:</span>
                <span className="px-2 py-0.5 rounded bg-sky-500/20 text-sky-300 border border-sky-500/40">
                  {activeRestoredCheckpoint.id}
                </span>
                <span className="text-gray-400">• Step {activeRestoredCheckpoint.step} • Loss {activeRestoredCheckpoint.loss}</span>
              </div>
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => setCurrentView('notebook')}
                  className="px-3 py-1 bg-sky-500 hover:bg-sky-600 text-white rounded font-bold transition flex items-center space-x-1"
                >
                  <span>Open Notebook Kernel</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              </div>
            </div>
          )}

          {/* Checkpoint Filter Pills */}
          <div className="flex flex-wrap items-center justify-between gap-3 bg-[#0a0e17] p-3 rounded-xl border border-white/10 text-xs font-mono">
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => setCheckpointFilter('all')}
                className={`px-3 py-1.5 rounded-lg transition ${
                  checkpointFilter === 'all'
                    ? 'bg-sky-500/20 text-sky-300 border border-sky-500/40 font-bold'
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                All Checkpoints ({savedCheckpoints.length})
              </button>
              <button
                onClick={() => setCheckpointFilter('auto')}
                className={`px-3 py-1.5 rounded-lg transition ${
                  checkpointFilter === 'auto'
                    ? 'bg-sky-500/20 text-sky-300 border border-sky-500/40 font-bold'
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                Auto-Convergence Steps ({savedCheckpoints.filter(c => c.isAutomatic).length})
              </button>
              <button
                onClick={() => setCheckpointFilter('manual')}
                className={`px-3 py-1.5 rounded-lg transition ${
                  checkpointFilter === 'manual'
                    ? 'bg-sky-500/20 text-sky-300 border border-sky-500/40 font-bold'
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                Manual Snapshots ({savedCheckpoints.filter(c => !c.isAutomatic).length})
              </button>
            </div>

            <div className="text-gray-400 text-[11px]">
              Showing {savedCheckpoints.filter(c => {
                if (checkpointFilter === 'auto') return c.isAutomatic;
                if (checkpointFilter === 'manual') return !c.isAutomatic;
                return true;
              }).length} Checkpoints
            </div>
          </div>

          {/* Checkpoints Cards List */}
          <div className="space-y-3 font-mono text-xs">
            {savedCheckpoints
              .filter(c => {
                if (checkpointFilter === 'auto') return c.isAutomatic;
                if (checkpointFilter === 'manual') return !c.isAutomatic;
                return true;
              })
              .map((ckpt) => {
                const isActive = activeRestoredCheckpoint?.id === ckpt.id;
                return (
                  <div
                    key={ckpt.id}
                    className={`p-5 rounded-xl border transition flex flex-col lg:flex-row lg:items-center justify-between gap-4 ${
                      isActive
                        ? 'bg-sky-950/25 border-sky-500/60 shadow-lg'
                        : 'bg-[#0a0e17] border-white/10 hover:border-white/20'
                    }`}
                  >
                    <div className="space-y-2 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="text-base font-bold text-white">{ckpt.id}</span>
                        <span className={`px-2 py-0.5 rounded text-[10px] ${
                          ckpt.isAutomatic
                            ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                            : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                        }`}>
                          {ckpt.isAutomatic ? 'AUTOMATED STEP CHECKPOINT' : 'MANUAL WEIGHT SNAPSHOT'}
                        </span>
                        {isActive && (
                          <span className="px-2 py-0.5 rounded text-[10px] bg-sky-500/30 text-sky-200 border border-sky-400 flex items-center space-x-1">
                            <Check className="w-3 h-3 text-sky-300" />
                            <span className="font-bold">ACTIVE IN KERNEL</span>
                          </span>
                        )}
                        <span className="text-gray-500 text-[11px]">{ckpt.timestamp}</span>
                      </div>

                      <div className="text-gray-300 text-xs flex items-center space-x-2">
                        <span className="text-orange-400 font-bold">{ckpt.experimentName || 'Research Run'}</span>
                        {ckpt.notes && <span className="text-gray-400">• {ckpt.notes}</span>}
                      </div>

                      {/* Detailed Parameters Row */}
                      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 p-3 bg-black/40 rounded-lg border border-white/5 text-[11px]">
                        <div>
                          <div className="text-gray-500 text-[10px]">TRAINING EPOCH</div>
                          <div className="text-white font-bold">{ckpt.epoch}</div>
                        </div>
                        <div>
                          <div className="text-gray-500 text-[10px]">STEP ITERATION</div>
                          <div className="text-amber-400 font-bold">{ckpt.step.toLocaleString()}</div>
                        </div>
                        <div>
                          <div className="text-gray-500 text-[10px]">VALIDATION LOSS</div>
                          <div className="text-emerald-400 font-bold">{ckpt.loss}</div>
                        </div>
                        <div>
                          <div className="text-gray-500 text-[10px]">VAL ACCURACY</div>
                          <div className="text-sky-400 font-bold">{ckpt.valAccuracy}%</div>
                        </div>
                        <div>
                          <div className="text-gray-500 text-[10px]">SNAPSHOT SIZE</div>
                          <div className="text-gray-300 font-bold">{(ckpt.sizeMB / 1024).toFixed(1)} GB</div>
                        </div>
                      </div>

                      {/* Content Addressing & Storage Path */}
                      <div className="flex flex-wrap items-center gap-4 text-[10px] text-gray-500">
                        <span className="flex items-center space-x-1 font-mono text-gray-400">
                          <HardDrive className="w-3.5 h-3.5 text-gray-400" />
                          <span>{ckpt.path || `bsy://checkpoints/${ckpt.id}.pt`}</span>
                        </span>
                        <span className="flex items-center space-x-1 font-mono text-emerald-400/80">
                          <ShieldCheck className="w-3.5 h-3.5" />
                          <span>{ckpt.sha256 || 'sha256:verified_content'}</span>
                        </span>
                      </div>
                    </div>

                    {/* Action Column */}
                    <div className="flex flex-col sm:flex-row lg:flex-col gap-2 shrink-0 justify-center">
                      <button
                        onClick={() => {
                          restoreCheckpoint(ckpt.id, { target: 'notebook' });
                          setCurrentView('notebook');
                        }}
                        className="px-4 py-2 rounded-lg bg-orange-500 hover:bg-orange-600 text-white font-bold text-xs transition flex items-center justify-center space-x-1.5 shadow"
                        title="Restore model weights into active notebook PyTorch kernel and open notebook"
                      >
                        <FileCode className="w-3.5 h-3.5" />
                        <span>Restore into Notebook</span>
                      </button>

                      <button
                        onClick={() => {
                          restoreCheckpoint(ckpt.id, { target: 'training' });
                          setCurrentView('compute_brain');
                        }}
                        className="px-4 py-2 rounded-lg bg-white/10 hover:bg-white/15 text-gray-200 border border-white/10 text-xs transition flex items-center justify-center space-x-1.5"
                        title="Hot-swap training cluster to this exact step and view Compute Brain"
                      >
                        <RotateCcw className="w-3.5 h-3.5 text-amber-400" />
                        <span>Rollback Cluster</span>
                      </button>

                      <button
                        onClick={() => reproduceExperiment(ckpt.experimentId || 'EXP-04')}
                        className="px-4 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white text-xs transition flex items-center justify-center space-x-1"
                        title="Rerun complete training pipeline with exact seed, hyperparameters, and dataset version"
                      >
                        <GitFork className="w-3 h-3 text-indigo-400" />
                        <span>Reproduce Run</span>
                      </button>
                    </div>
                  </div>
                );
              })}
          </div>
        </div>
      )}
    </div>
  );
};
