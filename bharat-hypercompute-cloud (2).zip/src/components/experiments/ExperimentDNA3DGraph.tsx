import React, { useRef, useEffect, useState } from 'react';
import {
  Dna,
  ShieldCheck,
  CheckCircle2,
  Lock,
  GitCommit,
  Layers,
  Sparkles,
  ExternalLink,
  ChevronRight,
  Database,
  Code,
  Sliders,
  Cpu,
  Box,
  Rocket
} from 'lucide-react';
import { TrustBadge } from '../common/TrustBadge';

interface LineageNode {
  id: string;
  stage: 'Dataset' | 'Code' | 'Environment' | 'Hyperparameters' | 'Compute' | 'Run' | 'Checkpoint' | 'Model' | 'Deployment';
  name: string;
  hash: string;
  details: string;
  verified: boolean;
  status: 'valid' | 'active' | 'archived';
}

const LINEAGE_NODES: LineageNode[] = [
  {
    id: 'ds_bhasha_v3',
    stage: 'Dataset',
    name: 'Bhasha-Indic-Corpus-v3',
    hash: 'sha256:7f8a91b2c3d4e5f60718293a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b3c',
    details: '850,000 tokenized Hindi/Tamil/Telugu instruction pairs. De-duplicated with MinHash LSH.',
    verified: true,
    status: 'valid'
  },
  {
    id: 'code_git',
    stage: 'Code',
    name: 'train_ddp_flash_attn.py',
    hash: 'git:commit-9df28a38c11e4f9b8c2d1e0a7f6e5d4c3b2a1098',
    details: 'PyTorch 2.4 + FlashAttention-3 + DeepSpeed ZeRO-3 configuration file.',
    verified: true,
    status: 'valid'
  },
  {
    id: 'env_cuda',
    stage: 'Environment',
    name: 'MII-PyTorch-CUDA12.4-Image',
    hash: 'docker:sha256:d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2c3d4e5',
    details: 'Locked deterministic CUDA 12.4, cuDNN 9.1, NCCL 2.21, vLLM 0.6.1 runtime.',
    verified: true,
    status: 'valid'
  },
  {
    id: 'hp_config',
    stage: 'Hyperparameters',
    name: 'LR=2e-5, Cosine Decay, Warmup=5%',
    hash: 'config:sha256:3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b3c4d5e6f7a8b9c0d1e2f3a4b',
    details: 'Global Batch Size 128, Seq Len 4096, LoRA Rank 16, Alpha 32, Dropout 0.05.',
    verified: true,
    status: 'valid'
  },
  {
    id: 'compute_pod',
    stage: 'Compute',
    name: '4× BHARAT H100 SXM5 (Delhi Pod #01)',
    hash: 'hw:node-delhi-01-rack-04-h100-sxm5-mesh',
    details: '4x 80GB HBM3 memory, 900 GB/s NVLink, 3.2 Tbps RoCE sovereign interconnect.',
    verified: true,
    status: 'valid'
  },
  {
    id: 'run_track',
    stage: 'Run',
    name: 'EXP-MII-INDIC-7B-DDP #482',
    hash: 'run:uuid-e8a9c2b4-7103-4921-b847-92cf38910a51',
    details: 'Training duration 2h 15m. Final Training Loss 1.482. Validation Loss 1.541.',
    verified: true,
    status: 'valid'
  },
  {
    id: 'ckpt_step3500',
    stage: 'Checkpoint',
    name: 'step_003500.pt (Best Loss Checkpoint)',
    hash: 'sha256:91b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2',
    details: 'Weights fp16 verified. Zero NaN/Inf anomalies detected across all tensor layers.',
    verified: true,
    status: 'valid'
  },
  {
    id: 'model_reg',
    stage: 'Model',
    name: 'IndicLLM-7B-Instruct-v3.0',
    hash: 'model:mii-indicllm-7b-v3-prod',
    details: 'MII Sovereign Model Registry. Scored 87.4% on BhashaBench and 74.2% on IndicMMLU.',
    verified: true,
    status: 'valid'
  },
  {
    id: 'deploy_vllm',
    stage: 'Deployment',
    name: 'vLLM Sovereign Endpoint (api.mii.in)',
    hash: 'endpoint:dep-mii-indicllm-prod-01',
    details: 'Serving 42 requests/sec with P95 latency of 14.8ms under 99.99% uptime SLA.',
    verified: true,
    status: 'active'
  }
];

export const ExperimentDNA3DGraph: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  const [selectedNode, setSelectedNode] = useState<LineageNode>(LINEAGE_NODES[0]);
  const [autoRotate, setAutoRotate] = useState<boolean>(true);

  // Refs for 60fps canvas animation (eliminates state thrashing and maximum update depth errors)
  const rotYRef = useRef<number>(0.1);
  const autoRotateRef = useRef<boolean>(true);
  const isDraggingRef = useRef<boolean>(false);
  const dragStartRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const selectedNodeRef = useRef<LineageNode>(LINEAGE_NODES[0]);

  useEffect(() => {
    autoRotateRef.current = autoRotate;
  }, [autoRotate]);

  useEffect(() => {
    selectedNodeRef.current = selectedNode;
  }, [selectedNode]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;

    const handleResize = () => {
      if (containerRef.current && canvas) {
        const rect = containerRef.current.getBoundingClientRect();
        const dpr = window.devicePixelRatio || 1;
        canvas.width = rect.width * dpr;
        canvas.height = rect.height * dpr;
        ctx.scale(dpr, dpr);
      }
    };

    handleResize();
    window.addEventListener('resize', handleResize);

    let tick = 0;

    const render = () => {
      if (!canvas || !containerRef.current) return;
      const width = containerRef.current.clientWidth;
      const height = containerRef.current.clientHeight;

      if (autoRotateRef.current && !isDraggingRef.current) {
        rotYRef.current += 0.002;
      }

      ctx.clearRect(0, 0, width, height);

      // Background
      const bg = ctx.createRadialGradient(width / 2, height / 2, 20, width / 2, height / 2, width / 2);
      bg.addColorStop(0, '#0a0e1a');
      bg.addColorStop(1, '#05070c');
      ctx.fillStyle = bg;
      ctx.fillRect(0, 0, width, height);

      const cx = width / 2;
      const cy = height / 2;
      const stepX = (width - 120) / (LINEAGE_NODES.length - 1);

      // Project 3D DNA Double Helix Strand
      const projected = LINEAGE_NODES.map((node, i) => {
        const xOffset = - (width - 140) / 2 + i * stepX;
        const angle = i * 0.7 + rotYRef.current;
        const yOffset = Math.sin(angle) * 45;
        const zOffset = Math.cos(angle) * 50;

        const fov = 350;
        const scale = fov / (fov + zOffset + 120);

        return {
          node,
          px: cx + xOffset * scale,
          py: cy + yOffset * scale,
          scale,
          zOffset
        };
      });

      // Draw backbone connection lines
      for (let i = 0; i < projected.length - 1; i++) {
        const pA = projected[i];
        const pB = projected[i + 1];

        ctx.strokeStyle = 'rgba(249, 115, 22, 0.35)';
        ctx.lineWidth = 2 * pA.scale;
        ctx.beginPath();
        ctx.moveTo(pA.px, pA.py);
        ctx.lineTo(pB.px, pB.py);
        ctx.stroke();

        // Animated DNA base-pair pulses
        const progress = ((tick * 0.015 + i * 0.2) % 1);
        const pulseX = pA.px + (pB.px - pA.px) * progress;
        const pulseY = pA.py + (pB.py - pA.py) * progress;

        ctx.fillStyle = '#f97316';
        ctx.beginPath();
        ctx.arc(pulseX, pulseY, 2.5 * pA.scale, 0, Math.PI * 2);
        ctx.fill();
      }

      // Sort by depth
      const sorted = [...projected].sort((a, b) => b.zOffset - a.zOffset);

      // Draw nodes
      sorted.forEach(({ node, px, py, scale }) => {
        const isSelected = selectedNodeRef.current?.id === node.id;
        const radius = (isSelected ? 16 : 12) * scale;

        // Glow
        const glow = ctx.createRadialGradient(px, py, 2, px, py, radius * 2);
        glow.addColorStop(0, isSelected ? 'rgba(249, 115, 22, 0.8)' : 'rgba(56, 189, 248, 0.4)');
        glow.addColorStop(1, 'rgba(0, 0, 0, 0)');
        ctx.fillStyle = glow;
        ctx.beginPath();
        ctx.arc(px, py, radius * 2, 0, Math.PI * 2);
        ctx.fill();

        // Node circle
        ctx.fillStyle = isSelected ? '#ea580c' : '#0284c7';
        ctx.beginPath();
        ctx.arc(px, py, radius, 0, Math.PI * 2);
        ctx.fill();

        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 1.5;
        ctx.stroke();

        // Stage label
        ctx.fillStyle = '#ffffff';
        ctx.font = `bold ${Math.max(8, 9 * scale)}px ui-monospace, SFMono-Regular, monospace`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(node.stage.substring(0, 4).toUpperCase(), px, py);

        // Subtitle
        ctx.fillStyle = isSelected ? '#fed7aa' : '#94a3b8';
        ctx.font = `${Math.max(8, 9 * scale)}px ui-monospace, SFMono-Regular, monospace`;
        ctx.fillText(node.stage, px, py + radius + 10);
      });

      tick++;
      animId = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animId);
    };
  }, []);

  return (
    <div className="space-y-3">
      <div
        ref={containerRef}
        className="relative w-full h-[320px] rounded-2xl overflow-hidden border border-white/10 bg-[#07090e] shadow-xl"
      >
        <canvas
          ref={canvasRef}
          onPointerDown={e => {
            isDraggingRef.current = true;
            dragStartRef.current = { x: e.clientX, y: e.clientY };
          }}
          onPointerMove={e => {
            if (!isDraggingRef.current) return;
            const dx = e.clientX - dragStartRef.current.x;
            rotYRef.current += dx * 0.007;
            dragStartRef.current = { x: e.clientX, y: e.clientY };
          }}
          onPointerUp={() => {
            isDraggingRef.current = false;
          }}
          onPointerCancel={() => {
            isDraggingRef.current = false;
          }}
          className="w-full h-full cursor-grab active:cursor-grabbing block"
        />

        {/* Top Badges */}
        <div className="absolute top-3 left-3 flex items-center space-x-2 pointer-events-none">
          <span className="px-2.5 py-1 rounded-lg bg-black/70 backdrop-blur-md border border-white/10 text-xs font-mono text-orange-400 font-bold">
            3D CRYPTOGRAPHIC EXPERIMENT DNA
          </span>
          <TrustBadge type="SIMULATED" size="xs" />
        </div>

        {/* Auto-rotate button */}
        <div className="absolute top-3 right-3 flex items-center space-x-2">
          <button
            onClick={() => setAutoRotate(!autoRotate)}
            className={`px-2.5 py-1 rounded-lg text-xs font-mono border backdrop-blur-md transition ${
              autoRotate ? 'bg-orange-500/20 text-orange-300 border-orange-500/40' : 'bg-black/60 text-gray-400 border-white/10'
            }`}
          >
            {autoRotate ? 'Helix Orbit' : 'Paused'}
          </button>
        </div>

        {/* Bottom lineage step buttons */}
        <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between gap-1 overflow-x-auto py-1">
          {LINEAGE_NODES.map(node => (
            <button
              key={node.id}
              onClick={() => setSelectedNode(node)}
              className={`px-2 py-1 rounded-lg text-[11px] font-mono whitespace-nowrap transition border ${
                selectedNode.id === node.id
                  ? 'bg-orange-500 text-white font-bold border-orange-400'
                  : 'bg-black/70 backdrop-blur-md text-gray-400 hover:text-white border-white/10'
              }`}
            >
              {node.stage}
            </button>
          ))}
        </div>
      </div>

      {/* Selected Node Cryptographic Inspector */}
      <div className="p-4 rounded-xl bg-[#0a0e17] border border-orange-500/30 space-y-2 text-xs font-mono shadow-lg">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-white/10 pb-2">
          <div className="flex items-center space-x-2">
            <span className="text-orange-400 font-bold uppercase">{selectedNode.stage} Artifact</span>
            <span className="text-gray-500">/</span>
            <span className="text-white font-semibold">{selectedNode.name}</span>
          </div>
          <div className="flex items-center space-x-1.5 text-emerald-400 text-[11px]">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Cryptographically Verified SHA-256</span>
          </div>
        </div>

        <p className="text-gray-300 text-xs">{selectedNode.details}</p>

        <div className="p-2 bg-black/60 rounded border border-white/5 flex items-center justify-between gap-2 text-[10px] text-gray-400">
          <div className="flex items-center space-x-1.5 truncate">
            <Lock className="w-3 h-3 text-orange-400 shrink-0" />
            <span className="truncate">{selectedNode.hash}</span>
          </div>
          <span className="text-emerald-400 font-bold shrink-0">IMMUTABLE</span>
        </div>
      </div>
    </div>
  );
};
