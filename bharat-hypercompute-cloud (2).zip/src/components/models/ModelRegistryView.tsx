import React from 'react';
import { useApp } from '../../context/AppContext';
import { TrustBadge } from '../common/TrustBadge';
import {
  Box,
  Rocket,
  GitCommit,
  CheckCircle2,
  HardDrive,
  Cpu,
  Layers,
  Sparkles,
  ArrowRight,
  ShieldCheck
} from 'lucide-react';

export const ModelRegistryView: React.FC = () => {
  const { models, deployModel, setCurrentView, showNotification } = useApp();
  const selectedModel = models[0];

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center space-x-2">
            <span className="text-xs font-mono text-orange-400 font-bold uppercase tracking-wider">
              ASSET GOVERNANCE
            </span>
            <span className="text-gray-600">/</span>
            <span className="text-xs font-mono text-gray-400">Model Registry</span>
            <TrustBadge type="SIMULATED" size="xs" />
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white font-display flex items-center space-x-2">
            <Box className="w-7 h-7 text-orange-400" />
            <span>Model Registry</span>
          </h1>
          <p className="text-xs sm:text-sm text-gray-400">
            Validated weights, checkpoint artifacts, benchmark metrics, and seamless 1-click API serving.
          </p>
        </div>

        <button
          onClick={() => {
            deployModel(selectedModel.id, selectedModel.currentVersion);
            setCurrentView('deployments');
          }}
          className="px-4 py-2 rounded-xl bg-orange-500 hover:bg-orange-600 text-white font-bold text-xs shadow-lg transition flex items-center space-x-1.5 self-start sm:self-auto"
        >
          <Rocket className="w-4 h-4" />
          <span>Deploy Current Version to API</span>
        </button>
      </div>

      {/* Model Overview Card */}
      <div className="p-6 rounded-2xl bg-[#0a0e17] border border-white/10 space-y-4 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/10 pb-4">
          <div>
            <div className="flex items-center space-x-2">
              <h2 className="text-xl font-bold text-white font-display">
                {selectedModel.name}
              </h2>
              <span className="px-2 py-0.5 rounded bg-orange-950 text-orange-400 border border-orange-800/40 text-xs font-mono font-bold">
                {selectedModel.currentVersion}
              </span>
              <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800/40 text-xs font-mono">
                {selectedModel.deploymentStatus === 'active' ? 'SERVED ON LIVE API' : 'VALIDATED'}
              </span>
            </div>
            <p className="text-xs text-gray-400 mt-1 max-w-2xl">
              {selectedModel.description}
            </p>
          </div>

          <div className="text-right font-mono text-xs text-gray-400">
            <div>Owner: <span className="text-white">{selectedModel.owner}</span></div>
            <div className="text-[10px] text-gray-500">Architecture: LLaMA-based Indic bilingual</div>
          </div>
        </div>

        {/* Technical Specs */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs font-mono">
          <div className="p-3 bg-black/40 rounded-lg border border-white/5">
            <div className="text-gray-500 text-[10px]">Parameters</div>
            <div className="text-lg font-bold text-white mt-0.5">
              {selectedModel.versions[0].paramsCount}
            </div>
            <div className="text-[10px] text-emerald-400 font-sans mt-0.5">Dense Transformer</div>
          </div>

          <div className="p-3 bg-black/40 rounded-lg border border-white/5">
            <div className="text-gray-500 text-[10px]">Serving Engine</div>
            <div className="text-lg font-bold text-orange-400 mt-0.5">
              vLLM 0.6.3
            </div>
            <div className="text-[10px] text-gray-400 font-sans mt-0.5">PagedAttention Enabled</div>
          </div>

          <div className="p-3 bg-black/40 rounded-lg border border-white/5">
            <div className="text-gray-500 text-[10px]">Val Accuracy</div>
            <div className="text-lg font-bold text-emerald-400 mt-0.5">
              {selectedModel.versions[0].metrics.accuracy}%
            </div>
            <div className="text-[10px] text-gray-400 font-sans mt-0.5">IndicBenchmark Suite</div>
          </div>

          <div className="p-3 bg-black/40 rounded-lg border border-white/5">
            <div className="text-gray-500 text-[10px]">p95 Token Latency</div>
            <div className="text-lg font-bold text-sky-400 mt-0.5">
              {selectedModel.versions[0].metrics.latencyP95Ms} ms
            </div>
            <div className="text-[10px] text-gray-400 font-sans mt-0.5">Measured on 2x L40S</div>
          </div>
        </div>
      </div>

      {/* Model Versions History Table */}
      <div className="rounded-xl bg-[#0a0e17] border border-white/10 overflow-hidden shadow-xl">
        <div className="p-4 bg-black/40 border-b border-white/10 flex items-center justify-between text-xs font-mono">
          <span className="text-gray-300 font-bold uppercase">Version Genealogy & Checkpoints</span>
          <span className="text-gray-500">{selectedModel.versions.length} versions tracked</span>
        </div>

        <div className="divide-y divide-white/5 font-mono text-xs text-gray-300">
          {selectedModel.versions.map((ver, idx) => (
            <div key={ver.version} className="p-4 flex flex-col md:flex-row md:items-center justify-between gap-3 hover:bg-white/5 transition">
              <div className="space-y-1">
                <div className="flex items-center space-x-2">
                  <Box className="w-4 h-4 text-orange-400" />
                  <span className="font-bold text-white">{ver.version}</span>
                  <span className={`text-[10px] px-1.5 py-0.5 rounded font-bold ${
                    ver.status === 'Deployed'
                      ? 'bg-emerald-500/20 text-emerald-300'
                      : 'bg-white/10 text-gray-300'
                  }`}>
                    {ver.status.toUpperCase()}
                  </span>
                  <span className="text-gray-500 text-[11px]">• Source: {ver.experimentId}</span>
                </div>
                <div className="text-xs text-gray-400 font-sans">
                  Trained on dataset {ver.datasetVersion} with {ver.framework} engine. Artifact size: {(ver.sizeMB / 1024).toFixed(1)} GB.
                </div>
              </div>

              <div className="flex items-center space-x-4 text-xs shrink-0">
                <div className="text-right">
                  <div className="text-emerald-400 font-bold">{ver.metrics.accuracy}% accuracy</div>
                  <div className="text-[10px] text-gray-500">{ver.createdAt}</div>
                </div>

                {ver.status !== 'Deployed' ? (
                  <button
                    onClick={() => {
                      deployModel(selectedModel.id, ver.version);
                      setCurrentView('deployments');
                    }}
                    className="px-3 py-1 bg-orange-500/20 hover:bg-orange-500/30 text-orange-300 rounded border border-orange-500/30 text-xs transition flex items-center space-x-1"
                  >
                    <Rocket className="w-3 h-3" />
                    <span>Deploy</span>
                  </button>
                ) : (
                  <button
                    onClick={() => setCurrentView('deployments')}
                    className="px-3 py-1 bg-emerald-500/20 text-emerald-300 rounded border border-emerald-500/30 text-xs transition flex items-center space-x-1"
                  >
                    <span>Inspect API</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
