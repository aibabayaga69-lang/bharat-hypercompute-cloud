import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { TrustBadge } from '../common/TrustBadge';
import {
  TrendingUp,
  Share2,
  Users,
  MessageSquare,
  Linkedin,
  Mail,
  Award,
  Sparkles,
  ArrowUpRight,
  CheckCircle2,
  AlertTriangle,
  FlaskConical,
  BarChart3,
  ShieldCheck,
  Zap,
  Target,
  FileCheck,
  Check,
  XCircle,
  Eye,
  Smartphone
} from 'lucide-react';
import { MII_BRAND } from '../common/BrandIdentity';

export const GrowthMarketingView: React.FC = () => {
  const {
    growthExperiments,
    marketingCampaigns,
    experiments,
    showNotification
  } = useApp();

  const [activeTab, setActiveTab] = useState<'scientific_loop' | 'campaigns' | 'viral_forks' | 'referrals' | 'creative_auditor'>('scientific_loop');

  const [selectedCreativeId, setSelectedCreativeId] = useState<string>('cr_01');

  const creativeAudits = [
    {
      id: 'cr_01',
      title: 'Creative Alpha: National Sovereign Compute for Indian Researchers',
      format: 'Developer Banner / Social Ad (1200x630)',
      headline: 'BUILD AI. WE HANDLE THE COMPUTE.',
      supportingLine: 'High-throughput H100 clusters with Indian data residency. Free 2 hours daily quota for scholars.',
      cta: 'Reproduce Research DNA',
      brandAttribution: 'MII — THE BRAND / BHARAT HYPERCOMPUTE CLOUD.',
      score: 96,
      status: 'APPROVED & AUDITED',
      checks: [
        { name: '1. Text Density Check', passed: true, score: '18% area (<20% rule)', detail: 'Minimal copy, ample visual space' },
        { name: '2. Readability Score', passed: true, score: 'Grade 8 (Flesch: 74)', detail: 'Direct, clear, jargon-controlled language' },
        { name: '3. Mobile Readability Check', passed: true, score: 'PASS', detail: 'Minimum text size 16px, wraps gracefully at 360px' },
        { name: '4. Visual Hierarchy Check', passed: true, score: 'PASS', detail: 'Display font -> 14px support -> high-contrast CTA button' },
        { name: '5. Contrast Ratio Check', passed: true, score: '7.8:1 (WCAG AAA)', detail: 'White & amber text on deep slate canvas' },
        { name: '6. CTA Clarity', passed: true, score: 'PASS', detail: 'Specific action: "Reproduce Research DNA", single line' },
        { name: '7. Brand Consistency', passed: true, score: 'PASS (100%)', detail: 'Uses exact brand name, product name, and founder attribution' },
        { name: '8. Factual Claims Check', passed: true, score: 'PASS', detail: 'Zero fabricated cluster size claims; references public quota' },
        { name: '9. Unsupported Claims Check', passed: true, score: 'PASS', detail: 'No "world\'s fastest" or unverified superlatives' },
        { name: '10. Copyright Risk', passed: true, score: 'ZERO RISK', detail: 'All vector icons and fonts licensed for commercial distribution' },
        { name: '11. Misleading Claims Check', passed: true, score: 'ZERO VIOLATIONS', detail: 'Explicit disclosure of simulation environment and quota limits' },
        { name: '12. Accessibility Check', passed: true, score: 'PASS (98%)', detail: 'Screen reader aria-labels and descriptive alt-text defined' },
        { name: '13. Visual Clutter Check', passed: true, score: 'LOW (1.8/10)', detail: 'Clean typography, single focal point, generous padding' }
      ]
    },
    {
      id: 'cr_02',
      title: 'Creative Beta: Indic LLM 1-Click Reproducibility Challenge',
      format: 'Academic Lab Poster & GitHub Header',
      headline: 'VERIFIABLE BENCHMARKS. ZERO MARKETING HYPE.',
      supportingLine: 'Fork 12-language Indic tokenization experiments into your personal notebook in 1 click.',
      cta: 'Fork Experiment DNA',
      brandAttribution: 'BHARAT HYPERCOMPUTE CLOUD.',
      score: 94,
      status: 'APPROVED & AUDITED',
      checks: [
        { name: '1. Text Density Check', passed: true, score: '19% area', detail: 'Strictly complies with developer poster guidelines' },
        { name: '2. Readability Score', passed: true, score: 'Grade 7 (Flesch: 78)', detail: 'Clear scientific terminology without marketing fluff' },
        { name: '3. Mobile Readability Check', passed: true, score: 'PASS', detail: 'Scales down to 320px mobile viewport without truncation' },
        { name: '4. Visual Hierarchy Check', passed: true, score: 'PASS', detail: 'Clear step-by-step layout with numbered milestones' },
        { name: '5. Contrast Ratio Check', passed: true, score: '8.2:1 (WCAG AAA)', detail: 'High contrast terminal theme with emerald accents' },
        { name: '6. CTA Clarity', passed: true, score: 'PASS', detail: 'Actionable button: "Fork Experiment DNA"' },
        { name: '7. Brand Consistency', passed: true, score: 'PASS (100%)', detail: 'Includes official tagline: 🇮🇳 Make in India. Made for 🇮🇳 Make in India (MII). 🇮🇳' },
        { name: '8. Factual Claims Check', passed: true, score: 'PASS', detail: 'Benchmarks grounded in public Indo4B & IndicNLP corpora' },
        { name: '9. Unsupported Claims Check', passed: true, score: 'PASS', detail: 'All perplexity curves cite published ArXiv methodology' },
        { name: '10. Copyright Risk', passed: true, score: 'ZERO RISK', detail: 'Custom generated layout, open source test corpora' },
        { name: '11. Misleading Claims Check', passed: true, score: 'ZERO VIOLATIONS', detail: 'Clear notice: free tier quota provides 2 hrs computation' },
        { name: '12. Accessibility Check', passed: true, score: 'PASS (96%)', detail: 'Passes high-contrast color blindness emulation tests' },
        { name: '13. Visual Clutter Check', passed: true, score: 'LOW (2.1/10)', detail: 'Organized monospace code snippet layout' }
      ]
    },
    {
      id: 'cr_03',
      title: 'Creative Gamma: Capacity Economics & Margin Transparency',
      format: 'Enterprise & Institutional Briefing Card',
      headline: 'TRANSPARENT UNIT MATH. ZERO HIDDEN EGRESS.',
      supportingLine: 'Disaggregated compute billing: provider wholesale cost vs institutional discount vs sovereign subsidy.',
      cta: 'Audit Margin Ledger',
      brandAttribution: 'MII — THE BRAND / BHARAT HYPERCOMPUTE CLOUD.',
      score: 98,
      status: 'APPROVED & AUDITED',
      checks: [
        { name: '1. Text Density Check', passed: true, score: '16% area', detail: 'Ample whitespace around financial ledger figures' },
        { name: '2. Readability Score', passed: true, score: 'Grade 9 (Flesch: 69)', detail: 'Clear institutional finance & billing terminology' },
        { name: '3. Mobile Readability Check', passed: true, score: 'PASS', detail: 'Financial figures wrap into vertical stack on mobile' },
        { name: '4. Visual Hierarchy Check', passed: true, score: 'PASS', detail: 'Headline -> Price Table -> CTA' },
        { name: '5. Contrast Ratio Check', passed: true, score: '9.1:1 (WCAG AAA)', detail: 'Crisp white on dark navy background' },
        { name: '6. CTA Clarity', passed: true, score: 'PASS', detail: '"Audit Margin Ledger" links directly to Admin portal' },
        { name: '7. Brand Consistency', passed: true, score: 'PASS (100%)', detail: 'Verified MII brand hierarchy and founder provenance' },
        { name: '8. Factual Claims Check', passed: true, score: 'PASS', detail: 'Unit costs mathematically validated against provider rates' },
        { name: '9. Unsupported Claims Check', passed: true, score: 'PASS', detail: 'Shows both retail and provider wholesale cost side-by-side' },
        { name: '10. Copyright Risk', passed: true, score: 'ZERO RISK', detail: 'Proprietary financial model' },
        { name: '11. Misleading Claims Check', passed: true, score: 'ZERO VIOLATIONS', detail: 'Includes explicit disclaimer that spot prices fluctuate' },
        { name: '12. Accessibility Check', passed: true, score: 'PASS (99%)', detail: 'Table elements include scope and header associations' },
        { name: '13. Visual Clutter Check', passed: true, score: 'VERY LOW (1.2/10)', detail: 'Minimalist ledger aesthetic' }
      ]
    }
  ];

  const currentCreative = creativeAudits.find(c => c.id === selectedCreativeId) || creativeAudits[0];

  const scientificSteps = [
    { name: 'OBSERVE', desc: 'Continuous product & research telemetry' },
    { name: 'HYPOTHESIZE', desc: 'Falsifiable, testable impact statement' },
    { name: 'DESIGN', desc: 'Variant A vs Variant B isolation' },
    { name: 'TEST', desc: 'Audience traffic split without bias' },
    { name: 'MEASURE', desc: 'Statistical significance & confidence' },
    { name: 'ANALYZE', desc: 'Separate true causation from correlation' },
    { name: 'LEARN & REPEAT', desc: 'Deploy winning variant or iterate' }
  ];

  const viralTriggers = [
    {
      action: 'Fork This Experiment',
      desc: '1-click clone full Experiment DNA (code hash, dataset version, model base, random seed, compute topology) into personal notebook.',
      viralKFactor: '1.42x',
      status: 'Active Engine'
    },
    {
      action: 'Reproduce on Free 2-Hour Cloud',
      desc: 'Allows external peer reviewers and academic readers to verify loss curves and evaluation metrics without buying hardware.',
      viralKFactor: '1.85x',
      status: 'Active Engine'
    },
    {
      action: '1-Click API Playground Share',
      desc: 'Researchers share live hosted endpoints with interactive prompt playgrounds and production cURL snippets.',
      viralKFactor: '1.28x',
      status: 'Active Engine'
    },
    {
      action: 'Indic AI Benchmark Challenge',
      desc: 'Public university challenge leaderboards comparing multilingual perplexity and throughput on standard corpora.',
      viralKFactor: '2.10x',
      status: 'Active Engine'
    }
  ];

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-[#0d1624] via-[#09111c] to-[#0f172a] p-6 rounded-2xl border border-white/10 shadow-2xl relative overflow-hidden">
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="flex items-center space-x-2">
              <span className="text-xs font-mono text-orange-400 font-bold uppercase tracking-wider">
                MII GROWTH & MARKETING ENGINE
              </span>
              <span className="text-gray-600">/</span>
              <TrustBadge type="ESTIMATED" size="xs" />
              <span className="text-[10px] font-mono text-gray-400">Scientific Acquisition Loop</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white font-display flex items-center space-x-2.5">
              <TrendingUp className="w-8 h-8 text-orange-400" />
              <span>Organic Scientific Distribution & Marketing</span>
            </h1>
            <p className="text-xs sm:text-sm text-gray-300 max-w-2xl leading-relaxed">
              Strictly anti-spam, permission-based growth. Organic discovery is powered by reproducible research, shareable Experiment DNA manifests, university challenges, and transparent pricing.
            </p>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 shrink-0 text-center font-mono">
            <div className="p-2.5 bg-black/40 rounded-xl border border-white/10">
              <div className="text-[10px] text-gray-400">Active Experiments</div>
              <div className="text-lg font-bold text-white">{growthExperiments.length}</div>
              <div className="text-[9px] text-emerald-400">Statistical A/B</div>
            </div>
            <div className="p-2.5 bg-black/40 rounded-xl border border-white/10">
              <div className="text-[10px] text-gray-400">Public Experiment Forks</div>
              <div className="text-lg font-bold text-orange-400">142</div>
              <div className="text-[9px] text-orange-400/80">Organic Referral</div>
            </div>
            <div className="p-2.5 bg-black/40 rounded-xl border border-white/10 col-span-2 sm:col-span-1">
              <div className="text-[10px] text-gray-400">Spam Safeguards</div>
              <div className="text-lg font-bold text-emerald-400">100%</div>
              <div className="text-[9px] text-emerald-500">Opt-in Only</div>
            </div>
          </div>
        </div>

        {/* Tab Controls */}
        <div className="flex items-center space-x-2 mt-6 pt-4 border-t border-white/10 overflow-x-auto text-xs font-mono">
          <button
            onClick={() => setActiveTab('scientific_loop')}
            className={`px-3.5 py-1.5 rounded-lg transition ${
              activeTab === 'scientific_loop'
                ? 'bg-orange-500 text-white font-bold'
                : 'bg-white/5 text-gray-400 hover:text-white'
            }`}
          >
            Scientific Growth Loop ({growthExperiments.length})
          </button>
          <button
            onClick={() => setActiveTab('campaigns')}
            className={`px-3.5 py-1.5 rounded-lg transition ${
              activeTab === 'campaigns'
                ? 'bg-orange-500 text-white font-bold'
                : 'bg-white/5 text-gray-400 hover:text-white'
            }`}
          >
            Permissioned Campaigns ({marketingCampaigns.length})
          </button>
          <button
            onClick={() => setActiveTab('viral_forks')}
            className={`px-3.5 py-1.5 rounded-lg transition ${
              activeTab === 'viral_forks'
                ? 'bg-orange-500 text-white font-bold'
                : 'bg-white/5 text-gray-400 hover:text-white'
            }`}
          >
            Viral Research Mechanics (DNA Forks)
          </button>
          <button
            onClick={() => setActiveTab('referrals')}
            className={`px-3.5 py-1.5 rounded-lg transition ${
              activeTab === 'referrals'
                ? 'bg-orange-500 text-white font-bold'
                : 'bg-white/5 text-gray-400 hover:text-white'
            }`}
          >
            Scholar Referral & University Radar
          </button>
          <button
            onClick={() => setActiveTab('creative_auditor')}
            className={`px-3.5 py-1.5 rounded-lg transition flex items-center space-x-1.5 ${
              activeTab === 'creative_auditor'
                ? 'bg-orange-500 text-white font-bold shadow-lg'
                : 'bg-white/5 text-gray-400 hover:text-white'
            }`}
          >
            <FileCheck className="w-3.5 h-3.5 text-orange-400" />
            <span>Creative Lab & 13-Point Auditor</span>
          </button>
        </div>
      </div>

      {/* TAB 1: SCIENTIFIC GROWTH EXPERIMENTS */}
      {activeTab === 'scientific_loop' && (
        <div className="space-y-6">
          {/* Scientific Steps Visual Bar */}
          <div className="p-4 bg-[#0a0e17] rounded-xl border border-white/10">
            <div className="text-[10px] font-mono uppercase text-gray-400 mb-2">The Continuous Scientific Growth Method:</div>
            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2 text-center text-xs font-mono">
              {scientificSteps.map((step, idx) => (
                <div key={idx} className="p-2 bg-black/40 rounded-lg border border-white/5 space-y-0.5">
                  <div className="text-orange-400 font-bold text-[10px]">{step.name}</div>
                  <div className="text-gray-400 text-[9px] leading-tight">{step.desc}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Experiments Matrix */}
          <div className="space-y-4">
            {growthExperiments.map(exp => (
              <div
                key={exp.id}
                className="p-5 rounded-2xl bg-[#0a0e17] border border-white/10 space-y-4 text-xs"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-white/5 pb-3">
                  <div className="flex items-center space-x-2 font-mono">
                    <span className="text-orange-400 font-bold text-sm font-sans">{exp.name}</span>
                    <span className="text-gray-600">/</span>
                    <span className="text-gray-400 text-[11px]">{exp.channel}</span>
                  </div>

                  <div className="flex items-center space-x-2 font-mono">
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                        exp.status === 'CONCLUDED'
                          ? 'bg-emerald-950 text-emerald-400 border border-emerald-800/40'
                          : 'bg-amber-950 text-amber-400 border border-amber-800/40'
                      }`}
                    >
                      {exp.status}
                    </span>
                    <span className="text-gray-400">Sample: {exp.sampleSize.toLocaleString()}</span>
                  </div>
                </div>

                <div className="text-gray-300 font-sans text-xs leading-relaxed">
                  <span className="text-orange-400 font-bold font-mono">HYPOTHESIS: </span>
                  {exp.hypothesis}
                </div>

                {/* Variant A vs Variant B Breakdown */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 font-mono text-xs">
                  <div className="p-3 bg-black/40 rounded-xl border border-white/5 space-y-1.5">
                    <div className="text-gray-400 font-bold flex justify-between">
                      <span>VARIANT A (Control)</span>
                      <span className="text-white font-bold">{exp.variantAConversionPct}%</span>
                    </div>
                    <div className="text-gray-300 text-[11px] font-sans">{exp.variantA}</div>
                    <div className="w-full bg-white/10 h-1.5 rounded-full overflow-hidden">
                      <div className="bg-gray-400 h-full" style={{ width: `${exp.variantAConversionPct}%` }} />
                    </div>
                  </div>

                  <div className="p-3 bg-emerald-950/20 rounded-xl border border-emerald-800/30 space-y-1.5">
                    <div className="text-emerald-400 font-bold flex justify-between">
                      <span>VARIANT B (Treatment)</span>
                      <span className="text-emerald-300 font-bold">{exp.variantBConversionPct}%</span>
                    </div>
                    <div className="text-gray-200 text-[11px] font-sans">{exp.variantB}</div>
                    <div className="w-full bg-white/10 h-1.5 rounded-full overflow-hidden">
                      <div className="bg-emerald-500 h-full" style={{ width: `${exp.variantBConversionPct}%` }} />
                    </div>
                  </div>
                </div>

                {exp.verdict && (
                  <div className="p-3 bg-black/40 rounded-lg border border-white/5 flex items-center justify-between text-xs font-mono">
                    <div className="text-gray-200">
                      <span className="text-emerald-400 font-bold">VERDICT: </span>
                      {exp.verdict}
                    </div>
                    <span className="text-sky-400 font-bold shrink-0 ml-2">
                      Confidence: {exp.confidence}%
                    </span>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 2: PERMISSIONED CAMPAIGNS */}
      {activeTab === 'campaigns' && (
        <div className="space-y-4">
          <div className="p-4 bg-emerald-950/20 border border-emerald-800/40 rounded-xl text-xs font-mono text-emerald-300 flex items-center space-x-2">
            <ShieldCheck className="w-4 h-4 shrink-0 text-emerald-400" />
            <span>Strict Anti-Spam Compliance: All outreach utilizes 100% verified opt-in lists, zero scraped phone numbers, zero unsolicited cold messages, and 1-click immediate unsubscribe.</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {marketingCampaigns.map(camp => (
              <div
                key={camp.id}
                className="p-5 rounded-2xl bg-[#0a0e17] border border-white/10 space-y-3 text-xs font-mono"
              >
                <div className="flex justify-between items-center">
                  <span className="text-orange-400 font-bold uppercase">{camp.channel}</span>
                  <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800/40 text-[10px]">
                    {camp.status}
                  </span>
                </div>

                <div className="text-white font-bold font-sans text-sm">{camp.title}</div>
                <div className="text-gray-400 font-sans text-[11px]">{camp.objective}</div>

                <div className="pt-2 border-t border-white/5 space-y-1 text-[11px] text-gray-400">
                  <div>Audience: <span className="text-gray-200 font-sans">{camp.audience}</span></div>
                  <div className="flex justify-between">
                    <span>Performance Metric:</span>
                    <span className="text-emerald-400 font-bold">{camp.metricValue}</span>
                  </div>
                  <div className="flex justify-between text-gray-500">
                    <span>Budget / Spent:</span>
                    <span>${camp.budgetUSD} / ${camp.spentUSD} (Organic)</span>
                  </div>
                </div>

                <button
                  onClick={() => showNotification(`Campaign details for ${camp.title} opened.`, 'info')}
                  className="w-full py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-gray-300 text-[11px] transition"
                >
                  Inspect Campaign Telemetry
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 3: VIRAL RESEARCH MECHANICS */}
      {activeTab === 'viral_forks' && (
        <div className="space-y-4">
          <div className="text-xs font-mono text-gray-400">
            Organic discovery through reproducible science:
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {viralTriggers.map((trig, idx) => (
              <div
                key={idx}
                className="p-5 rounded-2xl bg-[#0a0e17] border border-white/10 space-y-2.5 text-xs font-mono"
              >
                <div className="flex justify-between items-center">
                  <span className="text-white font-bold font-sans text-sm">{trig.action}</span>
                  <span className="text-orange-400 font-bold text-[11px]">K-Factor: {trig.viralKFactor}</span>
                </div>
                <p className="text-gray-400 font-sans text-xs leading-relaxed">{trig.desc}</p>
                <div className="flex justify-between items-center pt-2 border-t border-white/5 text-[10px]">
                  <span className="text-emerald-400">{trig.status}</span>
                  <span className="text-gray-500">Deterministic Reproduction</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 4: SCHOLAR REFERRAL & UNIVERSITY RADAR */}
      {activeTab === 'referrals' && (
        <div className="p-6 rounded-2xl bg-[#0a0e17] border border-white/10 space-y-4 text-xs font-mono">
          <div className="flex justify-between items-center">
            <h3 className="text-sm font-bold text-white font-sans flex items-center space-x-2">
              <Award className="w-4 h-4 text-amber-400" />
              <span>National University AI Fellowship & Referral Program</span>
            </h3>
            <span className="text-emerald-400 text-[10px]">Active Partner Portal</span>
          </div>

          <p className="text-gray-300 font-sans leading-relaxed">
            Academic scholars and lab researchers earn additional sponsored compute credits by publishing verified, reproducible experiments with public Experiment DNA manifests.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
            <div className="p-3 bg-black/40 rounded-xl border border-white/5 space-y-1">
              <div className="text-gray-400 text-[10px]">Verified Student / Faculty</div>
              <div className="text-white font-bold text-sm">+2.0 Extra Compute Hrs/Day</div>
              <div className="text-[10px] text-gray-500">Institutions: IIT, NIT, IISc, IIIT</div>
            </div>
            <div className="p-3 bg-black/40 rounded-xl border border-white/5 space-y-1">
              <div className="text-gray-400 text-[10px]">Published Reproducible Paper</div>
              <div className="text-orange-400 font-bold text-sm">500 Compute Credits</div>
              <div className="text-[10px] text-gray-500">Requires verified ArXiv or GitHub hash</div>
            </div>
            <div className="p-3 bg-black/40 rounded-xl border border-white/5 space-y-1">
              <div className="text-gray-400 text-[10px]">Replicated Experiment Benchmark</div>
              <div className="text-sky-400 font-bold text-sm">100 Credits / Peer Review</div>
              <div className="text-[10px] text-gray-500">Anti-abuse token verification</div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: SECTION 21 MARKETING CREATIVE AUDITOR & AD LAB */}
      {activeTab === 'creative_auditor' && (
        <div className="space-y-6">
          <div className="p-6 rounded-2xl bg-[#0a0e17] border border-white/10 space-y-4">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-white/10 pb-3">
              <div>
                <h3 className="text-base font-bold text-white font-display flex items-center space-x-2">
                  <FileCheck className="w-5 h-5 text-orange-400" />
                  <span>Section 21: Marketing Creative Lab & 13-Point Audit Engine</span>
                </h3>
                <p className="text-xs text-gray-400 font-mono">
                  Every ad creative, social card, and lab poster must pass the 13-point audit threshold (&gt;90%) before publication.
                </p>
              </div>

              <div className="flex items-center space-x-2">
                {creativeAudits.map(cr => (
                  <button
                    key={cr.id}
                    onClick={() => setSelectedCreativeId(cr.id)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-mono font-bold transition ${
                      selectedCreativeId === cr.id
                        ? 'bg-orange-500/20 text-orange-300 border border-orange-500/50'
                        : 'bg-white/5 text-gray-400 hover:text-white border border-white/5'
                    }`}
                  >
                    {cr.id.toUpperCase()} ({cr.score}%)
                  </button>
                ))}
              </div>
            </div>

            {/* Creative Preview Canvas + Live 13-Point Audit Matrix */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Left Column (5 cols): Visual Creative Preview */}
              <div className="lg:col-span-5 space-y-4">
                <div className="p-3 bg-black/40 rounded-xl border border-white/10 text-xs font-mono text-gray-400">
                  <span className="text-gray-500 uppercase text-[10px]">Format:</span> {currentCreative.format}
                </div>

                {/* High-Fidelity Ad Simulation Card */}
                <div className="p-6 rounded-2xl bg-gradient-to-br from-[#0c1322] via-[#080d17] to-[#131b2e] border-2 border-orange-500/40 shadow-2xl relative overflow-hidden space-y-5 text-left">
                  <div className="flex items-center justify-between">
                    <span className="px-2.5 py-0.5 rounded text-[10px] font-mono font-bold uppercase tracking-wider bg-orange-500/20 text-orange-400 border border-orange-500/40">
                      MII RESEARCH
                    </span>
                    <span className="text-[10px] font-mono text-emerald-400 flex items-center space-x-1">
                      <CheckCircle2 className="w-3 h-3" />
                      <span>{currentCreative.status}</span>
                    </span>
                  </div>

                  <div className="space-y-2">
                    <h4 className="text-xl font-extrabold text-white tracking-tight leading-snug font-display">
                      {currentCreative.headline}
                    </h4>
                    <p className="text-xs text-gray-300 leading-relaxed font-sans">
                      {currentCreative.supportingLine}
                    </p>
                  </div>

                  <div className="pt-2 flex items-center justify-between border-t border-white/10">
                    <div className="text-[10px] font-mono text-gray-400 truncate max-w-[200px]">
                      {currentCreative.brandAttribution}
                    </div>
                    <button className="px-4 py-2 bg-orange-500 hover:bg-orange-600 text-white rounded-xl text-xs font-mono font-bold shadow-lg transition shrink-0">
                      {currentCreative.cta}
                    </button>
                  </div>
                </div>

                <div className="p-4 bg-emerald-950/20 border border-emerald-800/40 rounded-xl text-xs font-mono text-emerald-300 flex items-center justify-between">
                  <span>Overall Quality Audit Score:</span>
                  <span className="text-base font-bold text-emerald-400">{currentCreative.score} / 100</span>
                </div>
              </div>

              {/* Right Column (7 cols): The 13 Audit Checks */}
              <div className="lg:col-span-7 space-y-3">
                <div className="text-xs font-mono text-gray-400 flex items-center justify-between">
                  <span>13 Standard Inspection Criteria (Section 21)</span>
                  <span className="text-emerald-400">13 / 13 Passed</span>
                </div>

                <div className="divide-y divide-white/5 border border-white/10 rounded-xl bg-black/40 overflow-hidden text-xs font-mono">
                  {currentCreative.checks.map((chk, i) => (
                    <div key={i} className="p-3 flex items-center justify-between hover:bg-white/5 transition gap-2">
                      <div className="space-y-0.5">
                        <div className="text-white font-bold text-xs">{chk.name}</div>
                        <div className="text-[11px] text-gray-400">{chk.detail}</div>
                      </div>
                      <div className="text-right shrink-0">
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/40">
                          {chk.score}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
