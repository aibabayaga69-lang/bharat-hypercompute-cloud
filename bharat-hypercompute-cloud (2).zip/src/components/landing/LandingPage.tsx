import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { TrustBadge } from '../common/TrustBadge';
import { MII_BRAND, BrandHeaderStrip, SovereignFooter } from '../common/BrandIdentity';
import {
  Cpu,
  BrainCircuit,
  ArrowRight,
  BookOpen,
  FlaskConical,
  ShieldCheck,
  Zap,
  CheckCircle2,
  RefreshCw,
  Terminal,
  Layers,
  ChevronRight,
  Sliders,
  Sparkles,
  HelpCircle,
  Database,
  Box,
  Rocket,
  Flame,
  Award
} from 'lucide-react';

export const LandingPage: React.FC = () => {
  const { setCurrentView } = useApp();
  const [activeFaq, setActiveFaq] = useState<number | null>(null);

  const workflowSteps = [
    { label: 'Idea', icon: Sparkles },
    { label: 'Notebook', icon: BookOpen },
    { label: 'Compute Brain', icon: BrainCircuit },
    { label: 'Training', icon: Flame },
    { label: 'Experiment', icon: FlaskConical },
    { label: 'Model', icon: Box },
    { label: 'API', icon: Rocket }
  ];

  const faqs = [
    {
      q: 'How does Compute Brain decide which accelerator I need?',
      a: 'Compute Brain parses your model parameter count, batch size, dataset token count, and deadline or cost constraints. It matches your workload against available GPU, TPU, and multi-accelerator configurations, prioritizing memory bandwidth and distributed scaling efficiency without requiring manual CUDA setup.'
    },
    {
      q: 'What does "Make in India. Made for Make in India" signify?',
      a: 'MII is the future parent brand, and Bharat HyperCompute Cloud is the flagship AI compute and research product engineered specifically to provide world-class sovereign AI training infrastructure and tools for Indian and global research institutes, universities, and deep-tech enterprises.'
    },
    {
      q: 'Is the free tier really 2 compute-hours per day?',
      a: 'Yes. Free tier researchers receive 2 daily compute-hours for notebook exploration, data pre-processing, and experimental fine-tuning. Daily credits automatically reset at 00:00 UTC without requiring credit card registration.'
    },
    {
      q: 'How does Self-Healing Training work when a worker node fails?',
      a: 'Our runtime continuously takes micro-checkpoints based on epoch and step loss metrics. If a hardware fault, packet drop, or worker heartbeat loss is detected, the scheduler provisions a replacement node and restores model weights and optimizer states seamlessly.'
    },
    {
      q: 'Can I connect my own on-premise GPU clusters or private clouds?',
      a: 'Yes. Bharat HyperCompute Cloud is provider-agnostic. Through our ProviderAdapter architecture, you can attach connected nodes, private VPC clusters, or third-party cloud accelerators directly into your unified workspace.'
    }
  ];

  return (
    <div className="min-h-screen bg-[#07090e] text-gray-200">
      {/* Sovereign Top Header Strip */}
      <BrandHeaderStrip />

      {/* SECTION 1: HERO */}
      <section className="relative pt-12 pb-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto overflow-hidden">
        {/* Subtle background glow */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-96 h-96 bg-orange-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute top-1/3 right-1/4 w-80 h-80 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative text-center max-w-4xl mx-auto space-y-6">
          {/* Master Brand & Product Architecture Tag */}
          <div className="inline-flex items-center space-x-2 px-3 py-1.5 rounded-full bg-white/5 border border-white/10 text-xs font-mono">
            <span className="text-orange-400 font-bold">{MII_BRAND.parentBrand}</span>
            <span className="text-gray-500">/</span>
            <span className="text-gray-300 font-medium">{MII_BRAND.productName}</span>
            <span className="hidden sm:inline text-gray-600">|</span>
            <span className="hidden sm:inline text-amber-300">{MII_BRAND.officialTagline}</span>
          </div>

          <h1 className="text-4xl sm:text-6xl lg:text-7xl font-extrabold text-white tracking-tight font-display">
            Build AI.{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-400 via-amber-300 to-indigo-400">
              We Handle the Compute.
            </span>
          </h1>

          <p className="text-lg sm:text-xl text-gray-300 max-w-2xl mx-auto leading-relaxed">
            Train, fine-tune, experiment and deploy AI models without becoming an infrastructure engineer.
          </p>

          <div className="text-xs font-mono text-gray-400 flex items-center justify-center space-x-2">
            <span>{MII_BRAND.founderAttribution}</span>
            <span className="text-gray-600">•</span>
            <span className="text-amber-400/90">{MII_BRAND.positioning}</span>
          </div>

          <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-4">
            <button
              onClick={() => setCurrentView('overview')}
              className="w-full sm:w-auto px-8 py-3.5 rounded-xl bg-gradient-to-r from-orange-500 to-amber-600 hover:from-orange-600 hover:to-amber-700 text-white font-bold text-sm shadow-xl shadow-orange-500/20 hover:scale-[1.02] transition flex items-center justify-center space-x-2"
            >
              <span>Start Building Free</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={() => setCurrentView('compute_brain')}
              className="w-full sm:w-auto px-7 py-3.5 rounded-xl bg-white/5 hover:bg-white/10 text-gray-200 border border-white/10 font-semibold text-sm transition flex items-center justify-center space-x-2"
            >
              <span>Explore HyperCompute</span>
              <BrainCircuit className="w-4 h-4 text-orange-400" />
            </button>
          </div>

          {/* Core Product Loop Visual Flow */}
          <div className="pt-12">
            <div className="text-[11px] font-mono uppercase tracking-widest text-gray-500 mb-3">
              The Sovereign AI Research Loop
            </div>
            <div className="flex items-center justify-center flex-wrap gap-2 sm:gap-3">
              {workflowSteps.map((step, idx) => {
                const Icon = step.icon;
                return (
                  <React.Fragment key={step.label}>
                    <div className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-white/5 border border-white/10 text-xs font-mono text-gray-300">
                      <Icon className="w-3.5 h-3.5 text-orange-400" />
                      <span>{step.label}</span>
                    </div>
                    {idx < workflowSteps.length - 1 && (
                      <ChevronRight className="w-3 h-3 text-gray-600 shrink-0" />
                    )}
                  </React.Fragment>
                );
              })}
            </div>
          </div>
        </div>
      </section>

      {/* SECTION 2: PROBLEM */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto border-t border-white/5">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <h2 className="text-2xl sm:text-3xl font-bold font-display text-white">
            The Infrastructure Trap in AI Research
          </h2>
          <p className="text-gray-400 mt-2 text-sm sm:text-base">
            Researchers spend up to 60% of their research cycles wrestling with CUDA drivers, out-of-memory errors, NCCL network timeouts, and Kubernetes orchestrations instead of advancing model architectures.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-6 rounded-xl bg-[#0b0f19] border border-white/10">
            <div className="text-rose-400 font-mono text-xs uppercase mb-2">Pain Point 01</div>
            <h3 className="text-base font-bold text-white mb-2">CUDA & Driver Hell</h3>
            <p className="text-xs text-gray-400 leading-relaxed">
              Mismatched PyTorch, cuDNN, and kernel dependencies stalling experiments before a single gradient step executes.
            </p>
          </div>

          <div className="p-6 rounded-xl bg-[#0b0f19] border border-white/10">
            <div className="text-rose-400 font-mono text-xs uppercase mb-2">Pain Point 02</div>
            <h3 className="text-base font-bold text-white mb-2">Cluster Fragility</h3>
            <p className="text-xs text-gray-400 leading-relaxed">
              A single transient worker node dropout crashes an 18-hour training run with lost weights and wasted compute credits.
            </p>
          </div>

          <div className="p-6 rounded-xl bg-[#0b0f19] border border-white/10">
            <div className="text-rose-400 font-mono text-xs uppercase mb-2">Pain Point 03</div>
            <h3 className="text-base font-bold text-white mb-2">Deployment Friction</h3>
            <p className="text-xs text-gray-400 leading-relaxed">
              Turning trained weights into a low-latency, scalable production API endpoint often requires an entire MLOps engineering team.
            </p>
          </div>
        </div>
      </section>

      {/* SECTION 3: COMPUTE BRAIN */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto border-t border-white/5">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          <div className="lg:col-span-5 space-y-4">
            <div className="inline-flex items-center space-x-2 text-xs font-mono text-orange-400">
              <BrainCircuit className="w-4 h-4" />
              <span>CORE DIFFERENTIATOR</span>
            </div>
            <h2 className="text-3xl font-bold font-display text-white">
              Compute Brain: Intent to Infrastructure
            </h2>
            <p className="text-sm text-gray-300 leading-relaxed">
              Instead of forcing researchers to manually pick GPU architectures, VRAM quotas, and distributed topologies, simply describe what you want in plain natural language.
            </p>
            <div className="p-4 rounded-lg bg-black/60 border border-orange-500/20 text-xs font-mono text-gray-300 space-y-2">
              <div className="text-orange-300">"Fine-tune my 7B model on this dataset and finish as quickly as reasonably possible."</div>
              <div className="text-gray-500">↓ Compute Brain Recommendation:</div>
              <div className="text-emerald-400 font-semibold">4× BHARAT H100 SXM5 (80GB) DDP • bf16 • ~2.1 hrs</div>
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => setCurrentView('compute_brain')}
                className="px-5 py-2 rounded-lg bg-orange-500 hover:bg-orange-600 text-white text-xs font-bold transition"
              >
                Test Compute Brain Intent
              </button>
            </div>
          </div>

          <div className="lg:col-span-7 bg-[#0d121f] border border-white/10 rounded-2xl p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-white/10 pb-3 text-xs font-mono">
              <span className="text-gray-400">ANALYSIS PIPELINE</span>
              <TrustBadge type="SUGGESTED" size="xs" />
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
              <div className="bg-white/5 p-3 rounded-lg border border-white/5">
                <div className="text-[10px] text-gray-400 font-mono">Workload</div>
                <div className="text-xs font-bold text-white mt-1">7B Fine-Tuning</div>
              </div>
              <div className="bg-white/5 p-3 rounded-lg border border-white/5">
                <div className="text-[10px] text-gray-400 font-mono">Strategy</div>
                <div className="text-xs font-bold text-orange-400 mt-1">Balanced</div>
              </div>
              <div className="bg-white/5 p-3 rounded-lg border border-white/5">
                <div className="text-[10px] text-gray-400 font-mono">Est. Runtime</div>
                <div className="text-xs font-bold text-white mt-1">2h 10m</div>
              </div>
              <div className="bg-white/5 p-3 rounded-lg border border-white/5">
                <div className="text-[10px] text-gray-400 font-mono">Usage</div>
                <div className="text-xs font-bold text-sky-400 mt-1">68 Credits</div>
              </div>
            </div>

            <div className="p-3 bg-black/40 rounded-lg text-xs font-mono text-gray-300 border border-white/5 space-y-1">
              <div className="text-gray-400 text-[11px]">Compute Brain Reasoning:</div>
              <p className="text-gray-300">
                «Workload benefits from 4-way Distributed Data Parallel (DDP). 80GB HBM3 eliminates offloading bottlenecks, reducing total wall-clock time by 68% compared to single-accelerator training.»
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION 4: HYPERCOMPUTE & HARDWARE CATALOG */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto border-t border-white/5">
        <div className="text-center max-w-2xl mx-auto mb-10">
          <h2 className="text-2xl sm:text-3xl font-bold font-display text-white">
            Provider-Agnostic HyperCompute Architecture
          </h2>
          <p className="text-gray-400 text-xs sm:text-sm mt-2">
            Seamlessly route workloads across GPU, TPU, and connected on-premise compute nodes.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="p-5 rounded-xl bg-[#0b0f19] border border-white/10 hover:border-orange-500/40 transition space-y-2">
            <div className="flex justify-between items-center text-xs">
              <span className="font-mono text-orange-400">GPU ACCELERATOR</span>
              <TrustBadge type="SIMULATED" size="xs" />
            </div>
            <div className="font-bold text-white text-sm">BHARAT H100 SXM5</div>
            <div className="text-xs text-gray-400 font-mono">80GB HBM3 • 1,979 TFLOPS</div>
            <div className="text-xs text-gray-300">Engineered for large-scale LLM pre-training & fine-tuning.</div>
          </div>

          <div className="p-5 rounded-xl bg-[#0b0f19] border border-white/10 hover:border-orange-500/40 transition space-y-2">
            <div className="flex justify-between items-center text-xs">
              <span className="font-mono text-amber-400">GPU ACCELERATOR</span>
              <TrustBadge type="SIMULATED" size="xs" />
            </div>
            <div className="font-bold text-white text-sm">BHARAT A100 TensorCore</div>
            <div className="text-xs text-gray-400 font-mono">80GB SXM4 • 624 TFLOPS</div>
            <div className="text-xs text-gray-300">Cost-efficient workhorse for medium batches and evaluation.</div>
          </div>

          <div className="p-5 rounded-xl bg-[#0b0f19] border border-white/10 hover:border-orange-500/40 transition space-y-2">
            <div className="flex justify-between items-center text-xs">
              <span className="font-mono text-sky-400">TPU POD SLICE</span>
              <TrustBadge type="SIMULATED" size="xs" />
            </div>
            <div className="font-bold text-white text-sm">BHARAT TPU v4-16</div>
            <div className="text-xs text-gray-400 font-mono">128GB HBM • 1,100 TFLOPS</div>
            <div className="text-xs text-gray-300">Optimized for JAX/Flax tensor-parallel model architectures.</div>
          </div>

          <div className="p-5 rounded-xl bg-[#0b0f19] border border-white/10 hover:border-orange-500/40 transition space-y-2">
            <div className="flex justify-between items-center text-xs">
              <span className="font-mono text-emerald-400">ON-PREM NODE</span>
              <TrustBadge type="REQUIRES_PROVIDER" size="xs" />
            </div>
            <div className="font-bold text-white text-sm">Connected Node Adapter</div>
            <div className="text-xs text-gray-400 font-mono">64 vCPU • 256GB RAM</div>
            <div className="text-xs text-gray-300">Attach institutional workstation clusters to the unified console.</div>
          </div>
        </div>
      </section>

      {/* SECTION 5: AI NOTEBOOK */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto border-t border-white/5">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
          <div className="space-y-4">
            <div className="text-xs font-mono text-orange-400">AI-NATIVE RESEARCH CANVAS</div>
            <h2 className="text-3xl font-bold font-display text-white">
              An AI Notebook Built for Serious Research
            </h2>
            <p className="text-sm text-gray-300 leading-relaxed">
              Not another generic Jupyter clone. Experience dataset inspection blocks, real-time metrics telemetry, connected accelerator kernel switching, and an integrated AI Research Command Bar.
            </p>
            <ul className="space-y-2 text-xs text-gray-300">
              <li className="flex items-center space-x-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>One-click run cell & run all across multi-GPU kernels</span>
              </li>
              <li className="flex items-center space-x-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Integrated AI Copilot: Explain errors, optimize memory & generate training loops</span>
              </li>
              <li className="flex items-center space-x-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Direct binding to Dataset Center and Model Registry</span>
              </li>
            </ul>
            <button
              onClick={() => setCurrentView('notebooks')}
              className="px-5 py-2.5 rounded-lg bg-orange-500 hover:bg-orange-600 text-white font-semibold text-xs transition"
            >
              Open AI Research Notebook
            </button>
          </div>

          <div className="bg-[#0b0f19] border border-white/10 rounded-xl p-4 font-mono text-xs space-y-3">
            <div className="flex items-center justify-between border-b border-white/10 pb-2 text-gray-400">
              <div className="flex items-center space-x-2">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-500 inline-block" />
                <span className="w-2.5 h-2.5 rounded-full bg-amber-500 inline-block" />
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 inline-block" />
                <span className="text-gray-300 text-[11px] ml-2">01_FineTune_IndicLLM.ipynb</span>
              </div>
              <span className="text-emerald-400 text-[10px]">Kernel: 4x H100 (Connected)</span>
            </div>
            <div className="p-2.5 bg-black/50 rounded text-gray-300 border border-white/5">
              <div className="text-gray-500"># In[2]</div>
              <div className="text-orange-300">from bharat_hypercompute import ComputeBrain, SelfHealingTrainer</div>
              <div>trainer = SelfHealingTrainer(model="indic-7b", cluster="ddp_h100")</div>
              <div>trainer.train()</div>
            </div>
            <div className="p-2.5 bg-black/70 rounded border border-emerald-500/20 text-emerald-400 text-[11px]">
              <div>[Compute Brain] Allocated 4x BHARAT H100 SXM5 80GB</div>
              <div>[Step 100/2000] Train Loss: 0.812 | Perplexity: 2.25 | 14,200 tok/s</div>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION 6 & 7: EXPERIMENT LAB, DNA & REPRODUCIBILITY */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto border-t border-white/5">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <div className="text-xs font-mono text-orange-400 uppercase">Scientific Rigor</div>
          <h2 className="text-2xl sm:text-3xl font-bold font-display text-white mt-1">
            Experiment DNA & Guaranteed Reproducibility
          </h2>
          <p className="text-gray-400 text-xs sm:text-sm mt-2">
            Every experiment is cryptographically fingerprinted into an Experiment DNA hash combining code commit, dataset version, seed, hyperparameters, and accelerator topology.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-6 rounded-xl bg-[#0b0f19] border border-white/10 space-y-3">
            <FlaskConical className="w-6 h-6 text-orange-400" />
            <h3 className="text-base font-bold text-white">Experiment Matrix</h3>
            <p className="text-xs text-gray-400 leading-relaxed">
              Side-by-side comparative inspection of train loss, validation perplexity, token throughput, and credit consumption without arbitrary winner declarations.
            </p>
          </div>

          <div className="p-6 rounded-xl bg-[#0b0f19] border border-white/10 space-y-3">
            <Cpu className="w-6 h-6 text-amber-400" />
            <h3 className="text-base font-bold text-white">Experiment DNA Fingerprint</h3>
            <p className="text-xs text-gray-400 leading-relaxed">
              Compact fingerprint (e.g. DNA-9a8c2f1e4b) allowing researchers to inspect exactly what changed and what remained identical between training runs.
            </p>
          </div>

          <div className="p-6 rounded-xl bg-[#0b0f19] border border-white/10 space-y-3">
            <RefreshCw className="w-6 h-6 text-indigo-400" />
            <h3 className="text-base font-bold text-white">1-Click Fork & Reproduce</h3>
            <p className="text-xs text-gray-400 leading-relaxed">
              Instantly re-instantiate identical training environments, random seeds, and checkpoints with a single click.
            </p>
          </div>
        </div>
      </section>

      {/* SECTION 8: SELF-HEALING TRAINING */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto border-t border-white/5">
        <div className="p-8 rounded-2xl bg-gradient-to-br from-[#0c1220] to-[#07090e] border border-orange-500/20 shadow-xl space-y-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <div className="inline-flex items-center space-x-2 text-xs font-mono text-orange-400">
                <ShieldCheck className="w-4 h-4" />
                <span>RESILIENT COMPUTING</span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-bold font-display text-white mt-1">
                Self-Healing Training & Auto-Checkpoints
              </h2>
              <p className="text-sm text-gray-300 max-w-xl mt-1">
                Hardware dropout shouldn't kill your research. Automatic step-based checkpoints and worker failure recovery restore training state seamlessly.
              </p>
            </div>

            <button
              onClick={() => setCurrentView('compute_brain')}
              className="px-6 py-3 rounded-xl bg-orange-500 hover:bg-orange-600 text-white font-bold text-xs shadow-lg transition"
            >
              Test Self-Healing Failure Demo
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs font-mono">
            <div className="p-3 bg-black/40 rounded-lg border border-white/5">
              <span className="text-gray-400">1. Fault Detection</span>
              <p className="text-gray-300 mt-1">Worker heartbeat loss identified within 1.2s</p>
            </div>
            <div className="p-3 bg-black/40 rounded-lg border border-white/5">
              <span className="text-gray-400">2. Checkpoint Recall</span>
              <p className="text-gray-300 mt-1">Recovers last verified step weights from storage</p>
            </div>
            <div className="p-3 bg-black/40 rounded-lg border border-white/5">
              <span className="text-gray-400">3. Node Reallocation</span>
              <p className="text-gray-300 mt-1">Hot-swaps healthy accelerator from spare pool</p>
            </div>
            <div className="p-3 bg-black/40 rounded-lg border border-white/5">
              <span className="text-emerald-400">4. Auto-Resume</span>
              <p className="text-gray-300 mt-1">DDP ring re-synced; training proceeds</p>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION 9: MODEL → API */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto border-t border-white/5">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
          <div className="space-y-4">
            <div className="text-xs font-mono text-orange-400 uppercase">Production Serving</div>
            <h2 className="text-3xl font-bold font-display text-white">
              Model → API in Seconds
            </h2>
            <p className="text-sm text-gray-300 leading-relaxed">
              Once an experiment converges and registers in the Model Registry, deploy it directly to a serverless vLLM or Triton endpoint. Built-in latency observability, rate limiting, and masked API key handling.
            </p>
            <button
              onClick={() => setCurrentView('deployments')}
              className="px-5 py-2.5 rounded-lg bg-orange-500 hover:bg-orange-600 text-white font-semibold text-xs transition"
            >
              Open Live API Playground
            </button>
          </div>

          <div className="p-5 rounded-xl bg-[#0b0f19] border border-white/10 font-mono text-xs space-y-3">
            <div className="flex justify-between items-center text-gray-400 border-b border-white/10 pb-2">
              <span>cURL Inference Endpoint</span>
              <TrustBadge type="REQUIRES_API" size="xs" />
            </div>
            <div className="p-3 bg-black/60 rounded text-gray-300 overflow-x-auto text-[11px] leading-relaxed">
              curl -X POST https://api.bharat-hypercompute.in/v1/models/indic-7b:generate \<br />
              &nbsp;&nbsp;-H "Authorization: Bearer bhc_live_9f82••••••••"<br />
              &nbsp;&nbsp;-H "Content-Type: application/json" \<br />
              &nbsp;&nbsp;-d '{`{"prompt": "नमस्ते, मुझे AI के बारे में बताएं", "max_tokens": 128}`}'
            </div>
            <div className="flex justify-between text-[11px] text-gray-400">
              <span>p95 Latency: <strong className="text-emerald-400 font-bold">24ms</strong></span>
              <span>Error Rate: <strong className="text-emerald-400 font-bold">0.02%</strong></span>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION 10 & 11 & 12: PLANS & COST TRANSPARENCY */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto border-t border-white/5">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <div className="text-xs font-mono text-orange-400 uppercase">Zero Hidden Fees</div>
          <h2 className="text-3xl font-bold font-display text-white mt-1">
            Cost Guardian & Transparent Plans
          </h2>
          <p className="text-gray-400 text-xs sm:text-sm mt-2">
            Cost Guardian checks job credit consumption before any workload launches. No silent bill shocks.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          {/* FREE PLAN */}
          <div className="p-6 rounded-xl bg-[#0b0f19] border border-orange-500/40 relative space-y-4">
            <div className="text-xs font-mono text-orange-400 font-bold">SOVEREIGN FREE</div>
            <div className="text-2xl font-bold text-white">2 Compute Hrs / Day</div>
            <p className="text-xs text-gray-400">
              For students, researchers, and early experimenters. Daily reset at 00:00 UTC.
            </p>
            <ul className="text-xs text-gray-300 space-y-2">
              <li className="flex items-center space-x-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>2.0 hours daily compute</span>
              </li>
              <li className="flex items-center space-x-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>AI Notebook & Dataset Center</span>
              </li>
              <li className="flex items-center space-x-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>1 Active Model Deployment</span>
              </li>
            </ul>
            <button
              onClick={() => setCurrentView('overview')}
              className="w-full py-2 bg-orange-500 hover:bg-orange-600 text-white rounded-lg text-xs font-bold transition"
            >
              Start Free (No Card)
            </button>
          </div>

          {/* PRO PLAN */}
          <div className="p-6 rounded-xl bg-[#0b0f19] border border-white/10 space-y-4">
            <div className="text-xs font-mono text-gray-400">PRO RESEARCHER</div>
            <div className="text-2xl font-bold text-white">₹4,999 <span className="text-xs font-normal text-gray-400">/ mo</span></div>
            <p className="text-xs text-gray-400">
              For solo AI engineers and independent ML researchers running continuous jobs.
            </p>
            <ul className="text-xs text-gray-300 space-y-2">
              <li className="flex items-center space-x-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>150 Compute Credits / mo</span>
              </li>
              <li className="flex items-center space-x-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>Priority queue placement</span>
              </li>
              <li className="flex items-center space-x-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>Up to 8-GPU DDP allocations</span>
              </li>
            </ul>
            <button
              onClick={() => setCurrentView('overview')}
              className="w-full py-2 bg-white/10 hover:bg-white/20 text-white rounded-lg text-xs font-bold transition"
            >
              Select Pro
            </button>
          </div>

          {/* TEAM PLAN */}
          <div className="p-6 rounded-xl bg-[#0b0f19] border border-white/10 space-y-4">
            <div className="text-xs font-mono text-gray-400">TEAM / LAB</div>
            <div className="text-2xl font-bold text-white">₹24,999 <span className="text-xs font-normal text-gray-400">/ mo</span></div>
            <p className="text-xs text-gray-400">
              For university labs, AI startups, and collaborative research teams.
            </p>
            <ul className="text-xs text-gray-300 space-y-2">
              <li className="flex items-center space-x-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>1,000 Compute Credits / mo</span>
              </li>
              <li className="flex items-center space-x-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>RBAC organization workspace</span>
              </li>
              <li className="flex items-center space-x-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>Shared Dataset & Model Registry</span>
              </li>
            </ul>
            <button
              onClick={() => setCurrentView('overview')}
              className="w-full py-2 bg-white/10 hover:bg-white/20 text-white rounded-lg text-xs font-bold transition"
            >
              Select Team
            </button>
          </div>

          {/* ENTERPRISE & MII FOUNDER */}
          <div className="p-6 rounded-xl bg-[#0b0f19] border border-amber-500/40 relative space-y-4">
            <div className="text-xs font-mono text-amber-400 font-bold">MII FOUNDER / ENTERPRISE</div>
            <div className="text-2xl font-bold text-white">Custom / Unlimited</div>
            <p className="text-xs text-gray-400">
              Dedicated pod reservations, private VPC interconnects, and bypass quotas for verified MII partners.
            </p>
            <ul className="text-xs text-gray-300 space-y-2">
              <li className="flex items-center space-x-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-amber-400" />
                <span>Founder Quota Bypass</span>
              </li>
              <li className="flex items-center space-x-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-amber-400" />
                <span>Sovereign on-prem cluster adapters</span>
              </li>
              <li className="flex items-center space-x-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-amber-400" />
                <span>Dedicated HPC Solution Architect</span>
              </li>
            </ul>
            <button
              onClick={() => setCurrentView('overview')}
              className="w-full py-2 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 rounded-lg text-xs font-bold transition"
            >
              Contact MII Architecture
            </button>
          </div>
        </div>
      </section>

      {/* SECTION 13: SECURITY */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto border-t border-white/5">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-6 rounded-xl bg-[#0b0f19] border border-white/10 space-y-2">
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
            <h3 className="text-sm font-bold text-white">Strict Isolation</h3>
            <p className="text-xs text-gray-400">
              Workloads execute in isolated container environments with dedicated memory spaces and encrypted ephemeral storage.
            </p>
          </div>

          <div className="p-6 rounded-xl bg-[#0b0f19] border border-white/10 space-y-2">
            <Award className="w-5 h-5 text-orange-400" />
            <h3 className="text-sm font-bold text-white">Secrets & API Keys</h3>
            <p className="text-xs text-gray-400">
              API secrets are masked immediately upon generation. Zero client-side exposure of provider credentials.
            </p>
          </div>

          <div className="p-6 rounded-xl bg-[#0b0f19] border border-white/10 space-y-2">
            <Terminal className="w-5 h-5 text-indigo-400" />
            <h3 className="text-sm font-bold text-white">Full Audit Logs</h3>
            <p className="text-xs text-gray-400">
              Every experiment launch, code change, checkpoint restore, and API deployment is logged with IP, actor, and timestamp.
            </p>
          </div>
        </div>
      </section>

      {/* SECTION 14: FAQ */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto border-t border-white/5">
        <h2 className="text-2xl sm:text-3xl font-bold font-display text-white text-center mb-8">
          Frequently Asked Questions
        </h2>

        <div className="space-y-3">
          {faqs.map((item, idx) => (
            <div
              key={idx}
              className="rounded-xl bg-[#0b0f19] border border-white/10 overflow-hidden"
            >
              <button
                onClick={() => setActiveFaq(activeFaq === idx ? null : idx)}
                className="w-full p-4 text-left flex items-center justify-between text-sm font-semibold text-white hover:bg-white/5 transition"
              >
                <span>{item.q}</span>
                <span className="text-orange-400 font-mono text-lg">{activeFaq === idx ? '−' : '+'}</span>
              </button>
              {activeFaq === idx && (
                <div className="px-4 pb-4 text-xs text-gray-400 leading-relaxed border-t border-white/5 pt-3">
                  {item.a}
                </div>
              )}
            </div>
          ))}
        </div>
      </section>

      {/* SECTION 15: ABOUT & FOUNDER ATTRIBUTION */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto border-t border-white/5 space-y-6">
        <div className="p-6 sm:p-8 rounded-2xl bg-[#090d15] border border-white/10 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-white/10 pb-4">
            <div>
              <div className="text-xs font-mono text-orange-400 font-bold uppercase tracking-wider">
                {MII_BRAND.parentBrand}
              </div>
              <div className="text-lg font-bold text-white font-display">
                {MII_BRAND.productName}
              </div>
            </div>
            <div className="text-xs font-mono text-amber-300">
              {MII_BRAND.officialTagline}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2 text-xs text-gray-300 leading-relaxed">
            <div className="space-y-2">
              <div className="text-white font-semibold font-mono uppercase tracking-wider text-[11px]">
                Product Mission
              </div>
              <p>
                Bharat HyperCompute Cloud is built to eliminate infrastructure friction for AI researchers, labs, and enterprises across India.
                Our mission is simple: <strong className="text-white">{MII_BRAND.positioning}</strong>
              </p>
            </div>
            <div className="space-y-2">
              <div className="text-white font-semibold font-mono uppercase tracking-wider text-[11px]">
                Leadership & Provenance
              </div>
              <p>
                <strong className="text-white">{MII_BRAND.founderAttribution}</strong>. Designed as a sovereign, self-healing national AI training engine, adhering strictly to Digital Personal Data Protection (DPDP) standards with zero artificial claims or undisclosed corporate affiliations.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION 16: FINAL CTA */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 max-w-5xl mx-auto text-center border-t border-white/5 space-y-6">
        <div className="inline-block text-xs font-mono text-orange-400">
          {MII_BRAND.officialTagline}
        </div>
        <h2 className="text-3xl sm:text-5xl font-extrabold text-white font-display">
          Ready to Build Sovereign AI?
        </h2>
        <p className="text-sm sm:text-base text-gray-400 max-w-xl mx-auto">
          Experience frictionless AI research, intelligent compute scheduling, and reliable model deployment today.
        </p>

        <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-4">
          <button
            onClick={() => setCurrentView('overview')}
            className="w-full sm:w-auto px-8 py-3.5 rounded-xl bg-gradient-to-r from-orange-500 to-amber-600 hover:from-orange-600 hover:to-amber-700 text-white font-bold text-sm shadow-xl shadow-orange-500/20 transition"
          >
            Launch Bharat HyperCompute Console
          </button>
          <button
            onClick={() => setCurrentView('compute_brain')}
            className="w-full sm:w-auto px-6 py-3.5 rounded-xl bg-white/5 hover:bg-white/10 text-gray-200 border border-white/10 font-semibold text-sm transition"
          >
            Explore Compute Brain
          </button>
        </div>
      </section>

      {/* Sovereign Global Footer */}
      <SovereignFooter onNavigate={setCurrentView} />
    </div>
  );
};
