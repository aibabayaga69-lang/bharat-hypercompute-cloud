import React from 'react';
import { useApp } from '../../context/AppContext';
import { TrustBadge } from '../common/TrustBadge';
import {
  BarChart3,
  Zap,
  Crown,
  Clock,
  HardDrive,
  Cpu,
  Layers,
  CheckCircle2,
  Sliders,
  DollarSign,
  PieChart
} from 'lucide-react';

export const UsageCenterView: React.FC = () => {
  const { user, toggleEntitlement, accelerators } = useApp();

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-8 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center space-x-2">
            <span className="text-xs font-mono text-orange-400 font-bold uppercase tracking-wider">
              RESOURCE ACCOUNTING
            </span>
            <span className="text-gray-600">/</span>
            <TrustBadge type="ESTIMATED" size="xs" />
            <TrustBadge type="DEMO" size="xs" />
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white font-display flex items-center space-x-2">
            <BarChart3 className="w-7 h-7 text-orange-400" />
            <span>Usage & Compute Center</span>
          </h1>
          <p className="text-xs sm:text-sm text-gray-400">
            Real-time accounting of accelerator hours, storage allocations, and active entitlements.
          </p>
        </div>

        {/* Entitlement Switcher Banner */}
        <button
          onClick={toggleEntitlement}
          className="px-4 py-2 rounded-xl bg-gradient-to-r from-orange-500/20 to-amber-500/20 hover:from-orange-500/30 hover:to-amber-500/30 text-orange-300 border border-orange-500/30 font-mono text-xs font-bold transition flex items-center space-x-2 self-start sm:self-auto"
        >
          <Sliders className="w-4 h-4" />
          <span>
            {user.entitlement === 'founder'
              ? 'Active: MII FOUNDER (Click for Free)'
              : 'Active: FREE TIER (Click for Founder)'}
          </span>
        </button>
      </div>

      {/* Main Quota Card */}
      <div className="p-6 rounded-2xl bg-[#0a0e17] border border-white/10 space-y-6 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/10 pb-4">
          <div className="space-y-1">
            <div className="flex items-center space-x-2">
              <span className="text-xs font-mono text-gray-400 uppercase">Account Entitlement:</span>
              <span className="text-sm font-bold text-white font-mono uppercase">
                {user.entitlement === 'founder' ? 'MII FOUNDER ACCOUNT' : 'FREE USER PLAN'}
              </span>
              {user.entitlement === 'founder' && (
                <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-mono font-bold flex items-center space-x-1">
                  <Crown className="w-3 h-3" />
                  <span>PRIORITY PODS</span>
                </span>
              )}
            </div>
            <p className="text-xs text-gray-400">
              {user.entitlement === 'founder'
                ? 'Unlimited compute credits quota. Priority cluster scheduler. Note: Real hardware availability still applies.'
                : 'Sovereign Free Plan: 2.0 compute-hours allocated daily. Daily quota resets every 24 hours at 00:00 UTC.'}
            </p>
          </div>

          <div className="text-right font-mono text-xs text-gray-400">
            <div>Daily Reset Clock: <span className="text-white">{user.resetTime}</span></div>
            <div className="text-[10px] text-emerald-400 font-sans mt-0.5">Billing Currency: Indian Rupee (INR)</div>
          </div>
        </div>

        {/* Meter & Progress */}
        <div className="space-y-2">
          <div className="flex justify-between text-xs font-mono">
            <span className="text-gray-400">Today's Compute Consumption</span>
            <span className="text-orange-400 font-bold">
              {user.entitlement === 'founder'
                ? 'Unlimited (14.8 hrs logged)'
                : `${user.dailyComputeHoursUsed.toFixed(2)} / ${user.dailyComputeHoursLimit} hrs used (42%)`}
            </span>
          </div>

          <div className="w-full bg-white/10 h-3 rounded-full overflow-hidden">
            <div
              className={`h-full transition-all duration-300 ${
                user.entitlement === 'founder' ? 'bg-amber-400' : 'bg-gradient-to-r from-orange-500 to-amber-500'
              }`}
              style={{
                width: user.entitlement === 'founder' ? '100%' : `${(user.dailyComputeHoursUsed / user.dailyComputeHoursLimit) * 100}%`
              }}
            />
          </div>

          <div className="flex justify-between text-[11px] font-mono text-gray-500 pt-1">
            <span>Remaining Today: {user.entitlement === 'founder' ? '∞ (No Quota Cap)' : '1.15 hrs'}</span>
            <span>Concurrent Jobs Allowed: {user.entitlement === 'founder' ? '8 pods' : '1 pod'}</span>
          </div>
        </div>
      </div>

      {/* Breakdown by Accelerators */}
      <div className="rounded-xl bg-[#0a0e17] border border-white/10 overflow-hidden shadow-xl">
        <div className="p-4 bg-black/40 border-b border-white/10 flex items-center justify-between text-xs font-mono">
          <span className="text-gray-300 font-bold uppercase">Accelerator Catalog & Hourly Rates</span>
          <TrustBadge type="ESTIMATED" size="xs" />
        </div>

        <div className="divide-y divide-white/5 font-mono text-xs text-gray-300">
          {accelerators.map(acc => (
            <div key={acc.id} className="p-4 flex flex-col md:flex-row md:items-center justify-between gap-3 hover:bg-white/5 transition">
              <div className="space-y-1">
                <div className="flex items-center space-x-2">
                  <Cpu className="w-4 h-4 text-orange-400" />
                  <span className="font-bold text-white">{acc.name}</span>
                  <TrustBadge type={acc.isDemo ? 'DEMO' : 'REQUIRES_PROVIDER'} size="xs" />
                </div>
                <div className="text-xs text-gray-400 font-sans">
                  {acc.category} • {acc.vramGB > 0 ? `${acc.vramGB} GB VRAM • ` : ''}{acc.teraflops} TFLOPS • {acc.provider}
                </div>
              </div>

              <div className="flex items-center space-x-4 shrink-0">
                <div className="text-right">
                  <div className="text-emerald-400 font-bold">{acc.costPerHourCredits} credits / hr</div>
                  <div className="text-[10px] text-gray-500">Status: {acc.status}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
