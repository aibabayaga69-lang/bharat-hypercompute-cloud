import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { TrustBadge } from '../common/TrustBadge';
import { ComputeIntentPlan } from '../../types';
import { ComputeBrain3DPipeline } from './ComputeBrain3DPipeline';
import { DistributedTraining3DRing } from './DistributedTraining3DRing';
import { DynamicAIInterfaceEngine } from './DynamicAIInterfaceEngine';
import {
  BrainCircuit,
  Sparkles,
  Zap,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  Play,
  RotateCcw,
  Cpu,
  ChevronRight,
  Clock,
  ArrowRight,
  Sliders,
  DollarSign,
  Layers,
  Flame,
  ShieldAlert,
  Activity,
  Globe,
  History,
  HardDrive
} from 'lucide-react';

export const ComputeBrainView: React.FC = () => {
  const {
    user,
    project,
    activeIntent,
    setActiveIntent,
    executeIntentPlan,
    selfHealingState,
    startSelfHealingDemo,
    simulateWorkerFailure,
    resetSelfHealingDemo,
    savedCheckpoints,
    rollbackTrainingToCheckpoint,
    restoreCheckpoint,
    showNotification
  } = useApp();

  const [activeBrainTab, setActiveBrainTab] = useState<'intent_engine' | 'pipeline_3d' | 'distributed_3d' | 'self_healing'>('intent_engine');
  const [showRollbackOptions, setShowRollbackOptions] = useState(false);
  const [intentInput, setIntentInput] = useState('');
  const [selectedStrategy, setSelectedStrategy] = useState<'auto' | 'fastest' | 'balanced' | 'lowest_cost'>('balanced');
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const sampleIntents = [
    {
      title: 'Fastest 7B Fine-Tuning',
      query: 'Fine-tune my 7B model on Bhasha-v3 and finish as quickly as reasonably possible.',
      strategy: 'fastest' as const
    },
    {
      title: 'Lowest Cost Experiment',
      query: 'Run a parameter-efficient LoRA experiment on Hindi instructions as cheaply as possible.',
      strategy: 'lowest_cost' as const
    },
    {
      title: 'Balanced Production Run',
      query: 'Train with distributed data parallel to converge within 2.5 hours under budget.',
      strategy: 'balanced' as const
    },
    {
      title: 'Compare 3 Model Hyperparameters',
      query: 'Run a 3-way learning rate sweep across 1e-5, 2e-5, and 5e-5 on available GPUs.',
      strategy: 'auto' as const
    }
  ];

  const handleAnalyzeIntent = (queryText: string, strat: 'auto' | 'fastest' | 'balanced' | 'lowest_cost' = selectedStrategy) => {
    if (!queryText.trim()) return;
    setIsAnalyzing(true);
    setIntentInput(queryText);

    setTimeout(() => {
      let plan: ComputeIntentPlan;

      if (strat === 'fastest' || queryText.toLowerCase().includes('quickly') || queryText.toLowerCase().includes('fastest')) {
        plan = {
          query: queryText,
          parsedWorkload: 'Multi-GPU Distributed Fine-Tuning (DDP)',
          modelSize: 'IndicLLM-7B (7.24B Params)',
          recommendedCompute: '8× BHARAT H100 SXM5 (80GB HBM3)',
          acceleratorCount: 8,
          estimatedRuntime: '1h 10m',
          estimatedCredits: 128,
          costImpactPct: 64,
          reason: 'High parallelism with 8x H100 maximizes token throughput and completes training before user deadline.',
          strategy: 'fastest',
          status: 'suggested'
        };
      } else if (strat === 'lowest_cost' || queryText.toLowerCase().includes('cheap') || queryText.toLowerCase().includes('lowest')) {
        plan = {
          query: queryText,
          parsedWorkload: 'Parameter-Efficient LoRA Sweep',
          modelSize: 'IndicLLM-7B (LoRA Rank 16)',
          recommendedCompute: '1× BHARAT L40S Compute Engine (48GB)',
          acceleratorCount: 1,
          estimatedRuntime: '4h 15m',
          estimatedCredits: 24,
          costImpactPct: 12,
          reason: 'LoRA adapters fit comfortably within 48GB VRAM on a single node, cutting credit consumption by 75%.',
          strategy: 'lowest_cost',
          status: 'suggested'
        };
      } else {
        plan = {
          query: queryText,
          parsedWorkload: 'Balanced DDP Fine-Tuning',
          modelSize: 'IndicLLM-7B (Bhasha-v3 850k rows)',
          recommendedCompute: '4× BHARAT H100 SXM5 (80GB HBM3)',
          acceleratorCount: 4,
          estimatedRuntime: '2h 15m',
          estimatedCredits: 68,
          costImpactPct: 34,
          reason: '4x H100 DDP provides the optimal cost-to-throughput knee on the scaling curve without communication saturation.',
          strategy: 'balanced',
          status: 'suggested'
        };
      }

      setActiveIntent(plan);
      setIsAnalyzing(false);
      showNotification('Compute Brain analyzed workload and generated infrastructure plan.', 'success');
    }, 600);
  };

  const handleApproveAndExecute = () => {
    if (!activeIntent) return;
    executeIntentPlan(activeIntent);
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-8 max-w-7xl mx-auto">
      {/* Header */}
      <div className="space-y-2">
        <div className="flex items-center space-x-2">
          <span className="text-xs font-mono text-orange-400 font-bold uppercase tracking-wider">
            CORE PRODUCT DIFFERENTIATOR
          </span>
          <span className="text-gray-600">/</span>
          <TrustBadge type="SUGGESTED" size="xs" />
          <TrustBadge type="DEMO" size="xs" />
        </div>
        <h1 className="text-3xl font-extrabold text-white font-display flex items-center space-x-3">
          <BrainCircuit className="w-8 h-8 text-orange-400" />
          <span>Compute Brain & Compute Intent</span>
        </h1>
        <p className="text-sm text-gray-400 max-w-3xl">
          Describe the desired outcome in natural language instead of configuring complex clusters. Compute Brain analyzes parameters, dataset tokens, parallelism, and constraints to recommend the optimal infrastructure plan.
        </p>
      </div>

      {/* Navigation Tabs */}
      <div className="flex items-center space-x-1.5 p-1 bg-[#0a0e17] rounded-xl border border-white/10 text-xs font-mono overflow-x-auto">
        <button
          onClick={() => setActiveBrainTab('intent_engine')}
          className={`px-3.5 py-2 rounded-lg transition flex items-center space-x-1.5 shrink-0 ${
            activeBrainTab === 'intent_engine'
              ? 'bg-orange-500 text-white font-bold shadow-md shadow-orange-500/20'
              : 'text-gray-400 hover:text-white'
          }`}
        >
          <BrainCircuit className="w-4 h-4" />
          <span>Intent & Dynamic AI Engine</span>
        </button>

        <button
          onClick={() => setActiveBrainTab('pipeline_3d')}
          className={`px-3.5 py-2 rounded-lg transition flex items-center space-x-1.5 shrink-0 ${
            activeBrainTab === 'pipeline_3d'
              ? 'bg-orange-500 text-white font-bold shadow-md shadow-orange-500/20'
              : 'text-gray-400 hover:text-white'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>3D Neural Pipeline</span>
        </button>

        <button
          onClick={() => setActiveBrainTab('distributed_3d')}
          className={`px-3.5 py-2 rounded-lg transition flex items-center space-x-1.5 shrink-0 ${
            activeBrainTab === 'distributed_3d'
              ? 'bg-orange-500 text-white font-bold shadow-md shadow-orange-500/20'
              : 'text-gray-400 hover:text-white'
          }`}
        >
          <Activity className="w-4 h-4" />
          <span>3D Distributed Training Ring</span>
        </button>

        <button
          onClick={() => setActiveBrainTab('self_healing')}
          className={`px-3.5 py-2 rounded-lg transition flex items-center space-x-1.5 shrink-0 ${
            activeBrainTab === 'self_healing'
              ? 'bg-orange-500 text-white font-bold shadow-md shadow-orange-500/20'
              : 'text-gray-400 hover:text-white'
          }`}
        >
          <ShieldAlert className="w-4 h-4" />
          <span>Checkpoint Recovery Testbench</span>
        </button>
      </div>

      {/* TAB 1: INTENT & DYNAMIC AI ENGINE */}
      {activeBrainTab === 'intent_engine' && (
        <div className="space-y-6">
          {/* SECTION 1: Natural Language Compute Intent Box */}
          <div className="p-6 rounded-2xl bg-[#0a0e17] border border-white/10 space-y-4 shadow-xl">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-white/10 pb-3">
              <div className="flex items-center space-x-2 text-xs font-mono text-gray-300">
                <Sparkles className="w-4 h-4 text-orange-400" />
                <span className="font-bold">Enter Natural Language Compute Intent</span>
              </div>

              {/* Strategy Picker */}
              <div className="flex items-center space-x-1 text-xs font-mono">
                <span className="text-gray-500 mr-1 text-[11px]">Strategy:</span>
                {(['auto', 'fastest', 'balanced', 'lowest_cost'] as const).map(strat => (
                  <button
                    key={strat}
                    onClick={() => {
                      setSelectedStrategy(strat);
                      if (intentInput) handleAnalyzeIntent(intentInput, strat);
                    }}
                    className={`px-2 py-1 rounded text-[10px] uppercase transition ${
                      selectedStrategy === strat
                        ? 'bg-orange-500/20 text-orange-300 font-bold border border-orange-500/40'
                        : 'text-gray-400 hover:text-white bg-white/5'
                    }`}
                  >
                    {strat.replace('_', ' ')}
                  </button>
                ))}
              </div>
            </div>

            {/* Input & Action */}
            <div className="space-y-3">
              <textarea
                value={intentInput}
                onChange={e => setIntentInput(e.target.value)}
                placeholder="e.g., 'Train my model as cheaply as possible without exceeding tomorrow\'s deadline.'"
                rows={3}
                className="w-full bg-black/60 border border-white/10 rounded-xl p-3.5 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-orange-500/50"
              />

              <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
                <div className="flex items-center gap-1.5 flex-wrap text-xs">
                  <span className="text-[11px] font-mono text-gray-500">Quick Presets:</span>
                  {sampleIntents.map((item, idx) => (
                    <button
                      key={idx}
                      onClick={() => {
                        setSelectedStrategy(item.strategy);
                        handleAnalyzeIntent(item.query, item.strategy);
                      }}
                      className="px-2 py-1 rounded-md bg-white/5 hover:bg-white/10 text-gray-300 text-[11px] font-mono border border-white/5 transition"
                    >
                      {item.title}
                    </button>
                  ))}
                </div>

                <button
                  onClick={() => handleAnalyzeIntent(intentInput || sampleIntents[0].query)}
                  disabled={isAnalyzing}
                  className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-gradient-to-r from-orange-500 to-amber-600 hover:from-orange-600 hover:to-amber-700 text-white font-bold text-xs shadow-lg transition flex items-center justify-center space-x-2 shrink-0"
                >
                  {isAnalyzing ? (
                    <>
                      <RotateCcw className="w-3.5 h-3.5 animate-spin" />
                      <span>Analyzing Workload...</span>
                    </>
                  ) : (
                    <>
                      <BrainCircuit className="w-4 h-4" />
                      <span>Analyze with Compute Brain</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>

          {/* DYNAMIC AI INTERFACE ENGINE (Includes full 11-step intent lifecycle & contextual diagnostic workspace) */}
          <DynamicAIInterfaceEngine />
        </div>
      )}

      {/* TAB 2: 3D HOLOGRAPHIC NEURAL PIPELINE */}
      {activeBrainTab === 'pipeline_3d' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between text-xs font-mono text-gray-400">
            <span>3D AUTONOMOUS WORKLOAD ORCHESTRATION PIPELINE</span>
            <TrustBadge type="SIMULATED" size="xs" />
          </div>
          <ComputeBrain3DPipeline />
        </div>
      )}

      {/* TAB 3: 3D DISTRIBUTED TRAINING ALLREDUCE RING */}
      {activeBrainTab === 'distributed_3d' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between text-xs font-mono text-gray-400">
            <span>3D INTER-NODE ACCELERATOR COMMUNICATION & FAILOVER SIMULATOR</span>
            <TrustBadge type="DEMO" size="xs" />
          </div>
          <DistributedTraining3DRing />
        </div>
      )}

      {/* TAB 4: CHECKPOINT RECOVERY & COST GUARDIAN */}
      {activeBrainTab === 'self_healing' && (
        <div className="space-y-6">

      {/* SECTION 2: Compute Brain Recommendation & Cost Guardian */}
      {activeIntent && (
        <div className="p-6 rounded-2xl bg-gradient-to-br from-[#0c1220] to-[#080b12] border border-orange-500/30 space-y-6 shadow-2xl animate-in fade-in duration-200">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-white/10 pb-4">
            <div className="space-y-1">
              <div className="flex items-center space-x-2">
                <span className="text-xs font-mono text-orange-400 font-bold uppercase">
                  RECOMMENDED COMPUTE PLAN
                </span>
                <TrustBadge type={activeIntent.status.toUpperCase() as any} size="xs" />
                <TrustBadge type="ESTIMATED" size="xs" />
              </div>
              <h3 className="text-xl font-bold text-white font-display">
                {activeIntent.recommendedCompute}
              </h3>
            </div>

            <div className="text-right">
              <div className="text-xs font-mono text-gray-400">Estimated Usage</div>
              <div className="text-lg font-bold text-emerald-400 font-mono">
                ~{activeIntent.estimatedCredits} Credits
              </div>
            </div>
          </div>

          {/* Analysis Metrics Grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs font-mono">
            <div className="p-3 bg-black/40 rounded-lg border border-white/5">
              <div className="text-gray-400 text-[10px]">Workload Classification</div>
              <div className="text-white font-semibold mt-1 truncate">{activeIntent.parsedWorkload}</div>
            </div>
            <div className="p-3 bg-black/40 rounded-lg border border-white/5">
              <div className="text-gray-400 text-[10px]">Estimated Runtime</div>
              <div className="text-white font-semibold mt-1">~{activeIntent.estimatedRuntime}</div>
            </div>
            <div className="p-3 bg-black/40 rounded-lg border border-white/5">
              <div className="text-gray-400 text-[10px]">Parallelism Mode</div>
              <div className="text-orange-400 font-semibold mt-1">PyTorch DDP (4 Ranks)</div>
            </div>
            <div className="p-3 bg-black/40 rounded-lg border border-white/5">
              <div className="text-gray-400 text-[10px]">Quota Consumption</div>
              <div className="text-sky-400 font-semibold mt-1">{activeIntent.costImpactPct}% of Daily Limit</div>
            </div>
          </div>

          {/* Compute Brain Reasoning */}
          <div className="p-4 bg-black/60 rounded-xl border border-white/5 space-y-1 text-xs">
            <div className="font-mono text-gray-400 text-[11px]">Compute Brain Analysis:</div>
            <p className="text-gray-300 leading-relaxed font-sans text-xs">
              {activeIntent.reason}
            </p>
          </div>

          {/* COST GUARDIAN ALERT */}
          <div className="p-4 rounded-xl bg-amber-950/20 border border-amber-500/30 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-start space-x-3">
              <ShieldCheck className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
              <div>
                <div className="text-xs font-bold text-amber-300 font-mono">
                  COST GUARDIAN: PRE-LAUNCH CHECK
                </div>
                <div className="text-xs text-gray-300 mt-0.5">
                  {user.entitlement === 'founder' ? (
                    <span>MII Founder Entitlement recognized. Quota limits bypassed for priority cluster allocation.</span>
                  ) : (
                    <span>This configuration consumes ~{activeIntent.costImpactPct}% of your daily compute quota.</span>
                  )}
                </div>
              </div>
            </div>

            {/* Launch Approval Action */}
            <div className="flex items-center gap-2 shrink-0">
              {activeIntent.status !== 'executed' ? (
                <button
                  onClick={handleApproveAndExecute}
                  className="px-6 py-2.5 rounded-xl bg-orange-500 hover:bg-orange-600 text-white font-bold text-xs shadow-lg transition flex items-center space-x-1.5"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>Approve & Execute</span>
                </button>
              ) : (
                <div className="flex items-center space-x-2 text-xs text-emerald-400 font-mono font-bold">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Dispatched to Demo Cluster</span>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* SECTION 3: SELF-HEALING TRAINING DEMO & FAULT INJECTION */}
      <div className="p-6 rounded-2xl bg-[#0a0e17] border border-white/10 space-y-6 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-white/10 pb-4">
          <div>
            <div className="flex items-center space-x-2 text-xs font-mono text-orange-400">
              <ShieldAlert className="w-4 h-4" />
              <span className="font-bold">SELF-HEALING TRAINING TESTBENCH</span>
              <TrustBadge type="DEMO" size="xs" />
            </div>
            <h3 className="text-xl font-bold text-white font-display mt-1">
              Fault Tolerance & Worker Recovery Demo
            </h3>
            <p className="text-xs text-gray-400">
              Demonstrates automatic worker failure detection, checkpoint restoration, and training resumption.
            </p>
          </div>

          <div className="flex items-center gap-2">
            {!selfHealingState.isActive ? (
              <div className="flex items-center gap-2">
                <button
                  onClick={startSelfHealingDemo}
                  className="px-4 py-2 rounded-xl bg-orange-500 hover:bg-orange-600 text-white font-bold text-xs transition flex items-center space-x-1.5"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>Start Training Run</span>
                </button>
                <button
                  onClick={() => setShowRollbackOptions(!showRollbackOptions)}
                  className="px-3 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-gray-200 text-xs font-mono border border-white/10 transition flex items-center space-x-1"
                >
                  <History className="w-3.5 h-3.5 text-sky-400" />
                  <span>Rollback / Restore</span>
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <button
                  onClick={simulateWorkerFailure}
                  disabled={selfHealingState.status === 'interrupted' || selfHealingState.status === 'recovering'}
                  className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 disabled:opacity-50 text-white font-bold text-xs transition flex items-center space-x-1.5"
                >
                  <AlertTriangle className="w-3.5 h-3.5" />
                  <span>Simulate Worker Failure</span>
                </button>

                <button
                  onClick={() => setShowRollbackOptions(!showRollbackOptions)}
                  className="px-3 py-2 rounded-xl bg-sky-500/20 hover:bg-sky-500/30 text-sky-300 text-xs font-mono border border-sky-500/30 transition flex items-center space-x-1"
                  title="Manual Checkpoint Rollback"
                >
                  <History className="w-3.5 h-3.5" />
                  <span>Rollback</span>
                </button>

                <button
                  onClick={resetSelfHealingDemo}
                  className="px-3 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-gray-300 text-xs transition"
                  title="Reset Demo"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Manual Checkpoint Rollback Selector Bar */}
        {showRollbackOptions && (
          <div className="p-3 bg-sky-950/30 border border-sky-600/40 rounded-xl space-y-2 text-xs font-mono">
            <div className="flex items-center justify-between">
              <span className="font-bold text-sky-300 flex items-center space-x-1.5">
                <History className="w-3.5 h-3.5 text-sky-400" />
                <span>Hot-Swap Cluster to Checkpoint:</span>
              </span>
              <span className="text-[11px] text-gray-400">Zero data loss • Resumes training loop immediately</span>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              {[500, 1000, 1500, 2000].map((step) => {
                const loss = Math.max(0.31, 0.82 - (step / 2000) * 0.5);
                return (
                  <button
                    key={step}
                    onClick={() => {
                      rollbackTrainingToCheckpoint(step, loss);
                      setShowRollbackOptions(false);
                    }}
                    className="px-3 py-1.5 bg-black/60 hover:bg-sky-600 hover:text-white text-gray-200 border border-white/10 hover:border-sky-400 rounded-lg transition text-xs font-mono"
                  >
                    Step {step} (Loss: {loss.toFixed(3)})
                  </button>
                );
              })}
              {savedCheckpoints.slice(0, 3).map((ckpt) => (
                <button
                  key={ckpt.id}
                  onClick={() => {
                    restoreCheckpoint(ckpt.id, { target: 'training' });
                    setShowRollbackOptions(false);
                  }}
                  className="px-3 py-1.5 bg-sky-500/20 hover:bg-sky-500/40 text-sky-200 border border-sky-500/40 rounded-lg transition text-xs font-mono"
                >
                  {ckpt.id} (Step {ckpt.step})
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Status Tracker */}
        <div className="space-y-2">
          <div className="flex justify-between text-xs font-mono">
            <span className="text-gray-400">
              Training Progress: <strong className="text-white">{selfHealingState.currentStep}</strong> / {selfHealingState.totalSteps} steps
            </span>
            <span className="text-orange-400 font-bold">
              Loss: {selfHealingState.currentLoss.toFixed(3)}
            </span>
          </div>

          <div className="w-full bg-white/10 h-2.5 rounded-full overflow-hidden">
            <div
              className={`h-full transition-all duration-300 ${
                selfHealingState.status === 'interrupted'
                  ? 'bg-rose-500 animate-pulse'
                  : selfHealingState.status === 'recovering'
                  ? 'bg-amber-400'
                  : 'bg-gradient-to-r from-orange-500 to-amber-500'
              }`}
              style={{ width: `${(selfHealingState.currentStep / selfHealingState.totalSteps) * 100}%` }}
            />
          </div>

          <div className="grid grid-cols-3 gap-2 text-center text-xs font-mono pt-1">
            <div className="p-2 bg-black/40 rounded border border-white/5">
              <span className="text-[10px] text-gray-500">Node Status</span>
              <div
                className={`font-bold mt-0.5 ${
                  selfHealingState.status === 'interrupted'
                    ? 'text-rose-400'
                    : selfHealingState.status === 'recovering'
                    ? 'text-amber-400'
                    : 'text-emerald-400'
                }`}
              >
                {selfHealingState.status.toUpperCase()}
              </div>
            </div>

            <div className="p-2 bg-black/40 rounded border border-white/5">
              <span className="text-[10px] text-gray-500">Last Verified Checkpoint</span>
              <div className="font-bold text-white mt-0.5">
                Step {selfHealingState.lastCheckpointStep}
              </div>
            </div>

            <div className="p-2 bg-black/40 rounded border border-white/5">
              <span className="text-[10px] text-gray-500">DDP Cluster Size</span>
              <div className="font-bold text-orange-400 mt-0.5">
                4× BHARAT H100
              </div>
            </div>
          </div>
        </div>

        {/* Live Cluster Event Logs */}
        <div className="space-y-1">
          <div className="text-[11px] font-mono text-gray-400 uppercase">
            Cluster Event Telemetry
          </div>
          <div className="p-3 bg-black/80 rounded-xl font-mono text-xs text-gray-300 space-y-1 max-h-40 overflow-y-auto border border-white/5">
            {selfHealingState.logs.map((line, idx) => (
              <div
                key={idx}
                className={
                  line.includes('ALERT') || line.includes('interrupted')
                    ? 'text-rose-400 font-bold'
                    : line.includes('RESTORE') || line.includes('SCHEDULER')
                    ? 'text-amber-300'
                    : line.includes('COMPLETE') || line.includes('resumed')
                    ? 'text-emerald-400 font-semibold'
                    : 'text-gray-400'
                }
              >
                {line}
              </div>
            ))}
          </div>
        </div>
      </div>
        </div>
      )}
    </div>
  );
};
