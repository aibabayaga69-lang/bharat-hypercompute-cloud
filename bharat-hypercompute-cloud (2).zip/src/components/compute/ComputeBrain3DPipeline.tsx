import React, { useRef, useEffect, useState } from 'react';
import {
  BrainCircuit,
  Cpu,
  Layers,
  Sparkles,
  Zap,
  CheckCircle2,
  RotateCcw,
  ArrowRight,
  ShieldCheck,
  Server
} from 'lucide-react';

interface PipelineStage {
  id: string;
  name: string;
  short: string;
  description: string;
  status: 'active' | 'processing' | 'ready';
  latencyMs: number;
  outputSummary: string;
}

const STAGES: PipelineStage[] = [
  {
    id: 'intent',
    name: '1. Natural Language Intent',
    short: 'INTENT',
    description: 'Semantic intent extraction, token budgets, deadlines, and cost constraints',
    status: 'active',
    latencyMs: 12,
    outputSummary: 'Parsed: 7B Model Fine-Tune • Strategy: Balanced'
  },
  {
    id: 'workload',
    name: '2. Workload & FLOP Profiler',
    short: 'PROFILER',
    description: 'Memory footprint estimation, activation memory, batch size scaling knee',
    status: 'active',
    latencyMs: 28,
    outputSummary: '7.24B Params • 16-bit Mixed Precision • 850K tokens'
  },
  {
    id: 'resources',
    name: '3. Sovereign Resource Graph',
    short: 'FABRIC',
    description: 'Real-time telemetry across Delhi, Bengaluru, Mumbai & Hyderabad pods',
    status: 'active',
    latencyMs: 45,
    outputSummary: 'Matched: 4× H100 SXM5 (80GB HBM3) in Delhi Pod #01'
  },
  {
    id: 'auction',
    name: '4. Provider Spot & Wholesale',
    short: 'AUCTION',
    description: 'Transparent spot market arbitrage with SLA & zero hidden charges',
    status: 'active',
    latencyMs: 34,
    outputSummary: '₹140/hr per GPU • 34% cost efficiency vs global cloud'
  },
  {
    id: 'allocation',
    name: '5. Non-Blocking Provisioning',
    short: 'PROVISION',
    description: 'Automated Slurm/Kubernetes pod scheduling with pre-warmed CUDA images',
    status: 'ready',
    latencyMs: 65,
    outputSummary: 'Job ID: #RUN-MII-8491 • Direct NVLink Mesh'
  },
  {
    id: 'execution',
    name: '6. Distributed Training & Guardian',
    short: 'TRAIN',
    description: 'Real-time loss convergence, self-healing checkpointing & cost circuit breaker',
    status: 'ready',
    latencyMs: 15,
    outputSummary: 'DDP AllReduce Ring • Automated Failover Active'
  }
];

export const ComputeBrain3DPipeline: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  const [selectedStage, setSelectedStage] = useState<PipelineStage>(STAGES[0]);
  const [autoRotate, setAutoRotate] = useState<boolean>(true);

  // Refs for 60fps canvas animation (eliminates state thrashing)
  const rotYRef = useRef<number>(0.2);
  const autoRotateRef = useRef<boolean>(true);
  const isDraggingRef = useRef<boolean>(false);
  const dragStartRef = useRef<{ x: number }>({ x: 0 });
  const selectedStageRef = useRef<PipelineStage>(STAGES[0]);

  useEffect(() => {
    autoRotateRef.current = autoRotate;
  }, [autoRotate]);

  useEffect(() => {
    selectedStageRef.current = selectedStage;
  }, [selectedStage]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;

    const handleResize = () => {
      if (containerRef.current && canvas) {
        const rect = containerRef.current.getBoundingClientRect();
        const dpr = window.devicePixelRatio || 1;
        canvas.width = rect.width * dpr;
        canvas.height = rect.height * dpr;
        ctx.scale(dpr, dpr);
      }
    };

    handleResize();
    window.addEventListener('resize', handleResize);

    let tick = 0;

    const render = () => {
      if (!canvas || !containerRef.current) return;
      const width = containerRef.current.clientWidth;
      const height = containerRef.current.clientHeight;

      if (autoRotateRef.current && !isDraggingRef.current) {
        rotYRef.current += 0.002;
      }

      ctx.clearRect(0, 0, width, height);

      // Background styling
      const bg = ctx.createLinearGradient(0, 0, width, height);
      bg.addColorStop(0, '#0a0e1a');
      bg.addColorStop(0.5, '#060810');
      bg.addColorStop(1, '#080c16');
      ctx.fillStyle = bg;
      ctx.fillRect(0, 0, width, height);

      const cx = width / 2;
      const cy = height / 2;
      const radius = Math.min(width, height) * 0.38;

      // Project stage nodes along a 3D elliptical helix
      const stageCoords = STAGES.map((st, idx) => {
        const angle = (idx / STAGES.length) * Math.PI * 2 + rotYRef.current;
        const x3d = Math.cos(angle) * radius;
        const z3d = Math.sin(angle) * radius;
        const y3d = Math.sin(idx * 0.8 + tick * 0.03) * 15;

        const fov = 350;
        const scale = fov / (fov + z3d + 180);
        return {
          stage: st,
          px: cx + x3d * scale,
          py: cy + y3d * scale,
          scale,
          z3d
        };
      });

      // Sort by depth
      const sorted = [...stageCoords].sort((a, b) => b.z3d - a.z3d);

      // Connect pipeline ring with glowing spline
      ctx.beginPath();
      for (let i = 0; i < stageCoords.length; i++) {
        const p1 = stageCoords[i];
        const p2 = stageCoords[(i + 1) % stageCoords.length];
        if (i === 0) ctx.moveTo(p1.px, p1.py);
        ctx.lineTo(p2.px, p2.py);
      }
      ctx.closePath();
      ctx.strokeStyle = 'rgba(249, 115, 22, 0.25)';
      ctx.lineWidth = 2;
      ctx.stroke();

      // Animated flowing data packet pulses along ring
      const pulseCount = 8;
      for (let p = 0; p < pulseCount; p++) {
        const globalProgress = (tick * 0.008 + p / pulseCount) % 1;
        const segmentIdx = Math.floor(globalProgress * STAGES.length);
        const nextSegmentIdx = (segmentIdx + 1) % STAGES.length;
        const segmentProgress = (globalProgress * STAGES.length) % 1;

        const pA = stageCoords[segmentIdx];
        const pB = stageCoords[nextSegmentIdx];

        const pulseX = pA.px + (pB.px - pA.px) * segmentProgress;
        const pulseY = pA.py + (pB.py - pA.py) * segmentProgress;
        const pulseScale = pA.scale + (pB.scale - pA.scale) * segmentProgress;

        ctx.fillStyle = '#f97316';
        ctx.beginPath();
        ctx.arc(pulseX, pulseY, 3 * pulseScale, 0, Math.PI * 2);
        ctx.fill();
      }

      // Draw each 3D stage node
      sorted.forEach(({ stage, px, py, scale }) => {
        const isSelected = selectedStageRef.current?.id === stage.id;
        const nodeRadius = (isSelected ? 18 : 14) * scale;

        // Glow ring
        ctx.fillStyle = isSelected ? 'rgba(249, 115, 22, 0.3)' : 'rgba(99, 102, 241, 0.15)';
        ctx.beginPath();
        ctx.arc(px, py, nodeRadius * 2, 0, Math.PI * 2);
        ctx.fill();

        // Node Body
        const grad = ctx.createRadialGradient(px, py, 2, px, py, nodeRadius);
        if (isSelected) {
          grad.addColorStop(0, '#f97316');
          grad.addColorStop(1, '#9a3412');
        } else {
          grad.addColorStop(0, '#6366f1');
          grad.addColorStop(1, '#312e81');
        }
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(px, py, nodeRadius, 0, Math.PI * 2);
        ctx.fill();

        // Outer stroke
        ctx.strokeStyle = isSelected ? '#ffffff' : 'rgba(255, 255, 255, 0.4)';
        ctx.lineWidth = 1.5;
        ctx.stroke();

        // Stage Short Label
        ctx.fillStyle = '#ffffff';
        ctx.font = `bold ${Math.max(8, 9 * scale)}px ui-monospace, SFMono-Regular, monospace`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(stage.short, px, py);

        // Subtitle below
        ctx.fillStyle = isSelected ? '#fb923c' : '#94a3b8';
        ctx.font = `${Math.max(9, 10 * scale)}px ui-monospace, SFMono-Regular, monospace`;
        ctx.fillText(stage.name.split('. ')[1], px, py + nodeRadius + 10);
      });

      tick++;
      animId = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animId);
    };
  }, []);

  return (
    <div className="space-y-3">
      <div
        ref={containerRef}
        className="relative w-full h-[320px] rounded-2xl overflow-hidden border border-white/10 bg-[#07090e] shadow-xl group"
      >
        <canvas
          ref={canvasRef}
          onPointerDown={e => {
            isDraggingRef.current = true;
            dragStartRef.current = { x: e.clientX };
          }}
          onPointerMove={e => {
            if (!isDraggingRef.current) return;
            const dx = e.clientX - dragStartRef.current.x;
            rotYRef.current += dx * 0.007;
            dragStartRef.current = { x: e.clientX };
          }}
          onPointerUp={() => {
            isDraggingRef.current = false;
          }}
          onPointerCancel={() => {
            isDraggingRef.current = false;
          }}
          className="w-full h-full cursor-grab active:cursor-grabbing block"
        />

        {/* Overlay Badges */}
        <div className="absolute top-3 left-3 flex items-center space-x-2 pointer-events-none">
          <span className="px-2.5 py-1 rounded-lg bg-black/70 backdrop-blur-md border border-white/10 text-xs font-mono text-orange-400 font-bold">
            3D COMPUTE BRAIN PIPELINE
          </span>
          <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
            AUTONOMOUS
          </span>
        </div>

        {/* Orbit button */}
        <div className="absolute top-3 right-3 flex items-center space-x-2">
          <button
            onClick={() => setAutoRotate(!autoRotate)}
            className={`px-2.5 py-1 rounded-lg text-xs font-mono border backdrop-blur-md transition ${
              autoRotate ? 'bg-orange-500/20 text-orange-300 border-orange-500/40' : 'bg-black/60 text-gray-400 border-white/10'
            }`}
          >
            {autoRotate ? 'Orbiting' : 'Paused'}
          </button>
        </div>

        {/* Stage selection buttons along bottom */}
        <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between gap-1 overflow-x-auto py-1">
          {STAGES.map(st => (
            <button
              key={st.id}
              onClick={() => setSelectedStage(st)}
              className={`px-2.5 py-1 rounded-lg text-xs font-mono whitespace-nowrap transition border ${
                selectedStage.id === st.id
                  ? 'bg-orange-500 text-white font-bold border-orange-400 shadow-md shadow-orange-500/20'
                  : 'bg-black/70 backdrop-blur-md text-gray-400 hover:text-white border-white/10'
              }`}
            >
              {st.name.split('. ')[0]}
            </button>
          ))}
        </div>
      </div>

      {/* Selected Stage Detail Card */}
      <div className="p-4 rounded-xl bg-[#0a0e17] border border-orange-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs font-mono">
        <div className="space-y-0.5">
          <div className="flex items-center space-x-2">
            <span className="text-orange-400 font-bold uppercase">{selectedStage.name}</span>
            <span className="text-gray-500">|</span>
            <span className="text-gray-400">{selectedStage.latencyMs}ms resolution</span>
          </div>
          <p className="text-gray-300 text-xs">{selectedStage.description}</p>
        </div>

        <div className="px-3 py-2 rounded-lg bg-black/50 border border-white/10 shrink-0">
          <div className="text-[10px] text-gray-400 uppercase">Live Pipeline Output</div>
          <div className="text-emerald-400 font-bold text-xs">{selectedStage.outputSummary}</div>
        </div>
      </div>
    </div>
  );
};
