import React, { useRef, useEffect, useState } from 'react';
import {
  Cpu,
  RotateCcw,
  Zap,
  Activity,
  AlertTriangle,
  CheckCircle2,
  ShieldCheck,
  Play,
  RotateCw,
  Sliders,
  Layers
} from 'lucide-react';
import { TrustBadge } from '../common/TrustBadge';

interface GPUWorker {
  id: number;
  label: string;
  role: 'Primary' | 'Worker' | 'Warm Spare';
  status: 'healthy' | 'warning' | 'failed' | 'recovering';
  utilization: number;
  memoryUsedGB: number;
  temperatureC: number;
  packetThroughputGBs: number;
}

export const DistributedTraining3DRing: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  const [workers, setWorkers] = useState<GPUWorker[]>([
    { id: 0, label: 'GPU-0 (Rank 0 - Master)', role: 'Primary', status: 'healthy', utilization: 96, memoryUsedGB: 76.4, temperatureC: 45, packetThroughputGBs: 880 },
    { id: 1, label: 'GPU-1 (Rank 1)', role: 'Worker', status: 'healthy', utilization: 94, memoryUsedGB: 76.2, temperatureC: 46, packetThroughputGBs: 885 },
    { id: 2, label: 'GPU-2 (Rank 2)', role: 'Worker', status: 'healthy', utilization: 95, memoryUsedGB: 76.1, temperatureC: 48, packetThroughputGBs: 878 },
    { id: 3, label: 'GPU-3 (Rank 3)', role: 'Worker', status: 'healthy', utilization: 97, memoryUsedGB: 76.8, temperatureC: 44, packetThroughputGBs: 890 },
    { id: 4, label: 'GPU-4 (Rank 4)', role: 'Worker', status: 'healthy', utilization: 95, memoryUsedGB: 76.3, temperatureC: 46, packetThroughputGBs: 882 },
    { id: 5, label: 'GPU-5 (Rank 5)', role: 'Worker', status: 'healthy', utilization: 93, memoryUsedGB: 76.0, temperatureC: 43, packetThroughputGBs: 875 },
    { id: 6, label: 'GPU-6 (Rank 6)', role: 'Worker', status: 'healthy', utilization: 96, memoryUsedGB: 76.5, temperatureC: 47, packetThroughputGBs: 887 },
    { id: 7, label: 'GPU-7 (Rank 7)', role: 'Worker', status: 'healthy', utilization: 95, memoryUsedGB: 76.4, temperatureC: 45, packetThroughputGBs: 884 }
  ]);

  const [selectedWorker, setSelectedWorker] = useState<GPUWorker>(workers[0]);
  const [activePhase, setActivePhase] = useState<'Scatter-Reduce' | 'AllGather'>('Scatter-Reduce');
  const [failoverState, setFailoverState] = useState<'idle' | 'failed' | 'checkpoint_found' | 'reassigning' | 'restoring' | 'resumed'>('idle');
  const [failoverLog, setFailoverLog] = useState<string[]>([]);

  // Refs for 60fps canvas loop
  const workersRef = useRef<GPUWorker[]>(workers);
  const selectedWorkerRef = useRef<GPUWorker>(selectedWorker);

  useEffect(() => {
    workersRef.current = workers;
  }, [workers]);

  useEffect(() => {
    selectedWorkerRef.current = selectedWorker;
  }, [selectedWorker]);

  // Simulation: Trigger Failure and Self-Healing Recovery
  const handleSimulateWorkerFailure = () => {
    if (failoverState !== 'idle' && failoverState !== 'resumed') return;

    setFailoverState('failed');
    setFailoverLog(prev => ['[ALERT] Heartbeat timeout on Worker Rank 3 (Thermal Throttling / Link Drop)', ...prev]);

    // Mark GPU-3 as failed
    setWorkers(prev => prev.map(w => w.id === 3 ? { ...w, status: 'failed', utilization: 0, packetThroughputGBs: 0, temperatureC: 89 } : w));

    // Step 2: Checkpoint found
    setTimeout(() => {
      setFailoverState('checkpoint_found');
      setFailoverLog(prev => ['[STORAGE] Verified NVMe Tier Checkpoint: step_003500.pt (SHA-256 Validated)', ...prev]);

      // Step 3: Reassign warm spare
      setTimeout(() => {
        setFailoverState('reassigning');
        setFailoverLog(prev => ['[ORCHESTRATOR] Migrating Rank 3 workload to pre-warmed standby node BHARAT-H100-SPARE-09', ...prev]);

        // Step 4: Restoring checkpoint weights
        setTimeout(() => {
          setFailoverState('restoring');
          setFailoverLog(prev => ['[NCCL] Rebuilding communication ring mesh with new Rank 3 topology...', ...prev]);

          // Step 5: Resumed
          setTimeout(() => {
            setFailoverState('resumed');
            setWorkers(prev => prev.map(w => w.id === 3 ? { ...w, status: 'healthy', utilization: 95, packetThroughputGBs: 884, temperatureC: 44, label: 'GPU-3 (Rank 3 - Restored)' } : w));
            setFailoverLog(prev => ['[SUCCESS] Training converged and resumed with ZERO gradient drift. Total downtime: 4.8s', ...prev]);
          }, 1400);
        }, 1200);
      }, 1200);
    }, 1000);
  };

  const handleResetFailover = () => {
    setFailoverState('idle');
    setWorkers(prev => prev.map((w, idx) => ({
      ...w,
      status: 'healthy',
      utilization: 95,
      temperatureC: 45,
      packetThroughputGBs: 880,
      label: idx === 0 ? 'GPU-0 (Rank 0 - Master)' : `GPU-${idx} (Rank ${idx})`
    })));
    setFailoverLog([]);
  };

  // Canvas 3D Ring Animation
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let tick = 0;

    const handleResize = () => {
      if (containerRef.current && canvas) {
        const rect = containerRef.current.getBoundingClientRect();
        const dpr = window.devicePixelRatio || 1;
        canvas.width = rect.width * dpr;
        canvas.height = rect.height * dpr;
        ctx.scale(dpr, dpr);
      }
    };

    handleResize();
    window.addEventListener('resize', handleResize);

    const render = () => {
      if (!canvas || !containerRef.current) return;
      const width = containerRef.current.clientWidth;
      const height = containerRef.current.clientHeight;

      ctx.clearRect(0, 0, width, height);

      // Dark radial background
      const grad = ctx.createRadialGradient(width / 2, height / 2, 20, width / 2, height / 2, width / 2);
      grad.addColorStop(0, '#0a0f1d');
      grad.addColorStop(1, '#05070c');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, width, height);

      const cx = width / 2;
      const cy = height / 2;
      const ringRadius = Math.min(width, height) * 0.36;

      // Draw Ring Circuit
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.08)';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(cx, cy, ringRadius, 0, Math.PI * 2);
      ctx.stroke();

      // Draw Center Hub (NVLink / NVSwitch Crossbar)
      const hubGrad = ctx.createRadialGradient(cx, cy, 5, cx, cy, 35);
      hubGrad.addColorStop(0, 'rgba(249, 115, 22, 0.25)');
      hubGrad.addColorStop(1, 'rgba(249, 115, 22, 0)');
      ctx.fillStyle = hubGrad;
      ctx.beginPath();
      ctx.arc(cx, cy, 35, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = '#f97316';
      ctx.font = '10px ui-monospace, SFMono-Regular, monospace';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('NVSWITCH 900GB/s', cx, cy - 6);
      ctx.fillStyle = '#94a3b8';
      ctx.font = '9px ui-monospace, SFMono-Regular, monospace';
      ctx.fillText('AllReduce Ring', cx, cy + 8);

      // Calculate worker positions around ring
      const currentWorkers = workersRef.current;
      const currentSelected = selectedWorkerRef.current;
      const numWorkers = currentWorkers.length;
      const workerPositions = currentWorkers.map((w, i) => {
        const angle = (i / numWorkers) * Math.PI * 2 - Math.PI / 2;
        return {
          worker: w,
          x: cx + Math.cos(angle) * ringRadius,
          y: cy + Math.sin(angle) * ringRadius,
          angle
        };
      });

      // Draw interconnect lines between adjacent GPUs
      for (let i = 0; i < workerPositions.length; i++) {
        const curr = workerPositions[i];
        const next = workerPositions[(i + 1) % workerPositions.length];

        const isBroken = (curr.worker.status === 'failed' || next.worker.status === 'failed');

        ctx.strokeStyle = isBroken ? 'rgba(239, 68, 68, 0.4)' : 'rgba(56, 189, 248, 0.4)';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(curr.x, curr.y);
        ctx.lineTo(next.x, next.y);
        ctx.stroke();

        // Radiate hub lines
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
        ctx.beginPath();
        ctx.moveTo(cx, cy);
        ctx.lineTo(curr.x, curr.y);
        ctx.stroke();

        // Animate packets along the ring
        if (!isBroken) {
          const packetProgress = (tick * 0.02 + i * 0.25) % 1;
          const px = curr.x + (next.x - curr.x) * packetProgress;
          const py = curr.y + (next.y - curr.y) * packetProgress;

          ctx.fillStyle = '#38bdf8';
          ctx.beginPath();
          ctx.arc(px, py, 3, 0, Math.PI * 2);
          ctx.fill();
        }
      }

      // Draw GPU nodes
      workerPositions.forEach(({ worker, x, y }) => {
        const isSelected = currentSelected?.id === worker.id;
        const isFailed = worker.status === 'failed';
        const isRecovering = worker.status === 'recovering';

        // Outer glow
        const glow = ctx.createRadialGradient(x, y, 2, x, y, 24);
        if (isFailed) {
          glow.addColorStop(0, 'rgba(239, 68, 68, 0.8)');
          glow.addColorStop(1, 'rgba(239, 68, 68, 0)');
        } else if (isSelected) {
          glow.addColorStop(0, 'rgba(249, 115, 22, 0.8)');
          glow.addColorStop(1, 'rgba(249, 115, 22, 0)');
        } else {
          glow.addColorStop(0, 'rgba(16, 185, 129, 0.5)');
          glow.addColorStop(1, 'rgba(16, 185, 129, 0)');
        }
        ctx.fillStyle = glow;
        ctx.beginPath();
        ctx.arc(x, y, 24, 0, Math.PI * 2);
        ctx.fill();

        // Node circle
        ctx.fillStyle = isFailed ? '#b91c1c' : isSelected ? '#ea580c' : '#047857';
        ctx.beginPath();
        ctx.arc(x, y, 14, 0, Math.PI * 2);
        ctx.fill();

        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 1.5;
        ctx.stroke();

        // Text
        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 9px ui-monospace, SFMono-Regular, monospace';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(`R${worker.id}`, x, y);

        // Subtitle tag
        ctx.fillStyle = isFailed ? '#fca5a5' : '#cbd5e1';
        ctx.font = '8px ui-monospace, SFMono-Regular, monospace';
        ctx.fillText(`${worker.temperatureC}°C`, x, y + 20);
      });

      tick++;
      animId = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animId);
    };
  }, []);

  return (
    <div className="space-y-4">
      {/* 3D Ring Canvas */}
      <div
        ref={containerRef}
        className="relative w-full h-[360px] rounded-2xl overflow-hidden border border-white/10 bg-[#07090e] shadow-2xl"
      >
        <canvas ref={canvasRef} className="w-full h-full block" />

        {/* Top Badges */}
        <div className="absolute top-3 left-3 flex items-center space-x-2">
          <span className="px-2.5 py-1 rounded-lg bg-black/70 backdrop-blur-md border border-white/10 text-xs font-mono text-orange-400 font-bold">
            8× H100 ALLREDUCE RING TOPOLOGY
          </span>
          <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
            NVLink 900 GB/s
          </span>
        </div>

        {/* Phase Toggle */}
        <div className="absolute top-3 right-3 flex items-center space-x-1.5 text-xs font-mono">
          <button
            onClick={() => setActivePhase('Scatter-Reduce')}
            className={`px-2.5 py-1 rounded-lg border transition ${
              activePhase === 'Scatter-Reduce'
                ? 'bg-orange-500/20 text-orange-300 border-orange-500/40'
                : 'bg-black/60 text-gray-400 border-white/10'
            }`}
          >
            Scatter-Reduce
          </button>
          <button
            onClick={() => setActivePhase('AllGather')}
            className={`px-2.5 py-1 rounded-lg border transition ${
              activePhase === 'AllGather'
                ? 'bg-orange-500/20 text-orange-300 border-orange-500/40'
                : 'bg-black/60 text-gray-400 border-white/10'
            }`}
          >
            AllGather
          </button>
        </div>

        {/* Bottom Interactive Trigger Controls */}
        <div className="absolute bottom-3 left-3 right-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="flex items-center space-x-1 overflow-x-auto py-1">
            {workers.map(w => (
              <button
                key={w.id}
                onClick={() => setSelectedWorker(w)}
                className={`px-2 py-0.5 rounded text-xs font-mono border transition ${
                  selectedWorker.id === w.id
                    ? 'bg-orange-500 text-white font-bold border-orange-400'
                    : w.status === 'failed'
                    ? 'bg-red-500/20 text-red-300 border-red-500/40'
                    : 'bg-black/70 text-gray-400 border-white/10 hover:text-white'
                }`}
              >
                GPU-{w.id}
              </button>
            ))}
          </div>

          <div className="flex items-center space-x-2 shrink-0">
            {failoverState === 'idle' || failoverState === 'resumed' ? (
              <button
                onClick={handleSimulateWorkerFailure}
                className="px-3 py-1.5 rounded-lg bg-red-500/20 hover:bg-red-500/30 text-red-300 border border-red-500/40 text-xs font-mono font-bold transition flex items-center space-x-1.5"
              >
                <AlertTriangle className="w-3.5 h-3.5 text-red-400" />
                <span>Simulate GPU-3 Failure</span>
              </button>
            ) : (
              <button
                onClick={handleResetFailover}
                className="px-3 py-1.5 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 text-xs font-mono font-bold transition flex items-center space-x-1.5"
              >
                <RotateCcw className="w-3.5 h-3.5 text-emerald-400" />
                <span>Reset Failure Sim</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Failover Lifecycle Progress (When Active) */}
      {failoverState !== 'idle' && (
        <div className="p-4 rounded-xl bg-[#0e121e] border border-orange-500/40 space-y-3 animate-in fade-in duration-200">
          <div className="flex items-center justify-between text-xs font-mono">
            <div className="flex items-center space-x-2">
              <ShieldCheck className="w-4 h-4 text-orange-400" />
              <span className="font-bold text-white uppercase">Self-Healing Failover Sequence</span>
            </div>
            <span className="text-orange-400 font-bold uppercase">{failoverState.replace('_', ' ')}</span>
          </div>

          {/* Stepper visual */}
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 text-[10px] font-mono">
            <div className={`p-2 rounded border text-center ${failoverState === 'failed' ? 'bg-red-500/20 border-red-500 text-red-300 font-bold' : 'bg-black/40 border-white/5 text-gray-500'}`}>
              1. Failure Detected
            </div>
            <div className={`p-2 rounded border text-center ${failoverState === 'checkpoint_found' ? 'bg-amber-500/20 border-amber-500 text-amber-300 font-bold' : 'bg-black/40 border-white/5 text-gray-500'}`}>
              2. Checkpoint Loaded
            </div>
            <div className={`p-2 rounded border text-center ${failoverState === 'reassigning' ? 'bg-sky-500/20 border-sky-500 text-sky-300 font-bold' : 'bg-black/40 border-white/5 text-gray-500'}`}>
              3. Spare Reassigned
            </div>
            <div className={`p-2 rounded border text-center ${failoverState === 'restoring' ? 'bg-indigo-500/20 border-indigo-500 text-indigo-300 font-bold' : 'bg-black/40 border-white/5 text-gray-500'}`}>
              4. Ring Restored
            </div>
            <div className={`p-2 rounded border text-center ${failoverState === 'resumed' ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300 font-bold' : 'bg-black/40 border-white/5 text-gray-500'}`}>
              5. Training Resumed
            </div>
          </div>

          {/* Console logs */}
          <div className="p-2.5 bg-black/70 rounded-lg font-mono text-[11px] text-gray-300 max-h-24 overflow-y-auto space-y-1 border border-white/5">
            {failoverLog.map((log, i) => (
              <div key={i} className="text-emerald-400 leading-tight">
                {log}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Selected GPU Telemetry Box */}
      <div className="p-4 rounded-xl bg-[#0a0e17] border border-white/10 grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono">
        <div className="space-y-0.5">
          <div className="text-gray-500 text-[10px] uppercase">Node Identifier</div>
          <div className="text-white font-bold">{selectedWorker.label}</div>
        </div>
        <div className="space-y-0.5">
          <div className="text-gray-500 text-[10px] uppercase">VRAM Allocation</div>
          <div className="text-sky-400 font-bold">{selectedWorker.memoryUsedGB} / 80 GB HBM3</div>
        </div>
        <div className="space-y-0.5">
          <div className="text-gray-500 text-[10px] uppercase">Inter-Node Throughput</div>
          <div className="text-emerald-400 font-bold">{selectedWorker.packetThroughputGBs} GB/s NVLink</div>
        </div>
        <div className="space-y-0.5">
          <div className="text-gray-500 text-[10px] uppercase">Core Operating Temp</div>
          <div className={`font-bold ${selectedWorker.temperatureC > 70 ? 'text-red-400' : 'text-amber-300'}`}>
            {selectedWorker.temperatureC}°C (Sub-ambient Liquid)
          </div>
        </div>
      </div>
    </div>
  );
};
