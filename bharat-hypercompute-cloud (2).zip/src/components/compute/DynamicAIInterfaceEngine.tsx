import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../../context/AppContext';
import { TrustBadge } from '../common/TrustBadge';
import {
  BrainCircuit,
  Sparkles,
  Zap,
  Activity,
  AlertTriangle,
  CheckCircle2,
  Cpu,
  Clock,
  DollarSign,
  TrendingDown,
  ShieldCheck,
  Play,
  RotateCcw,
  Sliders,
  ChevronRight,
  ArrowRight,
  BarChart3,
  Server,
  Terminal,
  FileCode,
  Layers,
  Wrench,
  Check,
  XCircle,
  HelpCircle
} from 'lucide-react';

export type ActionStatus = 'SUGGESTED' | 'APPROVED' | 'EXECUTED' | 'BLOCKED' | 'REQUIRES_PROVIDER' | 'REQUIRES_API';

export interface ComputeOption {
  id: string;
  name: string;
  accelerator: string;
  count: number;
  runtimeEst: string;
  costCredits: number;
  costINR: number;
  efficiencyRating: 'Highest Speed' | 'Optimal Knee' | 'Lowest Cost';
  isRecommended?: boolean;
}

export interface DiagnosticData {
  gpuUtilizationPct: number;
  gpuMemoryUsedGB: number;
  gpuMemoryTotalGB: number;
  cpuUtilizationPct: number;
  dataloaderThroughputSamplesSec: number;
  targetIngestionSamplesSec: number;
  networkCommunicationLatencyUs: number;
  primaryBottleneck: string;
  recentChanges: string;
  checkpointStep: number;
  checkpointLoss: number;
  suspectedCauses: string[];
  recommendedFixes: {
    id: string;
    title: string;
    description: string;
    codePatch: string;
    expectedSpeedup: string;
    expectedCostSavings: string;
    status: ActionStatus;
  }[];
}

interface DynamicAIInterfaceEngineProps {
  initialQuery?: string;
  onPlanExecuted?: (planName: string) => void;
}

export const DynamicAIInterfaceEngine: React.FC<DynamicAIInterfaceEngineProps> = ({
  initialQuery,
  onPlanExecuted
}) => {
  const { showNotification } = useApp();

  const [activeWorkflow, setActiveWorkflow] = useState<'intent_lifecycle' | 'diagnostic_workspace' | 'optimization_panel'>('intent_lifecycle');
  const [currentStepIndex, setCurrentStepIndex] = useState<number>(0);
  const [selectedOptionId, setSelectedOptionId] = useState<string>('opt_balanced');
  const [approvalStatus, setApprovalStatus] = useState<ActionStatus>('SUGGESTED');
  const [isExecuting, setIsExecuting] = useState<boolean>(false);
  const intervalRef = useRef<any>(null);

  useEffect(() => {
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    };
  }, []);
  const [liveMetrics, setLiveMetrics] = useState({
    step: 450,
    totalSteps: 1200,
    currentLoss: 1.48,
    throughputTFLOPS: 312,
    mfuPct: 54.2,
    etaMin: 42
  });

  // Intent Lifecycle sample compute options
  const computeOptions: ComputeOption[] = [
    {
      id: 'opt_fastest',
      name: 'Option A: Max Throughput Cluster',
      accelerator: '8× BHARAT H100 SXM5 (80GB)',
      count: 8,
      runtimeEst: '1h 10m',
      costCredits: 128,
      costINR: 11072,
      efficiencyRating: 'Highest Speed'
    },
    {
      id: 'opt_balanced',
      name: 'Option B: Pareto-Optimal Scaling Knee (Recommended)',
      accelerator: '4× BHARAT H100 SXM5 (80GB)',
      count: 4,
      runtimeEst: '2h 15m',
      costCredits: 68,
      costINR: 5882,
      efficiencyRating: 'Optimal Knee',
      isRecommended: true
    },
    {
      id: 'opt_lowest_cost',
      name: 'Option C: Budget LoRA Instance',
      accelerator: '1× BHARAT L40S (48GB)',
      count: 1,
      runtimeEst: '5h 40m',
      costCredits: 26,
      costINR: 2249,
      efficiencyRating: 'Lowest Cost'
    }
  ];

  // Contextual Diagnostic Data ("Why is my training slow?")
  const [diagnostic, setDiagnostic] = useState<DiagnosticData>({
    gpuUtilizationPct: 42,
    gpuMemoryUsedGB: 74.2,
    gpuMemoryTotalGB: 80,
    cpuUtilizationPct: 98,
    dataloaderThroughputSamplesSec: 180,
    targetIngestionSamplesSec: 720,
    networkCommunicationLatencyUs: 14,
    primaryBottleneck: 'PyTorch DataLoader CPU Worker Starvation (Tokenization on-the-fly)',
    recentChanges: 'Switched from pre-sharded Parquet to streaming raw JSONL without persistent workers.',
    checkpointStep: 3500,
    checkpointLoss: 1.84,
    suspectedCauses: [
      'Single-threaded data worker (num_workers=0) blocking GPU execution',
      'Regex string sanitization performed inside Python __getitem__ loop',
      'Missing pin_memory=True causing synchronous host-to-device memory copies'
    ],
    recommendedFixes: [
      {
        id: 'fix_dataloader',
        title: 'Apply Multi-Process Pre-Fetched DataLoader Patch',
        description: 'Set num_workers=4, pin_memory=True, and persistent_workers=True in PyTorch DataLoader config.',
        codePatch: `dataloader = DataLoader(\n  dataset,\n  batch_size=32,\n  num_workers=4,\n  pin_memory=True,\n  persistent_workers=True,\n  prefetch_factor=2\n)`,
        expectedSpeedup: '+3.8× throughput increase',
        expectedCostSavings: '63% compute credits saved',
        status: 'SUGGESTED'
      },
      {
        id: 'fix_torch_compile',
        title: 'Activate torch.compile with reduce-overhead Mode',
        description: 'JIT compile fused activation kernels and eliminate Python interpreter launch overhead.',
        codePatch: `model = torch.compile(model, mode="reduce-overhead")`,
        expectedSpeedup: '+24% raw tensor core speedup',
        expectedCostSavings: '18% credit efficiency gain',
        status: 'SUGGESTED'
      }
    ]
  });

  const selectedOpt = computeOptions.find(o => o.id === selectedOptionId) || computeOptions[1];

  const handleApprovePlan = () => {
    setApprovalStatus('APPROVED');
    showNotification('Compute plan APPROVED by user. Ready for execution.', 'success');
  };

  const handleExecutePlan = () => {
    setIsExecuting(true);
    setApprovalStatus('EXECUTED');
    showNotification('Spinning up 4× BHARAT H100 SXM5 cluster with direct NVLink mesh...', 'info');

    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }

    // Simulate streaming step progress safely
    intervalRef.current = setInterval(() => {
      setLiveMetrics(prev => {
        const nextStep = prev.step + 50;
        if (nextStep >= prev.totalSteps) {
          if (intervalRef.current) {
            clearInterval(intervalRef.current);
            intervalRef.current = null;
          }

          // Defer all side-effects and cross-component updates outside React's render phase
          setTimeout(() => {
            setIsExecuting(false);
            if (onPlanExecuted) {
              onPlanExecuted(selectedOpt.name);
            }
            showNotification('Training run converged and checkpoint step 1200 saved to Model Registry!', 'success');
          }, 0);

          return {
            ...prev,
            step: prev.totalSteps,
            currentLoss: 0.82,
            etaMin: 0
          };
        }
        return {
          ...prev,
          step: nextStep,
          currentLoss: Math.max(0.82, Number((prev.currentLoss - 0.04).toFixed(3))),
          etaMin: Math.max(1, prev.etaMin - 3)
        };
      });
    }, 800);
  };

  const handleApplyFix = (fixId: string) => {
    setDiagnostic(prev => ({
      ...prev,
      gpuUtilizationPct: 96,
      cpuUtilizationPct: 48,
      dataloaderThroughputSamplesSec: 740,
      recommendedFixes: prev.recommendedFixes.map(f => f.id === fixId ? { ...f, status: 'EXECUTED' as ActionStatus } : f)
    }));
    showNotification('Applied DataLoader optimization patch! GPU utilization surged to 96%.', 'success');
  };

  return (
    <div className="space-y-6">
      {/* Engine Switcher Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3 rounded-xl bg-[#0a0e17] border border-white/10">
        <div className="flex items-center space-x-2">
          <BrainCircuit className="w-4 h-4 text-orange-400" />
          <span className="text-xs font-mono font-bold text-white uppercase">
            Dynamic AI Interface Engine
          </span>
          <TrustBadge type={approvalStatus} size="xs" />
        </div>

        <div className="flex items-center space-x-1 text-xs font-mono">
          <button
            onClick={() => setActiveWorkflow('intent_lifecycle')}
            className={`px-3 py-1.5 rounded-lg transition ${
              activeWorkflow === 'intent_lifecycle'
                ? 'bg-orange-500/20 text-orange-300 font-bold border border-orange-500/40'
                : 'text-gray-400 hover:text-white bg-white/5'
            }`}
          >
            Intent-to-Execution Pipeline
          </button>
          <button
            onClick={() => setActiveWorkflow('diagnostic_workspace')}
            className={`px-3 py-1.5 rounded-lg transition ${
              activeWorkflow === 'diagnostic_workspace'
                ? 'bg-orange-500/20 text-orange-300 font-bold border border-orange-500/40'
                : 'text-gray-400 hover:text-white bg-white/5'
            }`}
          >
            Why is My Training Slow? (Diagnostic)
          </button>
        </div>
      </div>

      {/* ================= WORKFLOW A: INTENT-TO-EXECUTION LIFECYCLE ================= */}
      {activeWorkflow === 'intent_lifecycle' && (
        <div className="p-6 rounded-2xl bg-[#090d16] border border-orange-500/30 shadow-2xl space-y-6">
          {/* Top Intent Summary */}
          <div className="space-y-1 border-b border-white/10 pb-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono text-orange-400 font-bold uppercase">
                AI WORKLOAD DECOMPOSITION & OPTIMIZATION PIPELINE
              </span>
              <span className="text-xs font-mono text-gray-400">Strict User-In-The-Loop Governance</span>
            </div>
            <div className="text-sm font-semibold text-white">
              Prompt: "Train my model as cheaply as possible without exceeding tomorrow's deadline."
            </div>
          </div>

          {/* 11-Stage Interactive Pipeline Visualizer */}
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-2 text-xs font-mono">
            {[
              { num: '1', name: 'INTENT', desc: 'Workload parsing', done: true },
              { num: '2', name: 'ANALYSIS', desc: '7.24B Params • 850k rows', done: true },
              { num: '3', name: 'OPTIONS', desc: '3 cluster architectures', done: true },
              { num: '4', name: 'COST & TIME', desc: '~₹5,882 • 2h 15m', done: true },
              { num: '5', name: 'RISKS', desc: 'OOM check • Preemption 0%', done: true },
              { num: '6', name: 'APPROVAL', desc: approvalStatus === 'SUGGESTED' ? 'Awaiting User Gate' : 'User Confirmed', done: approvalStatus !== 'SUGGESTED' }
            ].map(stage => (
              <div
                key={stage.num}
                className={`p-3 rounded-xl border space-y-1 ${
                  stage.done
                    ? 'bg-emerald-500/10 border-emerald-500/30 text-white'
                    : 'bg-black/40 border-white/5 text-gray-400'
                }`}
              >
                <div className="flex items-center justify-between text-[10px] font-bold">
                  <span className="text-orange-400">{stage.num}. {stage.name}</span>
                  {stage.done && <CheckCircle2 className="w-3 h-3 text-emerald-400" />}
                </div>
                <div className="text-[11px] text-gray-300 truncate">{stage.desc}</div>
              </div>
            ))}
          </div>

          {/* Compute Options Selection Table */}
          <div className="space-y-3">
            <div className="flex items-center justify-between text-xs font-mono">
              <span className="font-bold text-gray-300 uppercase">Evaluated Infrastructure Options</span>
              <span className="text-gray-500">Click to Select Architecture</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {computeOptions.map(opt => {
                const isSelected = selectedOptionId === opt.id;
                return (
                  <div
                    key={opt.id}
                    onClick={() => setSelectedOptionId(opt.id)}
                    className={`p-4 rounded-xl border cursor-pointer transition space-y-3 relative ${
                      isSelected
                        ? 'bg-orange-500/15 border-orange-500 text-white shadow-xl'
                        : 'bg-black/40 border-white/10 hover:border-white/20 text-gray-300'
                    }`}
                  >
                    {opt.isRecommended && (
                      <span className="absolute -top-2.5 right-3 px-2 py-0.5 rounded-full text-[9px] font-mono font-bold bg-orange-500 text-white shadow">
                        AI RECOMMENDED
                      </span>
                    )}

                    <div>
                      <div className="text-xs font-mono font-bold text-white">{opt.name}</div>
                      <div className="text-[11px] text-orange-400 font-mono mt-0.5">{opt.accelerator}</div>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-xs font-mono bg-black/40 p-2 rounded-lg border border-white/5">
                      <div>
                        <div className="text-[10px] text-gray-500 uppercase">Runtime</div>
                        <div className="font-bold text-white">{opt.runtimeEst}</div>
                      </div>
                      <div>
                        <div className="text-[10px] text-gray-500 uppercase">Cost</div>
                        <div className="font-bold text-emerald-400">₹{opt.costINR.toLocaleString()}</div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between text-[11px] font-mono">
                      <span className="text-gray-400">{opt.costCredits} Credits</span>
                      <span className="text-xs text-sky-400">{opt.efficiencyRating}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Explicit User Approval & Execution Gate */}
          <div className="p-4 rounded-xl bg-black/60 border border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="flex items-center space-x-2 text-xs font-mono">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span className="font-bold text-white">Safe Execution Guarantee</span>
                <span className="text-gray-500">|</span>
                <span className="text-gray-400">Never silently charges cards or launches without confirmation</span>
              </div>
              <p className="text-xs text-gray-400">
                Selected: <strong className="text-white">{selectedOpt.accelerator}</strong> • Estimated Runtime: <strong className="text-white">{selectedOpt.runtimeEst}</strong> • Total Budget: <strong className="text-emerald-400">₹{selectedOpt.costINR.toLocaleString()}</strong>
              </p>
            </div>

            <div className="flex items-center space-x-3 shrink-0">
              {approvalStatus === 'SUGGESTED' ? (
                <button
                  onClick={handleApprovePlan}
                  className="px-5 py-2.5 rounded-xl bg-orange-500 hover:bg-orange-600 text-white font-bold text-xs font-mono shadow-lg transition flex items-center space-x-1.5"
                >
                  <Check className="w-4 h-4" />
                  <span>Approve Compute Plan</span>
                </button>
              ) : approvalStatus === 'APPROVED' ? (
                <button
                  onClick={handleExecutePlan}
                  disabled={isExecuting}
                  className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs font-mono shadow-lg transition flex items-center space-x-1.5"
                >
                  <Play className="w-4 h-4" />
                  <span>Execute on Bharat Cloud</span>
                </button>
              ) : (
                <div className="flex items-center space-x-2 text-emerald-400 font-mono text-xs">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Workload In Progress</span>
                </div>
              )}
            </div>
          </div>

          {/* Live Execution Telemetry Stream (When Approved or Executed) */}
          {(approvalStatus === 'APPROVED' || approvalStatus === 'EXECUTED') && (
            <div className="p-4 rounded-xl bg-[#0c1220] border border-emerald-500/30 space-y-3 animate-in fade-in duration-200">
              <div className="flex items-center justify-between text-xs font-mono">
                <div className="flex items-center space-x-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  <span className="font-bold text-white uppercase">Live Training Telemetry</span>
                  <span className="text-gray-500">|</span>
                  <span className="text-gray-400">Job: #MII-DDP-7B-8491</span>
                </div>
                <span className="text-emerald-400 font-bold">{liveMetrics.step} / {liveMetrics.totalSteps} Steps</span>
              </div>

              {/* Progress Bar */}
              <div className="w-full h-2 bg-black/60 rounded-full overflow-hidden border border-white/10">
                <div
                  className="h-full bg-gradient-to-r from-orange-500 to-emerald-400 transition-all duration-300"
                  style={{ width: `${(liveMetrics.step / liveMetrics.totalSteps) * 100}%` }}
                />
              </div>

              {/* Metrics Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-mono">
                <div className="p-2 bg-black/40 rounded border border-white/5">
                  <div className="text-gray-500 text-[10px]">Cross-Entropy Loss</div>
                  <div className="text-emerald-400 font-bold text-sm">{liveMetrics.currentLoss}</div>
                </div>
                <div className="p-2 bg-black/40 rounded border border-white/5">
                  <div className="text-gray-500 text-[10px]">Throughput</div>
                  <div className="text-white font-bold text-sm">{liveMetrics.throughputTFLOPS} TFLOPS</div>
                </div>
                <div className="p-2 bg-black/40 rounded border border-white/5">
                  <div className="text-gray-500 text-[10px]">Model Flops Util (MFU)</div>
                  <div className="text-sky-400 font-bold text-sm">{liveMetrics.mfuPct}%</div>
                </div>
                <div className="p-2 bg-black/40 rounded border border-white/5">
                  <div className="text-gray-500 text-[10px]">Estimated Completion</div>
                  <div className="text-amber-400 font-bold text-sm">~{liveMetrics.etaMin} mins</div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ================= WORKFLOW B: CONTEXTUAL DIAGNOSTIC WORKSPACE ================= */}
      {activeWorkflow === 'diagnostic_workspace' && (
        <div className="p-6 rounded-2xl bg-[#090d16] border border-orange-500/30 shadow-2xl space-y-6 animate-in fade-in duration-200">
          {/* Diagnostic Header */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-white/10 pb-4">
            <div className="space-y-0.5">
              <div className="flex items-center space-x-2">
                <span className="text-xs font-mono text-red-400 font-bold uppercase">
                  DIAGNOSTIC WORKSPACE
                </span>
                <span className="text-gray-600">/</span>
                <span className="text-xs font-mono text-gray-400">Target Query: "Why is my training slow?"</span>
              </div>
              <h2 className="text-xl font-bold text-white font-display">
                Automated Infrastructure & Dataloader Health Inspection
              </h2>
            </div>

            <div className="flex items-center space-x-2">
              <span className="px-2.5 py-1 rounded-lg bg-red-500/20 border border-red-500/30 text-red-300 text-xs font-mono font-bold flex items-center space-x-1">
                <AlertTriangle className="w-3.5 h-3.5 text-red-400" />
                <span>Bottleneck Identified</span>
              </span>
            </div>
          </div>

          {/* Telemetry Gauge Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 text-xs font-mono">
            <div className="p-3 bg-black/40 rounded-xl border border-white/5 space-y-1">
              <div className="text-gray-500 text-[10px] uppercase">GPU Utilization</div>
              <div className={`text-base font-bold ${diagnostic.gpuUtilizationPct < 60 ? 'text-red-400' : 'text-emerald-400'}`}>
                {diagnostic.gpuUtilizationPct}%
              </div>
              <div className="text-[10px] text-gray-400">
                {diagnostic.gpuUtilizationPct < 60 ? 'Stalled / Starved' : 'Optimal'}
              </div>
            </div>

            <div className="p-3 bg-black/40 rounded-xl border border-white/5 space-y-1">
              <div className="text-gray-500 text-[10px] uppercase">GPU Memory (VRAM)</div>
              <div className="text-base font-bold text-sky-400">
                {diagnostic.gpuMemoryUsedGB} / {diagnostic.gpuMemoryTotalGB} GB
              </div>
              <div className="text-[10px] text-gray-400">92% Allocation (Healthy)</div>
            </div>

            <div className="p-3 bg-black/40 rounded-xl border border-white/5 space-y-1">
              <div className="text-gray-500 text-[10px] uppercase">CPU Core Load</div>
              <div className={`text-base font-bold ${diagnostic.cpuUtilizationPct > 90 ? 'text-red-400' : 'text-emerald-400'}`}>
                {diagnostic.cpuUtilizationPct}%
              </div>
              <div className="text-[10px] text-red-400 font-bold">100% Core Pegged</div>
            </div>

            <div className="p-3 bg-black/40 rounded-xl border border-white/5 space-y-1">
              <div className="text-gray-500 text-[10px] uppercase">DataLoader Rate</div>
              <div className="text-base font-bold text-amber-400">
                {diagnostic.dataloaderThroughputSamplesSec} / sec
              </div>
              <div className="text-[10px] text-gray-400">GPU wants {diagnostic.targetIngestionSamplesSec}/s</div>
            </div>

            <div className="p-3 bg-black/40 rounded-xl border border-white/5 space-y-1">
              <div className="text-gray-500 text-[10px] uppercase">NCCL Latency</div>
              <div className="text-base font-bold text-emerald-400">
                {diagnostic.networkCommunicationLatencyUs} μs
              </div>
              <div className="text-[10px] text-gray-400">InfiniBand NDR 400G</div>
            </div>

            <div className="p-3 bg-black/40 rounded-xl border border-white/5 space-y-1">
              <div className="text-gray-500 text-[10px] uppercase">Checkpoint Integrity</div>
              <div className="text-base font-bold text-white">
                Step {diagnostic.checkpointStep}
              </div>
              <div className="text-[10px] text-emerald-400">SHA-256 Validated</div>
            </div>
          </div>

          {/* Root Cause & Diagnostic Findings */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 text-xs font-mono">
            {/* Left: Suspected Causes */}
            <div className="p-4 rounded-xl bg-black/50 border border-white/10 space-y-3">
              <div className="flex items-center space-x-2 text-red-400 font-bold">
                <AlertTriangle className="w-4 h-4" />
                <span>Primary Bottleneck & Suspected Causes</span>
              </div>
              <p className="text-gray-300 leading-relaxed">
                <strong className="text-white">{diagnostic.primaryBottleneck}:</strong> The Tensor Cores on your BHARAT H100 are spending 58% of execution cycles idle waiting for the next mini-batch to be tokenized and transferred from host memory.
              </p>

              <div className="space-y-1.5 pt-1">
                {diagnostic.suspectedCauses.map((cause, i) => (
                  <div key={i} className="flex items-start space-x-2 text-gray-300">
                    <span className="text-red-400 font-bold">•</span>
                    <span>{cause}</span>
                  </div>
                ))}
              </div>

              <div className="pt-2 border-t border-white/5 text-[11px] text-gray-400">
                Recent Diff: <span className="text-gray-300">{diagnostic.recentChanges}</span>
              </div>
            </div>

            {/* Right: Recommended Fixes with 1-Click Apply */}
            <div className="p-4 rounded-xl bg-black/50 border border-white/10 space-y-3">
              <div className="flex items-center space-x-2 text-emerald-400 font-bold">
                <Wrench className="w-4 h-4" />
                <span>Recommended Fixes & Expected Impact</span>
              </div>

              <div className="space-y-3">
                {diagnostic.recommendedFixes.map(fix => (
                  <div key={fix.id} className="p-3 rounded-lg bg-white/5 border border-white/10 space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="font-bold text-white text-[11px]">{fix.title}</div>
                      <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                        {fix.expectedSpeedup}
                      </span>
                    </div>
                    <p className="text-[11px] text-gray-400">{fix.description}</p>

                    <pre className="p-2 bg-black/80 rounded border border-white/5 text-[10px] text-orange-300 overflow-x-auto font-mono">
                      {fix.codePatch}
                    </pre>

                    <div className="flex items-center justify-between pt-1">
                      <span className="text-[10px] text-emerald-400 font-bold">
                        Impact: {fix.expectedCostSavings}
                      </span>
                      {fix.status === 'EXECUTED' ? (
                        <span className="text-[10px] font-bold text-emerald-400 flex items-center space-x-1">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Patch Applied</span>
                        </span>
                      ) : (
                        <button
                          onClick={() => handleApplyFix(fix.id)}
                          className="px-3 py-1 bg-orange-500 hover:bg-orange-600 text-white rounded text-[10px] font-bold transition flex items-center space-x-1"
                        >
                          <span>Apply Patch to Notebook</span>
                          <ArrowRight className="w-3 h-3" />
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
