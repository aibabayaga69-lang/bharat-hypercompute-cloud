import React, { useRef, useEffect, useState, useCallback } from 'react';
import {
  Maximize2,
  Minimize2,
  RotateCcw,
  Layers,
  Activity,
  Server,
  Cpu,
  MapPin,
  CheckCircle2,
  Radio,
  Zap,
  Info
} from 'lucide-react';
import { TrustBadge } from '../common/TrustBadge';

export interface SupercomputeNode {
  id: string;
  name: string;
  city: string;
  state: string;
  lat: number;
  lng: number;
  x: number; // projected 3d coords
  y: number;
  z: number;
  clusterType: string;
  acceleratorCount: number;
  acceleratorModel: string;
  utilizationPct: number;
  temperatureC: number;
  status: 'Operational' | 'Queue' | 'Maintenance';
  activeJob: string;
  queueDepth: number;
  powerPUE: number;
  greenEnergyPct: number;
  bandwidthGbps: number;
}

const NODES_DATA: SupercomputeNode[] = [
  {
    id: 'delhi_pod_01',
    name: 'Delhi-NCR Sovereign Supercomputing Pod #01',
    city: 'Noida / New Delhi',
    state: 'Uttar Pradesh / NCR',
    lat: 28.5355,
    lng: 77.391,
    x: 0,
    y: 80,
    z: 20,
    clusterType: 'Tier-4 Sovereign Hyperscale',
    acceleratorCount: 64,
    acceleratorModel: 'BHARAT H100 SXM5 (80GB HBM3)',
    utilizationPct: 78,
    temperatureC: 44,
    status: 'Operational',
    activeJob: 'IndicLLM-7B DDP (Distributed Data Parallel)',
    queueDepth: 2,
    powerPUE: 1.14,
    greenEnergyPct: 62,
    bandwidthGbps: 3200
  },
  {
    id: 'blr_corridor_02',
    name: 'Bengaluru Deep-Tech AI Pod #02',
    city: 'Bengaluru',
    state: 'Karnataka',
    lat: 12.9716,
    lng: 77.5946,
    x: 10,
    y: -70,
    z: -30,
    clusterType: 'C-DAC / Academic High-Throughput Pod',
    acceleratorCount: 96,
    acceleratorModel: 'BHARAT TPU v4-16 & H100 Mesh',
    utilizationPct: 86,
    temperatureC: 47,
    status: 'Operational',
    activeJob: 'JAX Multilingual Scaling Benchmark',
    queueDepth: 5,
    powerPUE: 1.18,
    greenEnergyPct: 85,
    bandwidthGbps: 4800
  },
  {
    id: 'mum_hub_03',
    name: 'Mumbai Financial AI Hub Pod #03',
    city: 'Navi Mumbai',
    state: 'Maharashtra',
    lat: 19.076,
    lng: 72.8777,
    x: -80,
    y: -20,
    z: -10,
    clusterType: 'Low-Latency Ultra-Secure Financial Fabric',
    acceleratorCount: 48,
    acceleratorModel: 'BHARAT H100 & L40S Inference Fabric',
    utilizationPct: 54,
    temperatureC: 39,
    status: 'Operational',
    activeJob: 'Sub-millisecond vLLM Indic Serving',
    queueDepth: 1,
    powerPUE: 1.12,
    greenEnergyPct: 70,
    bandwidthGbps: 2400
  },
  {
    id: 'hyd_tpu_04',
    name: 'Hyderabad Sovereign TPU Pod #04',
    city: 'HITEC City, Hyderabad',
    state: 'Telangana',
    lat: 17.385,
    lng: 78.4867,
    x: 20,
    y: -30,
    z: 10,
    clusterType: 'Distributed Matrix Multiplication Pod',
    acceleratorCount: 32,
    acceleratorModel: 'BHARAT TPU v4 Pod Slice (Optical Ring)',
    utilizationPct: 68,
    temperatureC: 41,
    status: 'Operational',
    activeJob: 'Megatron-LM Tensor Parallelism Checkpoint',
    queueDepth: 0,
    powerPUE: 1.16,
    greenEnergyPct: 58,
    bandwidthGbps: 1600
  },
  {
    id: 'pune_cdac_05',
    name: 'Pune Supercomputing & Quantum Gateway #05',
    city: 'Pune',
    state: 'Maharashtra',
    lat: 18.5204,
    lng: 73.8567,
    x: -50,
    y: -40,
    z: -20,
    clusterType: 'National Supercomputing Mission Partner',
    acceleratorCount: 32,
    acceleratorModel: 'PARAM Sovereign Accelerator Pool',
    utilizationPct: 62,
    temperatureC: 42,
    status: 'Operational',
    activeJob: 'Scientific Climate Model Training',
    queueDepth: 1,
    powerPUE: 1.2,
    greenEnergyPct: 90,
    bandwidthGbps: 1600
  }
];

interface HyperCompute3DMapProps {
  onSelectNode?: (node: SupercomputeNode) => void;
}

export const HyperCompute3DMap: React.FC<HyperCompute3DMapProps> = ({ onSelectNode }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  const [selectedNode, setSelectedNode] = useState<SupercomputeNode>(NODES_DATA[0]);
  const [hoveredNode, setHoveredNode] = useState<SupercomputeNode | null>(null);
  const [is3DMode, setIs3DMode] = useState<boolean>(true);
  const [autoRotate, setAutoRotate] = useState<boolean>(true);

  // Refs for 60fps canvas animation & camera angles (eliminates re-render thrashing)
  const rotXRef = useRef<number>(0.35); // tilt
  const rotYRef = useRef<number>(0.2); // azimuth
  const zoomRef = useRef<number>(1.0);
  const autoRotateRef = useRef<boolean>(true);
  const isDraggingRef = useRef<boolean>(false);
  const dragStartRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const selectedNodeRef = useRef<SupercomputeNode>(NODES_DATA[0]);
  const hoveredNodeRef = useRef<SupercomputeNode | null>(null);

  useEffect(() => {
    autoRotateRef.current = autoRotate;
  }, [autoRotate]);

  useEffect(() => {
    selectedNodeRef.current = selectedNode;
  }, [selectedNode]);

  useEffect(() => {
    hoveredNodeRef.current = hoveredNode;
  }, [hoveredNode]);

  // Motion preference
  const [prefersReducedMotion, setPrefersReducedMotion] = useState<boolean>(false);

  useEffect(() => {
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
    setPrefersReducedMotion(mq.matches);
    if (mq.matches) {
      setAutoRotate(false);
      autoRotateRef.current = false;
    }
  }, []);

  const handleNodeClick = (node: SupercomputeNode) => {
    setSelectedNode(node);
    selectedNodeRef.current = node;
    if (onSelectNode) onSelectNode(node);
  };

  const handleResetCamera = () => {
    rotXRef.current = 0.35;
    rotYRef.current = 0.2;
    zoomRef.current = 1.0;
  };

  // Canvas 3D render loop
  useEffect(() => {
    if (!is3DMode) return;

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;

    const handleResize = () => {
      if (containerRef.current && canvas) {
        const rect = containerRef.current.getBoundingClientRect();
        const dpr = window.devicePixelRatio || 1;
        canvas.width = rect.width * dpr;
        canvas.height = rect.height * dpr;
        ctx.scale(dpr, dpr);
      }
    };

    handleResize();
    window.addEventListener('resize', handleResize);

    let tick = 0;

    const render = () => {
      if (!canvas || !containerRef.current) return;
      const width = containerRef.current.clientWidth;
      const height = containerRef.current.clientHeight;

      if (autoRotateRef.current && !isDraggingRef.current && !prefersReducedMotion) {
        rotYRef.current += 0.003;
      }

      ctx.clearRect(0, 0, width, height);

      // Background gradient
      const bgGrad = ctx.createRadialGradient(
        width / 2,
        height / 2,
        10,
        width / 2,
        height / 2,
        Math.max(width, height) / 1.2
      );
      bgGrad.addColorStop(0, '#0c1322');
      bgGrad.addColorStop(0.5, '#070a12');
      bgGrad.addColorStop(1, '#05070c');
      ctx.fillStyle = bgGrad;
      ctx.fillRect(0, 0, width, height);

      const cx = width / 2;
      const cy = height / 2;
      const fov = 380 * zoomRef.current;

      // 3D projection helper
      const project = (x: number, y: number, z: number) => {
        // Rotate around Y
        const cosY = Math.cos(rotYRef.current);
        const sinY = Math.sin(rotYRef.current);
        const x1 = x * cosY - z * sinY;
        const z1 = z * cosY + x * sinY;

        // Rotate around X
        const cosX = Math.cos(rotXRef.current);
        const sinX = Math.sin(rotXRef.current);
        const y2 = y * cosX - z1 * sinX;
        const z2 = z1 * cosX + y * sinX;

        // Perspective
        const scale = fov / (fov + z2 + 250);
        return {
          px: cx + x1 * scale,
          py: cy - y2 * scale,
          scale,
          z2
        };
      };

      // Draw Grid / Hexagonal Plane Base
      ctx.lineWidth = 1;
      const gridSize = 180;
      const step = 45;

      for (let gx = -gridSize; gx <= gridSize; gx += step) {
        const pStart = project(gx, -110, -gridSize);
        const pEnd = project(gx, -110, gridSize);
        ctx.strokeStyle = gx === 0 ? 'rgba(249, 115, 22, 0.35)' : 'rgba(255, 255, 255, 0.06)';
        ctx.beginPath();
        ctx.moveTo(pStart.px, pStart.py);
        ctx.lineTo(pEnd.px, pEnd.py);
        ctx.stroke();
      }

      for (let gz = -gridSize; gz <= gridSize; gz += step) {
        const pStart = project(-gridSize, -110, gz);
        const pEnd = project(gridSize, -110, gz);
        ctx.strokeStyle = gz === 0 ? 'rgba(99, 102, 241, 0.35)' : 'rgba(255, 255, 255, 0.06)';
        ctx.beginPath();
        ctx.moveTo(pStart.px, pStart.py);
        ctx.lineTo(pEnd.px, pEnd.py);
        ctx.stroke();
      }

      // Project all nodes
      const projectedNodes = NODES_DATA.map(node => {
        const base = project(node.x, -110, node.z);
        const heightOffset = -110 + (node.acceleratorCount / 96) * 120;
        const top = project(node.x, heightOffset, node.z);
        return {
          node,
          base,
          top,
          zOrder: top.z2
        };
      });

      // Sort by depth (painter's algorithm)
      projectedNodes.sort((a, b) => b.zOrder - a.zOrder);

      // Draw high-speed inter-pod fiber beams (NKN Mesh)
      for (let i = 0; i < projectedNodes.length; i++) {
        for (let j = i + 1; j < projectedNodes.length; j++) {
          const nA = projectedNodes[i];
          const nB = projectedNodes[j];

          ctx.beginPath();
          ctx.moveTo(nA.top.px, nA.top.py);
          ctx.lineTo(nB.top.px, nB.top.py);
          ctx.strokeStyle = 'rgba(56, 189, 248, 0.18)';
          ctx.lineWidth = 1;
          ctx.stroke();

          // Animated particle packets along beam
          const packetProgress = ((tick * 0.015 + (i + j) * 0.25) % 1);
          const packetX = nA.top.px + (nB.top.px - nA.top.px) * packetProgress;
          const packetY = nA.top.py + (nB.top.py - nA.top.py) * packetProgress;

          ctx.fillStyle = '#38bdf8';
          ctx.beginPath();
          ctx.arc(packetX, packetY, 1.8 * nA.top.scale, 0, Math.PI * 2);
          ctx.fill();
        }
      }

      // Draw Extruded 3D Towers and Nodes
      projectedNodes.forEach(({ node, base, top }) => {
        const isSelected = selectedNodeRef.current?.id === node.id;
        const isHovered = hoveredNodeRef.current?.id === node.id;

        // Pillar beam
        const pillarGrad = ctx.createLinearGradient(base.px, base.py, top.px, top.py);
        if (isSelected) {
          pillarGrad.addColorStop(0, 'rgba(249, 115, 22, 0.2)');
          pillarGrad.addColorStop(1, 'rgba(249, 115, 22, 0.85)');
        } else {
          pillarGrad.addColorStop(0, 'rgba(99, 102, 241, 0.15)');
          pillarGrad.addColorStop(1, 'rgba(56, 189, 248, 0.6)');
        }

        ctx.strokeStyle = pillarGrad;
        ctx.lineWidth = Math.max(3, 7 * top.scale);
        ctx.beginPath();
        ctx.moveTo(base.px, base.py);
        ctx.lineTo(top.px, top.py);
        ctx.stroke();

        // Base ground ring
        ctx.strokeStyle = isSelected ? 'rgba(249, 115, 22, 0.6)' : 'rgba(255, 255, 255, 0.2)';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.arc(base.px, base.py, 12 * base.scale, 0, Math.PI * 2);
        ctx.stroke();

        // Top sphere
        const nodeRadius = (isSelected ? 10 : 8) * top.scale;

        // Outer glow
        const glow = ctx.createRadialGradient(
          top.px,
          top.py,
          nodeRadius * 0.2,
          top.px,
          top.py,
          nodeRadius * 2.5
        );
        if (isSelected) {
          glow.addColorStop(0, 'rgba(249, 115, 22, 0.9)');
          glow.addColorStop(1, 'rgba(249, 115, 22, 0)');
        } else {
          glow.addColorStop(0, 'rgba(56, 189, 248, 0.7)');
          glow.addColorStop(1, 'rgba(56, 189, 248, 0)');
        }
        ctx.fillStyle = glow;
        ctx.beginPath();
        ctx.arc(top.px, top.py, nodeRadius * 2.5, 0, Math.PI * 2);
        ctx.fill();

        // Solid center
        ctx.fillStyle = isSelected ? '#ea580c' : '#0284c7';
        ctx.beginPath();
        ctx.arc(top.px, top.py, nodeRadius, 0, Math.PI * 2);
        ctx.fill();

        // Label
        ctx.fillStyle = isSelected ? '#ffffff' : '#94a3b8';
        ctx.font = `${Math.max(10, 11 * top.scale)}px ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace`;
        ctx.textAlign = 'center';
        ctx.fillText(node.city, top.px, top.py - nodeRadius - 6);

        ctx.fillStyle = isSelected ? '#fb923c' : '#64748b';
        ctx.font = `${Math.max(8, 9 * top.scale)}px ui-monospace, SFMono-Regular, monospace`;
        ctx.fillText(`${node.acceleratorCount}x ${node.acceleratorModel.split(' ')[1]}`, top.px, top.py - nodeRadius - 18);
      });

      tick++;
      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationFrameId);
    };
  }, [is3DMode, prefersReducedMotion]);

  // Pointer interaction for Canvas
  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    isDraggingRef.current = true;
    dragStartRef.current = { x: e.clientX, y: e.clientY };
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!isDraggingRef.current) return;
    const dx = e.clientX - dragStartRef.current.x;
    const dy = e.clientY - dragStartRef.current.y;

    rotYRef.current += dx * 0.007;
    rotXRef.current = Math.max(-0.2, Math.min(1.2, rotXRef.current + dy * 0.007));
    dragStartRef.current = { x: e.clientX, y: e.clientY };
  };

  const handlePointerUp = () => {
    isDraggingRef.current = false;
  };

  const handleWheel = (e: React.WheelEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    zoomRef.current = Math.max(0.6, Math.min(1.8, zoomRef.current - e.deltaY * 0.001));
  };

  return (
    <div className="space-y-4">
      {/* 3D Visualizer Canvas Box */}
      <div
        ref={containerRef}
        className="relative w-full h-[380px] sm:h-[440px] rounded-2xl overflow-hidden border border-white/10 bg-[#07090e] shadow-2xl group"
      >
        {is3DMode ? (
          <canvas
            ref={canvasRef}
            onPointerDown={handlePointerDown}
            onPointerMove={handlePointerMove}
            onPointerUp={handlePointerUp}
            onPointerCancel={handlePointerUp}
            onWheel={handleWheel}
            className="w-full h-full cursor-grab active:cursor-grabbing touch-none select-none block"
          />
        ) : (
          /* 2D Schematic Alternative View */
          <div className="w-full h-full p-6 overflow-y-auto bg-[#07090e] flex flex-col justify-center">
            <div className="text-xs font-mono text-gray-400 mb-3 flex items-center justify-between">
              <span>2D SUPERCOMPUTING POD TOPOLOGY</span>
              <span className="text-orange-400">NATIONAL KNOWLEDGE NETWORK (NKN)</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {NODES_DATA.map(node => (
                <button
                  key={node.id}
                  onClick={() => handleNodeClick(node)}
                  className={`p-3.5 rounded-xl border text-left transition ${
                    selectedNode?.id === node.id
                      ? 'bg-orange-500/15 border-orange-500/50 text-white'
                      : 'bg-white/5 border-white/5 hover:border-white/20 text-gray-300'
                  }`}
                >
                  <div className="flex items-center justify-between text-xs font-bold font-mono">
                    <span>{node.city}</span>
                    <span className="text-emerald-400">{node.utilizationPct}% Util</span>
                  </div>
                  <div className="text-[11px] text-gray-400 mt-1 truncate">{node.name}</div>
                  <div className="text-[10px] text-orange-400 font-mono mt-2">
                    {node.acceleratorCount}× {node.acceleratorModel}
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Top-Right Control Toolbar */}
        <div className="absolute top-3 right-3 flex items-center space-x-2 z-10">
          <button
            onClick={() => setIs3DMode(!is3DMode)}
            className="px-2.5 py-1 rounded-lg bg-black/70 backdrop-blur-md border border-white/10 text-xs font-mono text-gray-200 hover:text-white hover:bg-black/90 transition flex items-center space-x-1.5"
            title="Toggle 2D / 3D Mode"
          >
            <Layers className="w-3.5 h-3.5 text-orange-400" />
            <span>{is3DMode ? '3D Active' : '2D Grid'}</span>
          </button>

          {is3DMode && (
            <>
              <button
                onClick={() => setAutoRotate(!autoRotate)}
                className={`px-2.5 py-1 rounded-lg bg-black/70 backdrop-blur-md border border-white/10 text-xs font-mono transition ${
                  autoRotate ? 'text-orange-400 border-orange-500/40' : 'text-gray-400 hover:text-white'
                }`}
                title="Toggle Auto-Orbit"
              >
                Orbit
              </button>

              <button
                onClick={handleResetCamera}
                className="p-1.5 rounded-lg bg-black/70 backdrop-blur-md border border-white/10 text-gray-400 hover:text-white hover:bg-black/90 transition"
                title="Reset Camera Angle"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
            </>
          )}
        </div>

        {/* Top-Left Status Strip */}
        <div className="absolute top-3 left-3 flex items-center space-x-2 z-10 pointer-events-none">
          <div className="flex items-center space-x-1.5 px-3 py-1 rounded-lg bg-black/70 backdrop-blur-md border border-white/10 text-xs font-mono text-gray-300">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="font-bold">5 HyperCompute Pods</span>
            <span className="text-gray-500">|</span>
            <span className="text-orange-400 font-bold">272 High-End Accelerators</span>
          </div>
          <TrustBadge type="SIMULATED" size="xs" />
        </div>

        {/* Bottom Interactive Node Strip */}
        <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between z-10 pointer-events-auto">
          <div className="flex items-center space-x-1.5 overflow-x-auto py-1 max-w-full">
            {NODES_DATA.map(node => (
              <button
                key={node.id}
                onClick={() => handleNodeClick(node)}
                className={`px-2.5 py-1 rounded-lg text-xs font-mono whitespace-nowrap transition border ${
                  selectedNode?.id === node.id
                    ? 'bg-orange-500 text-white font-bold border-orange-400 shadow-lg shadow-orange-500/20'
                    : 'bg-black/70 backdrop-blur-md text-gray-400 hover:text-white border-white/10 hover:border-white/20'
                }`}
              >
                {node.city}
              </button>
            ))}
          </div>

          <div className="hidden sm:flex items-center space-x-2 text-[10px] font-mono text-gray-400 bg-black/70 backdrop-blur-md px-2.5 py-1 rounded-lg border border-white/10 shrink-0">
            <Info className="w-3 h-3 text-orange-400" />
            <span>Drag to rotate • Scroll to zoom</span>
          </div>
        </div>
      </div>

      {/* Selected Node Inspector Drawer / Card */}
      {selectedNode && (
        <div className="p-5 rounded-2xl bg-[#0a0e17] border border-orange-500/30 shadow-xl space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/10 pb-3">
            <div className="space-y-0.5">
              <div className="flex items-center space-x-2">
                <span className="text-xs font-mono text-orange-400 font-bold uppercase">
                  ACTIVE 3D NODE INSPECTOR
                </span>
                <span className="text-gray-600">/</span>
                <span className="text-xs font-mono text-emerald-400 flex items-center space-x-1">
                  <CheckCircle2 className="w-3 h-3 inline" />
                  <span>{selectedNode.status}</span>
                </span>
              </div>
              <h3 className="text-lg font-bold text-white font-display flex items-center space-x-2">
                <Server className="w-5 h-5 text-orange-400" />
                <span>{selectedNode.name}</span>
              </h3>
              <p className="text-xs text-gray-400">
                {selectedNode.city}, {selectedNode.state} • {selectedNode.clusterType}
              </p>
            </div>

            <div className="flex items-center space-x-4 shrink-0 text-right">
              <div>
                <div className="text-[10px] font-mono text-gray-400">Cluster Capacity</div>
                <div className="text-base font-bold text-white font-mono">
                  {selectedNode.acceleratorCount}× Accelerators
                </div>
              </div>
              <div>
                <div className="text-[10px] font-mono text-gray-400">Live Utilization</div>
                <div className="text-base font-bold text-emerald-400 font-mono">
                  {selectedNode.utilizationPct}%
                </div>
              </div>
            </div>
          </div>

          {/* Telemetry Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 text-xs font-mono">
            <div className="p-3 bg-black/40 rounded-xl border border-white/5 space-y-1">
              <div className="text-gray-500 text-[10px] uppercase">Accelerator Spec</div>
              <div className="text-white font-semibold truncate">{selectedNode.acceleratorModel}</div>
            </div>

            <div className="p-3 bg-black/40 rounded-xl border border-white/5 space-y-1">
              <div className="text-gray-500 text-[10px] uppercase">Interconnect Fabric</div>
              <div className="text-sky-400 font-semibold">{selectedNode.bandwidthGbps} Gbps RoCE/InfiniBand</div>
            </div>

            <div className="p-3 bg-black/40 rounded-xl border border-white/5 space-y-1">
              <div className="text-gray-500 text-[10px] uppercase">Power Efficiency (PUE)</div>
              <div className="text-white font-semibold">{selectedNode.powerPUE} PUE (Sub-ambient liquid)</div>
            </div>

            <div className="p-3 bg-black/40 rounded-xl border border-white/5 space-y-1">
              <div className="text-gray-500 text-[10px] uppercase">Clean Solar/Hydro %</div>
              <div className="text-emerald-400 font-semibold">{selectedNode.greenEnergyPct}% Sovereign Green</div>
            </div>

            <div className="p-3 bg-black/40 rounded-xl border border-white/5 space-y-1">
              <div className="text-gray-500 text-[10px] uppercase">Core Thermal</div>
              <div className="text-amber-400 font-semibold">{selectedNode.temperatureC}°C Nominal</div>
            </div>

            <div className="p-3 bg-black/40 rounded-xl border border-white/5 space-y-1">
              <div className="text-gray-500 text-[10px] uppercase">Queue Allocation</div>
              <div className="text-white font-semibold">{selectedNode.queueDepth} pending workloads</div>
            </div>
          </div>

          {/* Live Workload Running */}
          <div className="p-3 bg-white/5 rounded-xl border border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs font-mono">
            <div className="flex items-center space-x-2">
              <Activity className="w-4 h-4 text-orange-400 animate-pulse" />
              <span className="text-gray-400">Current Primary Job:</span>
              <span className="text-white font-bold">{selectedNode.activeJob}</span>
            </div>
            <div className="flex items-center space-x-2">
              <span className="text-gray-400 text-[11px]">Sovereign Indian Data Boundary:</span>
              <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 text-[10px] font-bold border border-emerald-500/40">
                100% IN-REGION
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
