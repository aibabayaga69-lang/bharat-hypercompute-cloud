import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { TrustBadge } from '../common/TrustBadge';
import { HyperComputeProvider } from '../../types/aiCompany';
import { HyperCompute3DMap } from './HyperCompute3DMap';
import {
  MapPin,
  Cpu,
  Radio,
  Server,
  Activity,
  Layers,
  Sparkles,
  DollarSign,
  TrendingDown,
  ShieldCheck,
  Zap,
  Globe,
  CheckCircle2,
  Clock,
  Leaf
} from 'lucide-react';

export const ComputeMapView: React.FC = () => {
  const { providers, showNotification } = useApp();
  const [selectedRoutingStrategy, setSelectedRoutingStrategy] = useState<'Auto' | 'Fastest' | 'Lowest Cost' | 'Lowest Carbon' | 'India Region'>('India Region');
  const [selectedCurrency, setSelectedCurrency] = useState<'INR' | 'USD'>('INR');

  const exchangeRateUSDToINR = 86.5;

  const formatCurrency = (inrAmount: number) => {
    if (selectedCurrency === 'USD') {
      return `$${(inrAmount / exchangeRateUSDToINR).toFixed(2)}`;
    }
    return `₹${inrAmount.toLocaleString()}`;
  };

  const regions = [
    {
      id: 'reg_delhi',
      name: 'Delhi-NCR Supercomputing Pod #01',
      city: 'Noida / New Delhi',
      status: 'Operational',
      utilizationPct: 78,
      clusters: [
        { name: '4× BHARAT H100 SXM5 (Cluster A)', status: 'Busy', job: 'IndicLLM-7B (DDP)' },
        { name: '8× BHARAT H100 SXM5 (Cluster B)', status: 'Available', job: 'Idle' },
        { name: '16× BHARAT A100 (Cluster C)', status: 'Busy', job: 'Speech-Indic (FineTune)' }
      ]
    },
    {
      id: 'reg_blr',
      name: 'Bengaluru Deep-Tech Corridor Pod #02',
      city: 'Bengaluru, Karnataka',
      status: 'Operational',
      utilizationPct: 84,
      clusters: [
        { name: 'BHARAT TPU v4-16 Pod Slice', status: 'Queue', job: 'JAX Scaling Benchmark' },
        { name: '8× BHARAT L40S Inference Engine', status: 'Busy', job: 'Production vLLM Serving' }
      ]
    },
    {
      id: 'reg_mum',
      name: 'Mumbai Sovereign AI Hub Pod #03',
      city: 'Mumbai, Maharashtra',
      status: 'Operational',
      utilizationPct: 52,
      clusters: [
        { name: '4× BHARAT H100 SXM5 (Cluster D)', status: 'Available', job: 'Idle' },
        { name: 'Institutional Connected Node Adapter', status: 'Available', job: 'Real-Time Sync' }
      ]
    }
  ];

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#0d1424] via-[#09111c] to-[#0d1424] p-6 rounded-2xl border border-white/10 shadow-2xl relative overflow-hidden">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center space-x-2">
              <span className="text-xs font-mono text-orange-400 font-bold uppercase tracking-wider">
                HYPERCOMPUTE FABRIC & MARKET
              </span>
              <span className="text-gray-600">/</span>
              <TrustBadge type="DEMO" size="xs" />
              <TrustBadge type="ESTIMATED" size="xs" />
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white font-display flex items-center space-x-2">
              <MapPin className="w-7 h-7 text-orange-400" />
              <span>HyperCompute Map & Transparent Provider Market</span>
            </h1>
            <p className="text-xs sm:text-sm text-gray-300 max-w-2xl leading-relaxed">
              Provider-agnostic compute layer showing live telemetry, data residency, Wholesale cost, public market benchmarks, and sustainable margins. Target ~50% market discount where economically viable.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0 font-mono text-xs">
            {/* Currency Selector */}
            <div className="p-1 bg-black/50 border border-white/10 rounded-lg flex items-center space-x-1">
              <button
                onClick={() => setSelectedCurrency('INR')}
                className={`px-2.5 py-1 rounded transition ${
                  selectedCurrency === 'INR' ? 'bg-orange-500 text-white font-bold' : 'text-gray-400 hover:text-white'
                }`}
              >
                ₹ INR (UPI / GST)
              </button>
              <button
                onClick={() => setSelectedCurrency('USD')}
                className={`px-2.5 py-1 rounded transition ${
                  selectedCurrency === 'USD' ? 'bg-orange-500 text-white font-bold' : 'text-gray-400 hover:text-white'
                }`}
              >
                $ USD (Global)
              </button>
            </div>
          </div>
        </div>

        {/* Compute Brain Routing Mode Selector */}
        <div className="flex items-center space-x-2 mt-6 pt-4 border-t border-white/10 overflow-x-auto text-xs font-mono">
          <span className="text-gray-400 shrink-0 mr-1">Compute Brain Route:</span>
          {(['Auto', 'Fastest', 'Lowest Cost', 'Lowest Carbon', 'India Region'] as const).map(strat => (
            <button
              key={strat}
              onClick={() => setSelectedRoutingStrategy(strat)}
              className={`px-3 py-1.5 rounded-lg shrink-0 transition ${
                selectedRoutingStrategy === strat
                  ? 'bg-orange-500 text-white font-bold'
                  : 'bg-white/5 text-gray-400 hover:text-white'
              }`}
            >
              {strat}
            </button>
          ))}
        </div>
      </div>

      {/* SECTION 0: INTERACTIVE 3D HYPERCOMPUTE MAP */}
      <div className="space-y-2">
        <div className="flex items-center justify-between text-xs font-mono text-gray-400">
          <span className="flex items-center space-x-1.5">
            <Globe className="w-3.5 h-3.5 text-orange-400" />
            <span className="text-white font-bold">Interactive 3D Sovereign Pod Topology</span>
            <span>(Simulated Telemetry & Topology)</span>
          </span>
          <TrustBadge type="SIMULATED" size="xs" />
        </div>
        <HyperCompute3DMap />
      </div>

      {/* SECTION 1: TRANSPARENT PROVIDER MARKETPLACE (WHOLESALE LEDGER) */}
      <div className="space-y-4">
        <div className="flex items-center justify-between text-xs font-mono text-gray-400">
          <span className="flex items-center space-x-1.5">
            <DollarSign className="w-3.5 h-3.5 text-emerald-400" />
            <span className="text-white font-bold">Transparent Marketplace Economics</span>
            <span>(Wholesale vs. Customer vs. Market Benchmark)</span>
          </span>
          <TrustBadge type="ESTIMATED" size="xs" />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {providers.map(prov => {
            const discountPct = Math.round(
              ((prov.publicMarketBenchmarkPerHour - prov.customerPricePerHour) / prov.publicMarketBenchmarkPerHour) * 100
            );

            return (
              <div
                key={prov.id}
                className="p-5 rounded-2xl bg-[#0a0e17] border border-white/10 space-y-4 text-xs font-mono hover:border-white/20 transition"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-white/5 pb-3">
                  <div>
                    <div className="text-white font-bold font-sans text-sm">{prov.name}</div>
                    <div className="text-[11px] text-gray-400 flex items-center space-x-1.5 mt-0.5">
                      <MapPin className="w-3 h-3 text-orange-400" />
                      <span>{prov.region}</span>
                    </div>
                  </div>

                  <div className="flex items-center space-x-2">
                    <TrustBadge type={prov.tier === 'DEMO' ? 'DEMO' : 'REQUIRES_PROVIDER'} size="xs" />
                    <span
                      className={`text-[9px] px-2 py-0.5 rounded font-bold uppercase ${
                        prov.capacityStatus === 'AVAILABLE'
                          ? 'bg-emerald-950 text-emerald-400 border border-emerald-800/40'
                          : prov.capacityStatus === 'QUEUE'
                          ? 'bg-amber-950 text-amber-400 border border-amber-800/40'
                          : 'bg-rose-950 text-rose-400 border border-rose-800/40'
                      }`}
                    >
                      {prov.capacityStatus}
                    </span>
                  </div>
                </div>

                <div className="space-y-1">
                  <div className="text-gray-300 font-sans font-medium">{prov.accelerator}</div>
                  <div className="flex justify-between text-[11px] text-gray-400">
                    <span>Data Residency:</span>
                    <span className="text-emerald-400">{prov.dataResidency}</span>
                  </div>
                  <div className="flex justify-between text-[11px] text-gray-400">
                    <span>Queue Delay / Carbon:</span>
                    <span>{prov.queueTimeMinutes} min queue | Score: <span className="text-emerald-400">{prov.carbonScore}</span></span>
                  </div>
                </div>

                {/* Price Matrix */}
                <div className="p-3 bg-black/50 rounded-xl border border-white/5 space-y-2">
                  <div className="grid grid-cols-3 gap-2 text-center">
                    <div>
                      <div className="text-[10px] text-gray-500">Wholesale Cost</div>
                      <div className="text-gray-300 font-bold mt-0.5">{formatCurrency(prov.wholesaleCostPerHour)}/hr</div>
                    </div>
                    <div>
                      <div className="text-[10px] text-orange-400 font-bold">Bharat Price</div>
                      <div className="text-white font-bold text-sm mt-0.5">{formatCurrency(prov.customerPricePerHour)}/hr</div>
                    </div>
                    <div>
                      <div className="text-[10px] text-gray-500">Public Reference</div>
                      <div className="text-gray-400 line-through mt-0.5">{formatCurrency(prov.publicMarketBenchmarkPerHour)}/hr</div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-[10px] pt-2 border-t border-white/5">
                    <span className="text-emerald-400 font-bold flex items-center space-x-1">
                      <TrendingDown className="w-3 h-3" />
                      <span>{discountPct > 0 ? `${discountPct}% Discount vs Market` : 'Custom Dedicated Hardware'}</span>
                    </span>
                    <span className="text-gray-400">
                      Platform Margin: <span className="text-sky-400 font-bold">{prov.grossMarginPct}%</span>
                    </span>
                  </div>
                </div>

                <div className="pt-1 flex items-center justify-between">
                  <button
                    onClick={() => showNotification(`Provisioning allocation on ${prov.name} using route: ${selectedRoutingStrategy}`, 'success')}
                    className="w-full py-2 bg-orange-500/10 hover:bg-orange-500/20 text-orange-400 border border-orange-500/30 rounded-lg transition font-bold"
                  >
                    Select Provider Allocation
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* SECTION 2: PHYSICAL GEOGRAPHIC REGIONS & CLUSTERS */}
      <div className="space-y-4 pt-4">
        <div className="text-xs font-mono text-gray-400 flex items-center justify-between">
          <span>Active Supercomputing Pods & Node Utilization</span>
          <span className="text-emerald-400">All National Data Centers Connected</span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {regions.map(reg => (
            <div key={reg.id} className="p-5 rounded-2xl bg-[#0a0e17] border border-white/10 space-y-4 shadow-xl">
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <div>
                  <h3 className="font-bold text-white text-sm font-display">{reg.name}</h3>
                  <div className="text-[11px] text-gray-400 font-mono">{reg.city}</div>
                </div>
                <span className="text-emerald-400 text-[10px] font-mono flex items-center space-x-1">
                  <Radio className="w-2.5 h-2.5 animate-pulse" />
                  <span>ONLINE</span>
                </span>
              </div>

              {/* Utilization Bar */}
              <div className="space-y-1">
                <div className="flex justify-between text-[11px] font-mono text-gray-400">
                  <span>Cluster Load</span>
                  <span className="text-white font-bold">{reg.utilizationPct}%</span>
                </div>
                <div className="w-full bg-white/10 h-1.5 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-orange-500 to-amber-400"
                    style={{ width: `${reg.utilizationPct}%` }}
                  />
                </div>
              </div>

              {/* Clusters in Region */}
              <div className="space-y-2 pt-2">
                <div className="text-[10px] font-mono uppercase text-gray-500">Allocated Pods</div>
                {reg.clusters.map((cluster, i) => (
                  <div key={i} className="p-2.5 bg-black/40 rounded-lg border border-white/5 space-y-1">
                    <div className="flex items-center justify-between text-xs font-mono">
                      <span className="text-white font-medium truncate">{cluster.name}</span>
                      <span
                        className={`text-[9px] px-1.5 py-0.5 rounded font-bold ${
                          cluster.status === 'Available'
                            ? 'bg-emerald-950 text-emerald-400 border border-emerald-800/40'
                            : cluster.status === 'Queue'
                            ? 'bg-amber-950 text-amber-400 border border-amber-800/40'
                            : 'bg-indigo-950 text-indigo-400 border border-indigo-800/40'
                        }`}
                      >
                        {cluster.status.toUpperCase()}
                      </span>
                    </div>
                    <div className="text-[10px] text-gray-400 font-sans truncate">
                      Workload: {cluster.job}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
