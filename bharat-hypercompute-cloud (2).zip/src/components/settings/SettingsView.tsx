import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { TrustBadge } from '../common/TrustBadge';
import {
  Settings,
  Key,
  BrainCircuit,
  Lock,
  Plus,
  Trash2,
  CheckCircle2,
  Sliders,
  Shield,
  RotateCcw
} from 'lucide-react';

export const SettingsView: React.FC = () => {
  const { user, toggleEntitlement, researchMemory, clearResearchMemory, showNotification } = useApp();

  const [secrets, setSecrets] = useState([
    { key: 'HF_TOKEN', maskedVal: 'hf_••••••••••••••••••••39a1', scope: 'Project' },
    { key: 'WANDB_API_KEY', maskedVal: 'wandb_••••••••••••••••881b', scope: 'Global' },
    { key: 'BHARAT_CLOUD_CREDENTIALS', maskedVal: 'bsy_••••••••••••••••10c4', scope: 'Protected' }
  ]);

  const [newKey, setNewKey] = useState('');
  const [newVal, setNewVal] = useState('');

  const handleAddSecret = () => {
    if (!newKey.trim() || !newVal.trim()) {
      showNotification('Please enter both Secret Name and Value.', 'warning');
      return;
    }
    setSecrets([
      ...secrets,
      {
        key: newKey.toUpperCase().replace(/\s+/g, '_'),
        maskedVal: `${newVal.slice(0, 3)}••••••••••••${newVal.slice(-3)}`,
        scope: 'Project'
      }
    ]);
    setNewKey('');
    setNewVal('');
    showNotification('Secret encrypted and registered in hardware keystore.', 'success');
  };

  const handleDeleteSecret = (keyName: string) => {
    setSecrets(secrets.filter(s => s.key !== keyName));
    showNotification(`Secret ${keyName} deleted.`, 'info');
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center space-x-2">
            <span className="text-xs font-mono text-orange-400 font-bold uppercase tracking-wider">
              CONFIGURATION & SECURITY
            </span>
            <span className="text-gray-600">/</span>
            <TrustBadge type="APPROVED" size="xs" />
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white font-display flex items-center space-x-2">
            <Settings className="w-7 h-7 text-orange-400" />
            <span>Workspace Settings & Secrets</span>
          </h1>
          <p className="text-xs sm:text-sm text-gray-400">
            Hardware-backed secrets keystore, sovereign memory controls, and entitlement preferences.
          </p>
        </div>
      </div>

      {/* Grid: Secrets & Memory */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Secrets Architecture Card */}
        <div className="p-6 rounded-2xl bg-[#0a0e17] border border-white/10 space-y-4 shadow-xl">
          <div className="flex items-center justify-between border-b border-white/10 pb-3">
            <div className="flex items-center space-x-2 text-xs font-mono text-white font-bold">
              <Lock className="w-4 h-4 text-orange-400" />
              <span>Secrets & Key Architecture</span>
            </div>
            <span className="text-[10px] font-mono text-emerald-400">Masked & Protected</span>
          </div>

          <div className="space-y-2 font-mono text-xs">
            {secrets.map(s => (
              <div key={s.key} className="p-3 bg-black/40 rounded-lg border border-white/5 flex items-center justify-between">
                <div>
                  <div className="text-white font-bold">{s.key}</div>
                  <div className="text-[11px] text-gray-500">{s.maskedVal}</div>
                </div>
                <div className="flex items-center space-x-2">
                  <span className="px-1.5 py-0.5 rounded bg-white/5 text-gray-400 text-[9px] uppercase">
                    {s.scope}
                  </span>
                  <button
                    onClick={() => handleDeleteSecret(s.key)}
                    className="p-1 text-gray-500 hover:text-rose-400 transition"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* Add Secret Form */}
          <div className="pt-2 border-t border-white/5 space-y-2 text-xs font-mono">
            <div className="text-[11px] text-gray-400">Register New Secret Key</div>
            <div className="grid grid-cols-2 gap-2">
              <input
                type="text"
                placeholder="KEY_NAME"
                value={newKey}
                onChange={e => setNewKey(e.target.value)}
                className="bg-black/50 border border-white/10 rounded-lg p-2 text-white focus:outline-none focus:border-orange-500"
              />
              <input
                type="password"
                placeholder="Secret Value"
                value={newVal}
                onChange={e => setNewVal(e.target.value)}
                className="bg-black/50 border border-white/10 rounded-lg p-2 text-white focus:outline-none focus:border-orange-500"
              />
            </div>
            <button
              onClick={handleAddSecret}
              className="w-full py-2 bg-white/10 hover:bg-white/15 text-gray-200 rounded-lg font-bold transition flex items-center justify-center space-x-1"
            >
              <Plus className="w-3.5 h-3.5 text-orange-400" />
              <span>Store Secret</span>
            </button>
          </div>
        </div>

        {/* Research Memory Card */}
        <div className="p-6 rounded-2xl bg-[#0a0e17] border border-white/10 space-y-4 shadow-xl">
          <div className="flex items-center justify-between border-b border-white/10 pb-3">
            <div className="flex items-center space-x-2 text-xs font-mono text-white font-bold">
              <BrainCircuit className="w-4 h-4 text-orange-400" />
              <span>Sovereign Research Memory</span>
            </div>
            <button
              onClick={clearResearchMemory}
              className="text-[10px] font-mono text-rose-400 hover:text-rose-300 flex items-center space-x-1 transition"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Clear Memory</span>
            </button>
          </div>

          <p className="text-xs text-gray-400">
            The AI Research Copilot and Compute Brain remember your technical preferences, architectural decisions, and error history to personalize recommendations.
          </p>

          <div className="space-y-2 font-mono text-xs">
            {researchMemory.map((mem, idx) => (
              <div key={idx} className="p-3 bg-black/40 rounded-lg border border-white/5 space-y-1">
                <div className="flex justify-between items-center text-[10px]">
                  <span className="text-orange-400 font-bold uppercase">{mem.key.replace(/_/g, ' ')}</span>
                  <span className="text-gray-500">{mem.timestamp}</span>
                </div>
                <div className="text-gray-200 text-xs font-sans">{mem.finding}</div>
                <div className="text-[10px] text-gray-400 flex justify-between">
                  <span>Evidence: {mem.evidence}</span>
                  <span className="text-emerald-400 font-bold">Confidence: {mem.confidence}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
