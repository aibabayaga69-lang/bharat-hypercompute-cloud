import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { TrustBadge } from '../common/TrustBadge';
import {
  CreditCard,
  Coins,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  Copy,
  ExternalLink,
  QrCode,
  ArrowRight,
  RefreshCw,
  Clock,
  Sparkles,
  Lock,
  Wallet
} from 'lucide-react';

export const CryptoGatewayView: React.FC = () => {
  const {
    cryptoTokens,
    cryptoSessions,
    activeCryptoSession,
    createCryptoPaymentSession,
    simulateBlockchainConfirmation,
    user,
    showNotification
  } = useApp();

  const [paymentMode, setPaymentMode] = useState<'crypto' | 'fiat'>('crypto');
  const [selectedTokenSymbol, setSelectedTokenSymbol] = useState<string>('YGO');
  const [selectedPlan, setSelectedPlan] = useState<'founder' | 'credit_pack'>('founder');
  const [walletType, setWalletType] = useState<'external' | 'custodial'>('external');
  const [connectedWalletAddress, setConnectedWalletAddress] = useState<string | null>(null);

  const priorityTokens = cryptoTokens.filter(t => t.isPriority);
  const otherTokens = cryptoTokens.filter(t => !t.isPriority);

  const basePriceINR = selectedPlan === 'founder' ? 19999 : 4999;

  const handleConnectWallet = () => {
    // Non-custodial client-side connection simulation (never accesses or stores private keys)
    const mockAddr = '0x71C...B9a4 (MetaMask / Non-Custodial)';
    setConnectedWalletAddress(mockAddr);
    showNotification('External self-custody wallet connected securely. Private keys remain strictly on device.', 'success');
  };

  const handleInitiatePayment = () => {
    const planId = selectedPlan === 'founder' ? 'founder_monthly' : 'credits_5000';
    createCryptoPaymentSession(planId, selectedTokenSymbol, basePriceINR);
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard?.writeText?.(text);
    showNotification('Deposit address copied to clipboard.', 'info');
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Top Banner */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-gradient-to-r from-[#0c1220] via-[#080d16] to-[#0c1220] p-6 rounded-2xl border border-white/10 shadow-xl">
        <div className="space-y-1">
          <div className="flex items-center space-x-2">
            <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-orange-500/20 text-orange-400 border border-orange-500/30">
              MII Payment Infrastructure
            </span>
            <span className="text-xs text-gray-400 font-mono">Dual-Rail Settlement Architecture (Requires Web3 RPC / Provider for Mainnet)</span>
            <TrustBadge type="SIMULATED" size="xs" />
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-white font-display flex items-center space-x-2">
            <Coins className="w-7 h-7 text-orange-400" />
            <span>MII Crypto & Global Fiat Payment Gateway</span>
          </h1>
          <p className="text-sm text-gray-400 max-w-3xl leading-relaxed">
            Enterprise checkout supporting UPI/INR cards alongside multi-chain crypto. Priority discount tokens (YGO, YUSD, YAGYX) offer up to 30% savings with on-chain mempool verification and zero plaintext private key storage.
          </p>
        </div>

        <div className="flex items-center space-x-3 shrink-0">
          {!connectedWalletAddress ? (
            <button
              onClick={handleConnectWallet}
              className="px-4 py-2.5 bg-white/10 hover:bg-white/15 text-white rounded-xl text-xs font-bold transition flex items-center space-x-1.5 border border-white/10"
            >
              <Wallet className="w-4 h-4 text-orange-400" />
              <span>Connect External Wallet</span>
            </button>
          ) : (
            <div className="px-3 py-1.5 bg-emerald-500/10 border border-emerald-500/30 rounded-xl text-xs font-mono text-emerald-400 flex items-center space-x-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>{connectedWalletAddress}</span>
            </div>
          )}
        </div>
      </div>

      {/* Main Grid: Checkout Builder & Active Payment Session */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column (7 cols): Payment Configurator */}
        <div className="lg:col-span-7 space-y-6">
          {/* Plan Selector */}
          <div className="p-5 rounded-2xl bg-[#0a0e17] border border-white/10 space-y-3">
            <h2 className="text-sm font-bold uppercase tracking-wider text-gray-400 font-mono">
              1. Select Platform Entitlement Plan
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div
                onClick={() => setSelectedPlan('founder')}
                className={`p-4 rounded-xl border transition cursor-pointer space-y-2 ${
                  selectedPlan === 'founder'
                    ? 'bg-orange-500/10 border-orange-500/50'
                    : 'bg-white/5 border-white/5 hover:border-white/20'
                }`}
              >
                <div className="flex justify-between items-center">
                  <span className="font-bold text-white text-sm">Founder Unlimited Tier</span>
                  <span className="text-xs font-mono text-orange-400 font-bold">₹19,999 / mo</span>
                </div>
                <p className="text-xs text-gray-400">
                  Unlimited DDP cluster access, priority queue, 1,000-Agent Brain access, and full API deployment.
                </p>
              </div>

              <div
                onClick={() => setSelectedPlan('credit_pack')}
                className={`p-4 rounded-xl border transition cursor-pointer space-y-2 ${
                  selectedPlan === 'credit_pack'
                    ? 'bg-orange-500/10 border-orange-500/50'
                    : 'bg-white/5 border-white/5 hover:border-white/20'
                }`}
              >
                <div className="flex justify-between items-center">
                  <span className="font-bold text-white text-sm">100 Compute-Hours Pack</span>
                  <span className="text-xs font-mono text-gray-300 font-bold">₹4,999 once</span>
                </div>
                <p className="text-xs text-gray-400">
                  On-demand H100/L40S credits with no expiration. Ideal for university papers and checkpoint fine-tunes.
                </p>
              </div>
            </div>
          </div>

          {/* Payment Method Switcher */}
          <div className="p-5 rounded-2xl bg-[#0a0e17] border border-white/10 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-bold uppercase tracking-wider text-gray-400 font-mono">
                2. Select Payment Railroad
              </h2>
              <div className="flex bg-[#07090e] p-1 rounded-lg border border-white/10 text-xs font-mono">
                <button
                  onClick={() => setPaymentMode('crypto')}
                  className={`px-3 py-1 rounded transition ${
                    paymentMode === 'crypto' ? 'bg-orange-500 text-white font-bold' : 'text-gray-400 hover:text-white'
                  }`}
                >
                  Crypto (Discounts Active)
                </button>
                <button
                  onClick={() => setPaymentMode('fiat')}
                  className={`px-3 py-1 rounded transition ${
                    paymentMode === 'fiat' ? 'bg-orange-500 text-white font-bold' : 'text-gray-400 hover:text-white'
                  }`}
                >
                  Fiat (INR / UPI / Cards)
                </button>
              </div>
            </div>

            {paymentMode === 'crypto' ? (
              <div className="space-y-3">
                {/* Priority Tokens Group */}
                <div className="space-y-2">
                  <div className="flex items-center space-x-1.5 text-xs font-mono text-orange-400">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>PRIORITY PROTOCOL TOKENS (HIGHEST DISCOUNT)</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    {priorityTokens.map(token => {
                      const isSelected = selectedTokenSymbol === token.symbol;
                      return (
                        <div
                          key={token.symbol}
                          onClick={() => setSelectedTokenSymbol(token.symbol)}
                          className={`p-3.5 rounded-xl border transition cursor-pointer space-y-1.5 ${
                            isSelected
                              ? 'bg-orange-500/15 border-orange-500'
                              : 'bg-[#07090e] border-white/10 hover:border-white/20'
                          }`}
                        >
                          <div className="flex justify-between items-center">
                            <span className="font-bold text-white text-sm font-mono">{token.symbol}</span>
                            <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                              -{token.discountPct}% OFF
                            </span>
                          </div>
                          <div className="text-[11px] text-gray-400 truncate">{token.name}</div>
                          <div className="text-[10px] text-gray-500 font-mono">{token.network}</div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Standard Assets */}
                <div className="space-y-2 pt-2">
                  <div className="text-xs font-mono text-gray-400">STANDARD NATIVE & STABLE ASSETS</div>
                  <div className="grid grid-cols-2 gap-3">
                    {otherTokens.map(token => {
                      const isSelected = selectedTokenSymbol === token.symbol;
                      return (
                        <div
                          key={token.symbol}
                          onClick={() => setSelectedTokenSymbol(token.symbol)}
                          className={`p-3 rounded-xl border transition cursor-pointer flex items-center justify-between ${
                            isSelected
                              ? 'bg-orange-500/15 border-orange-500'
                              : 'bg-[#07090e] border-white/10 hover:border-white/20'
                          }`}
                        >
                          <div>
                            <div className="font-bold text-white text-xs font-mono">{token.symbol}</div>
                            <div className="text-[10px] text-gray-400">{token.network}</div>
                          </div>
                          <span className="text-[10px] text-emerald-400 font-mono">-{token.discountPct}%</span>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Custody Model Selection */}
                <div className="p-3 bg-white/5 rounded-xl border border-white/5 space-y-2">
                  <div className="text-xs font-mono text-gray-400">WALLET ARCHITECTURE</div>
                  <div className="flex items-center space-x-4 text-xs">
                    <label className="flex items-center space-x-1.5 cursor-pointer">
                      <input
                        type="radio"
                        checked={walletType === 'external'}
                        onChange={() => setWalletType('external')}
                        className="text-orange-500 focus:ring-0"
                      />
                      <span className="text-white">External Self-Custody (User Keys)</span>
                    </label>

                    <label className="flex items-center space-x-1.5 cursor-pointer">
                      <input
                        type="radio"
                        checked={walletType === 'custodial'}
                        onChange={() => setWalletType('custodial')}
                        className="text-orange-500 focus:ring-0"
                      />
                      <span className="text-white">Institutional Custody MPC Adapter</span>
                    </label>
                  </div>
                  <div className="text-[10px] text-gray-400 font-mono">
                    Security Guarantee: Plaintext private keys and seed phrases are never stored or exposed to frontend code.
                  </div>
                </div>

                <button
                  onClick={handleInitiatePayment}
                  className="w-full py-3 bg-orange-500 hover:bg-orange-600 text-white rounded-xl text-xs font-bold font-mono transition flex items-center justify-center space-x-2 shadow-lg shadow-orange-500/20"
                >
                  <span>Generate On-Chain Payment Request</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <div className="p-6 rounded-xl bg-white/5 border border-white/5 space-y-3 text-center">
                <CreditCard className="w-8 h-8 text-orange-400 mx-auto" />
                <div className="text-sm font-bold text-white">Domestic INR & UPI Gateway</div>
                <p className="text-xs text-gray-400 max-w-md mx-auto">
                  Instant activation with UPI (PhonePe, Google Pay, Paytm), RuPay, Net Banking, and corporate credit cards with GST invoice generation.
                </p>
                <button
                  onClick={() => showNotification('Redirecting to Razorpay / Cashfree UPI Sovereign Gateway...', 'info')}
                  className="px-6 py-2.5 bg-orange-500 hover:bg-orange-600 text-white rounded-xl text-xs font-bold transition"
                >
                  Pay ₹{basePriceINR.toLocaleString('en-IN')} via UPI
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Right Column (5 cols): Live Crypto Session Display */}
        <div className="lg:col-span-5 space-y-4">
          <div className="p-6 rounded-2xl bg-[#0c101a] border border-white/10 space-y-5">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center space-x-2">
                <Coins className="w-4 h-4 text-orange-400" />
                <span className="font-bold text-white text-sm font-display">
                  Active Payment Session
                </span>
              </div>

              {activeCryptoSession?.status === 'CONFIRMED' ? (
                <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center space-x-1">
                  <CheckCircle2 className="w-3 h-3" />
                  <span>ON-CHAIN CONFIRMED</span>
                </span>
              ) : (
                <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center space-x-1">
                  <Clock className="w-3 h-3 animate-spin" />
                  <span>AWAITING BLOCKS</span>
                </span>
              )}
            </div>

            {activeCryptoSession ? (
              <div className="space-y-4">
                {/* Pricing Breakdown */}
                <div className="p-4 bg-white/5 rounded-xl space-y-2 font-mono text-xs">
                  <div className="flex justify-between text-gray-400">
                    <span>Base Tier Price:</span>
                    <span>₹{activeCryptoSession.fiatAmountINR.toLocaleString('en-IN')}</span>
                  </div>

                  <div className="flex justify-between text-emerald-400 font-bold">
                    <span>Priority Token Discount:</span>
                    <span>-₹{activeCryptoSession.discountAppliedINR.toLocaleString('en-IN')}</span>
                  </div>

                  <div className="flex justify-between text-white text-sm font-bold pt-2 border-t border-white/10">
                    <span>Total Required:</span>
                    <span className="text-orange-400">
                      {activeCryptoSession.cryptoAmount} {activeCryptoSession.cryptoSymbol}
                    </span>
                  </div>
                </div>

                {/* Deposit Address Box */}
                <div className="space-y-1.5">
                  <label className="text-[11px] font-mono text-gray-400">
                    Deposit Address ({activeCryptoSession.network})
                  </label>
                  <div className="flex items-center space-x-2 bg-[#07090e] p-2.5 rounded-xl border border-white/10">
                    <span className="text-xs font-mono text-gray-200 truncate flex-1">
                      {activeCryptoSession.depositAddress}
                    </span>
                    <button
                      onClick={() => copyToClipboard(activeCryptoSession.depositAddress)}
                      className="p-1.5 hover:bg-white/10 rounded transition text-gray-400 hover:text-white"
                      title="Copy Address"
                    >
                      <Copy className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Confirmation Status */}
                <div className="space-y-1.5 font-mono text-xs">
                  <div className="flex justify-between text-gray-400">
                    <span>Block Confirmations:</span>
                    <span className="text-emerald-400 font-bold">
                      {activeCryptoSession.confirmations} / {activeCryptoSession.requiredConfirmations}
                    </span>
                  </div>
                  <div className="w-full bg-white/10 h-1.5 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-emerald-400 transition-all duration-500"
                      style={{
                        width: `${Math.min(100, (activeCryptoSession.confirmations / activeCryptoSession.requiredConfirmations) * 100)}%`
                      }}
                    />
                  </div>
                </div>

                {/* TX Hash */}
                {activeCryptoSession.txHash && (
                  <div className="p-3 bg-emerald-500/10 rounded-xl border border-emerald-500/20 text-xs font-mono text-gray-300 space-y-1">
                    <div className="text-emerald-400 font-bold flex items-center space-x-1">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Simulated Sandbox Confirmation</span>
                    </div>
                    <div className="text-[11px] text-gray-400 truncate">
                      Hash: {activeCryptoSession.txHash}
                    </div>
                  </div>
                )}

                {/* Simulate Confirmation Button for Demo Verification */}
                {activeCryptoSession.status !== 'CONFIRMED' && (
                  <button
                    onClick={() => simulateBlockchainConfirmation(activeCryptoSession.id)}
                    className="w-full py-2 bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-400 border border-emerald-500/40 rounded-xl text-xs font-bold font-mono transition flex items-center justify-center space-x-1.5"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>Simulate Node Block Finality</span>
                  </button>
                )}
              </div>
            ) : (
              <div className="text-center py-8 text-gray-500 text-xs">
                No active session. Select an entitlement plan and click Generate Payment Request.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
