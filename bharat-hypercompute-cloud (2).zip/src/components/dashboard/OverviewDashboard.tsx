import React from 'react';
import { useApp } from '../../context/AppContext';
import { TrustBadge } from '../common/TrustBadge';
import { MII_BRAND } from '../common/BrandIdentity';
import {
  BrainCircuit,
  BookOpen,
  FlaskConical,
  Database,
  Box,
  Rocket,
  Plus,
  Play,
  ArrowUpRight,
  Zap,
  Activity,
  CheckCircle2,
  Clock,
  Layers,
  Radio,
  Sliders,
  ShieldCheck,
  TrendingUp,
  Radar,
  AlertTriangle
} from 'lucide-react';

export const OverviewDashboard: React.FC = () => {
  const {
    project,
    user,
    experiments,
    models,
    deployments,
    notebook,
    timeline,
    setCurrentView,
    selfHealingState,
    startSelfHealingDemo,
    aiAgents,
    approvalQueue,
    freeResources
  } = useApp();

  const completedExperiments = experiments.filter(e => e.status === 'completed');
  const runningExperiments = experiments.filter(e => e.status === 'running');
  const activeDeployment = deployments[0];
  const pendingApprovals = approvalQueue.filter(a => a.status === 'PENDING');

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Top Banner & Quick Actions */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-gradient-to-r from-[#0d121f] via-[#090d15] to-[#0d121f] p-6 rounded-2xl border border-white/10 shadow-xl">
        <div className="space-y-1.5">
          <div className="flex items-center space-x-2 flex-wrap gap-y-1">
            <span className="text-xs font-mono text-orange-400 font-bold uppercase tracking-wider">
              {MII_BRAND.parentBrand}
            </span>
            <span className="text-gray-600">/</span>
            <span className="text-white font-mono text-xs font-medium">{MII_BRAND.productName}</span>
            <span className="text-gray-600">/</span>
            <span className="text-xs font-mono text-gray-300">{project.name}</span>
            <TrustBadge type="SIMULATED" size="xs" />
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white font-display">
            National AI Research Hub
          </h1>
          <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs font-mono">
            <span className="text-amber-300 font-medium">
              {MII_BRAND.officialTagline}
            </span>
            <span className="text-gray-600 hidden sm:inline">|</span>
            <span className="text-gray-400">
              {MII_BRAND.positioning}
            </span>
            <span className="text-gray-600 hidden md:inline">|</span>
            <span className="text-gray-400">
              {MII_BRAND.founderAttribution}
            </span>
          </div>
          <p className="text-xs sm:text-sm text-gray-400 max-w-2xl">
            {project.description}
          </p>
        </div>

        {/* Quick Action Buttons */}
        <div className="flex flex-wrap items-center gap-2 shrink-0">
          <button
            onClick={() => setCurrentView('compute_brain')}
            className="px-3.5 py-2 rounded-lg bg-orange-500 hover:bg-orange-600 text-white text-xs font-bold shadow transition flex items-center space-x-1.5"
          >
            <BrainCircuit className="w-3.5 h-3.5" />
            <span>Launch Compute Intent</span>
          </button>
          <button
            onClick={() => setCurrentView('notebooks')}
            className="px-3 py-2 rounded-lg bg-white/10 hover:bg-white/15 text-gray-200 text-xs font-medium border border-white/10 transition flex items-center space-x-1.5"
          >
            <BookOpen className="w-3.5 h-3.5 text-orange-400" />
            <span>New Notebook</span>
          </button>
          <button
            onClick={() => setCurrentView('datasets')}
            className="px-3 py-2 rounded-lg bg-white/10 hover:bg-white/15 text-gray-200 text-xs font-medium border border-white/10 transition flex items-center space-x-1.5"
          >
            <Database className="w-3.5 h-3.5 text-emerald-400" />
            <span>Dataset Center</span>
          </button>
          <button
            onClick={() => setCurrentView('deployments')}
            className="px-3 py-2 rounded-lg bg-white/10 hover:bg-white/15 text-gray-200 text-xs font-medium border border-white/10 transition flex items-center space-x-1.5"
          >
            <Rocket className="w-3.5 h-3.5 text-sky-400" />
            <span>Deploy Model</span>
          </button>
        </div>
      </div>

      {/* KPI / Status Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-6 gap-3 sm:gap-4">
        {/* Daily Compute Status Card */}
        <div className="p-4 rounded-xl bg-[#0a0e17] border border-white/10 space-y-2">
          <div className="flex items-center justify-between text-xs text-gray-400">
            <span className="font-mono">Today's Compute</span>
            <Zap className="w-4 h-4 text-orange-400" />
          </div>
          <div className="text-xl sm:text-2xl font-bold text-white font-display">
            {user.entitlement === 'founder' ? (
              <span className="text-amber-400 font-mono text-lg">Unlimited Quota</span>
            ) : (
              `${user.dailyComputeHoursUsed.toFixed(1)} / ${user.dailyComputeHoursLimit} hrs`
            )}
          </div>
          <div className="w-full bg-white/10 h-1.5 rounded-full overflow-hidden">
            <div
              className={`h-full ${user.entitlement === 'founder' ? 'bg-amber-400' : 'bg-orange-500'}`}
              style={{
                width: user.entitlement === 'founder' ? '100%' : `${(user.dailyComputeHoursUsed / user.dailyComputeHoursLimit) * 100}%`
              }}
            />
          </div>
          <div className="flex justify-between text-[10px] text-gray-500 font-mono">
            <span>{user.entitlement === 'founder' ? 'Founder Bypass' : 'Free Tier (2h/day)'}</span>
            <span>{user.resetTime}</span>
          </div>
        </div>

        {/* Active Accelerators */}
        <div className="p-4 rounded-xl bg-[#0a0e17] border border-white/10 space-y-2">
          <div className="flex items-center justify-between text-xs text-gray-400">
            <span className="font-mono">Active Compute Pod</span>
            <Radio className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
          </div>
          <div className="text-lg sm:text-xl font-bold text-white truncate">
            4× BHARAT H100
          </div>
          <div className="text-xs text-emerald-400 font-mono flex items-center space-x-1">
            <span>DDP Cluster Online</span>
            <span className="text-gray-500">•</span>
            <TrustBadge type="SIMULATED" size="xs" />
          </div>
          <div className="text-[10px] text-gray-500 font-mono">
            vRAM: 320 GB HBM3 Combined
          </div>
        </div>

        {/* AI Company Brain Status */}
        <div
          onClick={() => setCurrentView('company_brain')}
          className="p-4 rounded-xl bg-[#0a0e17] border border-white/10 hover:border-orange-500/40 transition cursor-pointer space-y-2"
        >
          <div className="flex items-center justify-between text-xs text-gray-400">
            <span className="font-mono">1,000-Agent Org</span>
            <BrainCircuit className="w-4 h-4 text-orange-400" />
          </div>
          <div className="text-xl sm:text-2xl font-bold text-white font-display">
            {aiAgents.filter(a => a.status === 'active' || a.status === 'executing').length} Active
          </div>
          <div className="text-xs text-orange-400 font-mono flex items-center space-x-1">
            <span>{pendingApprovals.length} Approval Gates</span>
            <span className="text-gray-600">•</span>
            <span>L0–L5</span>
          </div>
          <div className="text-[10px] text-gray-500 font-mono">
            Executive, R&D, Growth Brains
          </div>
        </div>

        {/* Free Resource Radar */}
        <div
          onClick={() => setCurrentView('resource_radar')}
          className="p-4 rounded-xl bg-[#0a0e17] border border-white/10 hover:border-orange-500/40 transition cursor-pointer space-y-2"
        >
          <div className="flex items-center justify-between text-xs text-gray-400">
            <span className="font-mono">Resource Radar</span>
            <Radar className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-xl sm:text-2xl font-bold text-white font-display">
            {freeResources.length} Open Assets
          </div>
          <div className="text-xs text-emerald-400 font-mono flex items-center space-x-1">
            <span>Models & Gov Grants</span>
          </div>
          <div className="text-[10px] text-gray-500 font-mono">
            100% Permissive Open-Source
          </div>
        </div>

        {/* Completed Experiments */}
        <div
          onClick={() => setCurrentView('experiments')}
          className="p-4 rounded-xl bg-[#0a0e17] border border-white/10 hover:border-orange-500/40 transition cursor-pointer space-y-2"
        >
          <div className="flex items-center justify-between text-xs text-gray-400">
            <span className="font-mono">Experiment Runs</span>
            <FlaskConical className="w-4 h-4 text-indigo-400" />
          </div>
          <div className="text-xl sm:text-2xl font-bold text-white font-display">
            {experiments.length} <span className="text-xs text-gray-400 font-normal">({completedExperiments.length} converged)</span>
          </div>
          <div className="text-xs text-gray-400 flex items-center space-x-1">
            <span className="text-emerald-400 font-mono font-medium">Top Loss: 0.318</span>
            <span className="text-gray-600">•</span>
            <span className="text-gray-400">EXP-04</span>
          </div>
          <div className="text-[10px] text-gray-500 font-mono">
            Experiment DNA tracked
          </div>
        </div>

        {/* Active Production API */}
        <div
          onClick={() => setCurrentView('deployments')}
          className="p-4 rounded-xl bg-[#0a0e17] border border-white/10 hover:border-orange-500/40 transition cursor-pointer space-y-2"
        >
          <div className="flex items-center justify-between text-xs text-gray-400">
            <span className="font-mono">Serving Endpoints</span>
            <Rocket className="w-4 h-4 text-sky-400" />
          </div>
          <div className="text-xl sm:text-2xl font-bold text-white font-display">
            1 Live API
          </div>
          <div className="text-xs text-sky-400 font-mono flex items-center space-x-1 truncate">
            <span>24ms p95 latency</span>
            <span className="text-gray-600">•</span>
            <span>14.8k reqs</span>
          </div>
          <div className="text-[10px] text-emerald-400 font-mono">
            99.98% Health (vLLM Engine)
          </div>
        </div>
      </div>

      {/* Main Grid: Active Compute & Self-Healing Demo + Recent Work */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column (8 cols): Active Compute Job & Self-Healing Spotlight */}
        <div className="lg:col-span-8 space-y-6">
          {/* Active Training Job / Self Healing Control */}
          <div className="p-5 rounded-xl bg-[#0c101a] border border-white/10 space-y-4">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center space-x-2">
                <ShieldCheck className="w-4 h-4 text-orange-400" />
                <span className="font-bold text-white text-sm font-display">
                  Cluster Training Engine & Self-Healing
                </span>
                <TrustBadge type="SIMULATED" size="xs" />
              </div>

              <div className="flex items-center space-x-2">
                {!selfHealingState.isActive ? (
                  <button
                    onClick={startSelfHealingDemo}
                    className="px-3 py-1 bg-orange-500 hover:bg-orange-600 text-white rounded text-xs font-bold transition flex items-center space-x-1"
                  >
                    <Play className="w-3 h-3" />
                    <span>Start Training Loop</span>
                  </button>
                ) : (
                  <button
                    onClick={() => setCurrentView('compute_brain')}
                    className="px-3 py-1 bg-white/10 hover:bg-white/20 text-gray-200 rounded text-xs font-mono transition"
                  >
                    Manage Run →
                  </button>
                )}
              </div>
            </div>

            {/* Live Progress Bar */}
            <div className="space-y-2">
              <div className="flex justify-between text-xs font-mono">
                <span className="text-gray-400">
                  Workload: <strong className="text-white">IndicLLM-7B Fine-Tune (Bhasha-v3)</strong>
                </span>
                <span className="text-orange-400 font-bold">
                  {selfHealingState.isActive
                    ? `${Math.round((selfHealingState.currentStep / selfHealingState.totalSteps) * 100)}% Complete`
                    : 'Ready to Dispatch'}
                </span>
              </div>

              <div className="w-full bg-white/10 h-2 rounded-full overflow-hidden">
                <div
                  className={`h-full transition-all duration-300 ${
                    selfHealingState.status === 'interrupted' ? 'bg-rose-500 animate-pulse' : 'bg-orange-500'
                  }`}
                  style={{
                    width: selfHealingState.isActive
                      ? `${(selfHealingState.currentStep / selfHealingState.totalSteps) * 100}%`
                      : '0%'
                  }}
                />
              </div>

              <div className="flex flex-wrap items-center justify-between text-[11px] font-mono text-gray-400 pt-1">
                <span>
                  Step: <strong className="text-white">{selfHealingState.currentStep}</strong> / {selfHealingState.totalSteps}
                </span>
                <span>
                  Loss: <strong className="text-emerald-400">{selfHealingState.currentLoss.toFixed(3)}</strong>
                </span>
                <span>
                  State:{' '}
                  <strong
                    className={
                      selfHealingState.status === 'interrupted'
                        ? 'text-rose-400 uppercase font-bold'
                        : selfHealingState.status === 'recovering'
                        ? 'text-amber-400 uppercase font-bold'
                        : 'text-emerald-400 uppercase font-bold'
                    }
                  >
                    {selfHealingState.status}
                  </strong>
                </span>
              </div>
            </div>

            {/* Live Mini Terminal Logs */}
            <div className="bg-black/60 rounded-lg p-3 border border-white/5 font-mono text-[11px] text-gray-300 space-y-1 max-h-32 overflow-y-auto">
              {selfHealingState.logs.map((log, i) => (
                <div
                  key={i}
                  className={
                    log.includes('ALERT') || log.includes('interrupted')
                      ? 'text-rose-400 font-bold'
                      : log.includes('RESTORE') || log.includes('SCHEDULER')
                      ? 'text-amber-300'
                      : log.includes('COMPLETE') || log.includes('resumed')
                      ? 'text-emerald-400'
                      : 'text-gray-400'
                  }
                >
                  {log}
                </div>
              ))}
            </div>
          </div>

          {/* Recent Notebooks & Experiments Tabs */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Notebook Box */}
            <div className="p-4 rounded-xl bg-[#0a0e17] border border-white/10 space-y-3">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-white font-display flex items-center space-x-1.5">
                  <BookOpen className="w-3.5 h-3.5 text-orange-400" />
                  <span>Active Notebook</span>
                </span>
                <span className="text-[10px] font-mono text-emerald-400">Kernel Connected</span>
              </div>
              <div className="p-3 bg-white/5 rounded-lg border border-white/5 space-y-1">
                <div className="text-xs font-mono font-medium text-white truncate">
                  {notebook.title}
                </div>
                <div className="text-[10px] text-gray-400 font-mono flex justify-between">
                  <span>{notebook.cells.length} cells • PyTorch 2.5</span>
                  <span>{notebook.lastSaved}</span>
                </div>
              </div>
              <button
                onClick={() => setCurrentView('notebooks')}
                className="w-full py-1.5 bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white rounded text-xs font-mono transition flex items-center justify-center space-x-1"
              >
                <span>Launch Research Notebook</span>
                <ArrowUpRight className="w-3 h-3" />
              </button>
            </div>

            {/* Top Experiment Run */}
            <div className="p-4 rounded-xl bg-[#0a0e17] border border-white/10 space-y-3">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-white font-display flex items-center space-x-1.5">
                  <FlaskConical className="w-3.5 h-3.5 text-indigo-400" />
                  <span>Candidate Model Run</span>
                </span>
                <TrustBadge type="EXECUTED" size="xs" />
              </div>
              <div className="p-3 bg-white/5 rounded-lg border border-white/5 space-y-1">
                <div className="text-xs font-mono font-medium text-white truncate">
                  {experiments[0].name}
                </div>
                <div className="text-[10px] text-gray-400 font-mono flex justify-between">
                  <span>Val Acc: {experiments[0].metrics.evalAccuracy}%</span>
                  <span>Perplexity: {experiments[0].metrics.perplexity}</span>
                </div>
              </div>
              <button
                onClick={() => setCurrentView('experiments')}
                className="w-full py-1.5 bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white rounded text-xs font-mono transition flex items-center justify-center space-x-1"
              >
                <span>Inspect Experiment DNA</span>
                <ArrowUpRight className="w-3 h-3" />
              </button>
            </div>
          </div>
        </div>

        {/* Right Column (4 cols): Research Timeline */}
        <div className="lg:col-span-4 p-5 rounded-xl bg-[#0a0e17] border border-white/10 space-y-4">
          <div className="flex items-center justify-between border-b border-white/10 pb-3">
            <div className="flex items-center space-x-2">
              <Clock className="w-4 h-4 text-orange-400" />
              <span className="font-bold text-white text-sm font-display">Research Timeline</span>
            </div>
            <span className="text-[10px] font-mono text-gray-400">All Events</span>
          </div>

          <div className="space-y-4 relative before:absolute before:inset-0 before:left-3 before:w-0.5 before:bg-white/10 pl-7 max-h-[460px] overflow-y-auto">
            {timeline.map(evt => (
              <div key={evt.id} className="relative space-y-1">
                {/* Timeline node */}
                <div className="absolute -left-7 top-1 w-2.5 h-2.5 rounded-full bg-orange-500 ring-4 ring-[#0a0e17]" />

                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-white truncate">{evt.title}</span>
                  <TrustBadge type={evt.trustTag} size="xs" />
                </div>
                <p className="text-[11px] text-gray-400 leading-relaxed">
                  {evt.description}
                </p>
                <div className="text-[10px] font-mono text-gray-400">
                  {evt.timestamp}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
