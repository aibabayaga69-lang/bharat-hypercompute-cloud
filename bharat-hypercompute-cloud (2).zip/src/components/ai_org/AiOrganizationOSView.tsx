import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import {
  DetailedAIAgent,
  DepartmentAllocationInfo,
  OrchestrationTaskItem,
  OwnerApprovalRequest,
  ImmutableAuditLogRecord,
  AutonomousSelfOptimizationProposal,
  CompanyKnowledgeMemoryItem,
  OrgDepartmentId,
  AgentState,
  RiskLevel
} from '../../types/aiOrganization';
import { UserRole } from '../../types';
import { TrustBadge } from '../common/TrustBadge';
import { MII_BRAND } from '../common/BrandIdentity';
import {
  ShieldAlert,
  ShieldCheck,
  BrainCircuit,
  Zap,
  Power,
  Pause,
  Play,
  RotateCcw,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Sliders,
  DollarSign,
  Cpu,
  Lock,
  Search,
  Filter,
  Eye,
  ArrowRight,
  GitPullRequest,
  BookOpen,
  Sparkles,
  Layers,
  Database,
  Terminal,
  Activity,
  History,
  TrendingDown,
  FileCheck,
  HelpCircle,
  ChevronDown,
  ChevronUp,
  Radio,
  Clock,
  UserCheck,
  Users
} from 'lucide-react';

export const AiOrganizationOSView: React.FC = () => {
  const {
    user,
    setUser,
    aiOrgState,
    orgDepartments,
    detailedAgents,
    orchestrationTasks,
    ownerApprovals,
    immutableAuditLogs,
    selfOptimizations,
    companyKnowledgeMemory,
    triggerEmergencyStop,
    toggleGlobalAiPause,
    resumeAllAgents,
    approveOwnerRequest,
    rejectOwnerRequest,
    escalateOwnerRequest,
    modifyApprovalLimits,
    stepAutonomousTaskLoop,
    showNotification
  } = useApp();

  // Active top-level subtab
  const [activeTab, setActiveTab] = useState<
    'overview' | 'departments' | 'directory' | 'tasks' | 'approvals' | 'costs' | 'optimizations' | 'memory' | 'audit_log'
  >('overview');

  // Directory filters
  const [deptFilter, setDeptFilter] = useState<string>('ALL');
  const [stateFilter, setStateFilter] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedAgent, setSelectedAgent] = useState<DetailedAIAgent | null>(null);

  // Emergency stop confirmation dialog
  const [showEmergencyModal, setShowEmergencyModal] = useState<boolean>(false);
  const [emergencyReason, setEmergencyReason] = useState<string>('Owner manual fail-safe trigger');

  // Role Gate check: Only OWNER and ADMIN are allowed!
  const isAuthorized = user.role === 'Owner' || user.role === 'Admin';

  // Filtered agents for directory
  const filteredAgents = useMemo(() => {
    return detailedAgents.filter(agent => {
      if (deptFilter !== 'ALL' && agent.department !== deptFilter) return false;
      if (stateFilter !== 'ALL' && agent.current_state !== stateFilter) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        return (
          agent.agent_id.toLowerCase().includes(q) ||
          agent.role.toLowerCase().includes(q) ||
          agent.specialty.toLowerCase().includes(q) ||
          agent.seniority.toLowerCase().includes(q) ||
          agent.model_provider.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [detailedAgents, deptFilter, stateFilter, searchQuery]);

  // If role check fails: STRICT 403 ACCESS DENIED SCREEN
  if (!isAuthorized) {
    return (
      <div className="min-h-[80vh] flex items-center justify-center p-6">
        <div className="max-w-xl w-full bg-[#0d121f] border border-red-500/40 rounded-2xl p-8 shadow-2xl space-y-6 text-center">
          <div className="w-16 h-16 bg-red-500/10 border border-red-500/30 rounded-2xl flex items-center justify-center mx-auto">
            <ShieldAlert className="w-9 h-9 text-red-400" />
          </div>

          <div className="space-y-2">
            <div className="inline-flex items-center space-x-1.5 px-2.5 py-0.5 rounded-full bg-red-500/10 text-red-400 border border-red-500/20 text-xs font-mono">
              <Lock className="w-3 h-3" />
              <span>HTTP 403 / UNAUTHORIZED ROLE</span>
            </div>
            <h1 className="text-2xl font-extrabold text-white font-display">
              MII AI Organization OS: Access Restricted
            </h1>
            <p className="text-sm text-gray-300 leading-relaxed">
              This private operating system is restricted exclusively to <strong className="text-white">Owner</strong> and <strong className="text-white">Admin</strong> roles. Public users, researchers, developers, and normal organization members cannot access or command autonomous AI agents.
            </p>
          </div>

          <div className="p-4 bg-black/40 rounded-xl border border-white/10 text-left text-xs font-mono space-y-1.5">
            <div className="text-gray-400">Current Session Principal:</div>
            <div className="text-white font-bold">{user.name} ({user.email})</div>
            <div className="text-amber-400">Active Role: <span className="underline">{user.role}</span> (Insufficient Permissions)</div>
            <div className="text-[11px] text-gray-400 pt-1">
              Enforcement Level: Data Layer & State Authorization Gate
            </div>
          </div>

          {/* Role switcher for evaluation/testing */}
          <div className="pt-2 border-t border-white/10 space-y-3">
            <p className="text-xs text-gray-400">
              Simulate credentials to test Owner/Admin authorization gate:
            </p>
            <div className="flex flex-wrap justify-center gap-2">
              <button
                onClick={() => {
                  setUser(prev => ({ ...prev, role: 'Owner', name: 'MII Founder (Owner)' }));
                  showNotification('Switched role to OWNER. Access granted to MII AI Organization OS.', 'success');
                }}
                className="px-3 py-1.5 bg-orange-600 hover:bg-orange-500 text-white rounded-lg text-xs font-medium transition flex items-center space-x-1.5"
              >
                <UserCheck className="w-3.5 h-3.5" />
                <span>Simulate OWNER</span>
              </button>
              <button
                onClick={() => {
                  setUser(prev => ({ ...prev, role: 'Admin', name: 'Platform Admin' }));
                  showNotification('Switched role to ADMIN. Access granted to MII AI Organization OS.', 'success');
                }}
                className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-medium transition flex items-center space-x-1.5"
              >
                <UserCheck className="w-3.5 h-3.5" />
                <span>Simulate ADMIN</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Top Banner / Orchestrator Status */}
      <div className="bg-gradient-to-r from-[#090e18] via-[#0d1628] to-[#140b24] p-6 rounded-2xl border border-white/10 shadow-2xl relative overflow-hidden">
        <div className="absolute -top-24 -right-24 w-96 h-96 bg-orange-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-xs font-mono text-orange-400 font-bold uppercase tracking-wider">
                {MII_BRAND.parentBrand}
              </span>
              <span className="text-gray-600">/</span>
              <span className="text-xs font-mono text-white font-medium">AI ORGANIZATION OS</span>
              <span className="text-gray-600">/</span>
              <span className="px-2 py-0.5 bg-amber-500/10 border border-amber-500/20 text-amber-300 rounded text-[10px] font-mono font-bold">
                OWNER & ADMIN PRIVILEGED
              </span>
              <TrustBadge type="APPROVED" size="xs" />
            </div>

            <h1 className="text-2xl sm:text-3xl font-extrabold text-white font-display flex items-center space-x-3">
              <BrainCircuit className="w-8 h-8 text-orange-400 shrink-0" />
              <span>1,000-AI Organization & Autonomous OS</span>
            </h1>

            <p className="text-xs sm:text-sm text-gray-300 max-w-3xl leading-relaxed">
              Hierarchical event-driven multi-agent architecture. 15 specialized departments with 1,000 pooled capacity under the <strong className="text-white">MII Executive Orchestrator</strong>. Governed by strict L0–L5 privilege levels, budget controls, and mandatory Owner approvals.
            </p>
          </div>

          {/* Emergency Fail-Safe Controls */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5 shrink-0">
            {aiOrgState.emergencyStop ? (
              <button
                onClick={resumeAllAgents}
                className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-mono font-bold transition flex items-center justify-center space-x-2 shadow-lg shadow-emerald-600/20"
              >
                <Play className="w-4 h-4" />
                <span>RESUME ALL AGENTS</span>
              </button>
            ) : (
              <>
                <button
                  onClick={toggleGlobalAiPause}
                  className={`px-3.5 py-2 rounded-xl text-xs font-mono font-bold transition flex items-center justify-center space-x-2 border ${
                    aiOrgState.globalAiPause
                      ? 'bg-amber-600 text-white border-amber-500 shadow-lg shadow-amber-600/20'
                      : 'bg-black/40 hover:bg-white/10 text-amber-300 border-amber-500/30'
                  }`}
                >
                  <Pause className="w-3.5 h-3.5" />
                  <span>{aiOrgState.globalAiPause ? 'GLOBAL AI PAUSED' : 'GLOBAL AI PAUSE'}</span>
                </button>

                <button
                  onClick={() => setShowEmergencyModal(true)}
                  className="px-3.5 py-2 bg-red-600 hover:bg-red-500 text-white rounded-xl text-xs font-mono font-bold transition flex items-center justify-center space-x-2 shadow-lg shadow-red-600/20"
                >
                  <Power className="w-3.5 h-3.5" />
                  <span>EMERGENCY STOP</span>
                </button>
              </>
            )}

            {/* Role indicator & test toggle */}
            <div className="px-3 py-1.5 bg-black/50 border border-white/10 rounded-xl text-[11px] font-mono text-gray-300 flex items-center justify-between sm:justify-start space-x-2">
              <span className="text-gray-400">Principal:</span>
              <span className="text-orange-400 font-bold">{user.role}</span>
              <button
                onClick={() => {
                  const nextRole: UserRole = user.role === 'Owner' ? 'Admin' : 'Owner';
                  setUser(prev => ({ ...prev, role: nextRole }));
                  showNotification(`Toggled privileged role to ${nextRole}.`, 'info');
                }}
                className="text-[10px] text-gray-400 hover:text-white underline ml-1"
              >
                (switch)
              </button>
            </div>
          </div>
        </div>

        {/* Emergency Stop Notice if active */}
        {aiOrgState.emergencyStop && (
          <div className="mt-4 p-3 bg-red-950/80 border border-red-500/50 rounded-xl flex items-center space-x-3 text-red-200 text-xs font-mono">
            <AlertTriangle className="w-5 h-5 text-red-400 shrink-0 animate-pulse" />
            <div>
              <span className="font-bold text-red-100">EMERGENCY STOP ACTIVE:</span> All autonomous workflows, active tasks, and external calls suspended at {aiOrgState.emergencyStopTimestamp}. Immutable audit logs preserved.
            </div>
          </div>
        )}
      </div>

      {/* KPI Capacity Summary Bar (Distinguishes 1,000 Capacity vs Currently Active) */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="p-4 bg-[#080d1a] rounded-xl border border-white/10 shadow space-y-1">
          <div className="text-[11px] font-mono text-gray-400 uppercase">Total Capacity</div>
          <div className="text-2xl font-bold font-mono text-white">1,000</div>
          <div className="text-[10px] text-orange-400 font-mono">Event-Driven Arch</div>
        </div>

        <div className="p-4 bg-[#080d1a] rounded-xl border border-white/10 shadow space-y-1">
          <div className="text-[11px] font-mono text-gray-400 uppercase">Currently Active</div>
          <div className="text-2xl font-bold font-mono text-emerald-400 flex items-center space-x-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
            <span>{aiOrgState.currentlyActive}</span>
          </div>
          <div className="text-[10px] text-gray-400 font-mono">Executing & Verifying</div>
        </div>

        <div className="p-4 bg-[#080d1a] rounded-xl border border-white/10 shadow space-y-1">
          <div className="text-[11px] font-mono text-gray-400 uppercase">Sleeping / Dormant</div>
          <div className="text-2xl font-bold font-mono text-gray-300">
            {aiOrgState.currentlySleeping}
          </div>
          <div className="text-[10px] text-gray-500 font-mono">Zero Idle Token Cost</div>
        </div>

        <div className="p-4 bg-[#080d1a] rounded-xl border border-white/10 shadow space-y-1">
          <div className="text-[11px] font-mono text-gray-400 uppercase">Queued Tasks</div>
          <div className="text-2xl font-bold font-mono text-amber-400">
            {aiOrgState.currentlyQueued}
          </div>
          <div className="text-[10px] text-gray-400 font-mono">Event Queue Depth</div>
        </div>

        <div className="p-4 bg-[#080d1a] rounded-xl border border-white/10 shadow space-y-1">
          <div className="text-[11px] font-mono text-gray-400 uppercase">Awaiting Owner Approval</div>
          <div className="text-2xl font-bold font-mono text-rose-400">
            {ownerApprovals.filter(a => a.status === 'PENDING').length}
          </div>
          <div className="text-[10px] text-rose-300 font-mono">L5 High-Impact Gates</div>
        </div>

        <div className="p-4 bg-[#080d1a] rounded-xl border border-white/10 shadow space-y-1">
          <div className="text-[11px] font-mono text-gray-400 uppercase">Daily Compute Burn</div>
          <div className="text-2xl font-bold font-mono text-indigo-300">
            ${aiOrgState.dailyCostUSD.toFixed(2)}
          </div>
          <div className="text-[10px] text-gray-400 font-mono">Month: ${aiOrgState.monthlyCostUSD.toFixed(2)}</div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex items-center space-x-1 border-b border-white/10 overflow-x-auto pb-1 text-xs font-mono">
        {[
          { id: 'overview', label: '1. Executive Orchestrator' },
          { id: 'departments', label: '2. 15 Departments (1,000 Alloc)' },
          { id: 'directory', label: '3. Agent Directory (1,000 Pool)' },
          { id: 'tasks', label: '4. Task Center (10-Step Loop)' },
          { id: 'approvals', label: `5. Owner Approvals (${ownerApprovals.filter(a => a.status === 'PENDING').length})` },
          { id: 'costs', label: '6. Cost Center & Routing' },
          { id: 'optimizations', label: '7. Autonomous Self-Optimization' },
          { id: 'memory', label: '8. Company Memory' },
          { id: 'audit_log', label: '9. Immutable Audit Log' }
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`px-3.5 py-2 rounded-t-lg font-medium whitespace-nowrap transition ${
              activeTab === tab.id
                ? 'bg-[#0f172a] text-orange-400 border-t-2 border-orange-500 border-x border-white/10'
                : 'text-gray-400 hover:text-white hover:bg-white/5'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* TAB 1: EXECUTIVE ORCHESTRATOR OVERVIEW */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          {/* Executive Intelligence Card */}
          <div className="p-6 bg-[#090e1a] rounded-2xl border border-white/10 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/10 pb-4">
              <div className="flex items-center space-x-3">
                <div className="h-10 w-10 rounded-xl bg-orange-500/10 border border-orange-500/30 flex items-center justify-center">
                  <BrainCircuit className="w-5 h-5 text-orange-400" />
                </div>
                <div>
                  <h2 className="text-lg font-bold text-white font-display">
                    MII Executive Orchestrator (Orchestrator-01)
                  </h2>
                  <p className="text-xs text-gray-400 font-mono">
                    Chief AI Orchestration & Operating Intelligence • Role-Scoped Delegation Engine
                  </p>
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <span className="px-2.5 py-1 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-lg text-xs font-mono font-bold flex items-center space-x-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  <span>STATUS: {aiOrgState.executiveOrchestratorStatus}</span>
                </span>
              </div>
            </div>

            <p className="text-xs text-gray-300 leading-relaxed">
              The Executive Orchestrator coordinates cross-departmental task decomposition, priority scheduling, budget bounds, and independent verification. It does <strong className="text-white underline">NOT</strong> possess unrestricted authority and is strictly constrained by the following operating policies:
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3 text-xs font-mono">
              <div className="p-3 bg-black/40 rounded-xl border border-white/5 space-y-1">
                <div className="text-orange-400 font-bold flex items-center space-x-1.5">
                  <Lock className="w-3.5 h-3.5" />
                  <span>Owner Approval Gate</span>
                </div>
                <div className="text-gray-300 text-[11px]">
                  L5 actions (money, ads, auth, data, public release) cannot proceed without explicit Owner sign-off.
                </div>
              </div>

              <div className="p-3 bg-black/40 rounded-xl border border-white/5 space-y-1">
                <div className="text-emerald-400 font-bold flex items-center space-x-1.5">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>Zero-Egress Firewall</span>
                </div>
                <div className="text-gray-300 text-[11px]">
                  Customer weights and datasets are hard-quarantined under India DPDP Act 2023.
                </div>
              </div>

              <div className="p-3 bg-black/40 rounded-xl border border-white/5 space-y-1">
                <div className="text-indigo-400 font-bold flex items-center space-x-1.5">
                  <DollarSign className="w-3.5 h-3.5" />
                  <span>Budget Hard Ceiling</span>
                </div>
                <div className="text-gray-300 text-[11px]">
                  $50.00/day max autonomous budget. Single task hard limit at $5.00 with recursive cycle detection.
                </div>
              </div>

              <div className="p-3 bg-black/40 rounded-xl border border-white/5 space-y-1">
                <div className="text-rose-400 font-bold flex items-center space-x-1.5">
                  <AlertTriangle className="w-3.5 h-3.5" />
                  <span>Zero Destructive Actions</span>
                </div>
                <div className="text-gray-300 text-[11px]">
                  No database drops, irreversible file deletions, or credential resets permitted autonomously.
                </div>
              </div>
            </div>

            {/* Governance Architecture Diagram */}
            <div className="p-4 bg-black/60 rounded-xl border border-white/10 space-y-2">
              <div className="text-[11px] font-mono text-gray-400 uppercase tracking-wider">
                Authority & Execution Hierarchy
              </div>
              <div className="flex flex-wrap items-center gap-2 text-xs font-mono">
                <span className="px-2.5 py-1 bg-orange-600/30 text-orange-300 rounded border border-orange-500/40 font-bold">
                  OWNER / ADMIN
                </span>
                <ArrowRight className="w-3 h-3 text-gray-500" />
                <span className="px-2.5 py-1 bg-amber-500/20 text-amber-300 rounded border border-amber-500/30 font-bold">
                  EXECUTIVE ORCHESTRATOR
                </span>
                <ArrowRight className="w-3 h-3 text-gray-500" />
                <span className="px-2.5 py-1 bg-indigo-500/20 text-indigo-300 rounded border border-indigo-500/30">
                  15 DEPARTMENT DIRECTORS
                </span>
                <ArrowRight className="w-3 h-3 text-gray-500" />
                <span className="px-2.5 py-1 bg-white/10 text-gray-200 rounded border border-white/10">
                  SPECIALIST AI AGENTS
                </span>
                <ArrowRight className="w-3 h-3 text-gray-500" />
                <span className="px-2.5 py-1 bg-emerald-500/20 text-emerald-300 rounded border border-emerald-500/30">
                  INDEPENDENT VERIFICATION
                </span>
                <ArrowRight className="w-3 h-3 text-gray-500" />
                <span className="px-2.5 py-1 bg-blue-500/20 text-blue-300 rounded border border-blue-500/30">
                  COMPANY MEMORY & LEARNING
                </span>
              </div>
            </div>
          </div>

          {/* Autonomous Operating System Core Loop */}
          <div className="p-6 bg-[#090e1a] rounded-2xl border border-white/10 space-y-4">
            <h2 className="text-base font-bold text-white font-display flex items-center space-x-2">
              <Radio className="w-5 h-5 text-orange-400" />
              <span>MII AI Operating System — Autonomous 11-Stage Closed Loop</span>
            </h2>
            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-11 gap-2 text-center text-[11px] font-mono">
              {[
                { step: '1', title: 'OBSERVE', desc: 'Scan telemetry' },
                { step: '2', title: 'UNDERSTAND', desc: 'Synthesize context' },
                { step: '3', title: 'PLAN', desc: 'Formulate strategy' },
                { step: '4', title: 'DECOMPOSE', desc: 'Break into subtasks' },
                { step: '5', title: 'ASSIGN', desc: 'Select specialists' },
                { step: '6', title: 'EXECUTE', desc: 'Run scoped tool' },
                { step: '7', title: 'VERIFY', desc: 'Independent review' },
                { step: '8', title: 'AUDIT', desc: 'Hash immutable log' },
                { step: '9', title: 'LEARN', desc: 'Store clean lesson' },
                { step: '10', title: 'OPTIMIZE', desc: 'Prune latency' },
                { step: '11', title: 'REPORT', desc: 'Owner status' }
              ].map(item => (
                <div key={item.step} className="p-2.5 bg-black/40 rounded-xl border border-white/5 space-y-1">
                  <div className="w-5 h-5 rounded-full bg-orange-500/20 text-orange-400 font-bold mx-auto flex items-center justify-center text-[10px]">
                    {item.step}
                  </div>
                  <div className="text-white font-bold text-[10px]">{item.title}</div>
                  <div className="text-gray-400 text-[9px]">{item.desc}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: 15 DEPARTMENTS ALLOCATION (EXACTLY 1,000 CAPACITY) */}
      {activeTab === 'departments' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-bold text-white font-display">
                Exact Department Capacity Allocation (15 Departments = 1,000 Agents)
              </h2>
              <p className="text-xs text-gray-400 font-mono">
                Formula: 20 + 80 + 120 + 100 + 90 + 80 + 80 + 80 + 50 + 50 + 50 + 50 + 50 + 50 + 50 = 1,000 Capacity (Dept #15: 30 Legal Specialists + 20 Governance Auditors)
              </p>
            </div>
            <span className="px-3 py-1 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded-lg text-xs font-mono font-bold">
              1,000 / 1,000 ALLOCATED
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {orgDepartments.map(dept => (
              <div
                key={dept.id}
                className="p-5 bg-[#090e1a] rounded-xl border border-white/10 hover:border-orange-500/40 transition space-y-3"
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono font-bold text-orange-400">
                    Dept #{dept.number}
                  </span>
                  <span className="text-xs font-mono text-white font-bold bg-white/10 px-2 py-0.5 rounded">
                    {dept.targetCapacity} Agents
                  </span>
                </div>

                <div>
                  <h3 className="text-sm font-bold text-white">{dept.name}</h3>
                  <div className="text-xs text-gray-400 font-mono">Director: {dept.directorName}</div>
                </div>

                <p className="text-xs text-gray-300 leading-relaxed line-clamp-2">
                  {dept.purpose}
                </p>

                {/* Capacity breakdown bar */}
                <div className="space-y-1">
                  <div className="flex items-center justify-between text-[10px] font-mono text-gray-400">
                    <span>Active: {dept.activeCount}</span>
                    <span>Sleeping: {dept.sleepingCount}</span>
                    <span>Queued: {dept.queuedCount}</span>
                  </div>
                  <div className="h-1.5 w-full bg-black/60 rounded-full overflow-hidden flex">
                    <div
                      className="bg-emerald-500 h-full"
                      style={{ width: `${(dept.activeCount / dept.targetCapacity) * 100}%` }}
                      title={`Active: ${dept.activeCount}`}
                    />
                    <div
                      className="bg-amber-500 h-full"
                      style={{ width: `${(dept.queuedCount / dept.targetCapacity) * 100}%` }}
                      title={`Queued: ${dept.queuedCount}`}
                    />
                    <div
                      className="bg-gray-700 h-full"
                      style={{ width: `${(dept.sleepingCount / dept.targetCapacity) * 100}%` }}
                      title={`Sleeping: ${dept.sleepingCount}`}
                    />
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-white/5 text-[10px] font-mono text-gray-400">
                  <span>Spend: ${dept.spentUSD.toFixed(2)} / ${dept.budgetCapUSD.toFixed(2)}</span>
                  <button
                    onClick={() => {
                      setDeptFilter(dept.id);
                      setActiveTab('directory');
                    }}
                    className="text-orange-400 hover:text-orange-300 flex items-center space-x-1"
                  >
                    <span>View Roster</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 3: AGENT DIRECTORY (FULL 1,000 ROSTER INSPECTOR) */}
      {activeTab === 'directory' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h2 className="text-lg font-bold text-white font-display">
                Agent Directory ({filteredAgents.length} shown of 1,000 Capacity)
              </h2>
              <p className="text-xs text-gray-400 font-mono">
                Inspect identity, capabilities, model routing, tools, permissions, and audit history.
              </p>
            </div>

            {/* Search & Filters */}
            <div className="flex flex-wrap items-center gap-2 text-xs font-mono">
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-gray-400 absolute left-2.5 top-2.5" />
                <input
                  type="text"
                  placeholder="Search ID, role, model..."
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  className="pl-8 pr-3 py-1.5 bg-black/50 border border-white/10 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-orange-500"
                />
              </div>

              <select
                value={deptFilter}
                onChange={e => setDeptFilter(e.target.value)}
                className="px-2.5 py-1.5 bg-black/50 border border-white/10 rounded-lg text-gray-300 focus:outline-none focus:border-orange-500"
              >
                <option value="ALL">All Departments</option>
                {orgDepartments.map(d => (
                  <option key={d.id} value={d.id}>{d.number}. {d.shortName}</option>
                ))}
              </select>

              <select
                value={stateFilter}
                onChange={e => setStateFilter(e.target.value)}
                className="px-2.5 py-1.5 bg-black/50 border border-white/10 rounded-lg text-gray-300 focus:outline-none focus:border-orange-500"
              >
                <option value="ALL">All States</option>
                <option value="ACTIVE">ACTIVE</option>
                <option value="EXECUTING">EXECUTING</option>
                <option value="VERIFYING">VERIFYING</option>
                <option value="QUEUED">QUEUED</option>
                <option value="SLEEPING">SLEEPING</option>
                <option value="AWAITING_APPROVAL">AWAITING_APPROVAL</option>
              </select>
            </div>
          </div>

          {/* Agents Table */}
          <div className="bg-[#090e1a] rounded-xl border border-white/10 overflow-hidden">
            <div className="overflow-x-auto max-h-[550px]">
              <table className="w-full text-left text-xs font-mono">
                <thead className="bg-black/60 text-gray-400 sticky top-0 border-b border-white/10">
                  <tr>
                    <th className="p-3">Agent ID</th>
                    <th className="p-3">Department & Role</th>
                    <th className="p-3">Seniority</th>
                    <th className="p-3">State</th>
                    <th className="p-3">Model</th>
                    <th className="p-3">Governance</th>
                    <th className="p-3">Cost / Latency</th>
                    <th className="p-3 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {filteredAgents.slice(0, 100).map(agent => (
                    <tr key={agent.agent_id} className="hover:bg-white/5 transition">
                      <td className="p-3 font-bold text-orange-400">
                        {agent.agent_id}
                      </td>
                      <td className="p-3">
                        <div className="text-white font-medium">{agent.role}</div>
                        <div className="text-[10px] text-gray-400 truncate max-w-xs">{agent.specialty}</div>
                      </td>
                      <td className="p-3 text-gray-300">
                        {agent.seniority}
                      </td>
                      <td className="p-3">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          agent.current_state === 'ACTIVE' || agent.current_state === 'EXECUTING'
                            ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                            : agent.current_state === 'VERIFYING'
                            ? 'bg-indigo-500/10 text-indigo-400 border border-indigo-500/20'
                            : agent.current_state === 'QUEUED'
                            ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                            : agent.current_state === 'AWAITING_APPROVAL'
                            ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                            : 'bg-gray-500/10 text-gray-400 border border-gray-500/20'
                        }`}>
                          {agent.current_state}
                        </span>
                      </td>
                      <td className="p-3 text-gray-300 text-[11px]">
                        {agent.model_provider.split(' ')[0]}
                      </td>
                      <td className="p-3 text-gray-400 text-[10px]">
                        {agent.governance_level}
                      </td>
                      <td className="p-3 text-gray-300 text-[11px]">
                        ${agent.estimated_cost.toFixed(2)} • {agent.average_latency}ms
                      </td>
                      <td className="p-3 text-right">
                        <button
                          onClick={() => setSelectedAgent(agent)}
                          className="px-2.5 py-1 bg-white/10 hover:bg-white/20 text-white rounded text-[11px] transition"
                        >
                          Inspect
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {filteredAgents.length > 100 && (
              <div className="p-3 bg-black/40 text-center text-xs text-gray-400 border-t border-white/5 font-mono">
                Showing first 100 agents of {filteredAgents.length} matching criteria. Refine filters above to locate specific specialists.
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 4: TASK CENTER (10-STEP ORCHESTRATION LOOP) */}
      {activeTab === 'tasks' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-bold text-white font-display">
                Task Center — Governed 10-Stage Lifecycle
              </h2>
              <p className="text-xs text-gray-400 font-mono">
                Classify → Decompose → Select → Check Permissions → Check Budget → Execute → Verify → Escalate → Commit → Learn
              </p>
            </div>
            <span className="text-xs font-mono text-gray-400">
              Active: {orchestrationTasks.filter(t => t.status !== 'COMPLETED').length} tasks
            </span>
          </div>

          <div className="space-y-4">
            {orchestrationTasks.map(task => (
              <div
                key={task.id}
                className="p-5 bg-[#090e1a] rounded-xl border border-white/10 space-y-4"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-white/5 pb-3">
                  <div className="space-y-0.5">
                    <div className="flex items-center space-x-2">
                      <span className="text-xs font-mono font-bold text-orange-400">{task.id}</span>
                      <span className="text-gray-600">/</span>
                      <span className="text-xs font-mono text-gray-300">{task.department}</span>
                      <span className="text-gray-600">/</span>
                      <span className={`px-2 py-0.2 rounded text-[10px] font-mono font-bold ${
                        task.riskLevel === 'Critical' ? 'bg-rose-500/20 text-rose-400' : 'bg-amber-500/20 text-amber-400'
                      }`}>
                        Risk: {task.riskLevel}
                      </span>
                    </div>
                    <h3 className="text-base font-bold text-white">{task.title}</h3>
                  </div>

                  <div className="flex items-center space-x-2">
                    <span className="text-xs font-mono px-2.5 py-1 rounded bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 font-bold">
                      STAGE: {task.currentStage}
                    </span>
                    <button
                      onClick={() => stepAutonomousTaskLoop(task.id)}
                      className="px-3 py-1 bg-orange-600 hover:bg-orange-500 text-white rounded text-xs font-mono font-bold transition flex items-center space-x-1"
                    >
                      <RotateCcw className="w-3 h-3" />
                      <span>Step Loop</span>
                    </button>
                  </div>
                </div>

                <p className="text-xs text-gray-300 leading-relaxed">
                  {task.description}
                </p>

                {/* Subtask decomposition */}
                <div className="p-3 bg-black/40 rounded-xl border border-white/5 space-y-2">
                  <div className="text-[11px] font-mono text-gray-400 uppercase">Subtask Decomposition</div>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs font-mono">
                    {task.subtasks.map(sub => (
                      <div key={sub.id} className="p-2 bg-black/60 rounded border border-white/5 space-y-1">
                        <div className="flex items-center justify-between text-[10px]">
                          <span className="text-gray-400">{sub.assignedTo}</span>
                          <span className={sub.status === 'DONE' ? 'text-emerald-400 font-bold' : 'text-amber-400'}>
                            {sub.status}
                          </span>
                        </div>
                        <div className="text-white text-[11px]">{sub.title}</div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Verification & Provenance */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-[11px] font-mono text-gray-400 pt-1">
                  <div>
                    <span className="text-gray-500">Verifier: </span>
                    <span className="text-gray-300">{task.verifierAgentId || 'Independent Reviewer'}</span>
                    <span className="text-gray-500"> • Confidence: </span>
                    <span className="text-emerald-400 font-bold">{task.confidenceScorePct}%</span>
                  </div>
                  <div>
                    <span className="text-gray-500">Cost: </span>
                    <span className="text-white font-bold">${task.actualCostUSD.toFixed(2)}</span>
                    <span className="text-gray-500"> • Tokens: </span>
                    <span className="text-gray-300">{task.tokensConsumed.toLocaleString()}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 5: OWNER APPROVALS */}
      {activeTab === 'approvals' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-bold text-white font-display">
                Owner / Admin Approval Gate (L5 Restricted Operations)
              </h2>
              <p className="text-xs text-gray-400 font-mono">
                Autonomous agents are blocked from executing financial, advertising, policy, authentication or destructive actions without explicit Owner authorization.
              </p>
            </div>
            <span className="text-xs font-mono px-3 py-1 bg-rose-500/10 text-rose-400 border border-rose-500/20 rounded font-bold">
              {ownerApprovals.filter(a => a.status === 'PENDING').length} PENDING GATES
            </span>
          </div>

          <div className="space-y-3">
            {ownerApprovals.map(req => (
              <div
                key={req.id}
                className="p-5 bg-[#090e1a] rounded-xl border border-white/10 space-y-3"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="space-y-1">
                    <div className="flex items-center space-x-2 text-xs font-mono">
                      <span className="text-orange-400 font-bold">{req.id}</span>
                      <span className="text-gray-600">/</span>
                      <span className="text-rose-400 font-bold">{req.category}</span>
                      <span className="text-gray-600">/</span>
                      <span className="text-gray-400">Risk: {req.risk}</span>
                    </div>
                    <h3 className="text-base font-bold text-white">{req.title}</h3>
                  </div>

                  <span className={`px-2.5 py-1 rounded text-xs font-mono font-bold ${
                    req.status === 'PENDING'
                      ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                      : req.status === 'APPROVED'
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                      : 'bg-red-500/20 text-red-300 border border-red-500/30'
                  }`}>
                    {req.status}
                  </span>
                </div>

                <p className="text-xs text-gray-300 leading-relaxed">
                  {req.description}
                </p>

                <div className="p-3 bg-black/40 rounded-xl border border-white/5 space-y-1 text-xs font-mono">
                  <div className="text-gray-400">Justification & Blast Radius:</div>
                  <div className="text-gray-300">{req.justification}</div>
                  <div className="text-amber-400 text-[11px] pt-1">Blast Radius: {req.blastRadius}</div>
                  {req.estimatedCostUSD !== undefined && req.estimatedCostUSD > 0 && (
                    <div className="text-white font-bold pt-1">Proposed Spend: ${req.estimatedCostUSD.toFixed(2)} USD</div>
                  )}
                </div>

                {/* Owner Actions */}
                {req.status === 'PENDING' && (
                  <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-white/5">
                    <button
                      onClick={() => approveOwnerRequest(req.id)}
                      className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-mono font-bold transition flex items-center space-x-1"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>APPROVE OPERATION</span>
                    </button>
                    <button
                      onClick={() => rejectOwnerRequest(req.id, 'Owner rejected via Policy §10')}
                      className="px-4 py-1.5 bg-red-600/80 hover:bg-red-600 text-white rounded-lg text-xs font-mono font-bold transition flex items-center space-x-1"
                    >
                      <XCircle className="w-3.5 h-3.5" />
                      <span>REJECT</span>
                    </button>
                    <button
                      onClick={() => escalateOwnerRequest(req.id, 'Escalated to board/legal counsel')}
                      className="px-3 py-1.5 bg-white/10 hover:bg-white/20 text-gray-300 rounded-lg text-xs font-mono transition"
                    >
                      <span>Escalate</span>
                    </button>
                    <button
                      onClick={() => modifyApprovalLimits(req.id, 50.00)}
                      className="px-3 py-1.5 bg-white/10 hover:bg-white/20 text-gray-300 rounded-lg text-xs font-mono transition"
                    >
                      <span>Cap to $50</span>
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 6: COST CENTER & MODEL ROUTING */}
      {activeTab === 'costs' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-5 bg-[#090e1a] rounded-xl border border-white/10 space-y-2">
              <div className="text-xs font-mono text-gray-400 uppercase">Today's Inference Spend</div>
              <div className="text-3xl font-extrabold font-mono text-white">
                ${aiOrgState.dailyCostUSD.toFixed(2)}
              </div>
              <div className="text-xs text-gray-400 font-mono">
                Hard Ceiling: $50.00 / day
              </div>
            </div>

            <div className="p-5 bg-[#090e1a] rounded-xl border border-white/10 space-y-2">
              <div className="text-xs font-mono text-gray-400 uppercase">Month-To-Date Spend</div>
              <div className="text-3xl font-extrabold font-mono text-indigo-400">
                ${aiOrgState.monthlyCostUSD.toFixed(2)}
              </div>
              <div className="text-xs text-gray-400 font-mono">
                Budget Allocation: $1,250.00 / month
              </div>
            </div>

            <div className="p-5 bg-[#090e1a] rounded-xl border border-white/10 space-y-2">
              <div className="text-xs font-mono text-gray-400 uppercase">Model Routing Efficiency</div>
              <div className="text-3xl font-extrabold font-mono text-emerald-400">
                72.4%
              </div>
              <div className="text-xs text-gray-400 font-mono">
                Routed to Fast/Cheaper Tiers
              </div>
            </div>
          </div>

          {/* Model Routing Architecture */}
          <div className="p-6 bg-[#090e1a] rounded-2xl border border-white/10 space-y-4">
            <h3 className="text-base font-bold text-white font-display">
              Autonomous Model Tier Routing Policy
            </h3>
            <p className="text-xs text-gray-300 leading-relaxed">
              Simple tasks are automatically dispatched to cost-effective models to prevent unnecessary token consumption. Higher-tier models are unlocked solely when justified by task complexity or formal verification rigor.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs font-mono">
              <div className="p-3 bg-black/40 rounded-xl border border-white/5 space-y-1">
                <div className="text-emerald-400 font-bold">Tier 1: Gemini 2.0 Flash</div>
                <div className="text-gray-300 text-[11px]">
                  Syntax parsing, telemetry sweeps, error classification, routine health checks.
                </div>
                <div className="text-[10px] text-gray-500 pt-1">Cost: $0.0001 / 1K tokens</div>
              </div>

              <div className="p-3 bg-black/40 rounded-xl border border-white/5 space-y-1">
                <div className="text-amber-400 font-bold">Tier 2: Gemini 1.5 Flash</div>
                <div className="text-gray-300 text-[11px]">
                  Wholesale margin arbitrage, dataset schema checks, developer documentation.
                </div>
                <div className="text-[10px] text-gray-500 pt-1">Cost: $0.0002 / 1K tokens</div>
              </div>

              <div className="p-3 bg-black/40 rounded-xl border border-white/5 space-y-1">
                <div className="text-indigo-400 font-bold">Tier 3: Gemini 1.5 Pro</div>
                <div className="text-gray-300 text-[11px]">
                  Distributed systems topology, red teaming, DPDP Act verification, executive planning.
                </div>
                <div className="text-[10px] text-gray-500 pt-1">Cost: $0.00125 / 1K tokens</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 7: AUTONOMOUS SELF-OPTIMIZATION */}
      {activeTab === 'optimizations' && (
        <div className="space-y-4">
          <div>
            <h2 className="text-lg font-bold text-white font-display">
              Autonomous Self-Optimization Engine
            </h2>
            <p className="text-xs text-gray-400 font-mono">
              The organization autonomously detects bottlenecks and formulates efficiency proposals. High-impact changes require Owner approval; agents cannot rewrite their own governance rules.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {selfOptimizations.map(opt => (
              <div
                key={opt.id}
                className="p-5 bg-[#090e1a] rounded-xl border border-white/10 space-y-3"
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono font-bold text-orange-400">{opt.id}</span>
                  <span className="text-xs font-mono px-2 py-0.5 rounded bg-white/10 text-white">
                    {opt.type}
                  </span>
                </div>

                <h3 className="text-sm font-bold text-white">{opt.title}</h3>

                <div className="p-3 bg-black/40 rounded-lg text-xs font-mono space-y-1 text-gray-300">
                  <div className="text-gray-400">Current Bottleneck:</div>
                  <div>{opt.currentBottleneck}</div>
                  <div className="text-gray-400 pt-2">Proposed Architecture Change:</div>
                  <div className="text-emerald-400">{opt.proposedChange}</div>
                </div>

                <div className="flex items-center justify-between text-xs font-mono pt-1 text-gray-400">
                  <span>Projected Savings: <strong className="text-emerald-400">{opt.projectedCostSavingsPct}%</strong></span>
                  <span>Latency Gain: <strong className="text-indigo-400">+{opt.projectedLatencyImprovementPct}%</strong></span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 8: COMPANY KNOWLEDGE MEMORY */}
      {activeTab === 'memory' && (
        <div className="space-y-4">
          <div>
            <h2 className="text-lg font-bold text-white font-display">
              Company Knowledge Memory (Controlled Organizational State)
            </h2>
            <p className="text-xs text-gray-400 font-mono">
              Stores verified decisions, research, lessons, and benchmark results. Strictly zero customer private datasets or PII.
            </p>
          </div>

          <div className="space-y-3">
            {companyKnowledgeMemory.map(mem => (
              <div
                key={mem.id}
                className="p-5 bg-[#090e1a] rounded-xl border border-white/10 space-y-2"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                  <div className="flex items-center space-x-2 text-xs font-mono">
                    <span className="text-orange-400 font-bold">{mem.id}</span>
                    <span className="text-gray-600">/</span>
                    <span className="text-white font-bold">{mem.category}</span>
                  </div>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-bold">
                    {mem.validationState}
                  </span>
                </div>

                <h3 className="text-sm font-bold text-white">{mem.title}</h3>
                <p className="text-xs text-gray-300 leading-relaxed">{mem.contentSummary}</p>

                <div className="flex flex-wrap items-center gap-3 pt-2 text-[10px] font-mono text-gray-400 border-t border-white/5">
                  <span>Provenance: {mem.provenance}</span>
                  <span>• Confidence: {mem.confidenceScorePct}%</span>
                  <span>• Owner: {mem.owner}</span>
                  <span>• Sensitivity: {mem.sensitivity}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 9: IMMUTABLE AUDIT LOG */}
      {activeTab === 'audit_log' && (
        <div className="space-y-4">
          <div>
            <h2 className="text-lg font-bold text-white font-display">
              Immutable Cryptographic Audit Trail
            </h2>
            <p className="text-xs text-gray-400 font-mono">
              Append-only audit ledger recording every autonomous decision, tool invocation, and human approval with SHA-256 integrity hashes.
            </p>
          </div>

          <div className="bg-[#090e1a] rounded-xl border border-white/10 overflow-hidden">
            <div className="overflow-x-auto max-h-[500px]">
              <table className="w-full text-left text-xs font-mono">
                <thead className="bg-black/60 text-gray-400 border-b border-white/10 sticky top-0">
                  <tr>
                    <th className="p-3">Timestamp</th>
                    <th className="p-3">Principal</th>
                    <th className="p-3">Action Description</th>
                    <th className="p-3">Objective (Why)</th>
                    <th className="p-3">Status</th>
                    <th className="p-3">Cryptographic Hash</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {immutableAuditLogs.map(log => (
                    <tr key={log.id} className="hover:bg-white/5 transition">
                      <td className="p-3 text-gray-400 whitespace-nowrap">{log.timestamp}</td>
                      <td className="p-3">
                        <div className="text-white font-medium">{log.who}</div>
                        <div className="text-[10px] text-gray-500">{log.roleOrSeniority}</div>
                      </td>
                      <td className="p-3 text-gray-200">{log.what}</td>
                      <td className="p-3 text-gray-400 max-w-xs truncate">{log.why}</td>
                      <td className="p-3">
                        <span className="px-2 py-0.5 bg-emerald-500/10 text-emerald-400 rounded text-[10px] font-bold">
                          {log.resultStatus}
                        </span>
                      </td>
                      <td className="p-3 text-gray-500 text-[10px] font-mono truncate max-w-[140px]" title={log.immutableHash}>
                        {log.immutableHash}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* AGENT DETAIL MODAL (ALL 24 REQUIRED IDENTITY FIELDS) */}
      {selectedAgent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-[#0b101c] border border-white/20 rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div>
                <span className="text-xs font-mono text-orange-400 font-bold">{selectedAgent.agent_id}</span>
                <h3 className="text-lg font-bold text-white font-display">{selectedAgent.role}</h3>
              </div>
              <button
                onClick={() => setSelectedAgent(null)}
                className="p-1.5 hover:bg-white/10 rounded-lg text-gray-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs font-mono">
              <div className="p-2.5 bg-black/40 rounded-lg border border-white/5 space-y-0.5">
                <span className="text-gray-400">Department:</span>
                <div className="text-white font-bold">{selectedAgent.department}</div>
              </div>
              <div className="p-2.5 bg-black/40 rounded-lg border border-white/5 space-y-0.5">
                <span className="text-gray-400">Seniority:</span>
                <div className="text-amber-400 font-bold">{selectedAgent.seniority}</div>
              </div>
              <div className="p-2.5 bg-black/40 rounded-lg border border-white/5 space-y-0.5">
                <span className="text-gray-400">Current State:</span>
                <div className="text-emerald-400 font-bold">{selectedAgent.current_state}</div>
              </div>
              <div className="p-2.5 bg-black/40 rounded-lg border border-white/5 space-y-0.5">
                <span className="text-gray-400">Governance Level:</span>
                <div className="text-indigo-400 font-bold">{selectedAgent.governance_level}</div>
              </div>
              <div className="p-2.5 bg-black/40 rounded-lg border border-white/5 space-y-0.5">
                <span className="text-gray-400">Model & Provider:</span>
                <div className="text-white font-medium">{selectedAgent.model_provider}</div>
              </div>
              <div className="p-2.5 bg-black/40 rounded-lg border border-white/5 space-y-0.5">
                <span className="text-gray-400">Data Access Level:</span>
                <div className="text-rose-400 font-bold">{selectedAgent.data_access_level}</div>
              </div>
              <div className="p-2.5 bg-black/40 rounded-lg border border-white/5 space-y-0.5">
                <span className="text-gray-400">Task Budget / Tokens:</span>
                <div className="text-white font-medium">${selectedAgent.budget.toFixed(2)} / {selectedAgent.token_budget} tok</div>
              </div>
              <div className="p-2.5 bg-black/40 rounded-lg border border-white/5 space-y-0.5">
                <span className="text-gray-400">Risk Level:</span>
                <div className="text-white font-bold">{selectedAgent.risk_level}</div>
              </div>
              <div className="p-2.5 bg-black/40 rounded-lg border border-white/5 space-y-0.5">
                <span className="text-gray-400">Parent Agent:</span>
                <div className="text-gray-300">{selectedAgent.parent_agent || 'None (Top Director)'}</div>
              </div>
              <div className="p-2.5 bg-black/40 rounded-lg border border-white/5 space-y-0.5">
                <span className="text-gray-400">Success Rate / Latency:</span>
                <div className="text-emerald-400 font-bold">{selectedAgent.success_rate.toFixed(1)}% / {selectedAgent.average_latency}ms</div>
              </div>
            </div>

            <div className="space-y-1.5 text-xs font-mono">
              <span className="text-gray-400">Capabilities:</span>
              <div className="flex flex-wrap gap-1">
                {selectedAgent.capabilities.map((c, i) => (
                  <span key={i} className="px-2 py-0.5 bg-white/5 rounded text-gray-300 border border-white/10">
                    {c}
                  </span>
                ))}
              </div>
            </div>

            <div className="space-y-1.5 text-xs font-mono">
              <span className="text-gray-400">Tools Allowed:</span>
              <div className="flex flex-wrap gap-1">
                {selectedAgent.tools_allowed.map((t, i) => (
                  <span key={i} className="px-2 py-0.5 bg-indigo-500/10 text-indigo-300 rounded border border-indigo-500/20">
                    {t}
                  </span>
                ))}
              </div>
            </div>

            <div className="space-y-1.5 text-xs font-mono">
              <span className="text-gray-400">Permissions:</span>
              <div className="flex flex-wrap gap-1">
                {selectedAgent.permissions.map((p, i) => (
                  <span key={i} className="px-2 py-0.5 bg-emerald-500/10 text-emerald-300 rounded border border-emerald-500/20">
                    {p}
                  </span>
                ))}
              </div>
            </div>

            <div className="pt-2 border-t border-white/10 flex justify-end">
              <button
                onClick={() => setSelectedAgent(null)}
                className="px-4 py-1.5 bg-white/10 hover:bg-white/20 text-white rounded-lg text-xs font-mono"
              >
                Close Inspector
              </button>
            </div>
          </div>
        </div>
      )}

      {/* EMERGENCY STOP CONFIRMATION MODAL */}
      {showEmergencyModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
          <div className="bg-[#12080a] border border-red-500/50 rounded-2xl max-w-lg w-full p-6 space-y-4 shadow-2xl text-left">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-red-500/20 border border-red-500/40 rounded-xl flex items-center justify-center shrink-0">
                <AlertTriangle className="w-7 h-7 text-red-400" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-white font-display">Confirm Global Emergency Stop</h3>
                <p className="text-xs text-red-300 font-mono">Privileged Owner / Admin Fail-Safe Action</p>
              </div>
            </div>

            <p className="text-xs text-gray-300 leading-relaxed">
              This will immediately halt all active agent tasks, scheduled workflows, and external provider dispatches. All immutable audit records will be cryptographically preserved.
            </p>

            <div className="space-y-1 text-xs font-mono">
              <label className="text-gray-400">Specify reason for audit log:</label>
              <input
                type="text"
                value={emergencyReason}
                onChange={e => setEmergencyReason(e.target.value)}
                className="w-full p-2.5 bg-black/60 border border-red-500/30 rounded-lg text-white text-xs focus:outline-none focus:border-red-500"
              />
            </div>

            <div className="flex items-center justify-end space-x-2 pt-2 border-t border-white/10">
              <button
                onClick={() => setShowEmergencyModal(false)}
                className="px-4 py-2 bg-white/10 hover:bg-white/20 text-gray-300 rounded-xl text-xs font-mono"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  triggerEmergencyStop(emergencyReason);
                  setShowEmergencyModal(false);
                }}
                className="px-4 py-2 bg-red-600 hover:bg-red-500 text-white rounded-xl text-xs font-mono font-bold transition flex items-center space-x-1.5"
              >
                <Power className="w-4 h-4" />
                <span>CONFIRM EMERGENCY STOP</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
