import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { TrustBadge } from '../common/TrustBadge';
import { DataPrivacyClass, ScientificValidationStatus } from '../../types/platformKnowledge';
import {
  BrainCircuit,
  Shield,
  ShieldCheck,
  Lock,
  Globe,
  Database,
  FileCheck,
  GitBranch,
  Search,
  CheckCircle2,
  AlertTriangle,
  Layers,
  Sparkles,
  ArrowRight,
  RefreshCw,
  ExternalLink,
  Sliders,
  Filter,
  Eye,
  Check
} from 'lucide-react';

export const KnowledgeEngineView: React.FC = () => {
  const {
    knowledgeManifests,
    knowledgeGraphNodes,
    scientificClaims,
    addKnowledgeCandidate,
    experiments,
    showNotification,
    customerDataFirewallConsent,
    setCustomerDataFirewallConsent
  } = useApp();

  const [activeTab, setActiveTab] = useState<'manifests' | 'graph' | 'firewall' | 'claims'>('manifests');
  const [selectedManifestId, setSelectedManifestId] = useState<string>(knowledgeManifests[0]?.id || '');
  const [privacyFilter, setPrivacyFilter] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const selectedManifest = knowledgeManifests.find(m => m.id === selectedManifestId) || knowledgeManifests[0];

  const filteredManifests = knowledgeManifests.filter(m => {
    if (privacyFilter !== 'ALL' && m.privacyClassification !== privacyFilter) return false;
    if (searchQuery && !m.modelId.toLowerCase().includes(searchQuery.toLowerCase()) && !m.findings.some(f => f.toLowerCase().includes(searchQuery.toLowerCase()))) return false;
    return true;
  });

  const handleGenerateManifestFromExp = () => {
    const latestExp = experiments[0];
    addKnowledgeCandidate({
      modelId: 'mod_exp_synthetic_run',
      modelVersion: 'v1.0-checkpoint',
      sourceExperimentId: latestExp?.id || 'exp_auto',
      privacyClassification: 'CONSENTED_GLOBAL_KNOWLEDGE',
      trainingEligibility: true,
      provenanceScore: 97,
      dataQualityScore: 95,
      scientificConfidence: 94,
      license: 'Apache-2.0 Open Sovereign',
      findings: [
        'AdamW weight decay 0.01 with cosine decay scheduled down to 1e-5 yielded lowest perplexity variance on Indic benchmarks.'
      ],
      techniques: ['Fused RMSNorm Kernel', 'Gradient Checkpointing with zero vRAM fragmentation'],
      optimizationDiscoveries: ['Saved 18% cluster power consumption using FP8 Tensor Core execution.'],
      failurePatternsAvoided: ['Prevented catastrophic forgetting by interweaving 10% general English pretraining corpus.'],
      hyperparameterOutcomes: {
        peak_lr: '2.0e-4',
        effective_batch: 64,
        steps: 2000
      },
      evaluationSummary: {
        evalAccuracyPct: 91.8,
        indicPerplexity: 4.81,
        safetyScore: 99.5
      },
      securityAuditPassed: true,
      piiCheckPassed: true,
      benchmarkContaminationChecked: true
    });
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Header & Brand Banner */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-gradient-to-r from-[#0c1220] via-[#080d16] to-[#0c1220] p-6 rounded-2xl border border-white/10 shadow-xl">
        <div className="space-y-1">
          <div className="flex items-center space-x-2">
            <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-orange-500/20 text-orange-400 border border-orange-500/30">
              MII Core System
            </span>
            <span className="text-xs text-gray-400 font-mono">🇮🇳 Make in India. Made for 🇮🇳 Make in India (MII). 🇮🇳</span>
            <TrustBadge type="APPROVED" size="xs" />
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-white font-display flex items-center space-x-2">
            <BrainCircuit className="w-7 h-7 text-orange-400" />
            <span>Collective AI Knowledge Engine</span>
          </h1>
          <p className="text-sm text-gray-400 max-w-3xl leading-relaxed">
            Continuous platform learning architecture. Every verified sovereign AI workload contributes verified findings, optimization recipes, and benchmark results back into collective intelligence — with a strict customer private data firewall.
          </p>
        </div>

        <div className="flex items-center space-x-3 shrink-0">
          <button
            onClick={handleGenerateManifestFromExp}
            className="px-4 py-2.5 bg-orange-500 hover:bg-orange-600 text-white rounded-xl text-xs font-bold transition flex items-center space-x-1.5 shadow-lg shadow-orange-500/20"
          >
            <Sparkles className="w-4 h-4" />
            <span>Ingest Knowledge Manifest</span>
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center space-x-2 border-b border-white/10 pb-2 overflow-x-auto">
        <button
          onClick={() => setActiveTab('manifests')}
          className={`px-4 py-2 rounded-lg text-xs font-medium transition flex items-center space-x-2 whitespace-nowrap ${
            activeTab === 'manifests'
              ? 'bg-orange-500/10 text-orange-400 border border-orange-500/30'
              : 'text-gray-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <FileCheck className="w-4 h-4" />
          <span>Model Knowledge Manifests ({knowledgeManifests.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('graph')}
          className={`px-4 py-2 rounded-lg text-xs font-medium transition flex items-center space-x-2 whitespace-nowrap ${
            activeTab === 'graph'
              ? 'bg-orange-500/10 text-orange-400 border border-orange-500/30'
              : 'text-gray-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <GitBranch className="w-4 h-4" />
          <span>MII Knowledge Graph ({knowledgeGraphNodes.length} Nodes)</span>
        </button>

        <button
          onClick={() => setActiveTab('firewall')}
          className={`px-4 py-2 rounded-lg text-xs font-medium transition flex items-center space-x-2 whitespace-nowrap ${
            activeTab === 'firewall'
              ? 'bg-orange-500/10 text-orange-400 border border-orange-500/30'
              : 'text-gray-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Lock className="w-4 h-4" />
          <span>Private Data Firewall & Policy</span>
        </button>

        <button
          onClick={() => setActiveTab('claims')}
          className={`px-4 py-2 rounded-lg text-xs font-medium transition flex items-center space-x-2 whitespace-nowrap ${
            activeTab === 'claims'
              ? 'bg-orange-500/10 text-orange-400 border border-orange-500/30'
              : 'text-gray-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <CheckCircle2 className="w-4 h-4" />
          <span>Scientific Validation ({scientificClaims.length} Claims)</span>
        </button>
      </div>

      {/* TAB 1: MODEL KNOWLEDGE MANIFESTS */}
      {activeTab === 'manifests' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Manifest List (5 cols) */}
          <div className="lg:col-span-5 space-y-4">
            <div className="flex items-center space-x-2">
              <div className="relative flex-1">
                <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-gray-500" />
                <input
                  type="text"
                  placeholder="Search findings, models, techniques..."
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  className="w-full pl-8 pr-3 py-1.5 bg-[#0a0e17] border border-white/10 rounded-lg text-xs text-white placeholder-gray-500 focus:outline-none focus:border-orange-500/50 font-mono"
                />
              </div>

              <select
                value={privacyFilter}
                onChange={e => setPrivacyFilter(e.target.value)}
                className="bg-[#0a0e17] border border-white/10 rounded-lg text-xs text-gray-300 px-2.5 py-1.5 focus:outline-none font-mono"
              >
                <option value="ALL">All Privacy</option>
                <option value="CONSENTED_GLOBAL_KNOWLEDGE">Consented Global</option>
                <option value="PLATFORM_RESEARCH">Platform Research</option>
                <option value="PRIVATE">Private Isolated</option>
              </select>
            </div>

            <div className="space-y-2">
              {filteredManifests.map(manifest => {
                const isSelected = manifest.id === selectedManifest.id;
                return (
                  <div
                    key={manifest.id}
                    onClick={() => setSelectedManifestId(manifest.id)}
                    className={`p-4 rounded-xl border transition cursor-pointer space-y-2 ${
                      isSelected
                        ? 'bg-orange-500/10 border-orange-500/40'
                        : 'bg-[#0a0e17] border-white/10 hover:border-white/20'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-mono text-xs font-bold text-white truncate">
                        {manifest.modelId} ({manifest.modelVersion})
                      </span>
                      <span className="px-2 py-0.5 rounded text-[10px] font-mono uppercase bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                        {manifest.privacyClassification}
                      </span>
                    </div>

                    <p className="text-xs text-gray-300 line-clamp-2">
                      {manifest.findings[0] || 'Verified research checkpoint.'}
                    </p>

                    <div className="flex items-center justify-between text-[10px] font-mono text-gray-400 pt-1 border-t border-white/5">
                      <span className="text-emerald-400">Quality: {manifest.dataQualityScore}%</span>
                      <span>Confidence: {manifest.scientificConfidence}%</span>
                      <span>{manifest.createdAt}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Right Manifest Detail (7 cols) */}
          <div className="lg:col-span-7 bg-[#0c101a] border border-white/10 rounded-2xl p-6 space-y-6">
            <div className="flex items-start justify-between border-b border-white/10 pb-4">
              <div>
                <div className="flex items-center space-x-2">
                  <h2 className="text-xl font-bold text-white font-display">
                    {selectedManifest.modelId}
                  </h2>
                  <span className="text-xs font-mono text-orange-400 bg-orange-500/10 px-2 py-0.5 rounded border border-orange-500/30">
                    {selectedManifest.modelVersion}
                  </span>
                </div>
                <div className="text-xs text-gray-400 font-mono mt-1">
                  Source: {selectedManifest.sourceExperimentId} • Checksum: {selectedManifest.checksum.substring(0, 22)}...
                </div>
              </div>

              <div className="text-right">
                <span className="px-2.5 py-1 rounded text-xs font-bold uppercase tracking-wider bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                  {selectedManifest.license}
                </span>
              </div>
            </div>

            {/* Quality & Security Scores */}
            <div className="grid grid-cols-3 gap-3">
              <div className="p-3 bg-white/5 rounded-xl border border-white/5 text-center">
                <div className="text-[10px] text-gray-400 uppercase font-mono">Data Quality</div>
                <div className="text-xl font-bold text-emerald-400 font-display">
                  {selectedManifest.dataQualityScore}%
                </div>
                <div className="text-[10px] text-gray-500">De-duplicated & Cleaned</div>
              </div>

              <div className="p-3 bg-white/5 rounded-xl border border-white/5 text-center">
                <div className="text-[10px] text-gray-400 uppercase font-mono">Provenance Score</div>
                <div className="text-xl font-bold text-sky-400 font-display">
                  {selectedManifest.provenanceScore}%
                </div>
                <div className="text-[10px] text-gray-500">Full Origin DNA</div>
              </div>

              <div className="p-3 bg-white/5 rounded-xl border border-white/5 text-center">
                <div className="text-[10px] text-gray-400 uppercase font-mono">Scientific Confidence</div>
                <div className="text-xl font-bold text-purple-400 font-display">
                  {selectedManifest.scientificConfidence}%
                </div>
                <div className="text-[10px] text-gray-500">Multi-run Validation</div>
              </div>
            </div>

            {/* Verified Findings */}
            <div className="space-y-2">
              <h3 className="text-xs font-bold uppercase tracking-wider text-orange-400 font-mono flex items-center space-x-1.5">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Verified Scientific Findings</span>
              </h3>
              <div className="space-y-2">
                {selectedManifest.findings.map((finding, idx) => (
                  <div key={idx} className="p-3 bg-white/5 rounded-lg border border-white/5 text-xs text-gray-200 flex items-start space-x-2">
                    <span className="text-orange-400 font-bold">•</span>
                    <span>{finding}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Compute Optimizations & Failure Patterns */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-emerald-400 font-mono">
                  Compute Optimizations
                </h4>
                {selectedManifest.optimizationDiscoveries.map((opt, idx) => (
                  <div key={idx} className="p-2.5 bg-emerald-500/5 rounded-lg border border-emerald-500/20 text-xs text-gray-300">
                    {opt}
                  </div>
                ))}
              </div>

              <div className="space-y-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400 font-mono">
                  Failure Patterns Avoided
                </h4>
                {selectedManifest.failurePatternsAvoided.map((fp, idx) => (
                  <div key={idx} className="p-2.5 bg-amber-500/5 rounded-lg border border-amber-500/20 text-xs text-gray-300">
                    {fp}
                  </div>
                ))}
              </div>
            </div>

            {/* Security Checklist */}
            <div className="p-4 rounded-xl bg-black/40 border border-white/10 space-y-2">
              <div className="text-xs font-mono text-gray-400 uppercase">
                Continuous Learning Safety Guardrails
              </div>
              <div className="grid grid-cols-3 gap-2 text-xs">
                <div className="flex items-center space-x-1.5 text-emerald-400">
                  <Check className="w-3.5 h-3.5" />
                  <span>PII Masked</span>
                </div>
                <div className="flex items-center space-x-1.5 text-emerald-400">
                  <Check className="w-3.5 h-3.5" />
                  <span>Zero Benchmark Contamination</span>
                </div>
                <div className="flex items-center space-x-1.5 text-emerald-400">
                  <Check className="w-3.5 h-3.5" />
                  <span>Red Team Passed</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: KNOWLEDGE GRAPH */}
      {activeTab === 'graph' && (
        <div className="space-y-4">
          <div className="p-4 rounded-xl bg-[#0c101a] border border-white/10 space-y-2">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-bold text-white font-display flex items-center space-x-2">
                <GitBranch className="w-5 h-5 text-orange-400" />
                <span>MII AI Knowledge Graph</span>
              </h2>
              <span className="text-xs text-gray-400 font-mono">
                Lineage: Research Paper → Dataset → Experiment → Checkpoint → Model → Evaluation → Finding
              </span>
            </div>
            <p className="text-xs text-gray-400">
              Visualizes verified relationships across research artifacts. Every model can trace its lineage back to scientific claims, datasets, experiments, and reproduction benchmarks.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {knowledgeGraphNodes.map(node => (
              <div key={node.id} className="p-4 rounded-xl bg-[#0a0e17] border border-white/10 space-y-3 hover:border-orange-500/40 transition">
                <div className="flex items-center justify-between">
                  <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase bg-orange-500/20 text-orange-400 border border-orange-500/30">
                    {node.type}
                  </span>
                  <span className="text-[10px] font-mono text-gray-500">{node.privacyClass}</span>
                </div>

                <div className="text-sm font-semibold text-white leading-snug">
                  {node.title}
                </div>

                <div className="text-[11px] text-gray-400 font-mono">
                  Owner: <span className="text-gray-300">{node.ownerTenant}</span>
                </div>

                {node.metrics && (
                  <div className="p-2 bg-white/5 rounded-lg text-[11px] font-mono space-y-1 text-gray-300">
                    {Object.entries(node.metrics).map(([k, v]) => (
                      <div key={k} className="flex justify-between">
                        <span className="text-gray-500 capitalize">{k}:</span>
                        <span className="text-emerald-400 font-bold">{v}</span>
                      </div>
                    ))}
                  </div>
                )}

                <div className="pt-2 border-t border-white/5 flex items-center justify-between text-[10px] font-mono">
                  <span className="text-emerald-400 flex items-center space-x-1">
                    <CheckCircle2 className="w-3 h-3" />
                    <span>Scientific {node.scientificStatus}</span>
                  </span>
                  <span className="text-gray-500">{node.connections.length} Links</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 3: PRIVATE DATA FIREWALL & TAXONOMY */}
      {activeTab === 'firewall' && (
        <div className="space-y-6">
          <div className="p-6 rounded-2xl bg-gradient-to-r from-red-950/30 via-[#0a0e17] to-amber-950/20 border border-red-500/30 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2 text-red-400 font-bold text-sm">
                <Shield className="w-5 h-5" />
                <span>STRICT CUSTOMER DATA FIREWALL POLICY (DPDP ACT COMPLIANT)</span>
              </div>
              <div className="flex items-center space-x-2">
                <span className="text-[11px] font-mono text-gray-400">Firewall Engine:</span>
                <span className={`px-2.5 py-1 rounded text-xs font-mono font-bold ${
                  customerDataFirewallConsent
                    ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40'
                    : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                }`}>
                  {customerDataFirewallConsent ? 'CONSENTED LEARNING ACTIVE' : 'HARD TECHNICAL QUARANTINE (DEFAULT)'}
                </span>
              </div>
            </div>

            <h2 className="text-xl font-bold text-white font-display">
              Zero Customer Private Data Enters Collective Training Without Explicit Consent
            </h2>
            <p className="text-xs text-gray-300 max-w-4xl leading-relaxed">
              Under MII architectural policy, tenant customer datasets, private notebook inputs, API inference payloads, and proprietary code are strictly partitioned in isolated object vaults. Only public, open-source, or explicitly consented research manifests enter the MII Collective AI Knowledge Engine.
            </p>

            {/* Interactive Affirmative Consent Toggle */}
            <div className="p-4 rounded-xl bg-black/40 border border-white/10 flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="space-y-1">
                <div className="text-xs font-bold text-white flex items-center space-x-2">
                  <Lock className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Tenant Dataset & Weight Quarantine Status:</span>
                  <span className={customerDataFirewallConsent ? 'text-amber-400 font-mono' : 'text-emerald-400 font-mono'}>
                    {customerDataFirewallConsent ? 'Opted-in (Anonymized Hyperparameter Recipes Only)' : '100% Isolated Quarantine (Default)'}
                  </span>
                </div>
                <p className="text-[11px] text-gray-400">
                  {customerDataFirewallConsent
                    ? 'You have opted to contribute anonymized loss curves and hyperparameter insights in exchange for platform compute credits. Proprietary data remains encrypted.'
                    : 'All private files, checkpoints, and notebook cells are quarantined. Collective learning crawlers receive HTTP 403 Forbidden with 0 bytes transferred.'}
                </p>
              </div>

              <button
                onClick={() => {
                  const newConsent = !customerDataFirewallConsent;
                  setCustomerDataFirewallConsent(newConsent);
                  showNotification(
                    newConsent
                      ? 'Affirmative Consent Granted: Anonymized hyperparameter recipes eligible for research credit bonus.'
                      : 'Strict Technical Quarantine Restored: Zero private data accessible to collective engine.',
                    newConsent ? 'info' : 'success'
                  );
                }}
                className={`px-4 py-2 rounded-lg text-xs font-bold transition flex items-center space-x-2 whitespace-nowrap shrink-0 ${
                  customerDataFirewallConsent
                    ? 'bg-red-500/20 hover:bg-red-500/30 text-red-400 border border-red-500/40'
                    : 'bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-400 border border-emerald-500/40'
                }`}
              >
                {customerDataFirewallConsent ? (
                  <>
                    <Lock className="w-3.5 h-3.5" />
                    <span>Revoke Consent & Enforce Hard Quarantine</span>
                  </>
                ) : (
                  <>
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>Opt-In Anonymized Research Manifest (Credits)</span>
                  </>
                )}
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-5 rounded-xl bg-[#0a0e17] border border-white/10 space-y-3">
              <div className="flex items-center space-x-2 text-emerald-400">
                <Globe className="w-4 h-4" />
                <span className="font-bold text-sm">PUBLIC & OPEN COMMONS</span>
              </div>
              <p className="text-xs text-gray-400">
                Public research preprints (ArXiv), permissively licensed datasets (MIT/Apache), and community benchmarks.
              </p>
              <div className="text-[11px] font-mono text-emerald-400 bg-emerald-500/10 p-2 rounded">
                Eligible for Global Knowledge Layer
              </div>
            </div>

            <div className="p-5 rounded-xl bg-[#0a0e17] border border-white/10 space-y-3">
              <div className="flex items-center space-x-2 text-sky-400">
                <CheckCircle2 className="w-4 h-4" />
                <span className="font-bold text-sm">CONSENTED RESEARCH</span>
              </div>
              <p className="text-xs text-gray-400">
                Workloads where research founders opt-in their optimization recipes, hyperparameter findings, and loss trajectories in exchange for compute credits.
              </p>
              <div className="text-[11px] font-mono text-sky-400 bg-sky-500/10 p-2 rounded">
                Anonymized Manifest Learning Only
              </div>
            </div>

            <div className="p-5 rounded-xl bg-[#0a0e17] border border-red-500/20 space-y-3">
              <div className="flex items-center space-x-2 text-red-400">
                <Lock className="w-4 h-4" />
                <span className="font-bold text-sm">TENANT PRIVATE & ISOLATED</span>
              </div>
              <p className="text-xs text-gray-400">
                Customer internal files, private fine-tuning datasets, enterprise prompts, and proprietary weights.
              </p>
              <div className="text-[11px] font-mono text-red-400 bg-red-500/10 p-2 rounded">
                Strict Technical Isolation • Never Shared
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: SCIENTIFIC CLAIMS VALIDATION */}
      {activeTab === 'claims' && (
        <div className="space-y-4">
          <div className="p-4 rounded-xl bg-[#0c101a] border border-white/10 space-y-1">
            <h2 className="text-lg font-bold text-white font-display flex items-center space-x-2">
              <CheckCircle2 className="w-5 h-5 text-emerald-400" />
              <span>Scientific Claim Validation Registry</span>
            </h2>
            <p className="text-xs text-gray-400">
              Models on Bharat HyperCompute Cloud cannot treat a research preprint as absolute truth. Every claim must have source attribution, empirical reproduction, and multi-run statistical confidence.
            </p>
          </div>

          <div className="space-y-3">
            {scientificClaims.map(claim => (
              <div key={claim.id} className="p-5 rounded-xl bg-[#0a0e17] border border-white/10 space-y-3">
                <div className="flex items-start justify-between">
                  <div className="space-y-1">
                    <div className="flex items-center space-x-2">
                      <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                        {claim.status}
                      </span>
                      <span className="text-xs font-mono text-gray-400">{claim.domain}</span>
                    </div>
                    <div className="text-sm font-bold text-white">{claim.claim}</div>
                  </div>

                  <div className="text-right">
                    <div className="text-lg font-bold text-emerald-400 font-display">
                      {claim.reproductionConfidence}%
                    </div>
                    <div className="text-[10px] text-gray-500 font-mono">Reproduction Confidence</div>
                  </div>
                </div>

                <div className="p-3 bg-white/5 rounded-lg border border-white/5 text-xs text-gray-300 space-y-1 font-mono">
                  <div><span className="text-gray-500">Source:</span> {claim.source}</div>
                  <div><span className="text-gray-500">Evidence:</span> {claim.evidence}</div>
                </div>

                <div className="flex items-center justify-between text-[11px] font-mono text-gray-500 pt-1">
                  <span>Independent Evaluations: {claim.independentEvaluationsCount} replications</span>
                  <span>Last Audited: {claim.lastEvaluated}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
