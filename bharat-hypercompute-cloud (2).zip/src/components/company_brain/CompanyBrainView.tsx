import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { TrustBadge } from '../common/TrustBadge';
import { AgentDepartment, AgentLevel, AIAgent } from '../../types/aiCompany';
import {
  BrainCircuit,
  Bot,
  ShieldCheck,
  Zap,
  Activity,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Layers,
  ChevronRight,
  TrendingUp,
  DollarSign,
  Cpu,
  Sparkles,
  Lock,
  ThumbsUp,
  ThumbsDown,
  ExternalLink,
  ShieldAlert,
  HelpCircle,
  FileCode2
} from 'lucide-react';

export const CompanyBrainView: React.FC = () => {
  const {
    aiAgents,
    agentTasks,
    approvalQueue,
    handleApproveItem,
    handleRejectItem,
    futureUpgrades,
    showNotification,
    setCurrentView
  } = useApp();

  const [selectedDept, setSelectedDept] = useState<string>('ALL');
  const [selectedAgent, setSelectedAgent] = useState<AIAgent | null>(aiAgents[0]);
  const [activeTab, setActiveTab] = useState<'agents' | 'approvals' | 'tasks' | 'economics'>('agents');

  const departments: { id: string; label: string; reportingTo: string; purpose: string }[] = [
    { id: 'ALL', label: 'All 15 Departments (1,000 Pooled Capacity)', reportingTo: 'Founder (Dhaval Batwal)', purpose: 'Event-driven multi-agent architecture' },
    { id: 'EXECUTIVE_BRAIN', label: '1. Executive & Strategic Governance', reportingTo: 'Founder', purpose: 'Sovereign roadmap alignment, KPI telemetry synthesis' },
    { id: 'RESEARCH_DIVISION', label: '2. AI & Deep Learning Research', reportingTo: 'Executive Brain', purpose: 'Literature tracking, Indic tokenization evaluation' },
    { id: 'COMPUTE_DIVISION', label: '3. Compute Topology & Cluster Scheduling', reportingTo: 'Executive Brain', purpose: 'Tensor parallel ring allocation, vLLM throughput' },
    { id: 'PRODUCT_DIVISION', label: '4. Product Engineering & Notebook UX', reportingTo: 'Executive Brain', purpose: 'Jupyter-style kernel, self-healing diagnostic UI' },
    { id: 'SECURITY_DIVISION', label: '5. Infrastructure Security & Cryptography', reportingTo: 'Executive Brain', purpose: 'Zero-persistence vaulting, audit trail' },
    { id: 'DATA_SOVEREIGNTY', label: '6. Data Engineering & Sovereignty (DPDP)', reportingTo: 'Regulatory', purpose: 'Geographic pod routing, privacy sanitization' },
    { id: 'GROWTH_DIVISION', label: '7. Growth, Science Community & Fellowships', reportingTo: 'Executive Brain', purpose: 'Reproducible experiment DNA forks, academic referrals' },
    { id: 'BRAND_DIVISION', label: '8. Brand Integrity & Provenance', reportingTo: 'Executive Brain', purpose: 'MII identity, founder provenance verification' },
    { id: 'MARKETING_DIVISION', label: '9. Marketing & Anti-Spam Creative Audit', reportingTo: 'Growth', purpose: 'Zero-hype advertising, 13-point creative scoring' },
    { id: 'CUSTOMER_INTELLIGENCE', label: '10. Academic Research Lab Concierge', reportingTo: 'Product', purpose: 'Scholar quota allocation & issue triage' },
    { id: 'TESTING_DIVISION', label: '11. Quality Assurance, Chaos & Testing', reportingTo: 'Product', purpose: 'Synthetic cluster chaos, failure rollback tests' },
    { id: 'MODEL_SERVING', label: '12. Model Serving, Quantization & Inference', reportingTo: 'Compute', purpose: 'AWQ/GPTQ 4-bit quantization, latency profiling' },
    { id: 'FINANCE_ECONOMICS', label: '13. Financial Economics & Margin Ledger', reportingTo: 'Executive Brain', purpose: 'Provider wholesale cost vs subsidy reconciliations' },
    { id: 'DEVELOPER_PLATFORM', label: '14. Developer Ecosystem & API Platform', reportingTo: 'Product', purpose: 'cURL, Python SDK, OpenAPI contract generation' },
    { id: 'REGULATORY_COMPLIANCE', label: '15. National Regulatory & AI Ethics', reportingTo: 'Founder', purpose: 'India AI Mission compliance & fairness oversight' }
  ];

  const filteredAgents = selectedDept === 'ALL'
    ? aiAgents
    : aiAgents.filter(a => a.department === selectedDept);

  const pendingApprovals = approvalQueue.filter(a => a.status === 'PENDING');
  const totalTokens = aiAgents.reduce((acc, a) => acc + a.totalTokensUsed, 0);
  const totalCost = aiAgents.reduce((acc, a) => acc + a.estimatedCostUSD, 0);

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-[#0e1424] via-[#090e18] to-[#120b22] p-6 rounded-2xl border border-white/10 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-orange-500/5 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="flex items-center space-x-2">
              <span className="text-xs font-mono text-orange-400 font-bold uppercase tracking-wider">
                MII AI COMPANY BRAIN
              </span>
              <span className="text-gray-600">/</span>
              <TrustBadge type="ESTIMATED" size="xs" />
              <span className="text-[10px] font-mono text-gray-400">Hierarchical Multi-Agent OS</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white font-display flex items-center space-x-2.5">
              <BrainCircuit className="w-8 h-8 text-orange-400" />
              <span>1,000-Agent Autonomous Organization</span>
            </h1>
            <p className="text-xs sm:text-sm text-gray-300 max-w-2xl leading-relaxed">
              Event-driven specialized agents driving research, compute efficiency, scientific growth, and security. Enforces strict human approval gates (L0–L5) before any irreversible action.
            </p>
          </div>

          {/* Quick Metrics */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center shrink-0">
            <div className="p-2.5 bg-black/40 rounded-xl border border-white/10">
              <div className="text-[10px] font-mono text-gray-400">Pooled Capacity</div>
              <div className="text-lg font-bold text-white font-mono">1,000</div>
              <div className="text-[9px] text-emerald-400">Event-Driven</div>
            </div>
            <div className="p-2.5 bg-black/40 rounded-xl border border-white/10">
              <div className="text-[10px] font-mono text-gray-400">Active / Sleeping</div>
              <div className="text-lg font-bold text-orange-400 font-mono">
                {aiAgents.filter(a => a.status === 'active' || a.status === 'executing').length} / {aiAgents.filter(a => a.status === 'sleeping').length}
              </div>
              <div className="text-[9px] text-gray-500">Auto-Wake</div>
            </div>
            <div className="p-2.5 bg-black/40 rounded-xl border border-white/10">
              <div className="text-[10px] font-mono text-gray-400">Pending Approvals</div>
              <div className="text-lg font-bold text-amber-400 font-mono">{pendingApprovals.length}</div>
              <div className="text-[9px] text-amber-500 font-mono">L4/L5 Gate</div>
            </div>
            <div className="p-2.5 bg-black/40 rounded-xl border border-white/10">
              <div className="text-[10px] font-mono text-gray-400">Total Inference Cost</div>
              <div className="text-lg font-bold text-sky-400 font-mono">${totalCost.toFixed(2)}</div>
              <div className="text-[9px] text-sky-500 font-mono">{(totalTokens / 1000000).toFixed(2)}M Tokens</div>
            </div>
          </div>
        </div>

        {/* Tab Controls */}
        <div className="flex items-center space-x-2 mt-6 pt-4 border-t border-white/10 overflow-x-auto text-xs font-mono">
          <button
            onClick={() => setActiveTab('agents')}
            className={`px-3.5 py-1.5 rounded-lg transition ${
              activeTab === 'agents'
                ? 'bg-orange-500 text-white font-bold'
                : 'bg-white/5 text-gray-400 hover:text-white'
            }`}
          >
            Agent Directory ({aiAgents.length} Sample Active)
          </button>
          <button
            onClick={() => setActiveTab('approvals')}
            className={`px-3.5 py-1.5 rounded-lg flex items-center space-x-1.5 transition ${
              activeTab === 'approvals'
                ? 'bg-orange-500 text-white font-bold'
                : 'bg-white/5 text-gray-400 hover:text-white'
            }`}
          >
            <span>Approval Queue</span>
            {pendingApprovals.length > 0 && (
              <span className="bg-amber-500 text-black px-1.5 py-0.2 rounded-full font-bold text-[10px]">
                {pendingApprovals.length}
              </span>
            )}
          </button>
          <button
            onClick={() => setActiveTab('tasks')}
            className={`px-3.5 py-1.5 rounded-lg transition ${
              activeTab === 'tasks'
                ? 'bg-orange-500 text-white font-bold'
                : 'bg-white/5 text-gray-400 hover:text-white'
            }`}
          >
            Live Execution Stream ({agentTasks.length})
          </button>
          <button
            onClick={() => setActiveTab('economics')}
            className={`px-3.5 py-1.5 rounded-lg transition ${
              activeTab === 'economics'
                ? 'bg-orange-500 text-white font-bold'
                : 'bg-white/5 text-gray-400 hover:text-white'
            }`}
          >
            Agent Cost Center & ROI
          </button>
        </div>

        {/* Privileged OS Callout Banner */}
        <div className="mt-4 p-3.5 bg-gradient-to-r from-orange-500/10 via-amber-500/10 to-transparent border border-orange-500/20 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs font-mono">
          <div className="flex items-center space-x-2.5">
            <ShieldAlert className="w-4 h-4 text-orange-400 shrink-0" />
            <span className="text-gray-200">
              <strong className="text-white">Privileged Owner / Admin OS:</strong> Manage the full 15-department, 1,000-agent capacity architecture, 10-step autonomous loops, emergency stop, and cryptographic audit logs.
            </span>
          </div>
          <button
            onClick={() => setCurrentView('ai_org_os')}
            className="px-3.5 py-1.5 bg-orange-600 hover:bg-orange-500 text-white rounded-lg font-bold shrink-0 transition flex items-center justify-center space-x-1 shadow-lg shadow-orange-600/20"
          >
            <span>Launch AI Org OS</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* TAB 1: AGENT DIRECTORY & GOVERNANCE */}
      {activeTab === 'agents' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left: Department Filter & Agent List */}
          <div className="lg:col-span-2 space-y-4">
            {/* Filter Bar */}
            <div className="flex items-center space-x-2 overflow-x-auto pb-2 text-xs font-mono">
              {departments.map(dept => (
                <button
                  key={dept.id}
                  onClick={() => setSelectedDept(dept.id)}
                  className={`px-2.5 py-1 rounded-md shrink-0 transition ${
                    selectedDept === dept.id
                      ? 'bg-orange-500/20 text-orange-400 border border-orange-500/40 font-bold'
                      : 'bg-white/5 text-gray-400 hover:text-gray-200 border border-white/5'
                  }`}
                >
                  {dept.label}
                </button>
              ))}
            </div>

            {/* Agent Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {filteredAgents.map(agent => {
                const isSelected = selectedAgent?.id === agent.id;
                return (
                  <div
                    key={agent.id}
                    onClick={() => setSelectedAgent(agent)}
                    className={`p-4 rounded-xl border cursor-pointer transition text-xs space-y-2.5 ${
                      isSelected
                        ? 'bg-orange-500/10 border-orange-500/50 shadow-lg'
                        : 'bg-[#0a0e17] border-white/10 hover:border-white/20'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-white font-sans text-sm truncate">{agent.name}</span>
                      <span
                        className={`text-[9px] font-mono px-1.5 py-0.5 rounded font-bold uppercase ${
                          agent.status === 'active'
                            ? 'bg-emerald-950 text-emerald-400 border border-emerald-800/40'
                            : agent.status === 'executing'
                            ? 'bg-orange-950 text-orange-400 border border-orange-800/40 animate-pulse'
                            : 'bg-gray-800 text-gray-400'
                        }`}
                      >
                        {agent.status}
                      </span>
                    </div>

                    <div className="text-gray-400 text-[11px] truncate">{agent.role}</div>

                    <div className="flex items-center justify-between text-[10px] font-mono text-gray-400 border-t border-white/5 pt-2">
                      <span className="text-sky-400">{agent.level}</span>
                      <span>{agent.model}</span>
                    </div>

                    <div className="text-[11px] text-gray-300 font-sans line-clamp-1">
                      {agent.lastAction}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Right: Selected Agent Detail & Policy Inspector */}
          {selectedAgent && (
            <div className="p-5 rounded-2xl bg-[#0a0e17] border border-white/10 space-y-4 text-xs font-mono">
              <div className="border-b border-white/10 pb-3">
                <div className="text-[10px] text-orange-400 uppercase font-bold tracking-wider">
                  {selectedAgent.department.replace('_', ' ')}
                </div>
                <h3 className="text-base font-bold text-white font-sans mt-0.5">{selectedAgent.name}</h3>
                <p className="text-gray-400 text-[11px] font-sans">{selectedAgent.role}</p>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between text-gray-400">
                  <span>Governance Level:</span>
                  <span className="text-orange-400 font-bold">{selectedAgent.level}</span>
                </div>
                <div className="flex justify-between text-gray-400">
                  <span>Inference Model:</span>
                  <span className="text-white">{selectedAgent.model}</span>
                </div>
                <div className="flex justify-between text-gray-400">
                  <span>Success Rate:</span>
                  <span className="text-emerald-400 font-bold">{selectedAgent.successRatePct}%</span>
                </div>
                <div className="flex justify-between text-gray-400">
                  <span>Tasks Processed:</span>
                  <span className="text-white">{selectedAgent.tasksCompleted}</span>
                </div>
                <div className="flex justify-between text-gray-400">
                  <span>Estimated Cost:</span>
                  <span className="text-sky-400 font-bold">${selectedAgent.estimatedCostUSD.toFixed(2)}</span>
                </div>
              </div>

              {/* Security & Permissions */}
              <div className="space-y-1.5 pt-2 border-t border-white/10">
                <div className="text-gray-400 font-bold flex items-center space-x-1">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Granted Permissions</span>
                </div>
                <div className="flex flex-wrap gap-1">
                  {selectedAgent.permissions.map((perm, i) => (
                    <span key={i} className="px-2 py-0.5 bg-emerald-950/40 text-emerald-300 rounded border border-emerald-800/30 text-[10px]">
                      {perm}
                    </span>
                  ))}
                </div>
              </div>

              {/* Strict Approval Required Triggers */}
              <div className="space-y-1.5 pt-2 border-t border-white/10">
                <div className="text-gray-400 font-bold flex items-center space-x-1">
                  <Lock className="w-3.5 h-3.5 text-amber-400" />
                  <span>Requires Explicit User Approval For:</span>
                </div>
                <div className="space-y-1">
                  {selectedAgent.requiresApprovalFor.map((item, i) => (
                    <div key={i} className="text-amber-300/90 text-[10px] flex items-center space-x-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-amber-400 shrink-0" />
                      <span>{item.replace(/_/g, ' ')}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-3 border-t border-white/10">
                <button
                  onClick={() => showNotification(`Triggered diagnostic ping on ${selectedAgent.name}. Status: Healthy.`, 'info')}
                  className="w-full py-2 bg-white/5 hover:bg-white/10 rounded-lg text-gray-300 font-medium transition"
                >
                  Run Agent Diagnostic Ping
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 2: APPROVAL QUEUE (HUMAN IN THE LOOP) */}
      {activeTab === 'approvals' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between text-xs font-mono text-gray-400">
            <span>Critical Actions Waiting for User Authorization</span>
            <span>Policy: Zero Unsolicited High-Impact Changes</span>
          </div>

          <div className="space-y-3">
            {approvalQueue.map(item => (
              <div
                key={item.id}
                className="p-5 rounded-2xl bg-[#0a0e17] border border-white/10 space-y-3 text-xs"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-white/5 pb-3">
                  <div className="flex items-center space-x-2">
                    <span className="px-2 py-0.5 rounded bg-amber-950 text-amber-400 border border-amber-800/50 font-mono text-[10px] font-bold">
                      {item.category}
                    </span>
                    <span className="text-gray-400 font-mono">By: {item.requestedByAgent}</span>
                    <span className="text-gray-600">|</span>
                    <span className="text-gray-500 font-mono">{item.timestamp}</span>
                  </div>

                  <div className="flex items-center space-x-2">
                    <span className="font-mono text-gray-400">Risk Level:</span>
                    <span
                      className={`font-mono font-bold text-[10px] px-2 py-0.5 rounded ${
                        item.risk === 'Critical'
                          ? 'bg-rose-950 text-rose-400 border border-rose-800/50'
                          : item.risk === 'High'
                          ? 'bg-amber-950 text-amber-400 border border-amber-800/50'
                          : 'bg-sky-950 text-sky-400 border border-sky-800/50'
                      }`}
                    >
                      {item.risk}
                    </span>
                  </div>
                </div>

                <div>
                  <h4 className="text-sm font-bold text-white font-sans">{item.title}</h4>
                  <p className="text-gray-300 font-sans text-xs mt-1 leading-relaxed">{item.description}</p>
                </div>

                <div className="p-3 bg-black/40 rounded-lg border border-white/5 space-y-1 font-mono text-[11px]">
                  <div className="text-gray-400">Evidence & Pre-conditions:</div>
                  <div className="text-gray-200">{item.evidence}</div>
                  {item.estimatedCost && (
                    <div className="text-sky-400 font-bold">Estimated Cost Impact: {item.estimatedCost}</div>
                  )}
                </div>

                {/* Actions */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-[11px] font-mono text-gray-500">
                    Status: <span className="font-bold text-white">{item.status}</span>
                  </span>

                  {item.status === 'PENDING' ? (
                    <div className="flex items-center space-x-2">
                      <button
                        onClick={() => handleRejectItem(item.id)}
                        className="px-3 py-1.5 rounded-lg bg-white/5 hover:bg-rose-950/40 text-gray-300 hover:text-rose-300 border border-white/10 hover:border-rose-800/50 text-xs font-medium transition flex items-center space-x-1"
                      >
                        <ThumbsDown className="w-3.5 h-3.5" />
                        <span>Reject</span>
                      </button>
                      <button
                        onClick={() => handleApproveItem(item.id)}
                        className="px-4 py-1.5 rounded-lg bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-bold shadow-lg transition flex items-center space-x-1"
                      >
                        <ThumbsUp className="w-3.5 h-3.5" />
                        <span>Approve & Authorize</span>
                      </button>
                    </div>
                  ) : (
                    <span
                      className={`text-xs font-mono font-bold px-3 py-1 rounded ${
                        item.status === 'APPROVED'
                          ? 'bg-emerald-950 text-emerald-400 border border-emerald-800/50'
                          : 'bg-rose-950 text-rose-400 border border-rose-800/50'
                      }`}
                    >
                      {item.status}
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 3: LIVE EXECUTION STREAM */}
      {activeTab === 'tasks' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between text-xs font-mono text-gray-400">
            <span>Continuous Asynchronous Agent Execution Log</span>
            <TrustBadge type="EXECUTED" size="xs" />
          </div>

          <div className="space-y-3">
            {agentTasks.map(task => (
              <div
                key={task.id}
                className="p-4 rounded-xl bg-[#0a0e17] border border-white/10 space-y-2 text-xs font-mono"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <span className="text-orange-400 font-bold">{task.agentName}</span>
                    <span className="text-gray-600">/</span>
                    <span className="text-gray-400 text-[11px]">{task.department}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <TrustBadge type={task.trustTag} size="xs" />
                    <span className="text-gray-500">{task.timestamp}</span>
                  </div>
                </div>

                <div className="text-white font-sans font-medium text-xs">{task.title}</div>
                <div className="text-gray-400 font-sans text-xs">{task.description}</div>

                {task.outputSummary && (
                  <div className="p-2.5 bg-black/40 rounded-lg border border-white/5 text-[11px] text-emerald-400">
                    {task.outputSummary}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 4: AGENT ECONOMICS & ROI */}
      {activeTab === 'economics' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="p-6 rounded-2xl bg-[#0a0e17] border border-white/10 space-y-4">
            <h3 className="text-sm font-bold text-white font-mono flex items-center space-x-2">
              <DollarSign className="w-4 h-4 text-emerald-400" />
              <span>Inference Cost Optimization Guardrails</span>
            </h3>
            <p className="text-xs text-gray-400 leading-relaxed">
              To keep 1,000 agents economically sustainable, the system applies hierarchical model routing: small, cheap models for telemetry and classification, and stronger models only for synthesis and code generation.
            </p>

            <div className="space-y-3 text-xs font-mono">
              <div className="p-3 bg-black/40 rounded-lg border border-white/5 flex justify-between items-center">
                <div>
                  <div className="text-white font-bold">gemini-1.5-flash</div>
                  <div className="text-gray-400 text-[10px]">Simple queries, telemetry, parsing</div>
                </div>
                <div className="text-right">
                  <div className="text-emerald-400 font-bold">78% of calls</div>
                  <div className="text-gray-500 text-[10px]">$0.075 / 1M tokens</div>
                </div>
              </div>

              <div className="p-3 bg-black/40 rounded-lg border border-white/5 flex justify-between items-center">
                <div>
                  <div className="text-white font-bold">gemini-1.5-pro</div>
                  <div className="text-gray-400 text-[10px]">Deep research, security audits, executive strategy</div>
                </div>
                <div className="text-right">
                  <div className="text-orange-400 font-bold">22% of calls</div>
                  <div className="text-gray-500 text-[10px]">$3.50 / 1M tokens</div>
                </div>
              </div>
            </div>
          </div>

          <div className="p-6 rounded-2xl bg-[#0a0e17] border border-white/10 space-y-4">
            <h3 className="text-sm font-bold text-white font-mono flex items-center space-x-2">
              <TrendingUp className="w-4 h-4 text-sky-400" />
              <span>Future Upgrade Proposals (MII Future Lab)</span>
            </h3>
            <div className="space-y-3">
              {futureUpgrades.map(upg => (
                <div key={upg.id} className="p-3 bg-black/40 rounded-lg border border-white/5 space-y-1.5 text-xs font-mono">
                  <div className="flex justify-between items-center">
                    <span className="text-white font-bold font-sans">{upg.title}</span>
                    <span className="text-emerald-400 text-[10px] uppercase font-bold">{upg.status}</span>
                  </div>
                  <div className="text-gray-400 text-[11px] font-sans">{upg.proposal}</div>
                  <div className="flex justify-between text-[10px] text-gray-500 pt-1">
                    <span>Impact: {upg.expectedImpact}</span>
                    <span className="text-sky-400 font-bold">Est. Cost: ${upg.estimatedComputeCostUSD}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
