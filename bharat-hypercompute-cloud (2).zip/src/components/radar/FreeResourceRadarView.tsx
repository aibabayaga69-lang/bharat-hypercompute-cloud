import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { TrustBadge } from '../common/TrustBadge';
import { FreeResourceRadarItem } from '../../types/aiCompany';
import {
  Radar,
  Database,
  Box,
  FileText,
  Gift,
  ExternalLink,
  ShieldCheck,
  Search,
  Filter,
  CheckCircle2,
  Sparkles,
  Award
} from 'lucide-react';

export const FreeResourceRadarView: React.FC = () => {
  const { freeResources, showNotification } = useApp();
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const categories = ['ALL', 'Model', 'Dataset', 'Research Paper', 'Cloud Credit'];

  const filteredResources = freeResources.filter(res => {
    const matchesCat = selectedCategory === 'ALL' || res.category === selectedCategory;
    const matchesSearch =
      res.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      res.source.toLowerCase().includes(searchQuery.toLowerCase()) ||
      res.summary.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Banner */}
      <div className="bg-gradient-to-r from-[#0d1624] via-[#09111c] to-[#0a1420] p-6 rounded-2xl border border-white/10 shadow-2xl relative overflow-hidden">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="flex items-center space-x-2">
              <span className="text-xs font-mono text-orange-400 font-bold uppercase tracking-wider">
                MII RADAR INTELLIGENCE
              </span>
              <span className="text-gray-600">/</span>
              <TrustBadge type="APPROVED" size="xs" />
              <span className="text-[10px] font-mono text-gray-400">Autonomous Open Resource Radar</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white font-display flex items-center space-x-2.5">
              <Radar className="w-8 h-8 text-orange-400" />
              <span>Free AI Resource & Subsidy Radar</span>
            </h1>
            <p className="text-xs sm:text-sm text-gray-300 max-w-2xl leading-relaxed">
              Continuously discovers publicly available open-source foundation models, free verified training datasets, government compute fellowship grants, and academic research credits.
            </p>
          </div>

          <div className="flex items-center space-x-3 text-xs font-mono shrink-0">
            <div className="p-3 bg-black/40 rounded-xl border border-white/10 text-center">
              <div className="text-gray-400 text-[10px]">Verified Open Assets</div>
              <div className="text-xl font-bold text-white">{freeResources.length}</div>
              <div className="text-[9px] text-emerald-400">100% Permissive / Grants</div>
            </div>
          </div>
        </div>

        {/* Filter & Search */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 mt-6 pt-4 border-t border-white/10">
          <div className="flex items-center space-x-2 overflow-x-auto w-full sm:w-auto text-xs font-mono">
            {categories.map(cat => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 rounded-lg shrink-0 transition ${
                  selectedCategory === cat
                    ? 'bg-orange-500 text-white font-bold'
                    : 'bg-white/5 text-gray-400 hover:text-white'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          <div className="relative w-full sm:w-64">
            <Search className="w-3.5 h-3.5 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search radar..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full bg-black/40 border border-white/10 rounded-lg pl-9 pr-3 py-1.5 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-orange-500 font-mono"
            />
          </div>
        </div>
      </div>

      {/* Grid of Verified Resources */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredResources.map(res => (
          <div
            key={res.id}
            className="p-5 rounded-2xl bg-[#0a0e17] border border-white/10 space-y-3 text-xs font-mono hover:border-white/20 transition"
          >
            <div className="flex items-center justify-between">
              <span className="px-2 py-0.5 rounded bg-orange-950/60 text-orange-400 border border-orange-800/40 text-[10px] font-bold uppercase">
                {res.category}
              </span>
              <div className="flex items-center space-x-2">
                <span className="text-[10px] text-emerald-400 flex items-center space-x-1">
                  <ShieldCheck className="w-3 h-3" />
                  <span>{res.verificationStatus}</span>
                </span>
                <span className="text-gray-500 text-[10px]">{res.dateDiscovered}</span>
              </div>
            </div>

            <div>
              <h3 className="text-sm font-bold text-white font-sans">{res.title}</h3>
              <p className="text-gray-400 font-sans text-xs mt-1 leading-relaxed">{res.summary}</p>
            </div>

            <div className="p-2.5 bg-black/40 rounded-lg border border-white/5 space-y-1 text-[11px]">
              <div className="flex justify-between text-gray-400">
                <span>Source / Origin:</span>
                <span className="text-gray-200 font-sans">{res.source}</span>
              </div>
              <div className="flex justify-between text-gray-400">
                <span>License Terms:</span>
                <span className="text-emerald-400 font-sans">{res.license}</span>
              </div>
              <div className="flex justify-between text-gray-400">
                <span>Verification Confidence:</span>
                <span className="text-sky-400 font-bold">{res.confidence}%</span>
              </div>
            </div>

            <div className="pt-2 flex items-center justify-between">
              <a
                href={res.url}
                target="_blank"
                rel="noreferrer"
                className="text-orange-400 hover:text-orange-300 transition flex items-center space-x-1 text-xs"
              >
                <span>Access Resource Direct</span>
                <ExternalLink className="w-3 h-3" />
              </a>

              <button
                onClick={() => showNotification(`Importing ${res.title} into your current Project Workspace.`, 'success')}
                className="px-3 py-1.5 bg-white/5 hover:bg-white/10 text-white rounded-lg transition"
              >
                Import to Workspace
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
