import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { TrustBadge } from '../common/TrustBadge';
import {
  Compass,
  FileText,
  Sparkles,
  ExternalLink,
  Cpu,
  Layers,
  ArrowRight,
  TrendingUp,
  Bookmark,
  CheckCircle2
} from 'lucide-react';

export const ResearchRadarView: React.FC = () => {
  const { researchRadar, showNotification } = useApp();
  const [activeCategory, setActiveCategory] = useState<string>('ALL');

  const categories = ['ALL', 'Sovereign Indic AI', 'Checkpoint Systems', 'Foundation Models', 'Compute Efficiency'];

  const filteredRadar = activeCategory === 'ALL'
    ? researchRadar
    : researchRadar.filter(r => r.category === activeCategory);

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-[#0d1424] via-[#080d18] to-[#11192d] p-6 rounded-2xl border border-white/10 shadow-2xl relative overflow-hidden">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="flex items-center space-x-2">
              <span className="text-xs font-mono text-orange-400 font-bold uppercase tracking-wider">
                MII RESEARCH RADAR
              </span>
              <span className="text-gray-600">/</span>
              <TrustBadge type="APPROVED" size="xs" />
              <span className="text-[10px] font-mono text-gray-400">Scientific Paper & Architecture Radar</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white font-display flex items-center space-x-2.5">
              <Compass className="w-8 h-8 text-orange-400" />
              <span>Global & Sovereign AI Research Radar</span>
            </h1>
            <p className="text-xs sm:text-sm text-gray-300 max-w-2xl leading-relaxed">
              Monitors cutting-edge ArXiv preprints, MLSys conference papers, tokenizer breakthroughs, and GPU kernel optimizations directly applicable to sovereign foundation models.
            </p>
          </div>

          <div className="p-3 bg-black/40 rounded-xl border border-white/10 text-center shrink-0 font-mono text-xs">
            <div className="text-gray-400 text-[10px]">Indexed Innovations</div>
            <div className="text-xl font-bold text-orange-400">{researchRadar.length}</div>
            <div className="text-[9px] text-emerald-400">Integrated in Compute Brain</div>
          </div>
        </div>

        {/* Categories Bar */}
        <div className="flex items-center space-x-2 overflow-x-auto mt-6 pt-4 border-t border-white/10 text-xs font-mono">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-3 py-1.5 rounded-lg shrink-0 transition ${
                activeCategory === cat
                  ? 'bg-orange-500 text-white font-bold'
                  : 'bg-white/5 text-gray-400 hover:text-white'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Radar Cards */}
      <div className="space-y-4">
        {filteredRadar.map(item => (
          <div
            key={item.id}
            className="p-5 rounded-2xl bg-[#0a0e17] border border-white/10 space-y-3 text-xs font-mono hover:border-white/20 transition"
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-white/5 pb-3">
              <div className="flex items-center space-x-2">
                <span className="px-2 py-0.5 rounded bg-orange-950/60 text-orange-400 border border-orange-800/40 text-[10px] font-bold uppercase">
                  {item.category}
                </span>
                <span className="text-gray-400">{item.arxivOrSource}</span>
                <span className="text-gray-600">|</span>
                <span className="text-gray-500">{item.date}</span>
              </div>
              <TrustBadge type={item.trustTag} size="xs" />
            </div>

            <div>
              <h3 className="text-base font-bold text-white font-sans">{item.title}</h3>
              <p className="text-gray-400 font-sans text-xs mt-1">Authors: {item.authors}</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2">
              <div className="p-3 bg-black/40 rounded-xl border border-white/5 space-y-1">
                <div className="text-gray-400 font-bold">Key Empirical Finding:</div>
                <div className="text-gray-200 font-sans text-xs leading-relaxed">{item.keyFinding}</div>
              </div>

              <div className="p-3 bg-orange-950/20 rounded-xl border border-orange-800/30 space-y-1">
                <div className="text-orange-400 font-bold">Impact on Bharat HyperCompute Cloud:</div>
                <div className="text-gray-200 font-sans text-xs leading-relaxed">{item.impactOnBharatCloud}</div>
              </div>
            </div>

            <div className="pt-2 flex items-center justify-between">
              <button
                onClick={() => showNotification(`Loaded paper manifest into Research Copilot context.`, 'success')}
                className="px-3.5 py-1.5 bg-orange-500/10 hover:bg-orange-500/20 text-orange-400 border border-orange-500/30 rounded-lg transition"
              >
                Discuss with Research Copilot
              </button>

              <button
                onClick={() => showNotification(`Added "${item.title}" to sovereign Research Memory.`, 'info')}
                className="px-3 py-1.5 bg-white/5 hover:bg-white/10 text-gray-300 rounded-lg transition flex items-center space-x-1"
              >
                <Bookmark className="w-3.5 h-3.5" />
                <span>Save to Research Memory</span>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
