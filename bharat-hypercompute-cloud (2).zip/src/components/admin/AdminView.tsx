import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { TrustBadge } from '../common/TrustBadge';
import {
  ShieldAlert,
  Users,
  Sliders,
  Activity,
  FileText,
  CheckCircle2,
  AlertTriangle,
  Building2,
  Server,
  DollarSign,
  TrendingUp
} from 'lucide-react';

export const AdminView: React.FC = () => {
  const { org, user, auditLogs, showNotification } = useApp();

  const [freeDailyLimit, setFreeDailyLimit] = useState(2.0);
  const [maxJobDurationHours, setMaxJobDurationHours] = useState(4.0);

  const handleSaveConfig = () => {
    showNotification('System quotas and free-tier parameters updated in administrative store.', 'success');
  };

  const members = [
    { name: 'Dhaval Batwal', email: 'founder@bharatcloud.in', role: 'Founder (MII)', status: 'Active' },
    { name: 'Institutional AI Researcher (Seat 01)', email: 'researcher-01@workspace.local', role: 'Researcher', status: 'Active' },
    { name: 'Deep Learning Systems Lead (Seat 02)', email: 'systems-02@workspace.local', role: 'Engineer', status: 'Active' },
    { name: 'National Lab Workspace Seat (Seat 03)', email: 'lab-seat-03@workspace.local', role: 'Researcher', status: 'Active' },
    { name: 'Sovereign Compliance Auditor (Seat 04)', email: 'auditor-04@workspace.local', role: 'Auditor', status: 'Active' }
  ];

  const economicsLedger = [
    {
      resource: 'BHARAT H100 SXM5 (80GB)',
      providerCost: '₹145 / hr',
      customerPrice: '₹195 / hr',
      discount: '₹20 / hr (Tier 1)',
      subsidy: '₹40 / hr (MeitY AI Grant)',
      grossMargin: '25.6%',
      capacityEconomics: '92% Reserved / 8% Spot'
    },
    {
      resource: 'BHARAT A100 TensorCore (80GB)',
      providerCost: '₹88 / hr',
      customerPrice: '₹120 / hr',
      discount: '₹15 / hr (Academic)',
      subsidy: '₹25 / hr (National R&D)',
      grossMargin: '26.7%',
      capacityEconomics: '88% Reserved / 12% Spot'
    },
    {
      resource: 'BHARAT TPU v4 Pod Slice (16)',
      providerCost: '₹110 / hr',
      customerPrice: '₹155 / hr',
      discount: '₹15 / hr (Volume)',
      subsidy: '₹30 / hr (Sovereign Grant)',
      grossMargin: '29.0%',
      capacityEconomics: '95% Reserved / 5% Spot'
    },
    {
      resource: 'On-Premises Connected Node Adapter',
      providerCost: '₹12 / hr (Network)',
      customerPrice: '₹35 / hr',
      discount: '₹5 / hr (Open Source)',
      subsidy: '₹10 / hr (Hardware Offset)',
      grossMargin: '65.7%',
      capacityEconomics: '100% Customer Hosted'
    }
  ];

  const systemHealth = [
    { service: 'Inference API Gateway', status: 'Healthy', latency: '12ms', uptime: '99.98%' },
    { service: 'Compute Brain Intent Parser', status: 'Healthy', latency: '45ms', uptime: '99.99%' },
    { service: 'Self-Healing Checkpoint Store', status: 'Healthy', latency: '8ms', uptime: '100%' },
    { service: 'Simulated Accelerator Pod Pool', status: 'Healthy', latency: '18ms', uptime: '99.95%' }
  ];

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center space-x-2">
            <span className="text-xs font-mono text-orange-400 font-bold uppercase tracking-wider">
              GOVERNANCE & AUDIT
            </span>
            <span className="text-gray-600">/</span>
            <TrustBadge type="APPROVED" size="xs" />
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white font-display flex items-center space-x-2">
            <ShieldAlert className="w-7 h-7 text-orange-400" />
            <span>Admin Center & Quota Controls</span>
          </h1>
          <p className="text-xs sm:text-sm text-gray-400">
            Configure free-tier compute ceilings, inspect institutional audit logs, and monitor infrastructure health.
          </p>
        </div>
      </div>

      {/* Grid: Quota Settings & System Health */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Free Tier Config Card */}
        <div className="p-6 rounded-2xl bg-[#0a0e17] border border-white/10 space-y-4 shadow-xl">
          <div className="flex items-center space-x-2 text-xs font-mono text-white font-bold border-b border-white/10 pb-3">
            <Sliders className="w-4 h-4 text-orange-400" />
            <span>Free-Tier & Quota Policy Settings</span>
          </div>

          <div className="space-y-4 text-xs font-mono">
            <div className="space-y-1">
              <label className="text-gray-400">Default Free Daily Compute Hours</label>
              <div className="flex items-center space-x-3">
                <input
                  type="number"
                  step="0.5"
                  min="1"
                  max="12"
                  value={freeDailyLimit}
                  onChange={e => setFreeDailyLimit(parseFloat(e.target.value) || 2)}
                  className="bg-black/50 border border-white/10 rounded-lg p-2 text-white w-28 focus:outline-none focus:border-orange-500"
                />
                <span className="text-gray-500">hours / user / day</span>
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-gray-400">Maximum Continuous Job Duration</label>
              <div className="flex items-center space-x-3">
                <input
                  type="number"
                  step="1"
                  min="1"
                  max="24"
                  value={maxJobDurationHours}
                  onChange={e => setMaxJobDurationHours(parseFloat(e.target.value) || 4)}
                  className="bg-black/50 border border-white/10 rounded-lg p-2 text-white w-28 focus:outline-none focus:border-orange-500"
                />
                <span className="text-gray-500">hours before auto-checkpoint pause</span>
              </div>
            </div>

            <button
              onClick={handleSaveConfig}
              className="px-4 py-2 bg-orange-500 hover:bg-orange-600 text-white rounded-lg font-bold text-xs transition"
            >
              Save Quota Policy
            </button>
          </div>
        </div>

        {/* System Health Card */}
        <div className="p-6 rounded-2xl bg-[#0a0e17] border border-white/10 space-y-4 shadow-xl">
          <div className="flex items-center space-x-2 text-xs font-mono text-white font-bold border-b border-white/10 pb-3">
            <Activity className="w-4 h-4 text-emerald-400" />
            <span>Core Infrastructure Telemetry</span>
          </div>

          <div className="space-y-2 font-mono text-xs">
            {systemHealth.map((s, idx) => (
              <div key={idx} className="p-2.5 bg-black/40 rounded-lg border border-white/5 flex items-center justify-between">
                <span className="text-gray-300 font-medium">{s.service}</span>
                <div className="flex items-center space-x-3 text-[11px]">
                  <span className="text-gray-500">{s.latency}</span>
                  <span className="text-emerald-400 font-bold">{s.status}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Organization Members Table */}
      <div className="rounded-xl bg-[#0a0e17] border border-white/10 overflow-hidden shadow-xl">
        <div className="p-4 bg-black/40 border-b border-white/10 flex items-center justify-between text-xs font-mono">
          <div className="flex items-center space-x-2">
            <Users className="w-4 h-4 text-orange-400" />
            <span className="text-gray-300 font-bold uppercase">Organization Roster ({org.name})</span>
          </div>
          <span className="text-gray-500">Tier: {org.tier}</span>
        </div>

        <div className="divide-y divide-white/5 font-mono text-xs text-gray-300">
          {members.map((m, idx) => (
            <div key={idx} className="p-4 flex items-center justify-between hover:bg-white/5 transition">
              <div className="space-y-0.5">
                <div className="text-white font-bold">{m.name}</div>
                <div className="text-[11px] text-gray-500">{m.email}</div>
              </div>
              <div className="flex items-center space-x-3">
                <span className="px-2 py-0.5 rounded bg-white/5 text-gray-300 border border-white/10 text-[10px]">
                  {m.role}
                </span>
                <span className="text-emerald-400 text-[10px] font-bold">
                  {m.status}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Capacity Economics & Pricing Disaggregation Ledger */}
      <div className="rounded-xl bg-[#0a0e17] border border-white/10 overflow-hidden shadow-xl">
        <div className="p-4 bg-black/40 border-b border-white/10 flex items-center justify-between text-xs font-mono">
          <div className="flex items-center space-x-2">
            <DollarSign className="w-4 h-4 text-emerald-400" />
            <span className="text-gray-300 font-bold uppercase">Compute Capacity Economics & Margin Ledger</span>
          </div>
          <span className="text-gray-400">Institutional Billing Unit Math</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left font-mono text-xs text-gray-300">
            <thead className="bg-black/30 text-gray-400 text-[10px] uppercase border-b border-white/5">
              <tr>
                <th className="p-3">Compute Resource</th>
                <th className="p-3">Provider Cost</th>
                <th className="p-3">Customer Price</th>
                <th className="p-3">Discount</th>
                <th className="p-3">Gov/Grant Subsidy</th>
                <th className="p-3">Gross Margin</th>
                <th className="p-3">Capacity Economics</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {economicsLedger.map((e, idx) => (
                <tr key={idx} className="hover:bg-white/5 transition">
                  <td className="p-3 text-white font-bold">{e.resource}</td>
                  <td className="p-3 text-gray-400">{e.providerCost}</td>
                  <td className="p-3 text-amber-300 font-semibold">{e.customerPrice}</td>
                  <td className="p-3 text-sky-400">{e.discount}</td>
                  <td className="p-3 text-emerald-400">{e.subsidy}</td>
                  <td className="p-3 text-emerald-300 font-bold">{e.grossMargin}</td>
                  <td className="p-3 text-gray-400">{e.capacityEconomics}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Cryptographic Audit Logs */}
      <div className="rounded-xl bg-[#0a0e17] border border-white/10 overflow-hidden shadow-xl">
        <div className="p-4 bg-black/40 border-b border-white/10 flex items-center justify-between text-xs font-mono">
          <div className="flex items-center space-x-2">
            <FileText className="w-4 h-4 text-sky-400" />
            <span className="text-gray-300 font-bold uppercase">Cryptographic Audit Trail</span>
          </div>
          <span className="text-gray-500">{auditLogs.length} events recorded</span>
        </div>

        <div className="divide-y divide-white/5 font-mono text-xs text-gray-300">
          {auditLogs.map(log => (
            <div key={log.id} className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-2 hover:bg-white/5 transition">
              <div>
                <div className="text-white font-bold">{log.action}</div>
                <div className="text-[11px] text-gray-400">{log.target}</div>
              </div>
              <div className="text-right text-[11px] text-gray-500 shrink-0">
                <div>Actor: <strong className="text-gray-300">{log.actor}</strong></div>
                <div>{log.timestamp} • IP: {log.ip}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
