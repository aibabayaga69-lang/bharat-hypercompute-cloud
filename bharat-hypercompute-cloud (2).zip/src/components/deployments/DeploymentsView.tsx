import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { TrustBadge } from '../common/TrustBadge';
import {
  Rocket,
  Key,
  Copy,
  CheckCircle2,
  Terminal,
  Activity,
  Zap,
  Play,
  Clock,
  Radio,
  ExternalLink,
  Code2
} from 'lucide-react';

export const DeploymentsView: React.FC = () => {
  const { deployments, showNotification } = useApp();
  const dep = deployments[0];

  const [activeCodeLang, setActiveCodeLang] = useState<'curl' | 'python' | 'javascript'>('curl');
  const [playgroundPrompt, setPlaygroundPrompt] = useState('भारत के प्रमुख वैज्ञानिक संस्थानों और उनके योगदान के बारे में संक्षिप्त में बताएं।');
  const [playgroundResponse, setPlaygroundResponse] = useState<string | null>(
    'भारत के प्रमुख वैज्ञानिक संस्थानों में भारतीय अंतरिक्ष अनुसंधान संगठन (ISRO), भाभा परमाणु अनुसंधान केंद्र (BARC), रक्षा अनुसंधान एवं विकास संगठन (DRDO), और वैज्ञानिक तथा औद्योगिक अनुसंधान परिषद (CSIR) शामिल हैं। इन संस्थानों ने उपग्रह प्रक्षेपण, स्वदेशी रक्षा तकनीक और स्वास्थ्य विज्ञान में आत्मनिर्भरता हासिल की है।'
  );
  const [isInferring, setIsInferring] = useState(false);
  const [measuredLatency, setMeasuredLatency] = useState(24);

  const handleRunInference = () => {
    if (!playgroundPrompt.trim()) return;
    setIsInferring(true);
    setPlaygroundResponse(null);

    setTimeout(() => {
      setIsInferring(false);
      const latency = Math.floor(Math.random() * 8) + 21;
      setMeasuredLatency(latency);

      if (playgroundPrompt.includes('English') || playgroundPrompt.toLowerCase().includes('what is')) {
        setPlaygroundResponse(`Bharat-IndicLLM-7B Response: The model has processed your query using bilingual Indic-English attention heads with calibrated factual precision and zero hallucination.`);
      } else {
        setPlaygroundResponse(`भारत-इंडिकएलएलएम (Bharat-IndicLLM-7B): आपके द्वारा पूछे गए प्रश्न "${playgroundPrompt.slice(0, 40)}..." का उत्तर 12 भारतीय भाषाओं में अनुवादित एवं सत्यापित ज्ञान-आधार से प्रस्तुत किया गया है।`);
      }
      showNotification(`API responded in ${latency}ms (vLLM PagedAttention engine).`, 'success');
    }, 450);
  };

  const copyEndpoint = () => {
    navigator.clipboard.writeText(dep.endpoint);
    showNotification('Inference endpoint copied to clipboard!', 'success');
  };

  const copySnippet = (code: string) => {
    navigator.clipboard.writeText(code);
    showNotification('Code snippet copied to clipboard!', 'success');
  };

  const curlSnippet = `curl -X POST ${dep.endpoint} \\
  -H "Authorization: Bearer ${dep.apiKeyMasked}" \\
  -H "Content-Type: application/json" \\
  -d '{
    "prompt": "${playgroundPrompt}",
    "temperature": 0.3,
    "max_tokens": 256
  }'`;

  const pythonSnippet = `import requests

url = "${dep.endpoint}"
headers = {
    "Authorization": "Bearer ${dep.apiKeyMasked}",
    "Content-Type": "application/json"
}
payload = {
    "prompt": "${playgroundPrompt}",
    "temperature": 0.3,
    "max_tokens": 256
}

response = requests.post(url, json=payload, headers=headers)
print(response.json()["choices"][0]["text"])`;

  const jsSnippet = `const res = await fetch("${dep.endpoint}", {
  method: "POST",
  headers: {
    "Authorization": "Bearer ${dep.apiKeyMasked}",
    "Content-Type": "application/json"
  },
  body: JSON.stringify({
    prompt: "${playgroundPrompt}",
    temperature: 0.3,
    max_tokens: 256
  })
});
const data = await res.json();
console.log(data);`;

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center space-x-2">
            <span className="text-xs font-mono text-orange-400 font-bold uppercase tracking-wider">
              MODEL → API INFERENCE
            </span>
            <span className="text-gray-600">/</span>
            <span className="text-xs font-mono text-emerald-400 flex items-center space-x-1">
              <Radio className="w-2.5 h-2.5 animate-pulse" />
              <span>ENDPOINT ACTIVE</span>
            </span>
            <TrustBadge type="REQUIRES_API" size="xs" />
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white font-display flex items-center space-x-2">
            <Rocket className="w-7 h-7 text-sky-400" />
            <span>Model Serving & API Playground</span>
          </h1>
          <p className="text-xs sm:text-sm text-gray-400">
            Zero-friction serverless inference with masked API keys, vLLM telemetry, and interactive request playground.
          </p>
        </div>
      </div>

      {/* Active Endpoint Overview Card */}
      <div className="p-6 rounded-2xl bg-[#0a0e17] border border-white/10 space-y-4 shadow-xl">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-white/10 pb-4">
          <div className="space-y-1">
            <div className="flex items-center space-x-2">
              <h2 className="text-xl font-bold text-white font-display">
                {dep.modelName}
              </h2>
              <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800/40 text-xs font-mono font-bold">
                {dep.modelVersion}
              </span>
              <span className="text-xs font-mono text-gray-400">
                {dep.compute}
              </span>
            </div>
            <div className="flex items-center space-x-2 font-mono text-xs text-gray-400 pt-1">
              <span className="text-white bg-black/60 px-2 py-1 rounded border border-white/10 truncate max-w-lg">
                {dep.endpoint}
              </span>
              <button
                onClick={copyEndpoint}
                className="p-1 rounded bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white transition"
                title="Copy endpoint"
              >
                <Copy className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <div className="p-2.5 bg-black/50 rounded-lg border border-white/10 font-mono text-xs space-y-0.5">
              <div className="text-gray-500 text-[10px] flex items-center space-x-1">
                <Key className="w-3 h-3 text-amber-400" />
                <span>Masked Secret Key</span>
              </div>
              <div className="text-gray-300 font-bold">{dep.apiKeyMasked}</div>
            </div>
          </div>
        </div>

        {/* Real-time Telemetry Metrics */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs font-mono">
          <div className="p-3 bg-black/40 rounded-lg border border-white/5">
            <div className="text-gray-500 text-[10px]">Requests (24h)</div>
            <div className="text-lg font-bold text-white mt-0.5">
              {dep.requests24h.toLocaleString()}
            </div>
            <div className="text-[10px] text-emerald-400 font-sans mt-0.5">Throughput: 142 req/s</div>
          </div>

          <div className="p-3 bg-black/40 rounded-lg border border-white/5">
            <div className="text-gray-500 text-[10px]">p95 Token Latency</div>
            <div className="text-lg font-bold text-emerald-400 mt-0.5">
              {measuredLatency} ms
            </div>
            <div className="text-[10px] text-gray-400 font-sans mt-0.5">FlashAttention-2 Kernel</div>
          </div>

          <div className="p-3 bg-black/40 rounded-lg border border-white/5">
            <div className="text-gray-500 text-[10px]">Inference Error Rate</div>
            <div className="text-lg font-bold text-sky-400 mt-0.5">
              {dep.errorRatePct}%
            </div>
            <div className="text-[10px] text-emerald-400 font-sans mt-0.5">Zero 5xx in last 6 hrs</div>
          </div>

          <div className="p-3 bg-black/40 rounded-lg border border-white/5">
            <div className="text-gray-500 text-[10px]">Cluster Health</div>
            <div className="text-lg font-bold text-emerald-400 mt-0.5">
              100% Online
            </div>
            <div className="text-[10px] text-gray-400 font-sans mt-0.5">Auto-Scaling: 1 - 4 Nodes</div>
          </div>
        </div>
      </div>

      {/* Main Grid: Interactive Playground (Left) & SDK Snippets (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: API Playground (7 cols) */}
        <div className="lg:col-span-7 p-6 rounded-2xl bg-[#0a0e17] border border-white/10 space-y-4 shadow-xl">
          <div className="flex items-center justify-between border-b border-white/10 pb-3">
            <div className="flex items-center space-x-2 text-xs font-mono text-orange-400 font-bold">
              <Zap className="w-4 h-4" />
              <span>Interactive API Playground</span>
            </div>
            <span className="text-[11px] font-mono text-gray-500">Live JSON Payload</span>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-mono text-gray-400">Input Prompt (Multilingual / Indic)</label>
            <textarea
              value={playgroundPrompt}
              onChange={e => setPlaygroundPrompt(e.target.value)}
              rows={4}
              className="w-full bg-black/60 border border-white/10 rounded-xl p-3 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-orange-500/50 leading-relaxed font-sans"
            />
          </div>

          <div className="flex justify-between items-center">
            <span className="text-[11px] font-mono text-gray-500">
              Params: temp=0.3 • max_tokens=256 • seed=42
            </span>

            <button
              onClick={handleRunInference}
              disabled={isInferring}
              className="px-5 py-2 bg-orange-500 hover:bg-orange-600 text-white font-bold text-xs rounded-xl shadow transition flex items-center space-x-1.5"
            >
              {isInferring ? (
                <>
                  <div className="w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  <span>Serving Inference...</span>
                </>
              ) : (
                <>
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>Send API Request</span>
                </>
              )}
            </button>
          </div>

          {/* Model Response Box */}
          <div className="border-t border-white/5 pt-3 space-y-1.5 font-mono text-xs">
            <div className="flex justify-between text-gray-500 text-[10px] uppercase">
              <span>Model Inference Response</span>
              <span className="text-emerald-400 font-bold">HTTP 200 OK ({measuredLatency}ms)</span>
            </div>

            <div className="p-4 bg-black/70 rounded-xl border border-white/5 text-gray-200 leading-relaxed font-sans text-xs min-h-[100px]">
              {playgroundResponse || (
                <span className="text-gray-600 font-mono text-xs">Awaiting inference...</span>
              )}
            </div>
          </div>
        </div>

        {/* Right Column: Code Snippets (5 cols) */}
        <div className="lg:col-span-5 p-6 rounded-2xl bg-[#0a0e17] border border-white/10 space-y-4 shadow-xl">
          <div className="flex items-center justify-between border-b border-white/10 pb-3">
            <div className="flex items-center space-x-2 text-xs font-mono text-gray-300 font-bold">
              <Code2 className="w-4 h-4 text-sky-400" />
              <span>Production Code Integration</span>
            </div>

            <div className="flex items-center space-x-1 text-xs font-mono">
              {(['curl', 'python', 'javascript'] as const).map(lang => (
                <button
                  key={lang}
                  onClick={() => setActiveCodeLang(lang)}
                  className={`px-2 py-0.5 rounded text-[10px] uppercase transition ${
                    activeCodeLang === lang
                      ? 'bg-sky-500/20 text-sky-300 font-bold border border-sky-500/30'
                      : 'text-gray-400 hover:text-white'
                  }`}
                >
                  {lang}
                </button>
              ))}
            </div>
          </div>

          <div className="relative">
            <pre className="p-4 bg-black/80 rounded-xl border border-white/5 font-mono text-[11px] text-gray-300 overflow-x-auto leading-relaxed max-h-96">
              {activeCodeLang === 'curl' && curlSnippet}
              {activeCodeLang === 'python' && pythonSnippet}
              {activeCodeLang === 'javascript' && jsSnippet}
            </pre>

            <button
              onClick={() => {
                const code =
                  activeCodeLang === 'curl'
                    ? curlSnippet
                    : activeCodeLang === 'python'
                    ? pythonSnippet
                    : jsSnippet;
                copySnippet(code);
              }}
              className="absolute top-2 right-2 p-1.5 rounded bg-white/10 hover:bg-white/20 text-gray-300 hover:text-white transition"
              title="Copy snippet"
            >
              <Copy className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
