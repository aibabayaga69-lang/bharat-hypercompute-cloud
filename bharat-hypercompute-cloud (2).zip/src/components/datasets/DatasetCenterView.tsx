import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { TrustBadge } from '../common/TrustBadge';
import {
  Database,
  Plus,
  GitBranch,
  ShieldCheck,
  AlertCircle,
  FileText,
  Clock,
  ArrowUpRight,
  Sparkles,
  Search,
  CheckCircle2
} from 'lucide-react';

export const DatasetCenterView: React.FC = () => {
  const { datasets, addDatasetVersion, setCurrentView, showNotification } = useApp();
  const [selectedDataset] = useState(datasets[0]);
  const [showNewVersionModal, setShowNewVersionModal] = useState(false);
  const [newVersionTag, setNewVersionTag] = useState('v3.1.0');
  const [newVersionSummary, setNewVersionSummary] = useState('');

  const handleCreateVersion = () => {
    if (!newVersionSummary.trim()) {
      showNotification('Please enter a change summary for this dataset version.', 'warning');
      return;
    }
    const newVer = {
      version: newVersionTag,
      sizeMB: selectedDataset.versions[0].sizeMB + 80,
      recordsCount: selectedDataset.versions[0].recordsCount + 50000,
      createdAt: 'Just now',
      schemaHealth: 'Optimal' as const,
      missingValuesPct: 0.01,
      duplicatesEstimatePct: 0.05,
      changeSummary: newVersionSummary
    };
    addDatasetVersion(selectedDataset.id, newVer);
    setShowNewVersionModal(false);
    setNewVersionSummary('');
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center space-x-2">
            <span className="text-xs font-mono text-orange-400 font-bold uppercase tracking-wider">
              CORPUS INTEGRITY
            </span>
            <span className="text-gray-600">/</span>
            <span className="text-xs font-mono text-gray-400">Dataset Registry</span>
            <TrustBadge type="SIMULATED" size="xs" />
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white font-display flex items-center space-x-2">
            <Database className="w-7 h-7 text-emerald-400" />
            <span>Dataset Center & Versioning</span>
          </h1>
          <p className="text-xs sm:text-sm text-gray-400">
            Immutable dataset versioning with schema health checks, missing token audits, and deduplication scoring.
          </p>
        </div>

        <button
          onClick={() => setShowNewVersionModal(true)}
          className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-lg transition flex items-center space-x-1.5 self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Register New Version</span>
        </button>
      </div>

      {/* Dataset Profile Card */}
      <div className="p-6 rounded-2xl bg-[#0a0e17] border border-white/10 space-y-4 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-white/10 pb-4">
          <div>
            <div className="flex items-center space-x-2">
              <h2 className="text-xl font-bold text-white font-display">
                {selectedDataset.name}
              </h2>
              <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800/40 text-xs font-mono font-bold">
                {selectedDataset.currentVersion}
              </span>
              <span className="text-xs font-mono text-gray-500 uppercase">
                {selectedDataset.format}
              </span>
            </div>
            <p className="text-xs text-gray-400 mt-1">
              {selectedDataset.description}
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setCurrentView('compute_brain')}
              className="px-3.5 py-1.5 rounded-lg bg-orange-500 hover:bg-orange-600 text-white text-xs font-bold transition flex items-center space-x-1"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Use in Compute Brain</span>
            </button>
          </div>
        </div>

        {/* Dataset Health Metrics Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs font-mono">
          <div className="p-3 bg-black/40 rounded-lg border border-white/5">
            <div className="text-gray-500 text-[10px]">Verified Records</div>
            <div className="text-lg font-bold text-white mt-0.5">
              {selectedDataset.versions[0].recordsCount.toLocaleString()}
            </div>
            <div className="text-[10px] text-emerald-400 font-sans mt-0.5">12 Indic Languages</div>
          </div>

          <div className="p-3 bg-black/40 rounded-lg border border-white/5">
            <div className="text-gray-500 text-[10px]">Disk Footprint</div>
            <div className="text-lg font-bold text-white mt-0.5">
              {(selectedDataset.versions[0].sizeMB / 1024).toFixed(2)} GB
            </div>
            <div className="text-[10px] text-gray-400 font-sans mt-0.5">Snappy Parquet</div>
          </div>

          <div className="p-3 bg-black/40 rounded-lg border border-white/5">
            <div className="text-gray-500 text-[10px]">Missing Token Values</div>
            <div className="text-lg font-bold text-emerald-400 mt-0.5">
              {selectedDataset.versions[0].missingValuesPct}%
            </div>
            <div className="text-[10px] text-emerald-400 font-sans mt-0.5">Health: Optimal</div>
          </div>

          <div className="p-3 bg-black/40 rounded-lg border border-white/5">
            <div className="text-gray-500 text-[10px]">Duplicate Estimate</div>
            <div className="text-lg font-bold text-sky-400 mt-0.5">
              {selectedDataset.versions[0].duplicatesEstimatePct}%
            </div>
            <div className="text-[10px] text-gray-400 font-sans mt-0.5">MinHash LSH Audited</div>
          </div>
        </div>
      </div>

      {/* Version History Table */}
      <div className="rounded-xl bg-[#0a0e17] border border-white/10 overflow-hidden shadow-xl">
        <div className="p-4 bg-black/40 border-b border-white/10 flex items-center justify-between text-xs font-mono">
          <span className="text-gray-300 font-bold uppercase">Version Changelog & Provenance</span>
          <span className="text-gray-500">{selectedDataset.versions.length} versions published</span>
        </div>

        <div className="divide-y divide-white/5 font-mono text-xs text-gray-300">
          {selectedDataset.versions.map((ver, idx) => (
            <div key={ver.version} className="p-4 flex flex-col md:flex-row md:items-center justify-between gap-3 hover:bg-white/5 transition">
              <div className="space-y-1">
                <div className="flex items-center space-x-2">
                  <GitBranch className="w-4 h-4 text-emerald-400" />
                  <span className="font-bold text-white">{ver.version}</span>
                  {idx === 0 && (
                    <span className="text-[9px] bg-emerald-500/20 text-emerald-300 px-1.5 py-0.5 rounded font-bold">
                      CURRENT
                    </span>
                  )}
                  <span className="text-gray-500 text-[11px]">• {ver.createdAt}</span>
                </div>
                <p className="text-gray-400 font-sans text-xs">
                  {ver.changeSummary}
                </p>
              </div>

              <div className="flex items-center space-x-4 text-xs shrink-0">
                <div className="text-right">
                  <div className="text-white">{ver.recordsCount.toLocaleString()} rows</div>
                  <div className="text-[10px] text-gray-500">{ver.sizeMB} MB</div>
                </div>

                <button
                  onClick={() => showNotification(`Dataset version ${ver.version} inspected.`, 'info')}
                  className="px-3 py-1 bg-white/5 hover:bg-white/10 rounded border border-white/10 text-gray-300 text-xs transition"
                >
                  Inspect
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* New Version Modal */}
      {showNewVersionModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="fixed inset-0 bg-black/80 backdrop-blur-sm"
            onClick={() => setShowNewVersionModal(false)}
          />
          <div className="relative w-full max-w-md bg-[#0d121f] border border-white/15 rounded-xl p-6 space-y-4 z-10 shadow-2xl">
            <h3 className="text-lg font-bold text-white font-display">
              Register Dataset Version
            </h3>

            <div className="space-y-2">
              <label className="text-xs font-mono text-gray-400">Semantic Version Tag</label>
              <input
                type="text"
                value={newVersionTag}
                onChange={e => setNewVersionTag(e.target.value)}
                className="w-full bg-black/50 border border-white/10 rounded-lg p-2 text-xs text-white focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div className="space-y-2">
              <label className="text-xs font-mono text-gray-400">Change Summary / Methodology</label>
              <textarea
                value={newVersionSummary}
                onChange={e => setNewVersionSummary(e.target.value)}
                placeholder="e.g. Added 50k Sanskrit grammatical pairs and pruned repetitive Hindi colloquial phrases."
                rows={3}
                className="w-full bg-black/50 border border-white/10 rounded-lg p-2 text-xs text-white focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div className="flex gap-2 pt-2">
              <button
                onClick={handleCreateVersion}
                className="flex-1 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold transition"
              >
                Register & Audit
              </button>
              <button
                onClick={() => setShowNewVersionModal(false)}
                className="px-4 py-2 bg-white/10 hover:bg-white/15 text-gray-300 rounded-lg text-xs transition"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
