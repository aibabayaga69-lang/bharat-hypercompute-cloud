import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { TrustBadge } from '../common/TrustBadge';
import {
  Play,
  Square,
  RotateCcw,
  Sparkles,
  Plus,
  Trash2,
  Bookmark,
  Terminal,
  Cpu,
  CheckCircle2,
  FileCode,
  Layers,
  ChevronDown,
  BrainCircuit,
  Zap,
  Activity,
  Copy,
  Undo2,
  Maximize2,
  History,
  X,
  Search,
  ShieldCheck,
  Check,
  HardDrive
} from 'lucide-react';

export const NotebookView: React.FC = () => {
  const {
    notebook,
    updateCell,
    runCell,
    runAllCells,
    addCell,
    deleteCell,
    project,
    showNotification,
    addTimelineEvent,
    savedCheckpoints,
    activeRestoredCheckpoint,
    saveNotebookCheckpoint,
    restoreCheckpoint,
    rollbackTrainingToCheckpoint
  } = useApp();

  const [showRestoreModal, setShowRestoreModal] = useState(false);
  const [checkpointSearch, setCheckpointSearch] = useState('');
  const [activeFilter, setActiveFilter] = useState<'all' | 'auto' | 'manual'>('all');

  const [activeCopilotTab, setActiveCopilotTab] = useState<'copilot' | 'terminal' | 'packages'>('copilot');
  const [copilotPrompt, setCopilotPrompt] = useState('');
  const [copilotActionState, setCopilotActionState] = useState<{
    status: 'idle' | 'suggested' | 'approved' | 'executed';
    actionName: string;
    explanation: string;
    impact: string;
    codeDiff?: string;
  } | null>(null);

  const [terminalLogs, setTerminalLogs] = useState<string[]>([
    'bharat-hypercompute-kernel v2.5.1 [Linux 6.6.0-generic x86_64]',
    'Attached Pod: 4x BHARAT H100 SXM5 80GB (PCIe Bus 0000:03:00.0 - 0000:06:00.0)',
    'NCCL version 2.21.5+cuda12.4 | InfiniBand NDR 400Gb/s detected (Demo simulation)',
    'Type python code or invoke Compute Brain commands with %brain'
  ]);

  const commandBarShortcuts = [
    { label: 'Analyze this dataset', prompt: 'Analyze dataset tokens, vocabulary size, and duplicate prompt distributions.' },
    { label: 'Optimize this code', prompt: 'Optimize memory allocation and recommend FlashAttention-2 integration.' },
    { label: 'Find bottlenecks', prompt: 'Profile step times to detect GPU starvation or DataLoader bottleneck.' },
    { label: 'Generate training loop', prompt: 'Generate an efficient PyTorch DDP training loop with gradient accumulation and bf16.' },
    { label: 'Prepare deployment', prompt: 'Export trained model checkpoint to vLLM format and generate deployment spec.' },
    { label: 'Explain this error', prompt: 'Inspect latest CUDA memory error and recommend optimal batch size reduction.' }
  ];

  const handleCopilotCommand = (cmdText: string) => {
    setCopilotPrompt(cmdText);
    showNotification(`AI Research Copilot analyzing: "${cmdText}"`, 'info');

    // Simulate structured intelligent copilot recommendation
    setTimeout(() => {
      if (cmdText.includes('Optimize') || cmdText.includes('bottleneck')) {
        setCopilotActionState({
          status: 'suggested',
          actionName: 'FlashAttention-2 & Fused AdamW Optimization',
          explanation: 'Replaces eager PyTorch attention with hardware-fused FlashAttention-2 kernels and binds fused AdamW optimizer.',
          impact: 'Reduces peak VRAM from 58GB to 39GB per GPU; increases token throughput by ~32%.',
          codeDiff: `+ # Compute Brain Optimized Attention & Optimizer\n+ model = AutoModelForCausalLM.from_pretrained(model_id, attn_implementation="flash_attention_2", torch_dtype=torch.bfloat16)\n+ optimizer = torch.optim.AdamW(model.parameters(), lr=2e-5, fused=True)`
        });
      } else if (cmdText.includes('training loop')) {
        setCopilotActionState({
          status: 'suggested',
          actionName: 'Resilient Self-Healing Training Loop',
          explanation: 'Injects automated epoch micro-checkpointing and exception-handling for instant worker hot-swaps.',
          impact: 'Guarantees zero lost epochs in case of transient node dropouts.',
          codeDiff: `+ with SelfHealingTrainer(checkpoint_interval=250, save_to="bsy://checkpoints/") as trainer:\n+     for epoch in range(epochs):\n+         trainer.step_epoch()`
        });
      } else {
        setCopilotActionState({
          status: 'suggested',
          actionName: 'Multilingual Tokenizer & Dataset Audit',
          explanation: 'Evaluates Indic vocabulary coverage against Bhasha-v3 corpus to ensure minimal token split degradation.',
          impact: 'Compresses average subword token sequence length by 19% across Hindi & Sanskrit sequences.',
          codeDiff: `+ # Audit Vocabulary Coverage\n+ stats = dataset.profile_tokens(tokenizer)\n+ print(f"Compression ratio: {stats['tokens_per_word']:.2f}")`
        });
      }
    }, 400);
  };

  const handleApplyCopilotDiff = () => {
    if (!copilotActionState?.codeDiff) return;

    // Append a new cell with the suggested code
    const newCell = {
      id: `cell_opt_${Date.now()}`,
      type: 'code' as const,
      content: copilotActionState.codeDiff.split('\n').map(l => l.replace(/^\+ /, '')).join('\n'),
      status: 'idle' as const
    };

    updateCell(notebook.cells[notebook.cells.length - 1].id, {});
    addCell('code');

    setCopilotActionState(prev => prev ? { ...prev, status: 'executed' } : null);
    addTimelineEvent({
      projectId: project.id,
      type: 'notebook',
      title: `Copilot Action Executed`,
      description: copilotActionState.actionName,
      timestamp: 'Just now',
      trustTag: 'EXECUTED'
    });
    showNotification('AI Copilot optimization applied to research notebook!', 'success');
  };

  const handleSaveCheckpoint = () => {
    saveNotebookCheckpoint(
      'Manual Research Checkpoint Saved',
      'Snapshot of notebook state, tensor weights, and kernel execution taken.'
    );
  };

  const filteredCheckpoints = savedCheckpoints.filter(ckpt => {
    const matchesSearch =
      ckpt.id.toLowerCase().includes(checkpointSearch.toLowerCase()) ||
      (ckpt.experimentName && ckpt.experimentName.toLowerCase().includes(checkpointSearch.toLowerCase())) ||
      (ckpt.notes && ckpt.notes.toLowerCase().includes(checkpointSearch.toLowerCase())) ||
      ckpt.step.toString().includes(checkpointSearch);

    if (!matchesSearch) return false;
    if (activeFilter === 'auto') return ckpt.isAutomatic;
    if (activeFilter === 'manual') return !ckpt.isAutomatic;
    return true;
  });

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Notebook Header Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#0a0e17] p-4 rounded-xl border border-white/10 shadow-lg">
        <div className="space-y-1">
          <div className="flex items-center space-x-2">
            <span className="text-xs font-mono text-orange-400 uppercase">AI RESEARCH NOTEBOOK</span>
            <span className="text-gray-600">/</span>
            <span className="text-xs font-mono text-emerald-400 flex items-center space-x-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              <span>KERNEL CONNECTED</span>
            </span>
            <TrustBadge type="DEMO" size="xs" />
          </div>
          <h1 className="text-xl sm:text-2xl font-bold text-white font-display flex items-center space-x-2">
            <FileCode className="w-5 h-5 text-orange-400" />
            <span>{notebook.title}</span>
          </h1>
        </div>

        {/* Notebook Execution Controls */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={runAllCells}
            className="px-3 py-1.5 rounded-lg bg-orange-500 hover:bg-orange-600 text-white font-bold text-xs shadow transition flex items-center space-x-1.5"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>Run All</span>
          </button>

          <button
            onClick={handleSaveCheckpoint}
            className="px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/15 text-gray-200 text-xs font-mono border border-white/10 transition flex items-center space-x-1.5"
            title="Save current notebook tensor state and code snapshot"
          >
            <Bookmark className="w-3.5 h-3.5 text-amber-400" />
            <span>Save Checkpoint</span>
          </button>

          <button
            onClick={() => setShowRestoreModal(true)}
            className="px-3 py-1.5 rounded-lg bg-sky-500/15 hover:bg-sky-500/25 text-sky-300 text-xs font-mono border border-sky-500/30 transition flex items-center space-x-1.5"
            title="Restore previous checkpoint weights into notebook kernel"
          >
            <History className="w-3.5 h-3.5 text-sky-400" />
            <span>Restore Checkpoint</span>
          </button>

          <button
            onClick={() => addCell('code')}
            className="px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/15 text-gray-200 text-xs font-mono border border-white/10 transition flex items-center space-x-1.5"
          >
            <Plus className="w-3.5 h-3.5 text-orange-400" />
            <span>+ Code</span>
          </button>

          <button
            onClick={() => addCell('markdown')}
            className="px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/15 text-gray-200 text-xs font-mono border border-white/10 transition flex items-center space-x-1.5"
          >
            <Plus className="w-3.5 h-3.5 text-indigo-400" />
            <span>+ Markdown</span>
          </button>
        </div>
      </div>

      {/* Active Restored Checkpoint Kernel Indicator */}
      {activeRestoredCheckpoint && (
        <div className="p-3 bg-sky-950/30 border border-sky-800/40 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs font-mono text-sky-300">
          <div className="flex flex-wrap items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-sky-400 animate-pulse" />
            <span className="font-bold text-white">Active Kernel Weights:</span>
            <span className="px-2 py-0.5 rounded bg-sky-500/20 text-sky-300 border border-sky-500/40">
              {activeRestoredCheckpoint.id}
            </span>
            <span className="text-gray-400">{activeRestoredCheckpoint.path}</span>
            <span className="text-emerald-400 font-bold">Loss: {activeRestoredCheckpoint.loss}</span>
            <span className="text-amber-400">Step: {activeRestoredCheckpoint.step}</span>
            <span className="text-gray-400">Acc: {activeRestoredCheckpoint.valAccuracy}%</span>
          </div>
          <div className="flex items-center space-x-3 shrink-0">
            <button
              onClick={() => rollbackTrainingToCheckpoint(activeRestoredCheckpoint.step, activeRestoredCheckpoint.loss)}
              className="text-xs text-amber-400 hover:text-amber-300 underline"
            >
              Sync Cluster to this Step
            </button>
            <button
              onClick={() => setShowRestoreModal(true)}
              className="text-xs text-sky-400 hover:text-white underline"
            >
              Restore Different
            </button>
          </div>
        </div>
      )}

      {/* AI Command Bar (Horizontal Quick Access) */}
      <div className="p-3 bg-[#0d121f] rounded-xl border border-white/10 space-y-2">
        <div className="flex items-center justify-between text-xs font-mono">
          <div className="flex items-center space-x-1.5 text-orange-300">
            <Sparkles className="w-3.5 h-3.5 text-orange-400" />
            <span className="font-bold">Notebook AI Command Bar</span>
          </div>
          <span className="text-gray-500 text-[10px]">Instant Research Copilot Actions</span>
        </div>

        <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
          {commandBarShortcuts.map((sc, i) => (
            <button
              key={i}
              onClick={() => handleCopilotCommand(sc.prompt)}
              className="px-2.5 py-1 rounded-md bg-white/5 hover:bg-orange-500/20 text-gray-300 hover:text-orange-300 border border-white/10 hover:border-orange-500/40 font-mono text-[11px] whitespace-nowrap transition"
            >
              {sc.label}
            </button>
          ))}
        </div>
      </div>

      {/* Main Grid: Cells on Left, Copilot/Terminal on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Cells Area (8 cols) */}
        <div className="lg:col-span-8 space-y-4">
          {notebook.cells.map((cell, index) => (
            <div
              key={cell.id}
              className="rounded-xl bg-[#090d15] border border-white/10 overflow-hidden shadow-md group transition hover:border-white/20"
            >
              {/* Cell Header Strip */}
              <div className="flex items-center justify-between px-3 py-1.5 bg-black/40 border-b border-white/5 text-[11px] font-mono text-gray-400">
                <div className="flex items-center space-x-2">
                  <span className="text-orange-400 font-bold">[{index + 1}]</span>
                  <span className="uppercase text-[10px] text-gray-500">{cell.type}</span>
                  {cell.status === 'running' && (
                    <span className="text-orange-400 animate-pulse flex items-center space-x-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-orange-400" />
                      <span>RUNNING</span>
                    </span>
                  )}
                  {cell.status === 'completed' && cell.executionTimeMs && (
                    <span className="text-emerald-400 text-[10px]">
                      ✓ {cell.executionTimeMs}ms
                    </span>
                  )}
                </div>

                <div className="flex items-center space-x-1">
                  {cell.type === 'code' && (
                    <button
                      onClick={() => runCell(cell.id)}
                      disabled={cell.status === 'running'}
                      className="px-2 py-0.5 rounded bg-orange-500/20 hover:bg-orange-500/30 text-orange-300 text-[11px] flex items-center space-x-1 transition"
                    >
                      <Play className="w-3 h-3 fill-current" />
                      <span>Run</span>
                    </button>
                  )}
                  <button
                    onClick={() => deleteCell(cell.id)}
                    className="p-1 text-gray-500 hover:text-rose-400 transition"
                    title="Delete cell"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Cell Editor Content */}
              <div className="p-3">
                <textarea
                  value={cell.content}
                  onChange={e => updateCell(cell.id, { content: e.target.value })}
                  rows={cell.content.split('\n').length || 3}
                  className="w-full bg-transparent font-mono text-xs text-gray-200 focus:outline-none resize-none leading-relaxed"
                  spellCheck={false}
                />
              </div>

              {/* Cell Output Display (if any) */}
              {cell.output && (
                <div className="border-t border-white/5 bg-black/60 p-3 font-mono text-xs text-gray-300 space-y-1">
                  <div className="text-[10px] text-gray-500 uppercase tracking-wider flex justify-between">
                    <span>Output</span>
                    <span className="text-emerald-400 font-bold">Exit Code: 0</span>
                  </div>
                  <pre className="text-gray-300 whitespace-pre-wrap text-[11px] leading-relaxed">
                    {cell.output}
                  </pre>
                </div>
              )}
            </div>
          ))}

          {/* Add Cell Footer */}
          <div className="flex items-center justify-center space-x-3 py-3 border border-dashed border-white/10 rounded-xl">
            <button
              onClick={() => addCell('code')}
              className="text-xs font-mono text-gray-400 hover:text-orange-400 flex items-center space-x-1.5 transition"
            >
              <Plus className="w-4 h-4" />
              <span>Add Code Cell</span>
            </button>
            <span className="text-gray-600">|</span>
            <button
              onClick={() => addCell('markdown')}
              className="text-xs font-mono text-gray-400 hover:text-indigo-400 flex items-center space-x-1.5 transition"
            >
              <Plus className="w-4 h-4" />
              <span>Add Markdown Cell</span>
            </button>
          </div>
        </div>

        {/* Right Sidebar: AI Research Copilot & Connected Cluster Terminal (4 cols) */}
        <div className="lg:col-span-4 space-y-4">
          {/* Tab buttons */}
          <div className="flex items-center rounded-xl bg-[#090d15] p-1 border border-white/10 text-xs font-mono">
            <button
              onClick={() => setActiveCopilotTab('copilot')}
              className={`flex-1 py-1.5 rounded-lg transition ${
                activeCopilotTab === 'copilot'
                  ? 'bg-orange-500/20 text-orange-300 font-bold border border-orange-500/30'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              AI Copilot
            </button>
            <button
              onClick={() => setActiveCopilotTab('terminal')}
              className={`flex-1 py-1.5 rounded-lg transition ${
                activeCopilotTab === 'terminal'
                  ? 'bg-orange-500/20 text-orange-300 font-bold border border-orange-500/30'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              Pod Terminal
            </button>
            <button
              onClick={() => setActiveCopilotTab('packages')}
              className={`flex-1 py-1.5 rounded-lg transition ${
                activeCopilotTab === 'packages'
                  ? 'bg-orange-500/20 text-orange-300 font-bold border border-orange-500/30'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              Packages
            </button>
          </div>

          {/* TAB 1: AI Copilot */}
          {activeCopilotTab === 'copilot' && (
            <div className="p-4 rounded-xl bg-[#0a0e17] border border-white/10 space-y-4">
              <div className="flex items-center justify-between text-xs">
                <div className="flex items-center space-x-1.5 text-white font-bold font-display">
                  <BrainCircuit className="w-4 h-4 text-orange-400" />
                  <span>Research Copilot</span>
                </div>
                <TrustBadge type={copilotActionState?.status.toUpperCase() as any || 'SUGGESTED'} size="xs" />
              </div>

              {/* Copilot input */}
              <div className="space-y-2">
                <textarea
                  value={copilotPrompt}
                  onChange={e => setCopilotPrompt(e.target.value)}
                  placeholder="Ask Copilot: 'Optimize batch size for 80GB HBM3' or 'Explain loss divergence'..."
                  rows={3}
                  className="w-full bg-black/50 border border-white/10 rounded-lg p-2.5 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-orange-500/50"
                />
                <button
                  onClick={() => handleCopilotCommand(copilotPrompt || 'Optimize this code')}
                  className="w-full py-1.5 bg-orange-500 hover:bg-orange-600 text-white rounded-lg text-xs font-bold transition flex items-center justify-center space-x-1"
                >
                  <Sparkles className="w-3 h-3" />
                  <span>Ask AI Copilot</span>
                </button>
              </div>

              {/* Copilot Proposed Action (AI Trust System) */}
              {copilotActionState && (
                <div className="p-3.5 rounded-lg bg-black/70 border border-orange-500/30 space-y-2 text-xs font-mono">
                  <div className="flex items-center justify-between">
                    <span className="text-orange-400 font-bold">{copilotActionState.actionName}</span>
                    <span className="text-[10px] text-gray-500 uppercase">{copilotActionState.status}</span>
                  </div>

                  <p className="text-gray-300 text-[11px] leading-relaxed">
                    {copilotActionState.explanation}
                  </p>

                  <div className="text-[11px] text-emerald-400 font-mono">
                    Expected Impact: {copilotActionState.impact}
                  </div>

                  {copilotActionState.codeDiff && (
                    <div className="bg-[#07090e] p-2 rounded border border-white/10 text-[10px] text-emerald-300 whitespace-pre-wrap overflow-x-auto">
                      {copilotActionState.codeDiff}
                    </div>
                  )}

                  {copilotActionState.status === 'suggested' && (
                    <div className="pt-1 flex gap-2">
                      <button
                        onClick={handleApplyCopilotDiff}
                        className="flex-1 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded text-xs font-bold transition"
                      >
                        Approve & Apply
                      </button>
                      <button
                        onClick={() => setCopilotActionState(null)}
                        className="px-3 py-1 bg-white/10 hover:bg-white/20 text-gray-300 rounded text-xs transition"
                      >
                        Dismiss
                      </button>
                    </div>
                  )}

                  {copilotActionState.status === 'executed' && (
                    <div className="text-emerald-400 text-[11px] flex items-center space-x-1">
                      <CheckCircle2 className="w-3 h-3" />
                      <span>Changes inserted into notebook as new executable cell.</span>
                    </div>
                  )}
                </div>
              )}

              {/* Pre-canned actions */}
              <div className="space-y-1 pt-2 border-t border-white/5 text-xs">
                <div className="text-[10px] font-mono uppercase text-gray-500">Quick Actions</div>
                <div className="grid grid-cols-2 gap-1.5">
                  <button
                    onClick={() => handleCopilotCommand('Profile memory bottlenecks')}
                    className="p-1.5 rounded bg-white/5 hover:bg-white/10 text-left text-[11px] text-gray-300 truncate"
                  >
                    Memory Profiler
                  </button>
                  <button
                    onClick={() => handleCopilotCommand('Suggest next hyperparameter')}
                    className="p-1.5 rounded bg-white/5 hover:bg-white/10 text-left text-[11px] text-gray-300 truncate"
                  >
                    Next Experiment
                  </button>
                  <button
                    onClick={() => handleCopilotCommand('Write documentation')}
                    className="p-1.5 rounded bg-white/5 hover:bg-white/10 text-left text-[11px] text-gray-300 truncate"
                  >
                    Generate Docs
                  </button>
                  <button
                    onClick={() => handleCopilotCommand('Prepare deployment')}
                    className="p-1.5 rounded bg-white/5 hover:bg-white/10 text-left text-[11px] text-gray-300 truncate"
                  >
                    Export vLLM
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: Pod Terminal */}
          {activeCopilotTab === 'terminal' && (
            <div className="p-4 rounded-xl bg-[#0a0e17] border border-white/10 space-y-3 font-mono text-xs">
              <div className="flex justify-between items-center text-gray-400 border-b border-white/5 pb-2">
                <span>Cluster TTY (bash)</span>
                <span className="text-emerald-400 text-[10px]">Connected</span>
              </div>
              <div className="bg-black/80 rounded-lg p-2.5 h-64 overflow-y-auto space-y-1 text-[11px] text-gray-300 border border-white/5">
                {terminalLogs.map((line, idx) => (
                  <div key={idx} className="leading-relaxed">{line}</div>
                ))}
                <div className="text-orange-400 flex items-center space-x-1">
                  <span>root@bharat-pod-04:~$</span>
                  <span className="w-1.5 h-3.5 bg-orange-400 animate-pulse inline-block" />
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: Packages */}
          {activeCopilotTab === 'packages' && (
            <div className="p-4 rounded-xl bg-[#0a0e17] border border-white/10 space-y-3 font-mono text-xs">
              <div className="flex justify-between items-center text-gray-400 border-b border-white/5 pb-2">
                <span>Environment Dependencies</span>
                <span className="text-gray-500 text-[10px]">pip freeze</span>
              </div>
              <div className="space-y-1.5 text-[11px] text-gray-300">
                <div className="flex justify-between p-1.5 bg-white/5 rounded">
                  <span>torch</span>
                  <span className="text-orange-400">2.5.1+cu124</span>
                </div>
                <div className="flex justify-between p-1.5 bg-white/5 rounded">
                  <span>transformers</span>
                  <span className="text-orange-400">4.46.2</span>
                </div>
                <div className="flex justify-between p-1.5 bg-white/5 rounded">
                  <span>flash-attn</span>
                  <span className="text-orange-400">2.6.3</span>
                </div>
                <div className="flex justify-between p-1.5 bg-white/5 rounded">
                  <span>vllm</span>
                  <span className="text-orange-400">0.6.3</span>
                </div>
                <div className="flex justify-between p-1.5 bg-white/5 rounded">
                  <span>datasets</span>
                  <span className="text-orange-400">3.1.0</span>
                </div>
                <div className="flex justify-between p-1.5 bg-white/5 rounded">
                  <span>deepspeed</span>
                  <span className="text-orange-400">0.15.4</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Restore Checkpoints Modal */}
      {showRestoreModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
          <div className="bg-[#0a0e17] border border-white/20 rounded-2xl w-full max-w-4xl max-h-[85vh] flex flex-col shadow-2xl overflow-hidden">
            {/* Modal Header */}
            <div className="p-5 border-b border-white/10 flex items-center justify-between bg-[#0d121f]">
              <div className="space-y-1">
                <div className="flex items-center space-x-2">
                  <span className="p-1.5 rounded-lg bg-sky-500/20 text-sky-400 border border-sky-500/30">
                    <History className="w-4 h-4" />
                  </span>
                  <h3 className="text-lg font-bold text-white font-display">
                    Restore Previous Checkpoints & Model Weights
                  </h3>
                  <span className="text-xs px-2 py-0.5 rounded bg-orange-500/20 text-orange-300 font-mono">
                    Zero Data Loss
                  </span>
                </div>
                <p className="text-xs text-gray-400 font-mono">
                  Select any historical training checkpoint to restore into the active research kernel or rollback distributed training.
                </p>
              </div>
              <button
                onClick={() => setShowRestoreModal(false)}
                className="p-1.5 rounded-lg text-gray-400 hover:text-white hover:bg-white/10 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Filter & Search Bar */}
            <div className="p-4 border-b border-white/10 bg-[#080c14] flex flex-col sm:flex-row gap-3 items-center justify-between">
              <div className="relative w-full sm:w-80">
                <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Search by ID, step, loss, or experiment..."
                  value={checkpointSearch}
                  onChange={(e) => setCheckpointSearch(e.target.value)}
                  className="w-full pl-9 pr-3 py-1.5 bg-black/50 border border-white/10 rounded-lg text-xs font-mono text-white placeholder-gray-500 focus:outline-none focus:border-orange-500/50"
                />
              </div>

              <div className="flex items-center gap-1.5 self-start sm:self-auto text-xs font-mono">
                <button
                  onClick={() => setActiveFilter('all')}
                  className={`px-3 py-1 rounded-lg transition ${
                    activeFilter === 'all'
                      ? 'bg-sky-500/20 text-sky-300 border border-sky-500/40 font-bold'
                      : 'text-gray-400 hover:text-white'
                  }`}
                >
                  All ({savedCheckpoints.length})
                </button>
                <button
                  onClick={() => setActiveFilter('auto')}
                  className={`px-3 py-1 rounded-lg transition ${
                    activeFilter === 'auto'
                      ? 'bg-sky-500/20 text-sky-300 border border-sky-500/40 font-bold'
                      : 'text-gray-400 hover:text-white'
                  }`}
                >
                  Auto Steps ({savedCheckpoints.filter(c => c.isAutomatic).length})
                </button>
                <button
                  onClick={() => setActiveFilter('manual')}
                  className={`px-3 py-1 rounded-lg transition ${
                    activeFilter === 'manual'
                      ? 'bg-sky-500/20 text-sky-300 border border-sky-500/40 font-bold'
                      : 'text-gray-400 hover:text-white'
                  }`}
                >
                  Manual Snapshots ({savedCheckpoints.filter(c => !c.isAutomatic).length})
                </button>
              </div>
            </div>

            {/* Checkpoint Cards List */}
            <div className="p-4 overflow-y-auto space-y-3 flex-1 font-mono text-xs">
              {filteredCheckpoints.length === 0 ? (
                <div className="p-8 text-center text-gray-500">
                  No checkpoints match your search criteria.
                </div>
              ) : (
                filteredCheckpoints.map((ckpt) => {
                  const isActiveInKernel = activeRestoredCheckpoint?.id === ckpt.id;
                  return (
                    <div
                      key={ckpt.id}
                      className={`p-4 rounded-xl border transition flex flex-col md:flex-row md:items-center justify-between gap-4 ${
                        isActiveInKernel
                          ? 'bg-sky-950/30 border-sky-500/60 shadow-lg shadow-sky-950/30'
                          : 'bg-[#0d121f] border-white/10 hover:border-white/20'
                      }`}
                    >
                      <div className="space-y-1.5 flex-1">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="font-bold text-white text-sm">{ckpt.id}</span>
                          <span className={`px-2 py-0.5 rounded text-[10px] ${
                            ckpt.isAutomatic
                              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                              : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                          }`}>
                            {ckpt.isAutomatic ? 'AUTOMATED STEP' : 'MANUAL SNAPSHOT'}
                          </span>
                          {isActiveInKernel && (
                            <span className="px-2 py-0.5 rounded text-[10px] bg-sky-500/30 text-sky-200 border border-sky-400 flex items-center space-x-1">
                              <Check className="w-3 h-3 text-sky-300" />
                              <span className="font-bold">ACTIVE IN KERNEL</span>
                            </span>
                          )}
                          <span className="text-gray-500 text-[11px]">{ckpt.timestamp}</span>
                        </div>

                        <div className="text-gray-300 text-xs flex items-center space-x-2">
                          <span className="text-orange-400">{ckpt.experimentName || 'Research Run'}</span>
                          {ckpt.notes && <span className="text-gray-500">• {ckpt.notes}</span>}
                        </div>

                        {/* Metrics Grid */}
                        <div className="flex flex-wrap items-center gap-4 text-[11px] pt-1">
                          <div className="text-gray-400">
                            Epoch: <span className="text-white font-bold">{ckpt.epoch}</span>
                          </div>
                          <div className="text-gray-400">
                            Step: <span className="text-amber-400 font-bold">{ckpt.step}</span>
                          </div>
                          <div className="text-gray-400">
                            Loss: <span className="text-emerald-400 font-bold">{ckpt.loss}</span>
                          </div>
                          <div className="text-gray-400">
                            Val Acc: <span className="text-sky-400 font-bold">{ckpt.valAccuracy}%</span>
                          </div>
                          <div className="text-gray-400">
                            Size: <span className="text-gray-200">{(ckpt.sizeMB / 1024).toFixed(1)} GB</span>
                          </div>
                        </div>

                        {/* Storage Path & Checksum */}
                        <div className="flex flex-wrap items-center gap-3 text-[10px] text-gray-500 pt-1">
                          <span className="flex items-center space-x-1 font-mono text-gray-400">
                            <HardDrive className="w-3 h-3 text-gray-400" />
                            <span>{ckpt.path || `bsy://checkpoints/${ckpt.id}.pt`}</span>
                          </span>
                          <span className="flex items-center space-x-1 font-mono text-emerald-400/80">
                            <ShieldCheck className="w-3 h-3" />
                            <span>{ckpt.sha256?.slice(0, 18) || 'sha256:verified'}...</span>
                          </span>
                        </div>
                      </div>

                      {/* Action Buttons */}
                      <div className="flex flex-col sm:flex-row md:flex-col gap-2 shrink-0">
                        <button
                          onClick={() => {
                            restoreCheckpoint(ckpt.id, { target: 'notebook' });
                            setShowRestoreModal(false);
                          }}
                          className={`px-4 py-2 rounded-lg font-bold text-xs transition flex items-center justify-center space-x-1.5 ${
                            isActiveInKernel
                              ? 'bg-sky-600 text-white hover:bg-sky-500'
                              : 'bg-orange-500 hover:bg-orange-600 text-white'
                          }`}
                        >
                          <History className="w-3.5 h-3.5" />
                          <span>{isActiveInKernel ? 'Reload Weights' : 'Restore into Kernel'}</span>
                        </button>

                        <button
                          onClick={() => {
                            restoreCheckpoint(ckpt.id, { target: 'training' });
                            setShowRestoreModal(false);
                          }}
                          className="px-4 py-1.5 rounded-lg bg-white/10 hover:bg-white/15 text-gray-300 hover:text-white border border-white/10 transition flex items-center justify-center space-x-1.5"
                          title="Hot-swap distributed training cluster to this exact step"
                        >
                          <RotateCcw className="w-3.5 h-3.5 text-amber-400" />
                          <span>Rollback Training</span>
                        </button>
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            {/* Modal Footer */}
            <div className="p-4 border-t border-white/10 bg-[#080c14] flex items-center justify-between text-xs font-mono">
              <div className="text-gray-400 flex items-center space-x-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>Zero-Corruption Policy: Every checkpoint verified by SHA-256 content addressing.</span>
              </div>
              <button
                onClick={() => setShowRestoreModal(false)}
                className="px-4 py-1.5 rounded-lg bg-white/10 hover:bg-white/15 text-gray-200"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
