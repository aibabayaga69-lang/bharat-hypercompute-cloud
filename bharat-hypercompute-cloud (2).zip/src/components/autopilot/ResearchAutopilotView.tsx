import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { TrustBadge } from '../common/TrustBadge';
import {
  Bot,
  Sparkles,
  Play,
  CheckCircle2,
  Sliders,
  Layers,
  ArrowRight,
  ShieldCheck,
  RotateCcw
} from 'lucide-react';

export const ResearchAutopilotView: React.FC = () => {
  const { showNotification, addTimelineEvent, project } = useApp();

  const [objective, setObjective] = useState('Find a better hyperparameter and batching configuration for IndicLLM-7B to reduce validation perplexity below 1.38.');
  const [isSynthesizing, setIsSynthesizing] = useState(false);
  const [planGenerated, setPlanGenerated] = useState(true);
  const [isApproved, setIsApproved] = useState(false);

  const handleGeneratePlan = () => {
    setIsSynthesizing(true);
    setTimeout(() => {
      setIsSynthesizing(false);
      setPlanGenerated(true);
      setIsApproved(false);
      showNotification('Research Autopilot synthesized multi-run experimentation matrix.', 'success');
    }, 500);
  };

  const handleApprovePlan = () => {
    setIsApproved(true);
    addTimelineEvent({
      projectId: project.id,
      type: 'experiment',
      title: 'Research Autopilot Plan Approved',
      description: 'Dispatched 3 parallel candidate variations with early-stopping criteria.',
      timestamp: 'Just now',
      trustTag: 'APPROVED'
    });
    showNotification('Autopilot Plan approved! Workloads queued in Demo Compute scheduler.', 'success');
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center space-x-2">
            <span className="text-xs font-mono text-orange-400 font-bold uppercase tracking-wider">
              AUTONOMOUS OPTIMIZATION
            </span>
            <span className="text-gray-600">/</span>
            <TrustBadge type="SUGGESTED" size="xs" />
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white font-display flex items-center space-x-2">
            <Bot className="w-7 h-7 text-orange-400" />
            <span>Research Autopilot</span>
          </h1>
          <p className="text-xs sm:text-sm text-gray-400">
            Define high-level scientific goals. Autopilot designs baseline controls, experimental variations, and stopping conditions—requiring user approval prior to execution.
          </p>
        </div>
      </div>

      {/* Goal Definition Card */}
      <div className="p-6 rounded-2xl bg-[#0a0e17] border border-white/10 space-y-4 shadow-xl">
        <div className="space-y-2">
          <label className="text-xs font-mono text-gray-400">Research Objective Statement</label>
          <textarea
            value={objective}
            onChange={e => setObjective(e.target.value)}
            rows={3}
            className="w-full bg-black/60 border border-white/10 rounded-xl p-3 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-orange-500/50 leading-relaxed font-sans"
          />
        </div>

        <div className="flex justify-end">
          <button
            onClick={handleGeneratePlan}
            disabled={isSynthesizing}
            className="px-6 py-2.5 bg-orange-500 hover:bg-orange-600 text-white font-bold text-xs rounded-xl shadow transition flex items-center space-x-2"
          >
            {isSynthesizing ? (
              <>
                <RotateCcw className="w-3.5 h-3.5 animate-spin" />
                <span>Designing Matrix...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-3.5 h-3.5" />
                <span>Synthesize Autopilot Plan</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Generated Experiment Plan */}
      {planGenerated && (
        <div className="p-6 rounded-2xl bg-[#0a0e17] border border-white/10 space-y-6 shadow-xl">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-white/10 pb-4">
            <div>
              <div className="flex items-center space-x-2">
                <span className="text-xs font-mono text-orange-400 font-bold uppercase">
                  SYNTHESIZED EXPERIMENT PLAN
                </span>
                <TrustBadge type={isApproved ? 'APPROVED' : 'SUGGESTED'} size="xs" />
                <TrustBadge type="ESTIMATED" size="xs" />
              </div>
              <h3 className="text-lg font-bold text-white font-display mt-0.5">
                Multi-Armed Hyperparameter Exploration
              </h3>
            </div>

            <div className="text-right font-mono text-xs text-gray-400">
              <div>Est. Credit Consumption: <span className="text-emerald-400 font-bold">~48 Credits</span></div>
              <div className="text-[10px] text-gray-500">Wall-clock limit: 3.0 hours</div>
            </div>
          </div>

          {/* Planned Variations */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 font-mono text-xs">
            <div className="p-4 bg-black/40 rounded-xl border border-white/5 space-y-2">
              <div className="text-orange-400 font-bold">Arm A (Baseline)</div>
              <p className="text-gray-300 text-[11px] font-sans">
                Standard AdamW with lr=2e-5, warmup=0.03, cosine decay.
              </p>
              <div className="text-[10px] text-gray-500">Target Loss: ≤ 0.339</div>
            </div>

            <div className="p-4 bg-black/40 rounded-xl border border-white/5 space-y-2">
              <div className="text-amber-400 font-bold">Arm B (Aggressive Warmup)</div>
              <p className="text-gray-300 text-[11px] font-sans">
                Warmup ratio 0.06 with Lion optimizer to test token generalization.
              </p>
              <div className="text-[10px] text-gray-500">Target Loss: ≤ 0.320</div>
            </div>

            <div className="p-4 bg-black/40 rounded-xl border border-white/5 space-y-2">
              <div className="text-sky-400 font-bold">Arm C (Dynamic Batching)</div>
              <p className="text-gray-300 text-[11px] font-sans">
                Gradual batch scaling from 64 to 256 effective tokens.
              </p>
              <div className="text-[10px] text-gray-500">Target Loss: ≤ 0.315</div>
            </div>
          </div>

          {/* Stopping Conditions & Cost Guard */}
          <div className="p-4 rounded-xl bg-black/50 border border-white/5 text-xs font-mono space-y-2">
            <div className="text-gray-400 font-bold">Early Stopping Conditions:</div>
            <ul className="text-gray-300 list-disc list-inside space-y-1 text-[11px]">
              <li>Halt run if validation perplexity plateaus across 3 consecutive evaluation checkpoints (delta &lt; 0.005).</li>
              <li>Instantly abort if gradient norm exceeds 4.5 to prevent numerical divergence.</li>
            </ul>
          </div>

          {/* Approval Section */}
          <div className="p-4 rounded-xl bg-amber-950/20 border border-amber-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center space-x-3">
              <ShieldCheck className="w-5 h-5 text-amber-400 shrink-0" />
              <div className="text-xs text-gray-300 font-mono">
                Mandatory Governance Rule: Workloads are never dispatched without explicit user sign-off.
              </div>
            </div>

            {!isApproved ? (
              <button
                onClick={handleApprovePlan}
                className="px-6 py-2 bg-orange-500 hover:bg-orange-600 text-white font-bold text-xs rounded-xl shadow transition"
              >
                Approve Experiment Plan
              </button>
            ) : (
              <div className="flex items-center space-x-2 text-xs text-emerald-400 font-mono font-bold">
                <CheckCircle2 className="w-4 h-4" />
                <span>Plan Approved & Dispatched</span>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
