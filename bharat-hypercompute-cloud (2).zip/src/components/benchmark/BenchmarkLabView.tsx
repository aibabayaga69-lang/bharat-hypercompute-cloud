import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { TrustBadge } from '../common/TrustBadge';
import {
  Layers,
  Award,
  Swords,
  TrendingUp,
  Cpu,
  Zap,
  Activity,
  CheckCircle2,
  ShieldCheck,
  Search,
  Sparkles,
  BarChart3,
  Gauge,
  HelpCircle,
  Play
} from 'lucide-react';

export const BenchmarkLabView: React.FC = () => {
  const {
    modelFamily,
    tournamentMatches,
    runTournamentMatch,
    showNotification
  } = useApp();

  const [activeTab, setActiveTab] = useState<'family' | 'tournaments' | 'methodology'>('family');
  const [selectedSuite, setSelectedSuite] = useState<string>('IndicMMLU-14Language Benchmark Suite');
  const [candidateAId, setCandidateAId] = useState<string>(modelFamily[0]?.id || '');
  const [candidateBId, setCandidateBId] = useState<string>(modelFamily[1]?.id || '');

  const suites = [
    'IndicMMLU-14Language Benchmark Suite',
    'HumanEval-Python-IndicDocstring Test',
    'GSM8K-Math-Reasoning-v2',
    'National-Sovereign-Safety-RedTeam-v1'
  ];

  const handleLaunchTournament = () => {
    if (candidateAId === candidateBId) {
      showNotification('Please select two distinct models for comparison.', 'warning');
      return;
    }
    runTournamentMatch(candidateAId, candidateBId, selectedSuite);
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Top Banner */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-gradient-to-r from-[#0c1220] via-[#080d16] to-[#0c1220] p-6 rounded-2xl border border-white/10 shadow-xl">
        <div className="space-y-1">
          <div className="flex items-center space-x-2">
            <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-orange-500/20 text-orange-400 border border-orange-500/30">
              MII Evaluation Suite
            </span>
            <span className="text-xs text-gray-400 font-mono">Transparent Scientific Evaluation</span>
            <TrustBadge type="SIMULATED" size="xs" />
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-white font-display flex items-center space-x-2">
            <Award className="w-7 h-7 text-orange-400" />
            <span>MII Benchmark Lab & Model Family</span>
          </h1>
          <p className="text-sm text-gray-400 max-w-3xl leading-relaxed">
            Multi-dimensional model evaluation without fabricated scores. Transparent testing across reasoning, coding, math, vision, multilingual Indic languages, safety, latency, and hardware efficiency.
          </p>
        </div>

        <div className="flex items-center space-x-3 shrink-0">
          <button
            onClick={() => setActiveTab('tournaments')}
            className="px-4 py-2.5 bg-orange-500 hover:bg-orange-600 text-white rounded-xl text-xs font-bold transition flex items-center space-x-1.5 shadow-lg shadow-orange-500/20"
          >
            <Swords className="w-4 h-4" />
            <span>Run Model Tournament</span>
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center space-x-2 border-b border-white/10 pb-2 overflow-x-auto">
        <button
          onClick={() => setActiveTab('family')}
          className={`px-4 py-2 rounded-lg text-xs font-medium transition flex items-center space-x-2 whitespace-nowrap ${
            activeTab === 'family'
              ? 'bg-orange-500/10 text-orange-400 border border-orange-500/30'
              : 'text-gray-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>MII Model Family ({modelFamily.length} Architectures)</span>
        </button>

        <button
          onClick={() => setActiveTab('tournaments')}
          className={`px-4 py-2 rounded-lg text-xs font-medium transition flex items-center space-x-2 whitespace-nowrap ${
            activeTab === 'tournaments'
              ? 'bg-orange-500/10 text-orange-400 border border-orange-500/30'
              : 'text-gray-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Swords className="w-4 h-4" />
          <span>Evaluation Tournaments ({tournamentMatches.length} Matches)</span>
        </button>

        <button
          onClick={() => setActiveTab('methodology')}
          className={`px-4 py-2 rounded-lg text-xs font-medium transition flex items-center space-x-2 whitespace-nowrap ${
            activeTab === 'methodology'
              ? 'bg-orange-500/10 text-orange-400 border border-orange-500/30'
              : 'text-gray-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <ShieldCheck className="w-4 h-4" />
          <span>Scientific Methodology & Contamination Defense</span>
        </button>
      </div>

      {/* TAB 1: MODEL FAMILY */}
      {activeTab === 'family' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {modelFamily.map(model => (
              <div
                key={model.id}
                className="p-5 rounded-2xl bg-[#0a0e17] border border-white/10 space-y-4 hover:border-orange-500/40 transition"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <span className="px-2 py-0.5 rounded text-[10px] font-mono uppercase bg-orange-500/20 text-orange-400 border border-orange-500/30">
                      MII {model.family}
                    </span>
                    <h3 className="text-lg font-bold text-white mt-1.5 font-display">
                      {model.name}
                    </h3>
                    <div className="text-xs text-gray-400 font-mono">
                      {model.parameters} • {model.version}
                    </div>
                  </div>

                  <div className="flex flex-col items-end space-y-1">
                    <TrustBadge type={model.trustTag} size="xs" />
                    <span className="px-2 py-0.5 rounded text-[10px] font-mono uppercase bg-white/5 text-gray-300 border border-white/10">
                      {model.status}
                    </span>
                  </div>
                </div>

                {/* Benchmark Radar Summary */}
                <div className="space-y-2 pt-2 border-t border-white/5">
                  <div className="flex justify-between text-xs">
                    <span className="text-gray-400">Indic Multilingual:</span>
                    <span className="text-emerald-400 font-mono font-bold">{model.benchmarkScores.multilingualIndic}%</span>
                  </div>
                  <div className="w-full bg-white/10 h-1.5 rounded-full overflow-hidden">
                    <div className="h-full bg-emerald-400" style={{ width: `${model.benchmarkScores.multilingualIndic}%` }} />
                  </div>

                  <div className="flex justify-between text-xs">
                    <span className="text-gray-400">Reasoning (MMLU):</span>
                    <span className="text-sky-400 font-mono font-bold">{model.benchmarkScores.reasoningMMLU}%</span>
                  </div>
                  <div className="w-full bg-white/10 h-1.5 rounded-full overflow-hidden">
                    <div className="h-full bg-sky-400" style={{ width: `${model.benchmarkScores.reasoningMMLU}%` }} />
                  </div>

                  <div className="flex justify-between text-xs">
                    <span className="text-gray-400">Coding (HumanEval):</span>
                    <span className="text-purple-400 font-mono font-bold">{model.benchmarkScores.codingHumanEval}%</span>
                  </div>
                  <div className="w-full bg-white/10 h-1.5 rounded-full overflow-hidden">
                    <div className="h-full bg-purple-400" style={{ width: `${model.benchmarkScores.codingHumanEval}%` }} />
                  </div>
                </div>

                <div className="flex items-center justify-between text-[11px] font-mono text-gray-400 pt-2 border-t border-white/5">
                  <span>Throughput: {model.benchmarkScores.efficiencyTokensPerSec} t/s</span>
                  <span className="text-orange-400">₹{model.pricingPer1kTokensINR}/1k tokens</span>
                </div>

                <div className="text-[11px] text-gray-500 bg-white/5 p-2 rounded">
                  <span className="text-gray-400 font-medium">Known Limitations:</span> {model.knownLimitations[0]}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 2: TOURNAMENTS */}
      {activeTab === 'tournaments' && (
        <div className="space-y-6">
          {/* Tournament Match Launcher Box */}
          <div className="p-6 rounded-2xl bg-[#0c101a] border border-white/10 space-y-4">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center space-x-2">
                <Swords className="w-5 h-5 text-orange-400" />
                <h2 className="text-base font-bold text-white font-display">
                  Launch Head-to-Head Model Tournament
                </h2>
              </div>
              <span className="text-xs text-gray-400 font-mono">
                Multidimensional Empirical Scoring
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="text-xs font-mono text-gray-400 block mb-1">Candidate Model A</label>
                <select
                  value={candidateAId}
                  onChange={e => setCandidateAId(e.target.value)}
                  className="w-full p-2 bg-[#07090e] border border-white/10 rounded-lg text-xs text-white font-mono focus:outline-none"
                >
                  {modelFamily.map(m => (
                    <option key={m.id} value={m.id}>{m.name} ({m.parameters})</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-xs font-mono text-gray-400 block mb-1">Candidate Model B</label>
                <select
                  value={candidateBId}
                  onChange={e => setCandidateBId(e.target.value)}
                  className="w-full p-2 bg-[#07090e] border border-white/10 rounded-lg text-xs text-white font-mono focus:outline-none"
                >
                  {modelFamily.map(m => (
                    <option key={m.id} value={m.id}>{m.name} ({m.parameters})</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-xs font-mono text-gray-400 block mb-1">Evaluation Suite</label>
                <select
                  value={selectedSuite}
                  onChange={e => setSelectedSuite(e.target.value)}
                  className="w-full p-2 bg-[#07090e] border border-white/10 rounded-lg text-xs text-white font-mono focus:outline-none"
                >
                  {suites.map(s => (
                    <option key={s} value={s}>{s}</option>
                  ))}
                </select>
              </div>
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={handleLaunchTournament}
                className="px-4 py-2 bg-orange-500 hover:bg-orange-600 text-white rounded-lg text-xs font-bold transition flex items-center space-x-1.5"
              >
                <Play className="w-3.5 h-3.5" />
                <span>Execute Head-to-Head Comparison</span>
              </button>
            </div>
          </div>

          {/* Past Tournament Results */}
          <div className="space-y-4">
            <h3 className="text-sm font-bold uppercase tracking-wider text-gray-400 font-mono">
              Recorded Head-to-Head Tournaments
            </h3>

            <div className="space-y-3">
              {tournamentMatches.map(match => (
                <div key={match.id} className="p-5 rounded-xl bg-[#0a0e17] border border-white/10 space-y-3">
                  <div className="flex items-start justify-between">
                    <div>
                      <span className="text-xs font-mono text-orange-400">{match.benchmarkSuite}</span>
                      <div className="text-base font-bold text-white mt-0.5">
                        {match.candidateA} <span className="text-gray-500 font-normal">vs</span> {match.candidateB}
                      </div>
                      <div className="text-[11px] font-mono text-gray-500">
                        Platform: {match.hardwarePlatform} • {match.timestamp}
                      </div>
                    </div>

                    <div className="text-right">
                      <div className="text-sm font-bold text-emerald-400 font-mono">
                        Winner: {match.winner}
                      </div>
                      <div className="text-xs text-gray-400 font-mono">
                        {match.scoreA} pts vs {match.scoreB} pts
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 border-t border-white/5 text-xs font-mono">
                    <div className="p-2 bg-white/5 rounded">
                      <span className="text-gray-500 block text-[10px]">ACCURACY</span>
                      <span className="text-gray-300">{match.dimensions.accuracy}</span>
                    </div>
                    <div className="p-2 bg-white/5 rounded">
                      <span className="text-gray-500 block text-[10px]">LATENCY</span>
                      <span className="text-gray-300">{match.dimensions.latency}</span>
                    </div>
                    <div className="p-2 bg-white/5 rounded">
                      <span className="text-gray-500 block text-[10px]">COMPUTE COST</span>
                      <span className="text-gray-300">{match.dimensions.cost}</span>
                    </div>
                    <div className="p-2 bg-white/5 rounded">
                      <span className="text-gray-500 block text-[10px]">SAFETY AUDIT</span>
                      <span className="text-gray-300">{match.dimensions.safety}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: METHODOLOGY */}
      {activeTab === 'methodology' && (
        <div className="space-y-6">
          <div className="p-6 rounded-2xl bg-[#0a0e17] border border-white/10 space-y-4">
            <h2 className="text-lg font-bold text-white font-display flex items-center space-x-2">
              <ShieldCheck className="w-5 h-5 text-emerald-400" />
              <span>Zero-Contamination Benchmark Policy</span>
            </h2>
            <p className="text-xs text-gray-300 leading-relaxed max-w-4xl">
              Model scores are never fabricated or cherry-picked. Bharat HyperCompute Cloud enforces strict 13-gram test-set de-contamination, verifiable evaluation seeds, and multi-run uncertainty estimation before admitting any candidate into the Sovereign Model Registry.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4 border-t border-white/5">
              <div className="p-4 bg-white/5 rounded-xl space-y-2">
                <div className="text-xs font-bold text-orange-400 font-mono">1. De-Contamination Scan</div>
                <p className="text-xs text-gray-400">
                  All training corpora are hashed against GSM8K, MMLU, and IndicBench test tokens. Any n-gram overlaps &gt; 0.05% trigger quarantine.
                </p>
              </div>

              <div className="p-4 bg-white/5 rounded-xl space-y-2">
                <div className="text-xs font-bold text-emerald-400 font-mono">2. Multi-Run Determinism</div>
                <p className="text-xs text-gray-400">
                  Every benchmark run reports mean and standard deviation across 3 separate random inference seeds on fixed vLLM configurations.
                </p>
              </div>

              <div className="p-4 bg-white/5 rounded-xl space-y-2">
                <div className="text-xs font-bold text-sky-400 font-mono">3. Reproducible Manifests</div>
                <p className="text-xs text-gray-400">
                  Evaluation results are tied directly to an immutable Git SHA, PyTorch wheel version, and CUDA kernel configuration.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
