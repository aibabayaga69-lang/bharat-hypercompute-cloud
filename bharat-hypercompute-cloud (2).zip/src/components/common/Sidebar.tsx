import React from 'react';
import { useApp, AppView } from '../../context/AppContext';
import { MII_BRAND } from './BrandIdentity';
import {
  LayoutDashboard,
  BookOpen,
  BrainCircuit,
  FlaskConical,
  Database,
  Box,
  Rocket,
  BarChart3,
  Bot,
  MapPin,
  Building2,
  ShieldAlert,
  Settings,
  X,
  Radio,
  ExternalLink,
  TrendingUp,
  Radar,
  Compass,
  DollarSign,
  Award,
  Coins,
  ShieldCheck,
  Send
} from 'lucide-react';

interface SidebarProps {
  mobileOpen?: boolean;
  onCloseMobile?: () => void;
}

interface NavItem {
  id: AppView;
  label: string;
  icon: React.ElementType;
  badge?: string;
  category?: string;
}

export const Sidebar: React.FC<SidebarProps> = ({ mobileOpen, onCloseMobile }) => {
  const { currentView, setCurrentView, selfHealingState } = useApp();

  const navItems: NavItem[] = [
    { id: 'overview', label: 'Overview', icon: LayoutDashboard },
    { id: 'notebooks', label: 'Notebooks', icon: BookOpen, badge: 'Active' },
    { id: 'compute_brain', label: 'Compute Brain', icon: BrainCircuit, badge: 'Core' },
    { id: 'experiments', label: 'Experiment Lab', icon: FlaskConical },
    { id: 'datasets', label: 'Dataset Center', icon: Database },
    { id: 'models', label: 'Model Registry', icon: Box },
    { id: 'deployments', label: 'Model → API', icon: Rocket, badge: 'Live' },
    { id: 'usage', label: 'Usage & Compute', icon: BarChart3 },
    { id: 'autopilot', label: 'Research Autopilot', icon: Bot, category: 'Advanced Research' },
    { id: 'compute_map', label: 'Market & Fabric', icon: MapPin, category: 'Advanced Research', badge: 'Wholesale' },
    { id: 'research_radar', label: 'Research Radar', icon: Compass, category: 'Advanced Research' },
    { id: 'resource_radar', label: 'Free Resource Radar', icon: Radar, category: 'Advanced Research' },
    { id: 'knowledge_engine', label: 'Knowledge Engine', icon: BrainCircuit, category: 'Collective Intelligence', badge: 'Core' },
    { id: 'benchmark_lab', label: 'Benchmark Lab', icon: Award, category: 'Collective Intelligence' },
    { id: 'company_brain', label: 'Company Brain', icon: BrainCircuit, category: 'AI Organization', badge: '1,000 Agents' },
    { id: 'ai_org_os', label: '1,000-AI Org OS', icon: ShieldAlert, category: 'AI Organization', badge: 'Privileged' },
    { id: 'growth_marketing', label: 'Growth & Marketing', icon: TrendingUp, category: 'AI Organization' },
    { id: 'launch_center', label: 'Launch Center', icon: Send, category: 'AI Organization', badge: 'Day-0' },
    { id: 'crypto_gateway', label: 'Crypto & Checkout', icon: Coins, category: 'Payments & Audits', badge: 'YGO/YUSD' },
    { id: 'expert_audit', label: '1B-Perspective Audit', icon: ShieldCheck, category: 'Payments & Audits', badge: '10 Loops' },
    { id: 'organization', label: 'Organization', icon: Building2, category: 'Management' },
    { id: 'admin', label: 'Admin Center', icon: ShieldAlert, category: 'Management' },
    { id: 'settings', label: 'Settings & Secrets', icon: Settings, category: 'Management' }
  ];

  const handleNavClick = (view: AppView) => {
    setCurrentView(view);
    if (onCloseMobile) onCloseMobile();
  };

  const content = (
    <div className="flex flex-col h-full justify-between py-4 px-3">
      {/* Navigation List */}
      <div className="space-y-6">
        {/* Mobile Header Close */}
        <div className="flex items-center justify-between px-2 md:hidden border-b border-white/10 pb-3">
          <div>
            <div className="text-[10px] font-mono text-orange-400 font-bold uppercase tracking-wider">
              {MII_BRAND.parentBrand}
            </div>
            <div className="font-display font-bold text-white text-sm">
              {MII_BRAND.productName}
            </div>
            <div className="text-[10px] font-mono text-amber-300">
              {MII_BRAND.officialTagline}
            </div>
          </div>
          <button
            onClick={onCloseMobile}
            className="p-1 rounded text-gray-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Primary Navigation */}
        <div className="space-y-1">
          <div className="px-2 pb-1 text-[10px] font-mono uppercase tracking-wider text-gray-400">
            Core Research Loop
          </div>
          {navItems.filter(item => !item.category).map(item => {
            const Icon = item.icon;
            const isActive = currentView === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={`w-full flex items-center justify-between px-2.5 py-2 rounded-lg text-xs font-medium transition ${
                  isActive
                    ? 'bg-orange-500/15 text-orange-400 border border-orange-500/30'
                    : 'text-gray-400 hover:text-gray-200 hover:bg-white/5'
                }`}
              >
                <div className="flex items-center space-x-2.5 truncate">
                  <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-orange-400' : 'text-gray-400'}`} />
                  <span className="truncate">{item.label}</span>
                </div>
                {item.badge && (
                  <span
                    className={`text-[9px] font-mono px-1.5 py-0.5 rounded ${
                      item.badge === 'Live'
                        ? 'bg-emerald-950 text-emerald-400 border border-emerald-800/40'
                        : 'bg-white/10 text-gray-300'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Advanced Research Section */}
        <div className="space-y-1">
          <div className="px-2 pb-1 text-[10px] font-mono uppercase tracking-wider text-gray-400">
            Advanced Compute
          </div>
          {navItems.filter(item => item.category === 'Advanced Research').map(item => {
            const Icon = item.icon;
            const isActive = currentView === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={`w-full flex items-center justify-between px-2.5 py-2 rounded-lg text-xs font-medium transition ${
                  isActive
                    ? 'bg-orange-500/15 text-orange-400 border border-orange-500/30'
                    : 'text-gray-400 hover:text-gray-200 hover:bg-white/5'
                }`}
              >
                <div className="flex items-center space-x-2.5 truncate">
                  <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-orange-400' : 'text-gray-400'}`} />
                  <span className="truncate">{item.label}</span>
                </div>
                {item.badge && (
                  <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-white/10 text-gray-300">
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Collective Intelligence Section */}
        <div className="space-y-1">
          <div className="px-2 pb-1 text-[10px] font-mono uppercase tracking-wider text-gray-400">
            Collective Intelligence
          </div>
          {navItems.filter(item => item.category === 'Collective Intelligence').map(item => {
            const Icon = item.icon;
            const isActive = currentView === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={`w-full flex items-center justify-between px-2.5 py-2 rounded-lg text-xs font-medium transition ${
                  isActive
                    ? 'bg-orange-500/15 text-orange-400 border border-orange-500/30'
                    : 'text-gray-400 hover:text-gray-200 hover:bg-white/5'
                }`}
              >
                <div className="flex items-center space-x-2.5 truncate">
                  <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-orange-400' : 'text-gray-400'}`} />
                  <span className="truncate">{item.label}</span>
                </div>
                {item.badge && (
                  <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-orange-500/20 text-orange-400 border border-orange-500/30">
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* AI Organization & Growth Section */}
        <div className="space-y-1">
          <div className="px-2 pb-1 text-[10px] font-mono uppercase tracking-wider text-gray-400">
            AI Organization & Growth
          </div>
          {navItems.filter(item => item.category === 'AI Organization').map(item => {
            const Icon = item.icon;
            const isActive = currentView === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={`w-full flex items-center justify-between px-2.5 py-2 rounded-lg text-xs font-medium transition ${
                  isActive
                    ? 'bg-orange-500/15 text-orange-400 border border-orange-500/30'
                    : 'text-gray-400 hover:text-gray-200 hover:bg-white/5'
                }`}
              >
                <div className="flex items-center space-x-2.5 truncate">
                  <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-orange-400' : 'text-gray-400'}`} />
                  <span className="truncate">{item.label}</span>
                </div>
                {item.badge && (
                  <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-white/10 text-gray-300">
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Payments & Audits Section */}
        <div className="space-y-1">
          <div className="px-2 pb-1 text-[10px] font-mono uppercase tracking-wider text-gray-400">
            Payments & Audits
          </div>
          {navItems.filter(item => item.category === 'Payments & Audits').map(item => {
            const Icon = item.icon;
            const isActive = currentView === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={`w-full flex items-center justify-between px-2.5 py-2 rounded-lg text-xs font-medium transition ${
                  isActive
                    ? 'bg-orange-500/15 text-orange-400 border border-orange-500/30'
                    : 'text-gray-400 hover:text-gray-200 hover:bg-white/5'
                }`}
              >
                <div className="flex items-center space-x-2.5 truncate">
                  <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-orange-400' : 'text-gray-400'}`} />
                  <span className="truncate">{item.label}</span>
                </div>
                {item.badge && (
                  <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-white/10 text-gray-300">
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Management & Admin Section */}
        <div className="space-y-1">
          <div className="px-2 pb-1 text-[10px] font-mono uppercase tracking-wider text-gray-400">
            Governance & Admin
          </div>
          {navItems.filter(item => item.category === 'Management').map(item => {
            const Icon = item.icon;
            const isActive = currentView === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={`w-full flex items-center justify-between px-2.5 py-2 rounded-lg text-xs font-medium transition ${
                  isActive
                    ? 'bg-orange-500/15 text-orange-400 border border-orange-500/30'
                    : 'text-gray-400 hover:text-gray-200 hover:bg-white/5'
                }`}
              >
                <div className="flex items-center space-x-2.5 truncate">
                  <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-orange-400' : 'text-gray-400'}`} />
                  <span className="truncate">{item.label}</span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Sidebar Footer: Active Pod Status */}
      <div className="pt-4 border-t border-white/10 space-y-2">
        <div className="bg-black/50 border border-white/10 rounded-lg p-2.5">
          <div className="flex items-center justify-between mb-1 text-[11px]">
            <span className="text-gray-400 font-mono">Cluster Status</span>
            <span className="flex items-center space-x-1 text-emerald-400 font-mono text-[10px]">
              <Radio className="w-2.5 h-2.5 animate-pulse" />
              <span>ONLINE</span>
            </span>
          </div>
          <div className="text-xs text-white font-medium truncate">
            4× BHARAT H100 SXM5
          </div>
          <div className="text-[10px] text-gray-400 font-mono mt-0.5 flex justify-between">
            <span>DDP Cluster #04</span>
            <span className="text-amber-400">Simulated Pod</span>
          </div>

          {selfHealingState.isActive && (
            <div className="mt-2 pt-2 border-t border-white/10 text-[10px] font-mono">
              <div className="flex justify-between text-gray-300">
                <span>Self-Healing Trainer</span>
                <span className={selfHealingState.status === 'interrupted' ? 'text-rose-400 font-bold' : 'text-emerald-400'}>
                  {selfHealingState.status.toUpperCase()}
                </span>
              </div>
              <div className="w-full bg-white/10 h-1 rounded-full mt-1 overflow-hidden">
                <div
                  className={`h-full transition-all duration-300 ${
                    selfHealingState.status === 'interrupted' ? 'bg-rose-500' : 'bg-orange-500'
                  }`}
                  style={{ width: `${(selfHealingState.currentStep / selfHealingState.totalSteps) * 100}%` }}
                />
              </div>
            </div>
          )}
        </div>

        {/* Public portal link */}
        <button
          onClick={() => handleNavClick('landing')}
          className="w-full flex items-center justify-center space-x-1.5 py-1.5 text-gray-400 hover:text-white text-[11px] rounded hover:bg-white/5 transition"
        >
          <span>Landing Showcase</span>
          <ExternalLink className="w-3 h-3" />
        </button>

        {/* MII Brand & Positioning Strip */}
        <div className="pt-2.5 border-t border-white/5 text-center space-y-0.5">
          <div className="text-[9px] font-mono text-orange-400 font-bold uppercase tracking-wider">
            {MII_BRAND.parentBrand}
          </div>
          <div className="text-[8.5px] font-mono text-gray-300 uppercase">
            {MII_BRAND.positioning}
          </div>
          <div className="text-[8.5px] font-mono text-amber-400/90">
            {MII_BRAND.officialTagline}
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop Persistent Sidebar */}
      <aside className="hidden md:flex flex-col w-60 shrink-0 border-r border-white/10 bg-[#07090e]/60 min-h-[calc(100vh-3.5rem)]">
        {content}
      </aside>

      {/* Mobile Drawer */}
      {mobileOpen && (
        <div className="fixed inset-0 z-50 flex md:hidden">
          <div
            className="fixed inset-0 bg-black/80 backdrop-blur-sm"
            onClick={onCloseMobile}
          />
          <div className="relative w-64 bg-[#0a0e17] border-r border-white/10 z-10">
            {content}
          </div>
        </div>
      )}
    </>
  );
};
