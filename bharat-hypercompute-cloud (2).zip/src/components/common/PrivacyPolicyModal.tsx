import React from 'react';
import { X, ShieldCheck, ExternalLink, Lock } from 'lucide-react';
import { MII_BRAND } from './BrandIdentity';

interface PrivacyPolicyModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PrivacyPolicyModal: React.FC<PrivacyPolicyModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="relative w-full max-w-4xl max-h-[90vh] bg-[#0c101a] border border-white/10 rounded-2xl shadow-2xl flex flex-col overflow-hidden text-gray-200">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/10 bg-black/40">
          <div className="flex items-center space-x-3">
            <div className="p-2 rounded-lg bg-orange-500/10 border border-orange-500/20 text-orange-400">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs font-mono text-orange-400 font-semibold tracking-wider uppercase">
                {MII_BRAND.parentBrand} • Official Legal Notice
              </div>
              <h2 className="text-lg font-bold text-white tracking-tight">
                Privacy Policy — {MII_BRAND.productName}
              </h2>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <a
              href="/privacy.html"
              target="_blank"
              rel="noopener noreferrer"
              className="px-3 py-1.5 text-xs font-mono text-cyan-400 hover:text-cyan-300 bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-500/30 rounded-lg flex items-center space-x-1.5 transition-colors"
            >
              <span>Open Standalone</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
            <button
              onClick={onClose}
              className="p-2 text-gray-400 hover:text-white hover:bg-white/10 rounded-lg transition-colors"
              aria-label="Close modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 text-sm leading-relaxed text-gray-300">
          
          <div className="p-4 rounded-xl bg-white/[0.03] border border-white/5 font-mono text-xs text-gray-400 space-y-1">
            <div><strong className="text-white">Effective Date:</strong> September 21, 2026 &nbsp;|&nbsp; <strong className="text-white">Last Updated:</strong> September 21, 2026</div>
            <div><strong className="text-white">Founder Attribution:</strong> {MII_BRAND.founderAttribution}</div>
            <div><strong className="text-white">Official URL:</strong> <a href="/privacy.html" className="text-orange-400 underline">https://bharat-hypercompute.in/privacy.html</a></div>
          </div>

          <section className="space-y-2">
            <h3 className="text-base font-bold text-white border-l-2 border-orange-500 pl-3">1. Introduction</h3>
            <p>Welcome to BHARAT HYPERCOMPUTE CLOUD, a technology platform operated under the MII brand.</p>
            <p>This Privacy Policy explains how information may be handled when you use our website, web application, progressive web application, or future mobile application (collectively, the “Service”).</p>
            <p>We aim to follow a privacy-by-design approach and collect only information reasonably necessary to operate, secure, improve, and support the Service.</p>
          </section>

          <section className="space-y-2">
            <h3 className="text-base font-bold text-white border-l-2 border-orange-500 pl-3">2. Information We May Handle</h3>
            <p>Depending on how you use the Service and which capabilities are enabled, the Service may handle:</p>
            <ul className="list-disc pl-5 space-y-1 text-gray-300">
              <li><strong>Information you provide:</strong> Name/display name, email address, account info, notebook content, experiment configurations, uploaded datasets, model metadata, deployment configurations, and support requests.</li>
              <li><strong>Technical and application information:</strong> Browser type, operating system, application version, device/session info, security logs, preferences, and locally stored application state.</li>
              <li><strong>Research and compute information:</strong> Experiment metadata, configuration parameters, notebook cells, model/dataset metadata, checkpoint metadata, resource-selection info, and audit trails.</li>
            </ul>
            <div className="p-3 bg-orange-500/10 border border-orange-500/20 rounded-lg text-xs text-orange-200">
              <strong>Local-First Notice:</strong> Where data is stored locally in the current application, it remains in your browser/device storage rather than being transmitted to a cloud backend.
            </div>
          </section>

          <section className="space-y-2">
            <h3 className="text-base font-bold text-white border-l-2 border-orange-500 pl-3">3. Customer Data and AI Training</h3>
            <p>Your private customer data is not automatically treated as global training data.</p>
            <p>Private prompts, private code, private datasets, secrets, credentials, personally identifiable information, restricted information, and confidential enterprise information are not automatically added to a global knowledge or model-training system.</p>
            <p>Potential data classifications include: <code className="text-cyan-300">PUBLIC</code>, <code className="text-cyan-300">ORGANIZATION</code>, <code className="text-cyan-300">PROJECT</code>, <code className="text-cyan-300">PRIVATE</code>, <code className="text-cyan-300">CONSENTED_GLOBAL_KNOWLEDGE</code>, <code className="text-cyan-300">PLATFORM_RESEARCH</code>.</p>
          </section>

          <section className="space-y-2">
            <h3 className="text-base font-bold text-white border-l-2 border-orange-500 pl-3">4. Third-Party AI, Cloud, and Compute Providers</h3>
            <p>Some advanced capabilities may require external providers or APIs (e.g., AI model inference, GPU/TPU providers, cloud storage, payment or blockchain RPC providers).</p>
            <p>These integrations are enabled only where configured and available. The Service does not represent simulated or unconnected provider functionality as live infrastructure.</p>
          </section>

          <section className="space-y-2">
            <h3 className="text-base font-bold text-white border-l-2 border-orange-500 pl-3">5. Current Local-First Operation</h3>
            <p>Parts of the current Service operate using browser memory, local storage, and locally processed deterministic operations. Local storage should not be treated as a guaranteed permanent backup.</p>
          </section>

          <section className="space-y-2">
            <h3 className="text-base font-bold text-white border-l-2 border-orange-500 pl-3">6. Security</h3>
            <p>We use reasonable technical and organizational measures appropriate to the current architecture to protect information (access controls, role-based authorization, session controls, HTTPS, secure network configuration, API-key masking, audit records, and approval controls).</p>
            <p>Do not upload passwords, private keys, wallet seed phrases, or other secrets unless the relevant feature explicitly requires and securely supports them.</p>
          </section>

          <section className="space-y-2">
            <h3 className="text-base font-bold text-white border-l-2 border-orange-500 pl-3">7. Payments and Cryptocurrency</h3>
            <p>Where payment functionality is only demonstrated or simulated, no real payment settlement is represented as having occurred. We do not request or intentionally store plaintext cryptocurrency private keys or wallet seed phrases.</p>
          </section>

          <section className="space-y-2">
            <h3 className="text-base font-bold text-white border-l-2 border-orange-500 pl-3">8. Data Sharing & Retention</h3>
            <p>We do not sell personal information as a business practice. We retain information only for as long as reasonably necessary to provide the Service, maintain security, satisfy legal obligations, or enforce agreements.</p>
          </section>

          <section className="space-y-2">
            <h3 className="text-base font-bold text-white border-l-2 border-orange-500 pl-3">9. Account and Data Deletion</h3>
            <p>Users may clear or delete their locally stored session data, research notebooks, and experiment states at any time via the in-app Settings or by clearing application data in their browser/device settings.</p>
          </section>

          <section className="space-y-2">
            <h3 className="text-base font-bold text-white border-l-2 border-orange-500 pl-3">10. Contact & Disclosures</h3>
            <div className="p-4 rounded-xl bg-white/[0.02] border border-white/10 space-y-1.5 text-xs font-mono">
              <div className="text-white font-bold">{MII_BRAND.parentBrand} • {MII_BRAND.productName}</div>
              <div>Privacy Contact: <a href="mailto:privacy@bharatcloud.in" className="text-cyan-400">privacy@bharatcloud.in</a></div>
              <div>Legal Framework: Designed in alignment with India's DPDP Act and international privacy-by-design standards.</div>
            </div>
          </section>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-white/10 bg-black/40 flex items-center justify-between text-xs text-gray-400 font-mono">
          <div className="flex items-center space-x-1.5">
            <Lock className="w-3.5 h-3.5 text-emerald-400" />
            <span>Local Data Isolation Active</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-white/10 hover:bg-white/20 text-white rounded-lg transition-colors font-sans text-xs font-medium"
          >
            Acknowledge & Close
          </button>
        </div>

      </div>
    </div>
  );
};
