import React, { useState } from 'react';
import { ShieldCheck, Sparkles, Cpu, ExternalLink } from 'lucide-react';
import { PrivacyPolicyModal } from './PrivacyPolicyModal';

export const MII_BRAND = {
  parentBrand: 'MII — THE BRAND',
  productName: 'BHARAT HYPERCOMPUTE CLOUD',
  positioning: 'BUILD AI. WE HANDLE THE COMPUTE.',
  officialTagline: '🇮🇳 Make in India. Made for 🇮🇳 Make in India (MII). 🇮🇳',
  founder: 'Dhaval Batwal',
  founderAttribution: 'Founded by Dhaval Batwal',
};

/**
 * Top-level or persistent brand header strip
 */
export const BrandHeaderStrip: React.FC<{ className?: string }> = ({
  className = ''
}) => {
  return (
    <div className={`flex items-center justify-between px-3 sm:px-6 py-1.5 border-b border-white/10 bg-black/70 text-[11px] font-mono text-gray-300 ${className}`}>
      <div className="flex items-center space-x-2 truncate">
        <span className="text-orange-400 font-bold uppercase tracking-wider shrink-0">
          {MII_BRAND.parentBrand}
        </span>
        <span className="text-gray-600 shrink-0">/</span>
        <span className="text-white font-medium shrink-0">
          {MII_BRAND.productName}
        </span>
        <span className="text-gray-600 shrink-0 hidden md:inline">|</span>
        <span className="text-amber-300 font-medium truncate text-[10px] sm:text-[11px] hidden sm:inline">
          {MII_BRAND.officialTagline}
        </span>
      </div>
    </div>
  );
};

/**
 * High-visibility Tagline Pill
 */
export const BrandTaglineBadge: React.FC<{ size?: 'sm' | 'md' | 'lg'; className?: string }> = ({
  size = 'sm',
  className = ''
}) => {
  const sizeClasses = {
    sm: 'text-[10px] px-2.5 py-1',
    md: 'text-xs px-3 py-1.5',
    lg: 'text-sm px-4 py-2 font-semibold'
  }[size];

  return (
    <div
      className={`inline-flex items-center space-x-1.5 font-mono rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 shadow-sm ${sizeClasses} ${className}`}
      title={MII_BRAND.officialTagline}
    >
      <span className="truncate">{MII_BRAND.officialTagline}</span>
    </div>
  );
};

/**
 * Minimalist Founder Attribution Label
 */
export const FounderAttribution: React.FC<{ className?: string }> = ({ className = '' }) => {
  return (
    <div className={`text-xs font-mono text-gray-400 ${className}`}>
      <span>{MII_BRAND.founderAttribution}</span>
    </div>
  );
};

/**
 * Unified Sovereign Footer Component
 */
export const SovereignFooter: React.FC<{ onNavigate?: (view: any) => void; className?: string }> = ({
  onNavigate,
  className = ''
}) => {
  const [isPrivacyOpen, setIsPrivacyOpen] = useState(false);

  return (
    <footer className={`border-t border-white/10 bg-[#05070c] text-gray-400 text-xs font-mono pt-12 pb-10 px-4 sm:px-6 lg:px-8 ${className}`}>
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Top Footer Row */}
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 pb-8 border-b border-white/10">
          <div className="space-y-2">
            <div className="flex items-center space-x-2">
              <div className="h-6 w-6 rounded bg-gradient-to-br from-orange-500 to-amber-600 flex items-center justify-center text-white">
                <Cpu className="w-3.5 h-3.5" />
              </div>
              <span className="font-bold text-white text-sm font-display tracking-tight">
                {MII_BRAND.productName}
              </span>
              <span className="text-gray-600">/</span>
              <span className="text-orange-400 font-bold">{MII_BRAND.parentBrand}</span>
            </div>
            <div className="text-[11px] text-amber-400/90 font-medium">
              {MII_BRAND.officialTagline}
            </div>
            <div className="text-gray-300 font-sans text-xs">
              {MII_BRAND.positioning}
            </div>
          </div>

          <div className="flex flex-col items-start md:items-end space-y-1">
            <div className="text-white font-medium text-xs">
              {MII_BRAND.founderAttribution}
            </div>
            <div className="text-[10px] text-gray-500 max-w-sm text-left md:text-right">
              Founder attribution is branding and company identity information. Zero fictitious legal claims or undisclosed affiliations.
            </div>
          </div>
        </div>

        {/* Middle Navigation Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-6 text-[11px]">
          <div className="space-y-2">
            <div className="text-white font-bold uppercase tracking-wider text-[10px]">Compute Fabric</div>
            <ul className="space-y-1.5 text-gray-400">
              <li>BHARAT H100 SXM5</li>
              <li>BHARAT A100 TensorCore</li>
              <li>BHARAT TPU v4 Pods</li>
              <li>On-Premise Node Connectors</li>
            </ul>
          </div>

          <div className="space-y-2">
            <div className="text-white font-bold uppercase tracking-wider text-[10px]">Research Engine</div>
            <ul className="space-y-1.5 text-gray-400">
              <li>Compute Brain Intent Parser</li>
              <li>Experiment DNA Provenance</li>
              <li>Self-Healing Training Checkpoints</li>
              <li>Collective Knowledge Engine</li>
            </ul>
          </div>

          <div className="space-y-2">
            <div className="text-white font-bold uppercase tracking-wider text-[10px]">Company & Governance</div>
            <ul className="space-y-1.5 text-gray-400">
              <li>MII AI Organization (1,000 Capacity)</li>
              <li>L0–L5 Human-in-the-Loop Gates</li>
              <li>Pre-Launch Audit Gate (30 Dimensions)</li>
              <li>
                <button
                  onClick={() => setIsPrivacyOpen(true)}
                  className="hover:text-orange-400 transition-colors text-left"
                >
                  Official Privacy Policy
                </button>
              </li>
            </ul>
          </div>

          <div className="space-y-2">
            <div className="text-white font-bold uppercase tracking-wider text-[10px]">National Sovereignty</div>
            <ul className="space-y-1.5 text-gray-400">
              <li>Delhi NCR Pod 01</li>
              <li>Mumbai West Pod 02</li>
              <li>Bengaluru Central Pod 03</li>
              <li>MeitY / DPDP Act Compliant</li>
            </ul>
          </div>
        </div>

        {/* Bottom Strip */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-6 border-t border-white/5 text-[10px] text-gray-400">
          <div className="flex items-center space-x-3">
            <span>© {new Date().getFullYear()} {MII_BRAND.parentBrand} • {MII_BRAND.productName}. All rights reserved.</span>
            <span>•</span>
            <button
              onClick={() => setIsPrivacyOpen(true)}
              className="hover:text-white underline underline-offset-4 decoration-white/20 transition-colors"
            >
              Privacy Policy
            </button>
          </div>
          <div className="flex items-center space-x-4">
            <span className="text-emerald-400 flex items-center space-x-1">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
              <span>Sovereign Pod Fabric Online</span>
            </span>
            <span>{MII_BRAND.founderAttribution}</span>
          </div>
        </div>
      </div>

      {/* Standalone & In-App Privacy Policy Modal */}
      <PrivacyPolicyModal isOpen={isPrivacyOpen} onClose={() => setIsPrivacyOpen(false)} />
    </footer>
  );
};
