import React from 'react';

export type TrustType =
  | 'REAL'
  | 'VERIFIED_REAL'
  | 'SIMULATED'
  | 'DEMO'
  | 'ESTIMATED'
  | 'SUGGESTED'
  | 'APPROVED'
  | 'EXECUTED'
  | 'BLOCKED'
  | 'REQUIRES_PROVIDER'
  | 'REQUIRES_API'
  | 'REQUIRES_HUMAN_REVIEW'
  | 'UNVERIFIED';

interface TrustBadgeProps {
  type: TrustType;
  className?: string;
  size?: 'xs' | 'sm' | 'md';
}

const trustConfig: Record<TrustType, { label: string; bg: string; text: string; border: string; desc: string }> = {
  REAL: {
    label: 'VERIFIED REAL',
    bg: 'bg-emerald-950/60',
    text: 'text-emerald-400',
    border: 'border-emerald-700/50',
    desc: 'Actual connected hardware or verified infrastructure.'
  },
  VERIFIED_REAL: {
    label: 'VERIFIED REAL',
    bg: 'bg-emerald-950/60',
    text: 'text-emerald-400',
    border: 'border-emerald-700/50',
    desc: 'Actual connected hardware or verified infrastructure.'
  },
  UNVERIFIED: {
    label: 'UNVERIFIED',
    bg: 'bg-zinc-950/60',
    text: 'text-zinc-400',
    border: 'border-zinc-700/50',
    desc: 'Unverified external claim or unbenchmarked metric.'
  },
  SIMULATED: {
    label: 'SIMULATED',
    bg: 'bg-amber-950/60',
    text: 'text-amber-400',
    border: 'border-amber-700/50',
    desc: 'Simulated high-fidelity environment. No live physical hardware claim.'
  },
  DEMO: {
    label: 'SIMULATED',
    bg: 'bg-amber-950/60',
    text: 'text-amber-400',
    border: 'border-amber-700/50',
    desc: 'Simulated high-fidelity environment. No live physical hardware claim.'
  },
  ESTIMATED: {
    label: 'ESTIMATED',
    bg: 'bg-sky-950/60',
    text: 'text-sky-400',
    border: 'border-sky-700/50',
    desc: 'Predicted compute usage, runtime, or cost calculation.'
  },
  SUGGESTED: {
    label: 'SUGGESTED',
    bg: 'bg-indigo-950/60',
    text: 'text-indigo-400',
    border: 'border-indigo-700/50',
    desc: 'AI Compute Brain recommendation awaiting user approval.'
  },
  APPROVED: {
    label: 'APPROVED',
    bg: 'bg-teal-950/60',
    text: 'text-teal-400',
    border: 'border-teal-700/50',
    desc: 'User reviewed and authorized the execution plan.'
  },
  EXECUTED: {
    label: 'EXECUTED',
    bg: 'bg-blue-950/60',
    text: 'text-blue-400',
    border: 'border-blue-700/50',
    desc: 'Operation was physically performed and recorded in state.'
  },
  BLOCKED: {
    label: 'BLOCKED',
    bg: 'bg-rose-950/60',
    text: 'text-rose-400',
    border: 'border-rose-700/50',
    desc: 'Safety policy, budget ceiling, or lack of authorization blocked execution.'
  },
  REQUIRES_PROVIDER: {
    label: 'REQUIRES_PROVIDER',
    bg: 'bg-purple-950/60',
    text: 'text-purple-400',
    border: 'border-purple-700/50',
    desc: 'Needs an external physical cloud provider or on-prem cluster credential.'
  },
  REQUIRES_API: {
    label: 'REQUIRES_API',
    bg: 'bg-indigo-950/60',
    text: 'text-indigo-400',
    border: 'border-indigo-700/50',
    desc: 'Needs valid API credentials or remote endpoint configuration.'
  },
  REQUIRES_HUMAN_REVIEW: {
    label: 'REQUIRES_HUMAN_REVIEW',
    bg: 'bg-orange-950/60',
    text: 'text-orange-400',
    border: 'border-orange-700/50',
    desc: 'Requires explicit human supervisor verification before proceeding.'
  }
};

export const TrustBadge: React.FC<TrustBadgeProps> = ({ type, className = '', size = 'xs' }) => {
  const cfg = trustConfig[type] || trustConfig.DEMO;
  
  const sizeClasses = {
    xs: 'text-[10px] px-1.5 py-0.5 tracking-wider',
    sm: 'text-xs px-2 py-0.5 tracking-wider',
    md: 'text-sm px-2.5 py-1 tracking-wide'
  }[size];

  return (
    <span
      title={`${cfg.label}: ${cfg.desc}`}
      className={`inline-flex items-center font-mono font-bold rounded uppercase border ${cfg.bg} ${cfg.text} ${cfg.border} ${sizeClasses} ${className}`}
    >
      {cfg.label}
    </span>
  );
};
