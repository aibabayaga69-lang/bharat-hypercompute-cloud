import React, { useState, useEffect, useRef } from 'react';
import { useApp, AppView } from '../../context/AppContext';
import {
  Search,
  BookOpen,
  BrainCircuit,
  FlaskConical,
  Database,
  Box,
  Rocket,
  ShieldAlert,
  Zap,
  Sparkles,
  RefreshCw,
  X,
  Sliders,
  Crown,
  TrendingUp,
  Radar,
  Compass,
  MapPin,
  Award,
  Coins,
  ShieldCheck,
  Send
} from 'lucide-react';

export const CommandPalette: React.FC = () => {
  const {
    isCommandPaletteOpen,
    setCommandPaletteOpen,
    setCurrentView,
    toggleEntitlement,
    user,
    simulateWorkerFailure,
    startSelfHealingDemo,
    showNotification
  } = useApp();

  const [query, setQuery] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isCommandPaletteOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
    } else {
      setQuery('');
    }
  }, [isCommandPaletteOpen]);

  if (!isCommandPaletteOpen) return null;

  interface Command {
    id: string;
    title: string;
    category: string;
    icon: React.ElementType;
    action: () => void;
  }

  const commands: Command[] = [
    {
      id: 'cmd_nb',
      title: 'Open AI Research Notebook (01_FineTune_IndicLLM)',
      category: 'Notebook',
      icon: BookOpen,
      action: () => {
        setCurrentView('notebooks');
        setCommandPaletteOpen(false);
      }
    },
    {
      id: 'cmd_brain',
      title: 'Compute Brain: Describe intent in natural language',
      category: 'Compute Brain',
      icon: BrainCircuit,
      action: () => {
        setCurrentView('compute_brain');
        setCommandPaletteOpen(false);
      }
    },
    {
      id: 'cmd_exp',
      title: 'Experiment Lab: Compare matrix & DNA fingerprints',
      category: 'Experiments',
      icon: FlaskConical,
      action: () => {
        setCurrentView('experiments');
        setCommandPaletteOpen(false);
      }
    },
    {
      id: 'cmd_fail',
      title: 'Simulate Worker Failure (Self-Healing Recovery Demo)',
      category: 'Self-Healing Training',
      icon: ShieldAlert,
      action: () => {
        setCurrentView('compute_brain');
        setCommandPaletteOpen(false);
        startSelfHealingDemo();
        setTimeout(() => simulateWorkerFailure(), 1500);
      }
    },
    {
      id: 'cmd_founder',
      title: user.entitlement === 'founder'
        ? 'Switch to Free Plan (2 Compute-Hours/Day)'
        : 'Switch to MII Founder Account (Unlimited Compute Quota)',
      category: 'Entitlement',
      icon: user.entitlement === 'founder' ? Sliders : Crown,
      action: () => {
        toggleEntitlement();
        setCommandPaletteOpen(false);
      }
    },
    {
      id: 'cmd_deploy',
      title: 'Deploy Model to Live API Playground',
      category: 'Model → API',
      icon: Rocket,
      action: () => {
        setCurrentView('deployments');
        setCommandPaletteOpen(false);
      }
    },
    {
      id: 'cmd_models',
      title: 'Model Registry: View Bharat-IndicLLM versions',
      category: 'Registry',
      icon: Box,
      action: () => {
        setCurrentView('models');
        setCommandPaletteOpen(false);
      }
    },
    {
      id: 'cmd_data',
      title: 'Dataset Center: Inspect Bhasha-Instruct-v3 health',
      category: 'Data',
      icon: Database,
      action: () => {
        setCurrentView('datasets');
        setCommandPaletteOpen(false);
      }
    },
    {
      id: 'cmd_company_brain',
      title: 'AI Company Brain: Manage 1,000-Agent Org & Approvals',
      category: 'AI Organization',
      icon: BrainCircuit,
      action: () => {
        setCurrentView('company_brain');
        setCommandPaletteOpen(false);
      }
    },
    {
      id: 'cmd_growth',
      title: 'Growth Engine: Scientific loops, viral forks, & scholar referrals',
      category: 'Growth & Marketing',
      icon: TrendingUp,
      action: () => {
        setCurrentView('growth_marketing');
        setCommandPaletteOpen(false);
      }
    },
    {
      id: 'cmd_resource_radar',
      title: 'Free Resource Radar: Discovered open models, grants & credits',
      category: 'Radar Intelligence',
      icon: Radar,
      action: () => {
        setCurrentView('resource_radar');
        setCommandPaletteOpen(false);
      }
    },
    {
      id: 'cmd_research_radar',
      title: 'Research Radar: ArXiv papers & sovereign architecture breakthroughs',
      category: 'Radar Intelligence',
      icon: Compass,
      action: () => {
        setCurrentView('research_radar');
        setCommandPaletteOpen(false);
      }
    },
    {
      id: 'cmd_compute_market',
      title: 'Wholesale Compute Market: Compare transparent margins & costs',
      category: 'HyperCompute Fabric',
      icon: MapPin,
      action: () => {
        setCurrentView('compute_map');
        setCommandPaletteOpen(false);
      }
    },
    {
      id: 'cmd_knowledge_engine',
      title: 'Collective AI Knowledge Engine: Sovereign manifests & graph claims',
      category: 'Collective Intelligence',
      icon: BrainCircuit,
      action: () => {
        setCurrentView('knowledge_engine');
        setCommandPaletteOpen(false);
      }
    },
    {
      id: 'cmd_benchmark_lab',
      title: 'Benchmark Lab & Model Family: Head-to-head empirical evaluations',
      category: 'Collective Intelligence',
      icon: Award,
      action: () => {
        setCurrentView('benchmark_lab');
        setCommandPaletteOpen(false);
      }
    },
    {
      id: 'cmd_crypto_gateway',
      title: 'Crypto Payment Gateway: Priority token discounts (YGO, YUSD, YAGYX)',
      category: 'Payments & Audits',
      icon: Coins,
      action: () => {
        setCurrentView('crypto_gateway');
        setCommandPaletteOpen(false);
      }
    },
    {
      id: 'cmd_expert_audit',
      title: '100K-AI Auditor Force & Human Expert Council: Verifiable audits',
      category: 'Payments & Audits',
      icon: ShieldCheck,
      action: () => {
        setCurrentView('expert_audit');
        setCommandPaletteOpen(false);
      }
    },
    {
      id: 'cmd_launch_center',
      title: 'MII Launch Command Center: Day-One scientific growth sequence',
      category: 'AI Organization',
      icon: Send,
      action: () => {
        setCurrentView('launch_center');
        setCommandPaletteOpen(false);
      }
    }
  ];

  const filtered = commands.filter(c =>
    c.title.toLowerCase().includes(query.toLowerCase()) ||
    c.category.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-20 px-4">
      <div
        className="fixed inset-0 bg-black/80 backdrop-blur-sm transition-opacity"
        onClick={() => setCommandPaletteOpen(false)}
      />

      <div className="relative w-full max-w-xl bg-[#0d121f] border border-white/15 rounded-xl shadow-2xl overflow-hidden z-10 animate-in fade-in zoom-in-95 duration-150">
        {/* Input Header */}
        <div className="flex items-center px-4 py-3 border-b border-white/10 bg-black/40">
          <Search className="w-4 h-4 text-orange-400 shrink-0 mr-3" />
          <input
            ref={inputRef}
            type="text"
            placeholder="Type a command, intent, or navigation target..."
            value={query}
            onChange={e => setQuery(e.target.value)}
            className="w-full bg-transparent text-sm text-white placeholder-gray-500 focus:outline-none"
          />
          <button
            onClick={() => setCommandPaletteOpen(false)}
            className="p-1 rounded text-gray-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Command List */}
        <div className="max-h-80 overflow-y-auto p-2 space-y-1">
          {filtered.length === 0 ? (
            <div className="py-8 text-center text-xs text-gray-500">
              No matching commands found.
            </div>
          ) : (
            filtered.map(cmd => {
              const Icon = cmd.icon;
              return (
                <button
                  key={cmd.id}
                  onClick={cmd.action}
                  className="w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-xs hover:bg-white/10 text-gray-200 hover:text-white transition group text-left"
                >
                  <div className="flex items-center space-x-3 truncate">
                    <div className="p-1.5 rounded-md bg-white/5 group-hover:bg-orange-500/20 text-orange-400 shrink-0">
                      <Icon className="w-4 h-4" />
                    </div>
                    <span className="truncate">{cmd.title}</span>
                  </div>
                  <span className="text-[10px] font-mono text-gray-500 uppercase shrink-0 ml-2">
                    {cmd.category}
                  </span>
                </button>
              );
            })
          )}
        </div>

        {/* Footer shortcuts */}
        <div className="px-4 py-2 border-t border-white/10 bg-black/30 flex items-center justify-between text-[11px] text-gray-500 font-mono">
          <div className="flex items-center space-x-2">
            <span>Navigation:</span>
            <kbd className="px-1 bg-white/10 rounded text-[10px]">↑</kbd>
            <kbd className="px-1 bg-white/10 rounded text-[10px]">↓</kbd>
            <span>to navigate</span>
          </div>
          <div className="flex items-center space-x-2">
            <kbd className="px-1.5 bg-white/10 rounded text-[10px]">ESC</kbd>
            <span>to close</span>
          </div>
        </div>
      </div>
    </div>
  );
};
