import React from 'react';
import { useApp } from '../../context/AppContext';
import { TrustBadge } from './TrustBadge';
import { MII_BRAND } from './BrandIdentity';
import {
  Cpu,
  Search,
  Sparkles,
  Zap,
  Crown,
  Layers,
  HelpCircle,
  Menu,
  ChevronDown,
  RefreshCw,
  Sliders
} from 'lucide-react';

interface HeaderProps {
  onToggleMobileMenu?: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onToggleMobileMenu }) => {
  const {
    user,
    toggleEntitlement,
    project,
    currentView,
    setCurrentView,
    setCommandPaletteOpen,
    resetWorkspaceData
  } = useApp();

  return (
    <header className="sticky top-0 z-40 w-full border-b border-white/10 bg-[#07090e]/90 backdrop-blur-md">
      {/* Topmost Brand Strip */}
      <div className="flex items-center justify-between px-3 sm:px-6 py-1.5 border-b border-white/10 bg-black/60 text-[11px] font-mono text-gray-300">
        <div className="flex items-center space-x-2 truncate">
          <span className="text-orange-400 font-bold uppercase tracking-wider shrink-0">{MII_BRAND.parentBrand}</span>
          <span className="text-gray-600 shrink-0">/</span>
          <span className="text-white font-medium shrink-0">{MII_BRAND.productName}</span>
          <span className="text-gray-600 shrink-0 hidden sm:inline">|</span>
          <span className="text-amber-300 font-medium truncate text-[10px] sm:text-[11px]">
            {MII_BRAND.officialTagline}
          </span>
          <span className="text-gray-600 shrink-0 hidden lg:inline">|</span>
          <span className="text-gray-400 text-[10px] hidden lg:inline">
            {MII_BRAND.positioning}
          </span>
        </div>

        <div className="flex items-center space-x-3 shrink-0 ml-2">
          <div className="flex items-center space-x-1">
            <span className="h-2 w-2 rounded-full bg-amber-400 animate-pulse" />
            <TrustBadge type="SIMULATED" size="xs" />
            <span className="hidden 2xl:inline text-[10px] text-gray-400">(Simulated Pods)</span>
          </div>

          <button
            onClick={resetWorkspaceData}
            title="Reset to default research scenario"
            className="hover:text-white transition flex items-center space-x-1 text-[10px] bg-white/5 hover:bg-white/10 px-2 py-0.5 rounded border border-white/10"
          >
            <RefreshCw className="w-3 h-3" />
            <span className="hidden sm:inline">Reset Workspace</span>
          </button>
        </div>
      </div>

      {/* Main Navigation Bar */}
      <div className="flex items-center justify-between px-3 sm:px-6 h-14">
        <div className="flex items-center space-x-3">
          {/* Mobile menu button */}
          <button
            onClick={onToggleMobileMenu}
            className="p-1.5 rounded-lg text-gray-400 hover:text-white hover:bg-white/5 md:hidden"
            aria-label="Toggle Navigation"
          >
            <Menu className="w-5 h-5" />
          </button>

          {/* Logo & Product Title */}
          <div
            onClick={() => setCurrentView('overview')}
            className="cursor-pointer flex items-center space-x-2.5 group"
          >
            <div className="h-8 w-8 rounded-lg bg-gradient-to-br from-orange-500 via-amber-600 to-indigo-600 flex items-center justify-center p-0.5 shadow-lg shadow-orange-500/10 group-hover:scale-105 transition">
              <div className="h-full w-full bg-[#07090e] rounded-[6px] flex items-center justify-center">
                <Cpu className="w-4 h-4 text-orange-400" />
              </div>
            </div>
            <div>
              <div className="flex items-center space-x-1.5 leading-none">
                <span className="font-bold text-white tracking-tight font-display text-sm sm:text-base">
                  Bharat HyperCompute
                </span>
              </div>
              <span className="text-[10px] text-gray-400 font-mono tracking-wider block">
                AI RESEARCH & HYPERCOMPUTE
              </span>
            </div>
          </div>

          {/* Project Switcher Pill */}
          <div className="hidden xl:flex items-center ml-4 pl-4 border-l border-white/10">
            <div className="flex items-center space-x-2 bg-white/5 hover:bg-white/10 px-2.5 py-1 rounded-md border border-white/10 cursor-pointer text-xs transition">
              <Layers className="w-3.5 h-3.5 text-orange-400" />
              <span className="text-gray-300 font-medium truncate max-w-[160px]">{project.name}</span>
              <ChevronDown className="w-3 h-3 text-gray-500" />
            </div>
          </div>
        </div>

        {/* Center / Right controls */}
        <div className="flex items-center space-x-2 sm:space-x-3">
          {/* Global Search / Command Palette Shortcut */}
          <button
            onClick={() => setCommandPaletteOpen(true)}
            className="hidden sm:flex items-center space-x-2 bg-white/5 hover:bg-white/10 border border-white/10 px-3 py-1.5 rounded-lg text-xs text-gray-400 transition"
          >
            <Search className="w-3.5 h-3.5 text-gray-400" />
            <span>Search or type intent...</span>
            <kbd className="px-1.5 py-0.5 rounded bg-white/10 text-[10px] font-mono text-gray-300 border border-white/10">
              ⌘K
            </kbd>
          </button>

          {/* Daily Compute Status / Entitlement Badge */}
          <div className="flex items-center space-x-1.5 bg-black/60 border border-white/10 rounded-lg p-1">
            {user.entitlement === 'founder' ? (
              <div className="flex items-center space-x-2 px-2 py-0.5 text-xs">
                <Crown className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
                <span className="font-semibold text-amber-300">MII FOUNDER</span>
                <span className="hidden lg:inline text-[10px] text-amber-400/80 font-mono">
                  (Unlimited Quota)
                </span>
              </div>
            ) : (
              <div className="flex items-center space-x-2 px-2 py-0.5 text-xs">
                <Zap className="w-3.5 h-3.5 text-orange-400" />
                <div>
                  <span className="text-gray-300 font-medium">
                    {user.dailyComputeHoursUsed.toFixed(1)} / {user.dailyComputeHoursLimit} hrs
                  </span>
                  <span className="hidden lg:inline text-[10px] text-gray-500 ml-1.5 font-mono">
                    (Resets in 7h)
                  </span>
                </div>
              </div>
            )}

            {/* Quick Toggle Button to test both Free & Founder modes */}
            <button
              onClick={toggleEntitlement}
              title="Click to toggle between Free (2 hrs/day) and MII Founder entitlement"
              className="px-2 py-1 text-[10px] font-mono font-medium rounded bg-orange-500/10 hover:bg-orange-500/20 text-orange-300 border border-orange-500/30 transition flex items-center space-x-1"
            >
              <Sliders className="w-3 h-3" />
              <span className="hidden sm:inline">
                {user.entitlement === 'founder' ? 'Switch to Free' : 'Switch to Founder'}
              </span>
            </button>
          </div>

          {/* Landing Page Preview / Switcher */}
          {currentView === 'landing' ? (
            <button
              onClick={() => setCurrentView('overview')}
              className="bg-orange-500 hover:bg-orange-600 text-white font-semibold text-xs px-3.5 py-1.5 rounded-lg shadow transition"
            >
              Go to Console
            </button>
          ) : (
            <button
              onClick={() => setCurrentView('landing')}
              className="text-gray-400 hover:text-white text-xs px-2.5 py-1.5 rounded-lg hover:bg-white/5 transition hidden md:inline-block"
            >
              Public Portal
            </button>
          )}

          {/* User profile icon */}
          <div
            onClick={() => setCurrentView('settings')}
            className="cursor-pointer h-8 w-8 rounded-full bg-gradient-to-tr from-orange-600 to-indigo-600 flex items-center justify-center font-bold text-xs text-white border border-white/20"
            title={`${user.name} (${user.role} - ${user.entitlement.toUpperCase()})`}
          >
            {user.name.split(' ').map(n => n[0]).join('').slice(0, 2)}
          </div>
        </div>
      </div>
    </header>
  );
};
