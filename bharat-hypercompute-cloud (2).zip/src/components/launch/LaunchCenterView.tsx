import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { TrustBadge } from '../common/TrustBadge';
import { PreLaunchAuditGate } from './PreLaunchAuditGate';
import {
  Rocket,
  Calendar,
  CheckCircle2,
  Clock,
  Send,
  Share2,
  Flame,
  Globe,
  Users,
  Award,
  Sparkles,
  ExternalLink,
  MessageSquare,
  ArrowRight,
  ShieldCheck,
  Check
} from 'lucide-react';

export const LaunchCenterView: React.FC = () => {
  const {
    launchPlans,
    showNotification
  } = useApp();

  const [activeTab, setActiveTab] = useState<'audit_gate' | 'timeline'>('audit_gate');
  const [selectedPhase, setSelectedPhase] = useState<string>('DAY_0');

  const selectedPlan = launchPlans.find(p => p.phase === selectedPhase) || launchPlans[0];

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Top Banner */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-gradient-to-r from-[#0c1220] via-[#080d16] to-[#0c1220] p-6 rounded-2xl border border-white/10 shadow-xl">
        <div className="space-y-1">
          <div className="flex items-center space-x-2">
            <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-orange-500/20 text-orange-400 border border-orange-500/30">
              National Launch Engine
            </span>
            <span className="text-xs text-gray-400 font-mono">🇮🇳 Make in India. Made for 🇮🇳 Make in India (MII). 🇮🇳</span>
            <TrustBadge type="APPROVED" size="xs" />
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-white font-display flex items-center space-x-2">
            <Rocket className="w-7 h-7 text-orange-400" />
            <span>MII Launch Command Center</span>
          </h1>
          <p className="text-sm text-gray-400 max-w-3xl leading-relaxed">
            Product-led growth, sovereign verification, and scientific awareness sequence. Zero fake virality or automated spam. Built on verifiable research stories, one-click reproducible experiments, and developer transparency.
          </p>
        </div>

        <div className="flex items-center space-x-2 shrink-0">
          <button
            onClick={() => setActiveTab('audit_gate')}
            className={`px-3.5 py-2 rounded-xl text-xs font-mono font-bold transition flex items-center space-x-1.5 border ${
              activeTab === 'audit_gate'
                ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 shadow-lg'
                : 'bg-black/40 text-gray-400 hover:text-white border-white/10'
            }`}
          >
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Pre-Launch Audit Gate (PASS)</span>
          </button>
          <button
            onClick={() => setActiveTab('timeline')}
            className={`px-3.5 py-2 rounded-xl text-xs font-mono font-bold transition flex items-center space-x-1.5 border ${
              activeTab === 'timeline'
                ? 'bg-orange-500/20 text-orange-300 border-orange-500/40 shadow-lg'
                : 'bg-black/40 text-gray-400 hover:text-white border-white/10'
            }`}
          >
            <Calendar className="w-4 h-4 text-orange-400" />
            <span>Launch Timeline (T-30 to Day 30)</span>
          </button>
        </div>
      </div>

      {/* VIEW A: PRE-LAUNCH AUDIT & SECURITY GATE */}
      {activeTab === 'audit_gate' && (
        <PreLaunchAuditGate />
      )}

      {/* VIEW B: LAUNCH PHASING SEQUENCE & ROADMAP */}
      {activeTab === 'timeline' && (
        <div className="space-y-6">

      {/* Launch Sequence Timeline Track */}
      <div className="p-6 rounded-2xl bg-[#0c101a] border border-white/10 space-y-4">
        <div className="flex items-center justify-between border-b border-white/10 pb-3">
          <div className="flex items-center space-x-2">
            <Calendar className="w-4 h-4 text-orange-400" />
            <h2 className="text-sm font-bold uppercase tracking-wider text-white font-display">
              Launch Phasing Sequence (T-30 to Day 30)
            </h2>
          </div>
          <span className="text-xs font-mono text-gray-400">
            Policy-Approved Milestones Only
          </span>
        </div>

        <div className="grid grid-cols-3 sm:grid-cols-6 lg:grid-cols-11 gap-2 pt-2">
          {['T-30', 'T-14', 'T-7', 'T-3', 'T-1', 'DAY_0', 'DAY_1', 'DAY_3', 'DAY_7', 'DAY_14', 'DAY_30'].map(phase => {
            const plan = launchPlans.find(p => p.phase === phase);
            const isSelected = selectedPhase === phase;
            const isCompleted = plan?.status === 'COMPLETED';
            const isActive = plan?.status === 'READY_ACTIVE';
            return (
              <button
                key={phase}
                onClick={() => setSelectedPhase(phase)}
                className={`p-2.5 rounded-xl border text-center transition space-y-1 ${
                  isSelected
                    ? 'bg-orange-500/20 border-orange-500'
                    : isCompleted
                    ? 'bg-emerald-500/10 border-emerald-500/30'
                    : isActive
                    ? 'bg-sky-500/10 border-sky-500/30'
                    : 'bg-[#07090e] border-white/10 opacity-70 hover:opacity-100'
                }`}
              >
                <div className="text-xs font-mono font-bold text-white">{phase.replace('_', ' ')}</div>
                <div className="text-[9px] font-mono uppercase truncate text-gray-400">
                  {isCompleted ? 'Done' : isActive ? 'Active' : 'Scheduled'}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Selected Phase Detail & Viral Research Loop Mechanics */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column (7 cols): Phase Briefing */}
        <div className="lg:col-span-7 space-y-6">
          <div className="p-6 rounded-2xl bg-[#0a0e17] border border-white/10 space-y-4">
            <div className="flex items-start justify-between">
              <div>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono uppercase bg-orange-500/20 text-orange-400 border border-orange-500/30 font-bold">
                  {selectedPlan.phase.replace('_', ' ')} MILESTONE
                </span>
                <h3 className="text-xl font-bold text-white mt-1.5 font-display">
                  {selectedPlan.title}
                </h3>
              </div>

              <span className="px-2.5 py-1 rounded text-xs font-mono font-bold uppercase bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                {selectedPlan.status}
              </span>
            </div>

            <p className="text-xs text-gray-300 leading-relaxed">
              <span className="text-gray-400 font-semibold">Objective:</span> {selectedPlan.objective}
            </p>

            <div className="grid grid-cols-2 gap-3 text-xs font-mono">
              <div className="p-3 bg-white/5 rounded-xl space-y-1">
                <span className="text-gray-500 block text-[10px]">AUDIENCE TARGET</span>
                <span className="text-gray-200">{selectedPlan.audience}</span>
              </div>
              <div className="p-3 bg-white/5 rounded-xl space-y-1">
                <span className="text-gray-500 block text-[10px]">BUDGET ALLOCATION</span>
                <span className="text-orange-400 font-bold">₹{selectedPlan.budgetINR.toLocaleString('en-IN')} (Strict Cap)</span>
              </div>
            </div>

            <div className="space-y-2 pt-2 border-t border-white/5">
              <div className="text-xs font-mono text-gray-400">DISTRIBUTION CHANNELS (OFFICIAL APIS ONLY)</div>
              <div className="flex flex-wrap gap-2">
                {selectedPlan.channels.map(channel => (
                  <span key={channel} className="px-2.5 py-1 bg-white/5 border border-white/10 rounded-lg text-xs font-mono text-gray-300">
                    {channel}
                  </span>
                ))}
              </div>
            </div>

            <div className="p-4 bg-orange-500/10 border border-orange-500/30 rounded-xl space-y-1.5">
              <div className="text-xs font-bold text-orange-400 font-mono flex items-center space-x-1.5">
                <Sparkles className="w-3.5 h-3.5" />
                <span>PRIMARY CALL TO ACTION (CTA)</span>
              </div>
              <div className="text-sm font-bold text-white font-mono">
                "{selectedPlan.cta}"
              </div>
            </div>
          </div>
        </div>

        {/* Right Column (5 cols): Viral Research Loop Mechanics */}
        <div className="lg:col-span-5 space-y-4">
          <div className="p-6 rounded-2xl bg-[#0c101a] border border-white/10 space-y-4">
            <div className="flex items-center space-x-2 text-white font-display font-bold text-base border-b border-white/10 pb-3">
              <Flame className="w-5 h-5 text-orange-400" />
              <span>Viral Research Mechanics</span>
            </div>

            <p className="text-xs text-gray-400 leading-relaxed">
              We replace promotional marketing with scientific utility. Researchers share what actually works:
            </p>

            <div className="space-y-3 text-xs">
              <div className="p-3 bg-white/5 rounded-xl border border-white/5 space-y-1">
                <div className="font-bold text-white flex items-center justify-between">
                  <span>1-Click Experiment DNA Forking</span>
                  <Share2 className="w-3.5 h-3.5 text-orange-400" />
                </div>
                <p className="text-gray-400 text-[11px]">
                  Every paper includes a verifiable run URL allowing any researcher to replicate findings in 2 hours on free tier quota.
                </p>
              </div>

              <div className="p-3 bg-white/5 rounded-xl border border-white/5 space-y-1">
                <div className="font-bold text-white flex items-center justify-between">
                  <span>Peer-Review Reproducibility Badges</span>
                  <Award className="w-3.5 h-3.5 text-emerald-400" />
                </div>
                <p className="text-gray-400 text-[11px]">
                  Independent validations earn cryptographically signed badges embedded in ArXiv LaTeX headers and GitHub READMEs.
                </p>
              </div>

              <div className="p-3 bg-white/5 rounded-xl border border-white/5 space-y-1">
                <div className="font-bold text-white flex items-center justify-between">
                  <span>National University Quota Pool</span>
                  <Users className="w-3.5 h-3.5 text-sky-400" />
                </div>
                <p className="text-gray-400 text-[11px]">
                  Scholars at accredited Indian universities automatically receive 2 hours of daily compute credits without needing a credit card.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
        </div>
      )}
    </div>
  );
};
