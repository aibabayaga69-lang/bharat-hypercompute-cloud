import {
  ModelKnowledgeManifest,
  KnowledgeGraphNode,
  ScientificClaim,
  MIIModelSpec,
  TournamentMatch,
  CryptoTokenConfig,
  CryptoPaymentSession,
  HumanExpert,
  AIAuditorSpecialist,
  PlatformAuditFinding,
  LaunchPhasePlan
} from '../types/platformKnowledge';

export const INITIAL_KNOWLEDGE_MANIFESTS: ModelKnowledgeManifest[] = [
  {
    id: 'mkm_01',
    modelId: 'mod_indic_7b_v2',
    modelVersion: 'v2.1-bhasha',
    sourceExperimentId: 'exp_04',
    privacyClassification: 'CONSENTED_GLOBAL_KNOWLEDGE',
    trainingEligibility: true,
    provenanceScore: 98,
    dataQualityScore: 94,
    scientificConfidence: 96,
    license: 'Apache-2.0 / Open Sovereign AI Commons',
    findings: [
      'Byte-fallback BPE with 64,000 vocabulary prevents token bloat in Devanagari by 42%.',
      'LoRA r=32 alpha=64 on q_proj & v_proj matches full fine-tuning with 68% less vRAM.'
    ],
    techniques: ['Rotary Position Embeddings (RoPE) theta=1000000', 'FlashAttention-2 Kernel Overlap'],
    optimizationDiscoveries: ['Zero-Redundancy Optimizer (ZeRO-Stage 3) partition offloading saved 4.2 hours training time.'],
    failurePatternsAvoided: ['Identified gradient explosion when learning rate exceeded 3.5e-4 on FP16; locked BF16 mixed precision.'],
    hyperparameterOutcomes: {
      peak_lr: '2.5e-4',
      warmup_ratio: '0.04',
      batch_size_global: 128,
      grad_accum_steps: 4
    },
    evaluationSummary: {
      evalAccuracyPct: 91.4,
      indicPerplexity: 4.88,
      safetyScore: 99.2
    },
    securityAuditPassed: true,
    piiCheckPassed: true,
    benchmarkContaminationChecked: true,
    checksum: 'sha256:8f4c19a9e339bdf54e5a9c39832714a60113c2c19e59838274028bcfa1',
    createdAt: '2026-09-18 19:45 IST'
  },
  {
    id: 'mkm_02',
    modelId: 'mod_indic_code_3b',
    modelVersion: 'v1.0-code',
    sourceExperimentId: 'exp_01',
    privacyClassification: 'PLATFORM_RESEARCH',
    trainingEligibility: true,
    provenanceScore: 95,
    dataQualityScore: 92,
    scientificConfidence: 91,
    license: 'MIT Permissive',
    findings: [
      'Multi-turn code docstring synthesis in Hindi & English improves developer prompt adherence by 27%.'
    ],
    techniques: ['Fill-in-the-Middle (FIM) PSM/SPM 50/50 rate', 'Cross-Entropy Loss masking on comments'],
    optimizationDiscoveries: ['Fused Cross Entropy Kernel cuts backward pass latency by 18%.'],
    failurePatternsAvoided: ['Filtered out 14,000 synthetic duplicate test functions from training corpora.'],
    hyperparameterOutcomes: {
      peak_lr: '1.8e-4',
      warmup_ratio: '0.05',
      batch_size_global: 64
    },
    evaluationSummary: {
      humanEvalScorePct: 44.2,
      indicCodeBleu: 58.1,
      safetyScore: 99.8
    },
    securityAuditPassed: true,
    piiCheckPassed: true,
    benchmarkContaminationChecked: true,
    checksum: 'sha256:32e8d356c9a008f1b63ca04cf09d9361ad58fb7ea5c90712536c4bdf41',
    createdAt: '2026-09-18 14:10 IST'
  }
];

export const INITIAL_KNOWLEDGE_GRAPH_NODES: KnowledgeGraphNode[] = [
  {
    id: 'kgn_paper_01',
    type: 'Paper',
    title: 'ArXiv:2408.08921: IndicTokenBench: Evaluating Subword Tokenizers for 22 Scheduled Indian Languages',
    ownerTenant: 'Academic Open Commons',
    privacyClass: 'PUBLIC',
    verified: true,
    scientificStatus: 'SUPPORTED',
    metrics: { citations: 84, peerReviewStatus: 'MLSys 2025 Accepted' },
    connections: ['kgn_dataset_01', 'kgn_finding_01']
  },
  {
    id: 'kgn_dataset_01',
    type: 'Dataset',
    title: 'Bhasha-Instruct-v3 (De-duplicated & Curated)',
    ownerTenant: 'MII Sovereign AI Research Org',
    privacyClass: 'CONSENTED_GLOBAL_KNOWLEDGE',
    verified: true,
    scientificStatus: 'SUPPORTED',
    metrics: { tokens: '14.2B', qualityScore: 96 },
    connections: ['kgn_exp_01', 'kgn_finding_01']
  },
  {
    id: 'kgn_exp_01',
    type: 'Experiment',
    title: 'EXP-04: Multi-Node DDP Fine-Tune with RoPE Scaling',
    ownerTenant: 'MII Sovereign AI Research Org',
    privacyClass: 'PLATFORM_RESEARCH',
    verified: true,
    scientificStatus: 'SUPPORTED',
    metrics: { evalLoss: '0.318', finalValAccuracy: '91.4%' },
    connections: ['kgn_ckpt_01', 'kgn_model_01']
  },
  {
    id: 'kgn_ckpt_01',
    type: 'Checkpoint',
    title: 'Checkpoint Step 1,600 (Self-Healing Verified)',
    ownerTenant: 'MII Sovereign AI Research Org',
    privacyClass: 'PROJECT',
    verified: true,
    scientificStatus: 'SUPPORTED',
    metrics: { sizeGB: '14.2', vRAMOverhead: '18GB' },
    connections: ['kgn_model_01']
  },
  {
    id: 'kgn_model_01',
    type: 'Model',
    title: 'Bharat-IndicLLM-7B-Instruct (v2.1)',
    ownerTenant: 'MII Sovereign AI Research Org',
    privacyClass: 'CONSENTED_GLOBAL_KNOWLEDGE',
    verified: true,
    scientificStatus: 'SUPPORTED',
    metrics: { evalAccuracy: '91.4%', perplexity: '4.88' },
    connections: ['kgn_eval_01', 'kgn_deploy_01']
  },
  {
    id: 'kgn_eval_01',
    type: 'Evaluation',
    title: 'National Indic Multilingual Benchmark Suite',
    ownerTenant: 'MII Benchmark Lab',
    privacyClass: 'PUBLIC',
    verified: true,
    scientificStatus: 'SUPPORTED',
    metrics: { languagesTested: 14, benchmarkRank: '#1 Open Sovereign' },
    connections: ['kgn_finding_01']
  },
  {
    id: 'kgn_finding_01',
    type: 'Finding',
    title: 'Byte-fallback BPE prevents out-of-vocabulary UNK tokens on rare Indic compound words',
    ownerTenant: 'MII Collective Knowledge Engine',
    privacyClass: 'CONSENTED_GLOBAL_KNOWLEDGE',
    verified: true,
    scientificStatus: 'SUPPORTED',
    metrics: { confidence: '98%', reproductionCount: 5 },
    connections: ['kgn_deploy_01']
  },
  {
    id: 'kgn_deploy_01',
    type: 'Deployment',
    title: 'Live vLLM Serving Endpoint (blr-pod-02)',
    ownerTenant: 'MII Sovereign AI Research Org',
    privacyClass: 'PLATFORM_RESEARCH',
    verified: true,
    scientificStatus: 'SUPPORTED',
    metrics: { p95Latency: '24ms', uptimePct: '99.98%' },
    connections: []
  }
];

export const INITIAL_SCIENTIFIC_CLAIMS: ScientificClaim[] = [
  {
    id: 'sc_01',
    claim: 'Byte-level fallback reduces token fragmentation in Devanagari script by >40% compared to standard Llama tokenizers.',
    domain: 'NLP & Tokenization',
    source: 'ArXiv:2408.08921 / Bharat Tokenizer Experiment #03',
    evidence: 'Measured 1.42 tokens/word on Hindi corpus vs 2.48 tokens/word on baseline Llama-2 tokenizer.',
    reproductionConfidence: 98,
    status: 'SUPPORTED',
    independentEvaluationsCount: 4,
    lastEvaluated: '2026-09-18'
  },
  {
    id: 'sc_02',
    claim: 'Quantization aware LoRA (QA-LoRA) retains 99.4% full-precision reasoning on 4-bit weights with zero perplexity degradation.',
    domain: 'Model Compression & Quantization',
    source: 'MLSys Benchmark Lab / EXP-02',
    evidence: 'Evaluated across 1,000 Indic MMLU reasoning questions with AWQ and GPTQ kernels.',
    reproductionConfidence: 92,
    status: 'SUPPORTED',
    independentEvaluationsCount: 3,
    lastEvaluated: '2026-09-17'
  },
  {
    id: 'sc_03',
    claim: 'Synthetic data alone without natural human alignment produces semantic degradation after 3 training epochs.',
    domain: 'Synthetic Corpora & Data Poisoning',
    source: 'MII Research Radar / Synthetic Loop Audit #12',
    evidence: 'Perplexity spiked from 5.1 to 14.8 when training on 100% recursive model outputs.',
    reproductionConfidence: 95,
    status: 'SUPPORTED',
    independentEvaluationsCount: 6,
    lastEvaluated: '2026-09-18'
  }
];

export const INITIAL_MII_MODEL_FAMILY: MIIModelSpec[] = [
  {
    id: 'mii_base_7b',
    name: 'MII Base Model 7B',
    family: 'Base',
    version: 'v1.2-rc',
    parameters: '7.2 Billion',
    status: 'Candidate Release',
    benchmarkScores: {
      multilingualIndic: 88.4,
      reasoningMMLU: 68.2,
      codingHumanEval: 48.6,
      safetyScore: 98.9,
      mathGSM8K: 62.4,
      efficiencyTokensPerSec: 142
    },
    knowledgeSourcesCount: 14,
    safetyAuditsCompleted: 8,
    knownLimitations: ['Requires domain fine-tuning for specialized legal or clinical vocabulary.'],
    pricingPer1kTokensINR: 0.08,
    trustTag: 'DEMO'
  },
  {
    id: 'mii_reasoning_14b',
    name: 'MII Reasoning Model 14B',
    family: 'Reasoning',
    version: 'v0.9-alpha',
    parameters: '14.1 Billion',
    status: 'Evaluation Tournaments',
    benchmarkScores: {
      multilingualIndic: 85.1,
      reasoningMMLU: 79.4,
      codingHumanEval: 64.2,
      safetyScore: 99.4,
      mathGSM8K: 81.2,
      efficiencyTokensPerSec: 78
    },
    knowledgeSourcesCount: 22,
    safetyAuditsCompleted: 12,
    knownLimitations: ['Higher inference latency due to internal test-time compute thought chains.'],
    pricingPer1kTokensINR: 0.24,
    trustTag: 'DEMO'
  },
  {
    id: 'mii_coding_3b',
    name: 'MII Coding Model 3B',
    family: 'Coding',
    version: 'v1.0-prod',
    parameters: '3.4 Billion',
    status: 'Requires External API',
    benchmarkScores: {
      multilingualIndic: 76.8,
      reasoningMMLU: 62.0,
      codingHumanEval: 72.8,
      safetyScore: 99.8,
      mathGSM8K: 66.5,
      efficiencyTokensPerSec: 210
    },
    knowledgeSourcesCount: 18,
    safetyAuditsCompleted: 15,
    knownLimitations: ['Context window optimized for 8,192 tokens; single-file architecture.'],
    pricingPer1kTokensINR: 0.04,
    trustTag: 'REQUIRES_API'
  },
  {
    id: 'mii_vision_8b',
    name: 'MII Vision-Language Model 8B',
    family: 'Vision',
    version: 'v0.8-preview',
    parameters: '8.4 Billion',
    status: 'In Development',
    benchmarkScores: {
      multilingualIndic: 82.0,
      reasoningMMLU: 64.5,
      codingHumanEval: 42.0,
      safetyScore: 97.8,
      mathGSM8K: 54.0,
      efficiencyTokensPerSec: 95
    },
    knowledgeSourcesCount: 9,
    safetyAuditsCompleted: 6,
    knownLimitations: ['Multilingual OCR on handwritten ancient scripts currently undergoing academic validation.'],
    pricingPer1kTokensINR: 0.14,
    trustTag: 'DEMO'
  },
  {
    id: 'mii_edge_1b',
    name: 'MII Small/Edge Model 1.5B',
    family: 'Edge',
    version: 'v1.1-ondevice',
    parameters: '1.5 Billion',
    status: 'Candidate Release',
    benchmarkScores: {
      multilingualIndic: 74.2,
      reasoningMMLU: 54.8,
      codingHumanEval: 38.4,
      safetyScore: 99.2,
      mathGSM8K: 44.0,
      efficiencyTokensPerSec: 380
    },
    knowledgeSourcesCount: 11,
    safetyAuditsCompleted: 9,
    knownLimitations: ['Quantized for on-device mobile NPU (Ollama/GGUF/ONNX); limited multi-step logic.'],
    pricingPer1kTokensINR: 0.02,
    trustTag: 'DEMO'
  },
  {
    id: 'mii_research_32b',
    name: 'MII Research Frontier Model 32B',
    family: 'Research',
    version: 'v0.5-train',
    parameters: '32.6 Billion MoE (8x4B)',
    status: 'In Development',
    benchmarkScores: {
      multilingualIndic: 89.2,
      reasoningMMLU: 84.1,
      codingHumanEval: 76.5,
      safetyScore: 99.1,
      mathGSM8K: 85.0,
      efficiencyTokensPerSec: 64
    },
    knowledgeSourcesCount: 38,
    safetyAuditsCompleted: 4,
    knownLimitations: ['Requires minimum 4x H100 GPU cluster or multi-host TPU slice.'],
    pricingPer1kTokensINR: 0.48,
    trustTag: 'DEMO'
  }
];

export const INITIAL_TOURNAMENT_MATCHES: TournamentMatch[] = [
  {
    id: 'match_01',
    benchmarkSuite: 'IndicMMLU-14Language Benchmark Suite',
    candidateA: 'MII Base Model 7B (v1.2)',
    candidateB: 'OpenIndic-Baseline 7B',
    metricJudged: 'Multilingual Accuracy & Perplexity',
    scoreA: 88.4,
    scoreB: 79.2,
    winner: 'MII Base Model 7B (v1.2)',
    timestamp: '2026-09-18 18:20',
    hardwarePlatform: 'BHARAT H100 SXM5 80GB (vLLM v0.6.2)',
    dimensions: {
      accuracy: '+9.2% Superior Indic Comprehension',
      latency: '18ms/token vs 22ms/token',
      cost: 'Identical vRAM footprint (14GB FP16)',
      safety: 'Zero hallucinated abusive compound nouns'
    }
  },
  {
    id: 'match_02',
    benchmarkSuite: 'HumanEval-Python-IndicDocstring Test',
    candidateA: 'MII Coding Model 3B (v1.0)',
    candidateB: 'General-Code-3B Reference',
    metricJudged: 'Pass@1 Functional Correctness',
    scoreA: 72.8,
    scoreB: 65.4,
    winner: 'MII Coding Model 3B (v1.0)',
    timestamp: '2026-09-18 15:45',
    hardwarePlatform: 'BHARAT L40S 48GB (TensorRT-LLM)',
    dimensions: {
      accuracy: '+7.4% higher syntax pass rate',
      latency: '210 tokens/sec throughput',
      cost: '45% less compute per inference call',
      safety: 'Clean AST parsing; no dangerous shell invocations'
    }
  }
];

export const INITIAL_CRYPTO_TOKENS: CryptoTokenConfig[] = [
  {
    symbol: 'YGO',
    name: 'Yield Guild Optimizer / YGO Protocol Token',
    network: 'Polygon PoS (ChainID 137)',
    chainId: 137,
    tokenAddress: '0x32890C5D2A88aA422D305F8F87De56852A7799B7',
    decimals: 18,
    isPriority: true,
    verifiedContract: true,
    explorerUrl: 'https://polygonscan.com/token/0x32890C5D2A88aA422D305F8F87De56852A7799B7',
    discountPct: 25, // 25% discount for paying with priority token
    minConfirmations: 30,
    status: 'LIVE_SUPPORTED'
  },
  {
    symbol: 'YUSD',
    name: 'Yield Universal Stable Dollar (YUSD)',
    network: 'Polygon PoS (ChainID 137)',
    chainId: 137,
    tokenAddress: '0x7169D38820dfd117C3FA1f22a697dBA58d90BA06',
    decimals: 6,
    isPriority: true,
    verifiedContract: true,
    explorerUrl: 'https://polygonscan.com/token/0x7169D38820dfd117C3FA1f22a697dBA58d90BA06',
    discountPct: 20, // 20% discount
    minConfirmations: 20,
    status: 'LIVE_SUPPORTED'
  },
  {
    symbol: 'YAGYX',
    name: 'YagyX Sovereign Compute Governance Token',
    network: 'Arbitrum One (ChainID 42161)',
    chainId: 42161,
    tokenAddress: '0x992B9aF72e02A44B22d3b28A8f731B45F540C93E',
    decimals: 18,
    isPriority: true,
    verifiedContract: true,
    explorerUrl: 'https://arbiscan.io/token/0x992B9aF72e02A44B22d3b28A8f731B45F540C93E',
    discountPct: 30, // 30% discount
    minConfirmations: 15,
    status: 'LIVE_SUPPORTED'
  },
  {
    symbol: 'USDC',
    name: 'USD Coin (Native)',
    network: 'Polygon PoS (ChainID 137)',
    chainId: 137,
    tokenAddress: '0x3c499c542cEF5E3811e1192ce70d8cC03d5c3359',
    decimals: 6,
    isPriority: false,
    verifiedContract: true,
    explorerUrl: 'https://polygonscan.com/token/0x3c499c542cEF5E3811e1192ce70d8cC03d5c3359',
    discountPct: 5,
    minConfirmations: 20,
    status: 'LIVE_SUPPORTED'
  },
  {
    symbol: 'ETH',
    name: 'Ethereum Native',
    network: 'Ethereum Mainnet (ChainID 1)',
    chainId: 1,
    tokenAddress: '0x0000000000000000000000000000000000000000',
    decimals: 18,
    isPriority: false,
    verifiedContract: true,
    explorerUrl: 'https://etherscan.io',
    discountPct: 5,
    minConfirmations: 12,
    status: 'LIVE_SUPPORTED'
  }
];

export const INITIAL_CRYPTO_SESSIONS: CryptoPaymentSession[] = [
  {
    id: 'pay_sess_9021',
    planId: 'founder_monthly',
    planName: 'MII Founder Unlimited Compute Tier',
    fiatAmountINR: 19999,
    cryptoSymbol: 'YGO',
    cryptoAmount: 184.25,
    discountAppliedINR: 4999.75, // 25% off
    depositAddress: '0x8849b2fE3d88E91219b13Eb518Fa0313c4943E19',
    network: 'Polygon PoS',
    status: 'CONFIRMED',
    txHash: '0x4f89d38102394c8e76a0129bcdd94e2238109bf58712a4b87612c78912ba091c',
    confirmations: 34,
    requiredConfirmations: 30,
    expiresAt: '2026-09-18 20:30',
    riskScore: 'LOW',
    serverVerified: true
  }
];

export const INITIAL_HUMAN_EXPERTS: HumanExpert[] = [
  {
    id: 'exp_h_01',
    name: 'Dr. Aarav Nambiar',
    domain: 'Distributed ML & GPU Kernels',
    institutionOrOrg: 'Center for High-Performance Computing, IISc Bangalore',
    credential: 'PhD MLSys, 18 IEEE Publications, Triton Compiler Contributor',
    verified: true,
    auditsCompleted: 42
  },
  {
    id: 'exp_h_02',
    name: 'Pooja Venkatesh',
    domain: 'Payment Security & Cryptography',
    institutionOrOrg: 'FinTech Sovereign Security Research Fellow',
    credential: 'CISSP, Smart Contract Security Auditor (CertiK/OpenZeppelin Alum)',
    verified: true,
    auditsCompleted: 31
  },
  {
    id: 'exp_h_03',
    name: 'Vikramaditya Sharma',
    domain: 'Indic NLP & Phonetics Tokenization',
    institutionOrOrg: 'National Language Technology Consortium, New Delhi',
    credential: 'Senior NLP Researcher, 22-Language Corpus Lead',
    verified: true,
    auditsCompleted: 58
  },
  {
    id: 'exp_h_04',
    name: 'Sneha Chawla',
    domain: 'Enterprise UX & Cognitive Accessibility',
    institutionOrOrg: 'Design Research Council India',
    credential: 'Principal UX Architect, WCAG 2.2 AAA Evaluator',
    verified: true,
    auditsCompleted: 24
  }
];

export const INITIAL_AI_AUDITORS: AIAuditorSpecialist[] = [
  {
    id: 'aud_ui',
    department: 'UI & Accessibility Auditor',
    focusArea: 'WCAG AA contrast, touch target dimensions, font scaling, no arbitrary gradients',
    model: 'gemini-1.5-flash',
    status: 'ACTIVE',
    findingsCount: 18,
    lastRan: '10 mins ago'
  },
  {
    id: 'aud_sec',
    department: 'Security & Red Team Auditor',
    focusArea: 'Prompt injection, PII leak, least-privilege token access, CSRF/CORS barriers',
    model: 'gemini-1.5-pro',
    status: 'ACTIVE',
    findingsCount: 12,
    lastRan: '25 mins ago'
  },
  {
    id: 'aud_perf',
    department: 'Performance & GPU Telemetry Auditor',
    focusArea: 'Kernel occupancy, memory fragmentation, cold start latency, bundle weight',
    model: 'gemini-1.5-flash',
    status: 'ACTIVE',
    findingsCount: 9,
    lastRan: '5 mins ago'
  },
  {
    id: 'aud_crypto',
    department: 'Blockchain & Payment Gateway Auditor',
    focusArea: 'Replay attacks, underpayment handling, multi-sig verification, fee slippage',
    model: 'gemini-1.5-pro',
    status: 'ACTIVE',
    findingsCount: 7,
    lastRan: '1 hour ago'
  },
  {
    id: 'aud_science',
    department: 'Scientific Reproducibility Auditor',
    focusArea: 'Seed determinism, loss curve variance, benchmark contamination detection',
    model: 'gemini-1.5-pro',
    status: 'ACTIVE',
    findingsCount: 14,
    lastRan: '15 mins ago'
  }
];

export const INITIAL_AUDIT_FINDINGS: PlatformAuditFinding[] = [
  {
    id: 'fnd_01',
    category: 'STRONG',
    domain: 'Reproducibility & Experiment DNA',
    severity: 'INFORMATIONAL',
    auditorType: 'HUMAN_EXPERT',
    auditorName: 'Dr. Aarav Nambiar (IISc)',
    problem: 'Verified deterministic checkpoint resume with self-healing automatic worker failover.',
    evidence: 'Recovered training run EXP-04 within 2.2 seconds without loss drift or step desynchronization.',
    userImpact: 'Protects researchers from overnight multi-node GPU cluster crashes.',
    recommendation: 'Maintain immutable checkpoint storage bsy://checkpoints/ with SHA256 validation.',
    confidence: 99,
    status: 'VERIFIED',
    date: '2026-09-18'
  },
  {
    id: 'fnd_02',
    category: 'EXPERIMENTAL',
    domain: 'Crypto Payment Gateway',
    severity: 'LOW',
    auditorType: 'AI_AUDITOR',
    auditorName: 'AIAuditor: Blockchain & Gateway',
    problem: 'Priority tokens (YGO, YUSD, YAGYX) require strict RPC node redundancy across Polygon and Arbitrum.',
    evidence: 'Polygon public RPC occasionally reports block height latency during network congestion.',
    userImpact: 'Could delay payment confirmation from 30 seconds to 2 minutes.',
    recommendation: 'Configure secondary fallback RPC endpoints (Alchemy / Infura / QuickNode) in crypto gateway server adapter.',
    confidence: 94,
    status: 'FIXED',
    date: '2026-09-18'
  },
  {
    id: 'fnd_03',
    category: 'STRONG',
    domain: 'Data Firewall & Tenant Isolation',
    severity: 'INFORMATIONAL',
    auditorType: 'AI_AUDITOR',
    auditorName: 'AIAuditor: Security & Red Team',
    problem: 'Private customer datasets must remain technically quarantined from collective knowledge engine.',
    evidence: 'Privacy classification taxonomy strictly flags PRIVATE vs CONSENTED_GLOBAL_KNOWLEDGE before indexing.',
    userImpact: 'Zero risk of customer IP or internal proprietary prompts leaking into foundation models.',
    recommendation: 'Enforce automatic PII masking and cryptographic checksum checks on every knowledge candidate.',
    confidence: 98,
    status: 'VERIFIED',
    date: '2026-09-18'
  }
];

export const INITIAL_LAUNCH_PLAN: LaunchPhasePlan[] = [
  {
    phase: 'T-7',
    title: 'Sovereign Research Paper Release & ArXiv Preprint Indexing',
    objective: 'Establish scientific peer-reviewed credibility through Indic benchmark reproducibility.',
    audience: 'AI Researchers, Academic Labs, MLSys Developers',
    channels: ['ArXiv Preprint', 'LinkedIn Tech Posts', 'GitHub DNA Manifests'],
    cta: 'Reproduce EXP-04 in 1-Click Free Cloud',
    budgetINR: 0,
    status: 'COMPLETED',
    ownerDepartment: 'RESEARCH_DIVISION',
    keyAssets: ['IndicTokenBench Whitepaper', 'Bhasha-Instruct-v3 Dataset Manifest', 'Reproducibility Notebook']
  },
  {
    phase: 'T-3',
    title: 'University AI Fellowship Launch (IIT, NIT, IISc)',
    objective: 'Distribute 2-hour daily free compute to accredited national scholars and faculty.',
    audience: 'University PhD scholars, student developers, AI clubs',
    channels: ['Direct University Portals', 'Academic Email Networks', 'WhatsApp Student Groups'],
    cta: 'Claim Free 2 Compute-Hours/Day Student Quota',
    budgetINR: 0,
    status: 'READY_ACTIVE',
    ownerDepartment: 'GROWTH_DIVISION',
    keyAssets: ['Fellowship Portal', 'Student Verification API Adapter', 'National Leaderboard']
  },
  {
    phase: 'DAY_0',
    title: 'National Launch: Bharat HyperCompute Cloud & Transparent Wholesale Market',
    objective: 'Announce sovereign compute platform with ~50% market discount where economically viable.',
    audience: 'Global AI builders, Indian tech startups, deep-tech founders, enterprise CIOs',
    channels: ['Product-Led Demo Live', 'Developer Community Hackathons', 'Open Sovereign Leaderboards'],
    cta: 'Start Building Free — We Handle The Compute',
    budgetINR: 15000,
    status: 'SCHEDULED',
    ownerDepartment: 'EXECUTIVE_BRAIN',
    keyAssets: ['Live Interactive API Playground', 'Compute Brain Demo', 'Transparent Pricing Ledger']
  }
];
