import {
  User,
  Organization,
  Project,
  Notebook,
  Dataset,
  Experiment,
  Model,
  Deployment,
  Accelerator,
  ResearchTimelineEvent,
  ResearchMemoryEntry,
  AuditLog
} from '../types';

export const INITIAL_USER_FREE: User = {
  id: 'usr_free_01',
  name: 'Ananya Sharma',
  email: 'ananya.sharma@research.ac.in',
  role: 'Researcher',
  entitlement: 'free',
  dailyComputeHoursUsed: 0.85,
  dailyComputeHoursLimit: 2.0,
  resetTime: '04:00 UTC (in 7 hrs)',
  activeOrgId: 'org_bharat_01'
};

export const INITIAL_USER_FOUNDER: User = {
  id: 'usr_mii_founder',
  name: 'MII Founder',
  email: 'founder@mii.org.in',
  role: 'Owner',
  entitlement: 'founder',
  dailyComputeHoursUsed: 14.8,
  dailyComputeHoursLimit: -1, // Unlimited compute credits quota
  resetTime: 'Continuous (Founder Quota Bypass)',
  activeOrgId: 'org_bharat_01'
};

export const INITIAL_ORG: Organization = {
  id: 'org_bharat_01',
  name: 'Bharat AI Research Lab',
  tier: 'Founder Tier',
  membersCount: 8,
  monthlyBudgetCredits: 50000,
  usedCredits: 12450
};

export const INITIAL_PROJECT: Project = {
  id: 'proj_indic_7b',
  name: 'IndicLLM-Bharat-7B',
  description: 'National bilingual foundation model fine-tuned on instruction corpora across 12 scheduled Indian languages with high factual fidelity.',
  tags: ['LLM', 'Indic-NLP', 'Fine-Tuning', 'DDP', 'PyTorch'],
  createdAt: '2026-08-10',
  updatedAt: 'Just now',
  notebooksCount: 2,
  experimentsCount: 5,
  modelsCount: 2,
  deploymentsCount: 1
};

export const INITIAL_ACCELERATORS: Accelerator[] = [
  {
    id: 'acc_h100',
    name: 'BHARAT H100 SXM5 (80GB HBM3)',
    category: 'GPU',
    vramGB: 80,
    teraflops: 1979,
    costPerHourCredits: 32,
    provider: 'Bharat Cloud (Demo)',
    isDemo: true,
    status: 'Available'
  },
  {
    id: 'acc_a100',
    name: 'BHARAT A100 TensorCore (80GB SXM4)',
    category: 'GPU',
    vramGB: 80,
    teraflops: 624,
    costPerHourCredits: 18,
    provider: 'Bharat Cloud (Demo)',
    isDemo: true,
    status: 'Available'
  },
  {
    id: 'acc_l40s',
    name: 'BHARAT L40S Compute Engine (48GB)',
    category: 'GPU',
    vramGB: 48,
    teraflops: 366,
    costPerHourCredits: 12,
    provider: 'Bharat Cloud (Demo)',
    isDemo: true,
    status: 'Available'
  },
  {
    id: 'acc_tpu_v4',
    name: 'BHARAT TPU v4-16 Pod Slice',
    category: 'TPU',
    vramGB: 128,
    teraflops: 1100,
    costPerHourCredits: 24,
    provider: 'Bharat Cloud (Demo)',
    isDemo: true,
    status: 'Queue'
  },
  {
    id: 'acc_cpu_cluster',
    name: 'High-Mem Workstation Node (64 vCPU, 256GB RAM)',
    category: 'CPU',
    vramGB: 0,
    teraflops: 45,
    costPerHourCredits: 2,
    provider: 'Connected Node (Real)',
    isDemo: false,
    status: 'Available'
  }
];

export const INITIAL_NOTEBOOK: Notebook = {
  id: 'nb_01',
  projectId: 'proj_indic_7b',
  title: '01_FineTune_IndicLLM_Bharat_7B.ipynb',
  lastSaved: '2 minutes ago',
  runtimeState: 'connected',
  activeAccelerator: 'BHARAT H100 SXM5 (80GB)',
  cells: [
    {
      id: 'cell_1',
      type: 'markdown',
      content: `# 🇮🇳 Bharat HyperCompute — IndicLLM-7B Fine-Tuning\n\nThis notebook demonstrates fine-tuning the 7B parameter base model on the curated **Bhasha-Instruct-v3** dataset using PyTorch with Distributed Data Parallel (DDP) and FlashAttention-2.\n\n*Compute Brain allocation:* **4× BHARAT H100 SXM5 (80GB)** with **bf16** mixed precision.`,
      status: 'completed'
    },
    {
      id: 'cell_2',
      type: 'code',
      content: `import torch\nimport transformers\nfrom bharat_hypercompute import ComputeBrain, SelfHealingTrainer\n\nprint(f"PyTorch Version: {torch.__version__}")\nprint(f"CUDA Available: {torch.cuda.is_available()}")\nif torch.cuda.is_available():\n    print(f"Cluster: {torch.cuda.device_count()}x {torch.cuda.get_device_name(0)}")`,
      output: `PyTorch Version: 2.5.1+cu124\nCUDA Available: True\nCluster: 4x BHARAT H100 SXM5 80GB HBM3 [Simulated Demo Environment]`,
      status: 'completed',
      executionTimeMs: 412,
      lastExecuted: '3 minutes ago'
    },
    {
      id: 'cell_3',
      type: 'code',
      content: `# Load Dataset from Dataset Center (Version 3)\nfrom datasets import load_dataset\n\ndataset = load_dataset('mii/bhasha-instruct-v3', split='train')\nprint(f"Loaded {len(dataset):,} instruction-response pairs across 12 Indian Languages.")\nprint("Languages represented: Hindi, Bengali, Tamil, Telugu, Marathi, Gujarati, Kannada, Malayalam, Odia, Punjabi, Assamese, Sanskrit.")`,
      output: `Dataset loaded: mii/bhasha-instruct-v3 [Verified SHA-256: 8f4b...1a09]\nTotal Records: 850,000 instruction-response pairs\nSchema Health: Optimal (0.00% missing tokens, 0.12% deduplicated)`,
      status: 'completed',
      executionTimeMs: 1240,
      lastExecuted: '2 minutes ago'
    },
    {
      id: 'cell_4',
      type: 'code',
      content: `# Configure Compute & Self-Healing Checkpointing\ntraining_args = {\n    "model_name": "bharat-indic-7b-base",\n    "learning_rate": 2e-5,\n    "batch_size_per_device": 8,\n    "gradient_accumulation_steps": 4,\n    "effective_batch_size": 128,\n    "epochs": 3,\n    "warmup_ratio": 0.03,\n    "checkpoint_interval_steps": 250,\n    "self_healing_enabled": True\n}\n\nprint("Trainer configured with Compute Brain auto-checkpointing.")`,
      output: `[Compute Brain] Strategy: Balanced (DDP 4x H100)\nEstimated Step Time: 114ms | Estimated Epoch: ~42m\nCheckpoint target: bsy://checkpoints/indic7b/run_05/`,
      status: 'completed',
      executionTimeMs: 310,
      lastExecuted: 'Just now'
    }
  ]
};

export const INITIAL_DATASET: Dataset = {
  id: 'ds_bhasha_v3',
  projectId: 'proj_indic_7b',
  name: 'Bhasha-Instruct-Multilingual',
  format: 'Parquet',
  description: 'Cleaned, deduplicated instruction-tuning corpus covering 12 Indic languages with verified cultural context and academic domain prompts.',
  currentVersion: 'v3.0.0',
  owner: 'Ananya Sharma',
  createdAt: '2026-08-15',
  versions: [
    {
      version: 'v3.0.0',
      sizeMB: 1240,
      recordsCount: 850000,
      createdAt: '2026-09-02',
      schemaHealth: 'Optimal',
      missingValuesPct: 0.01,
      duplicatesEstimatePct: 0.08,
      changeSummary: 'Added Sanskrit Vedic grammatical reasoning and improved Malayalam conversational tone.'
    },
    {
      version: 'v2.1.0',
      sizeMB: 980,
      recordsCount: 680000,
      createdAt: '2026-08-22',
      schemaHealth: 'Optimal',
      missingValuesPct: 0.04,
      duplicatesEstimatePct: 0.45,
      changeSummary: 'Deduplicated English-Hindi transliteration pairs using embedding cosine similarity.'
    },
    {
      version: 'v1.0.0',
      sizeMB: 650,
      recordsCount: 420000,
      createdAt: '2026-08-15',
      schemaHealth: 'Warnings',
      missingValuesPct: 0.85,
      duplicatesEstimatePct: 2.10,
      changeSummary: 'Initial raw ingestion from crowdsourced Indic language portals.'
    }
  ]
};

export const INITIAL_EXPERIMENTS: Experiment[] = [
  {
    id: 'EXP-04',
    projectId: 'proj_indic_7b',
    name: 'DDP 4x H100 bf16 Bhasha-v3 (Production Candidate)',
    objective: 'Fine-tune 7B base model with DDP 4x H100 using FlashAttention-2 and Bhasha-v3 corpus.',
    status: 'completed',
    modelName: 'Bharat-IndicLLM-7B-Base',
    datasetVersion: 'v3.0.0',
    hyperparameters: {
      learningRate: 0.00002,
      batchSize: 128,
      epochs: 3,
      warmupRatio: 0.03,
      optimizer: 'AdamW (beta1=0.9, beta2=0.95)',
      precision: 'bf16'
    },
    seed: 42,
    computeAlloc: {
      acceleratorId: 'acc_h100',
      acceleratorName: '4× BHARAT H100 SXM5 (80GB)',
      count: 4,
      distributionMode: 'Data-Parallel (DDP)',
      priority: 'Founder Priority',
      isDemo: true
    },
    metrics: {
      trainLoss: 0.318,
      valLoss: 0.339,
      perplexity: 1.403,
      tokensPerSec: 14200,
      evalAccuracy: 92.4
    },
    runtimeSeconds: 7420,
    estimatedCredits: 96,
    dna: {
      dnaHash: 'DNA-9a8c2f1e4b',
      codeHash: 'git:7bfa048',
      datasetVersion: 'v3.0.0',
      modelBase: 'bharat-7b-v0.9',
      environment: 'PyTorch 2.5 + CUDA 12.4 + FlashAttn-2',
      seed: 42,
      computeConfig: '4x H100 DDP / bf16 / grad_accum=4'
    },
    checkpoints: [
      { id: 'ckpt_4_1', epoch: 1, step: 2000, loss: 0.582, valAccuracy: 84.1, timestamp: '14:20', sizeMB: 14200, isAutomatic: true },
      { id: 'ckpt_4_2', epoch: 2, step: 4000, loss: 0.412, valAccuracy: 89.2, timestamp: '15:35', sizeMB: 14200, isAutomatic: true },
      { id: 'ckpt_4_3', epoch: 3, step: 6000, loss: 0.318, valAccuracy: 92.4, timestamp: '16:50', sizeMB: 14200, isAutomatic: true }
    ],
    reproducible: true,
    isPublic: true,
    author: 'Ananya Sharma',
    createdAt: '2026-09-12 14:00'
  },
  {
    id: 'EXP-03',
    projectId: 'proj_indic_7b',
    name: 'Single A100 fp16 Bhasha-v2 Baseline',
    objective: 'Initial benchmark run using single 80GB A100 to evaluate token throughput vs cost.',
    status: 'completed',
    modelName: 'Bharat-IndicLLM-7B-Base',
    datasetVersion: 'v2.1.0',
    hyperparameters: {
      learningRate: 0.00003,
      batchSize: 32,
      epochs: 2,
      warmupRatio: 0.05,
      optimizer: 'AdamW',
      precision: 'fp16'
    },
    seed: 42,
    computeAlloc: {
      acceleratorId: 'acc_a100',
      acceleratorName: '1× BHARAT A100 SXM4 (80GB)',
      count: 1,
      distributionMode: 'Single-Node',
      priority: 'Standard',
      isDemo: true
    },
    metrics: {
      trainLoss: 0.485,
      valLoss: 0.512,
      perplexity: 1.668,
      tokensPerSec: 3600,
      evalAccuracy: 86.8
    },
    runtimeSeconds: 12800,
    estimatedCredits: 64,
    dna: {
      dnaHash: 'DNA-3d71e9821a',
      codeHash: 'git:10e922b',
      datasetVersion: 'v2.1.0',
      modelBase: 'bharat-7b-v0.9',
      environment: 'PyTorch 2.4 + CUDA 12.1',
      seed: 42,
      computeConfig: '1x A100 Single-Node / fp16 / batch=32'
    },
    checkpoints: [
      { id: 'ckpt_3_1', epoch: 1, step: 1500, loss: 0.690, valAccuracy: 79.5, timestamp: '10:00', sizeMB: 14200, isAutomatic: true },
      { id: 'ckpt_3_2', epoch: 2, step: 3000, loss: 0.485, valAccuracy: 86.8, timestamp: '13:30', sizeMB: 14200, isAutomatic: true }
    ],
    reproducible: true,
    isPublic: false,
    author: 'Ananya Sharma',
    createdAt: '2026-09-08 09:30'
  },
  {
    id: 'EXP-02',
    projectId: 'proj_indic_7b',
    name: 'TPU v4-16 JAX/Flax Exploration',
    objective: 'Test scaling efficiency and compilation overhead with JAX Pjit on TPU v4 slice.',
    status: 'completed',
    modelName: 'Bharat-IndicLLM-7B-Base',
    datasetVersion: 'v2.1.0',
    hyperparameters: {
      learningRate: 0.000025,
      batchSize: 64,
      epochs: 1,
      warmupRatio: 0.02,
      optimizer: 'Adafactor',
      precision: 'bf16'
    },
    seed: 1337,
    computeAlloc: {
      acceleratorId: 'acc_tpu_v4',
      acceleratorName: 'BHARAT TPU v4-16 Pod Slice',
      count: 1,
      distributionMode: 'Tensor-Parallel',
      priority: 'Standard',
      isDemo: true
    },
    metrics: {
      trainLoss: 0.540,
      valLoss: 0.562,
      perplexity: 1.754,
      tokensPerSec: 16800,
      evalAccuracy: 84.9
    },
    runtimeSeconds: 3600,
    estimatedCredits: 24,
    dna: {
      dnaHash: 'DNA-77fa6c882d',
      codeHash: 'git:98a0021',
      datasetVersion: 'v2.1.0',
      modelBase: 'bharat-7b-v0.9',
      environment: 'JAX 0.4.30 + LibTPU',
      seed: 1337,
      computeConfig: 'TPU v4-16 / bf16 / Pjit 2D mesh'
    },
    checkpoints: [
      { id: 'ckpt_2_1', epoch: 1, step: 1000, loss: 0.540, valAccuracy: 84.9, timestamp: '11:00', sizeMB: 13900, isAutomatic: true }
    ],
    reproducible: true,
    isPublic: true,
    author: 'Devendra Patel',
    createdAt: '2026-09-04 10:15'
  }
];

export const INITIAL_MODELS: Model[] = [
  {
    id: 'mdl_indic_7b',
    projectId: 'proj_indic_7b',
    name: 'Bharat-IndicLLM-7B-Instruct',
    currentVersion: 'v1.0.0',
    description: 'Fine-tuned bilingual foundational language model optimized for conversational Hindi, Bengali, Tamil, and English multilingual comprehension.',
    deploymentStatus: 'active',
    activeDeploymentId: 'dep_indic_prod',
    owner: 'Ananya Sharma',
    versions: [
      {
        version: 'v1.0.0',
        experimentId: 'EXP-04',
        datasetVersion: 'v3.0.0',
        paramsCount: '7.24 Billion',
        sizeMB: 14450,
        framework: 'vLLM',
        status: 'Deployed',
        metrics: {
          valLoss: 0.339,
          accuracy: 92.4,
          latencyP95Ms: 24.2
        },
        createdAt: '2026-09-13'
      },
      {
        version: 'v0.9.1',
        experimentId: 'EXP-03',
        datasetVersion: 'v2.1.0',
        paramsCount: '7.24 Billion',
        sizeMB: 14450,
        framework: 'PyTorch',
        status: 'Validated',
        metrics: {
          valLoss: 0.512,
          accuracy: 86.8,
          latencyP95Ms: 48.6
        },
        createdAt: '2026-09-09'
      }
    ]
  }
];

export const INITIAL_DEPLOYMENT: Deployment = {
  id: 'dep_indic_prod',
  modelId: 'mdl_indic_7b',
  modelName: 'Bharat-IndicLLM-7B-Instruct',
  modelVersion: 'v1.0.0',
  endpoint: 'https://api.bharat-hypercompute.in/v1/models/indic-7b-instruct:generate',
  status: 'active',
  compute: '2× BHARAT L40S vLLM Engine (Demo Endpoint)',
  apiKeyMasked: 'bhc_live_9f82••••••••••••34a1',
  requests24h: 14820,
  avgLatencyMs: 24,
  errorRatePct: 0.02,
  createdAt: '2026-09-14'
};

export const INITIAL_TIMELINE: ResearchTimelineEvent[] = [
  {
    id: 'evt_1',
    projectId: 'proj_indic_7b',
    type: 'project',
    title: 'Project Initialized',
    description: 'Research workspace created under Bharat AI Research Lab.',
    timestamp: 'Aug 10, 2026',
    trustTag: 'EXECUTED'
  },
  {
    id: 'evt_2',
    projectId: 'proj_indic_7b',
    type: 'dataset',
    title: 'Dataset Ingested & Versioned (v3.0.0)',
    description: 'Ingested 850k bilingual pairs; schema health validated with 0.08% duplication estimate.',
    timestamp: 'Sep 02, 2026',
    trustTag: 'EXECUTED'
  },
  {
    id: 'evt_3',
    projectId: 'proj_indic_7b',
    type: 'compute',
    title: 'Compute Brain Analysis Completed',
    description: 'Recommended 4x H100 SXM5 DDP over single-node to complete training in under 2.5 hrs.',
    timestamp: 'Sep 12, 13:45',
    trustTag: 'SUGGESTED'
  },
  {
    id: 'evt_4',
    projectId: 'proj_indic_7b',
    type: 'experiment',
    title: 'Experiment EXP-04 Launched',
    description: 'DDP 4x H100 bf16 training job executed; self-healing trainer attached.',
    timestamp: 'Sep 12, 14:00',
    trustTag: 'EXECUTED'
  },
  {
    id: 'evt_5',
    projectId: 'proj_indic_7b',
    type: 'checkpoint',
    title: 'Epoch 3 Convergence Checkpoint (Loss: 0.318)',
    description: 'Saved optimal weights checkpoint to simulated storage (ckpt_4_3).',
    timestamp: 'Sep 12, 16:50',
    trustTag: 'EXECUTED'
  },
  {
    id: 'evt_6',
    projectId: 'proj_indic_7b',
    type: 'model',
    title: 'Model Registered (v1.0.0)',
    description: 'Registered Bharat-IndicLLM-7B-Instruct with 92.4% validation accuracy score.',
    timestamp: 'Sep 13, 10:30',
    trustTag: 'EXECUTED'
  },
  {
    id: 'evt_7',
    projectId: 'proj_indic_7b',
    type: 'deployment',
    title: 'Model → API Endpoint Live',
    description: 'Deployed to vLLM serverless endpoint with 24ms p95 latency profile.',
    timestamp: 'Sep 14, 11:15',
    trustTag: 'EXECUTED'
  }
];

export const INITIAL_RESEARCH_MEMORY: ResearchMemoryEntry[] = [
  {
    id: 'mem_1',
    projectId: 'proj_indic_7b',
    key: 'Precision & Throughput',
    finding: 'bf16 precision yields 2.85× higher token throughput than fp32 on H100 with zero degradation in perplexity (1.40 vs 1.41).',
    evidence: 'Measured in EXP-04 vs baseline pilot on synthetic validation sets.',
    confidence: 'High',
    timestamp: 'Sep 12, 2026'
  },
  {
    id: 'mem_2',
    projectId: 'proj_indic_7b',
    key: 'Learning Rate Warmup',
    finding: 'Warmup ratio of 0.03 prevents early gradient spike on newly initialized Devanagari embeddings.',
    evidence: 'Observed gradient norm stabilized at 0.42 throughout 6,000 steps.',
    confidence: 'Empirical',
    timestamp: 'Sep 09, 2026'
  },
  {
    id: 'mem_3',
    projectId: 'proj_indic_7b',
    key: 'Dataset Deduplication Impact',
    finding: 'Pruning 0.45% noisy transliterated pairs in v2.1 reduced repetitive token loops in conversational responses.',
    evidence: 'Human eval score improved from 78.4 to 88.2 on test prompt suite.',
    confidence: 'High',
    timestamp: 'Aug 25, 2026'
  }
];

export const INITIAL_AUDIT_LOGS: AuditLog[] = [
  {
    id: 'aud_01',
    action: 'Deployment Created',
    actor: 'Ananya Sharma',
    target: 'Bharat-IndicLLM-7B-Instruct v1.0.0',
    timestamp: '2026-09-14 11:15:00 UTC',
    ip: '103.21.144.62'
  },
  {
    id: 'aud_02',
    action: 'Experiment EXP-04 Approved & Dispatched',
    actor: 'MII Founder',
    target: '4x H100 DDP Cluster Allocation',
    timestamp: '2026-09-12 14:00:22 UTC',
    ip: '103.21.144.10'
  },
  {
    id: 'aud_03',
    action: 'Dataset Version v3.0.0 Published',
    actor: 'Ananya Sharma',
    target: 'Bhasha-Instruct-Multilingual',
    timestamp: '2026-09-02 18:30:11 UTC',
    ip: '103.21.144.62'
  }
];
