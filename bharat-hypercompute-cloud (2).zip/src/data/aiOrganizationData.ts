import {
  OrgDepartmentId,
  DepartmentAllocationInfo,
  DetailedAIAgent,
  OrchestrationTaskItem,
  OwnerApprovalRequest,
  ImmutableAuditLogRecord,
  AutonomousSelfOptimizationProposal,
  CompanyKnowledgeMemoryItem,
  AiOrganizationState
} from '../types/aiOrganization';

export const INITIAL_DEPARTMENTS: DepartmentAllocationInfo[] = [
  {
    id: 'dept_executive_orchestration',
    number: 1,
    name: 'Executive Orchestration',
    shortName: 'Executive',
    targetCapacity: 20,
    activeCount: 3,
    sleepingCount: 16,
    queuedCount: 1,
    blockedCount: 0,
    directorName: 'Executive Orchestrator Alpha',
    directorAgentId: 'agent_exec_01_orchestrator',
    purpose: 'Chief AI Orchestration, priority scheduling, cross-department coordination & owner policy enforcement',
    keySpecialties: ['Strategic Planning', 'Cross-Dept Routing', 'Escalation Arbiter', 'Budget Guardrails'],
    budgetCapUSD: 50.00,
    spentUSD: 6.42
  },
  {
    id: 'dept_aiml_research',
    number: 2,
    name: 'AI / ML Research',
    shortName: 'AI Research',
    targetCapacity: 80,
    activeCount: 4,
    sleepingCount: 72,
    queuedCount: 3,
    blockedCount: 1,
    directorName: 'Dr. Research Lead Matrix',
    directorAgentId: 'agent_aiml_01_director',
    purpose: 'Model architectures, Indic tokenization, attention mechanisms, reasoning paths & empirical scaling curves',
    keySpecialties: ['Transformer Scaling', 'Multimodal Kernels', 'Indic Tokenizer', 'Ablation Synthesis'],
    budgetCapUSD: 120.00,
    spentUSD: 18.90
  },
  {
    id: 'dept_software_engineering',
    number: 3,
    name: 'Software Engineering',
    shortName: 'Engineering',
    targetCapacity: 120,
    activeCount: 6,
    sleepingCount: 108,
    queuedCount: 4,
    blockedCount: 2,
    directorName: 'Chief Architect Turing',
    directorAgentId: 'agent_swe_01_director',
    purpose: 'Full-stack platform, distributed orchestration, API gateway, notebook kernels & AST refactoring',
    keySpecialties: ['React/TypeScript', 'Python Kernels', 'Distributed RPC', 'AST Mutation', 'Database Engines'],
    budgetCapUSD: 150.00,
    spentUSD: 24.15
  },
  {
    id: 'dept_compute_hpc_infra',
    number: 4,
    name: 'Compute / HPC / Infrastructure',
    shortName: 'Compute HPC',
    targetCapacity: 100,
    activeCount: 5,
    sleepingCount: 91,
    queuedCount: 3,
    blockedCount: 1,
    directorName: 'Infra Commander Volta',
    directorAgentId: 'agent_hpc_01_director',
    purpose: 'GPU/TPU cluster allocation, InfiniBand/RoCE AllReduce topology, vLLM profiling & preemption failover',
    keySpecialties: ['CUDA Kernels', 'DDP Ring Scheduling', 'InfiniBand RoCE', 'Kubernetes Pods', 'vRAM Packing'],
    budgetCapUSD: 200.00,
    spentUSD: 31.80
  },
  {
    id: 'dept_security_privacy_trust',
    number: 5,
    name: 'Security / Privacy / Trust',
    shortName: 'Security',
    targetCapacity: 90,
    activeCount: 4,
    sleepingCount: 84,
    queuedCount: 2,
    blockedCount: 0,
    directorName: 'Trust Sentinel Cipher',
    directorAgentId: 'agent_sec_01_director',
    purpose: 'DPDP Act compliance, cryptographic isolation, red/blue teaming, prompt injection & secrets containment',
    keySpecialties: ['DPDP Compliance', 'Red Team Auditing', 'Vault Cryptography', 'Tenant Isolation', 'Zero-Egress'],
    budgetCapUSD: 100.00,
    spentUSD: 12.30
  },
  {
    id: 'dept_qa_testing_reliability',
    number: 6,
    name: 'QA / Testing / Reliability',
    shortName: 'QA & Testing',
    targetCapacity: 80,
    activeCount: 3,
    sleepingCount: 74,
    queuedCount: 2,
    blockedCount: 1,
    directorName: 'Chaos Director Verifier',
    directorAgentId: 'agent_qa_01_director',
    purpose: 'Synthetic cluster chaos injection, regression testing, E2E validation & automatic rollback assertions',
    keySpecialties: ['Chaos Mesh', 'Regression Verification', 'Checkpoint Fuzzing', 'E2E Flow Tests'],
    budgetCapUSD: 80.00,
    spentUSD: 9.75
  },
  {
    id: 'dept_product_ux_ui',
    number: 7,
    name: 'Product / UX / UI',
    shortName: 'Product UX',
    targetCapacity: 80,
    activeCount: 3,
    sleepingCount: 75,
    queuedCount: 2,
    blockedCount: 0,
    directorName: 'Experience Architect Nielsen',
    directorAgentId: 'agent_prod_01_director',
    purpose: 'Cognitive load reduction, progressive disclosure, WCAG AA contrast & developer workflow ergonomics',
    keySpecialties: ['Cognitive Load', 'Design System', 'Accessibility WCAG', 'Information Architecture'],
    budgetCapUSD: 75.00,
    spentUSD: 8.40
  },
  {
    id: 'dept_marketing_advertising_growth',
    number: 8,
    name: 'Marketing / Advertising / Growth',
    shortName: 'Growth & Mktg',
    targetCapacity: 80,
    activeCount: 3,
    sleepingCount: 75,
    queuedCount: 2,
    blockedCount: 0,
    directorName: 'Growth Strategist Vector',
    directorAgentId: 'agent_mktg_01_director',
    purpose: 'Technical audience research, reproducible paper discovery, honest developer messaging & referral engines',
    keySpecialties: ['Developer Outreach', 'Paper Diffusion', 'Organic Radar', 'Ad Budget Proposal'],
    budgetCapUSD: 90.00,
    spentUSD: 11.20
  },
  {
    id: 'dept_brand_creative_media',
    number: 9,
    name: 'Brand / Creative / Media',
    shortName: 'Brand & Media',
    targetCapacity: 50,
    activeCount: 2,
    sleepingCount: 47,
    queuedCount: 1,
    blockedCount: 0,
    directorName: 'Brand Custodian Sovereign',
    directorAgentId: 'agent_brand_01_director',
    purpose: 'Make in India provenance guardrails, zero-hype visual standards & restrained institutional aesthetics',
    keySpecialties: ['Brand Provenance', 'Typography Pairing', 'Zero-Slop Guidelines', 'Restrained Attribution'],
    budgetCapUSD: 50.00,
    spentUSD: 4.80
  },
  {
    id: 'dept_customer_intel_support',
    number: 10,
    name: 'Customer Intelligence / Support',
    shortName: 'Customer Intel',
    targetCapacity: 50,
    activeCount: 2,
    sleepingCount: 47,
    queuedCount: 1,
    blockedCount: 0,
    directorName: 'Researcher Advocate Mitra',
    directorAgentId: 'agent_cust_01_director',
    purpose: 'University triage, doctoral quota support, error classification & frictionless notebook onboarding',
    keySpecialties: ['Doctoral Triage', 'Error Diagnosis', 'Onboarding Walkthrough', 'Feedback Synthesis'],
    budgetCapUSD: 50.00,
    spentUSD: 5.60
  },
  {
    id: 'dept_finance_pricing_economics',
    number: 11,
    name: 'Finance / Pricing / Economics',
    shortName: 'Finance & Pricing',
    targetCapacity: 50,
    activeCount: 2,
    sleepingCount: 47,
    queuedCount: 1,
    blockedCount: 0,
    directorName: 'Economics Analyst Kautilya',
    directorAgentId: 'agent_fin_01_director',
    purpose: 'Wholesale compute arbitrage, margin reconciliation, capacity economics & India AI Mission subsidy modeling',
    keySpecialties: ['Wholesale Arbitrage', 'Margin Guardrails', 'Subsidy Modeling', 'Cost Ledger Reconciliation'],
    budgetCapUSD: 60.00,
    spentUSD: 6.90
  },
  {
    id: 'dept_payments_crypto_blockchain',
    number: 12,
    name: 'Payments / Crypto / Blockchain',
    shortName: 'Payments Crypto',
    targetCapacity: 50,
    activeCount: 2,
    sleepingCount: 47,
    queuedCount: 1,
    blockedCount: 0,
    directorName: 'Settlement Architect Ledger',
    directorAgentId: 'agent_pay_01_director',
    purpose: 'Dual-rail settlement (INR UPI & YGO/YUSD on-chain escrow), transaction reconciliation & fraud prevention',
    keySpecialties: ['UPI Gateway', 'YGO Token Escrow', 'Dual-Rail Verification', 'Fraud Prevention'],
    budgetCapUSD: 60.00,
    spentUSD: 7.20
  },
  {
    id: 'dept_data_knowledge_collective',
    number: 13,
    name: 'Data / Knowledge / Collective AI',
    shortName: 'Data Knowledge',
    targetCapacity: 50,
    activeCount: 2,
    sleepingCount: 47,
    queuedCount: 1,
    blockedCount: 0,
    directorName: 'Provenance Sentinel Jnana',
    directorAgentId: 'agent_data_01_director',
    purpose: 'Open dataset provenance, PII scrubbing, benchmark contamination checks & organizational knowledge graph',
    keySpecialties: ['PII Scrubbing', 'Dataset Lineage', 'Contamination Auditing', 'Knowledge Extraction'],
    budgetCapUSD: 60.00,
    spentUSD: 6.50
  },
  {
    id: 'dept_scientific_validation',
    number: 14,
    name: 'Scientific Validation / Benchmarking',
    shortName: 'Sci Validation',
    targetCapacity: 50,
    activeCount: 2,
    sleepingCount: 47,
    queuedCount: 1,
    blockedCount: 0,
    directorName: 'Chief Methodologist Ramanujan',
    directorAgentId: 'agent_sci_01_director',
    purpose: 'Strict hypothesis vs verified fact distinction, reproducible seed validation & ablation rigor',
    keySpecialties: ['Ablation Studies', 'Reproducibility Verification', 'Statistical Significance', 'Hypothesis Falsification'],
    budgetCapUSD: 60.00,
    spentUSD: 7.10
  },
  {
    id: 'dept_legal_compliance_governance',
    number: 15,
    name: 'Legal / Compliance / Governance',
    shortName: 'Legal Compliance',
    targetCapacity: 50,
    activeCount: 1,
    sleepingCount: 48,
    queuedCount: 1,
    blockedCount: 0,
    directorName: 'Jurisdiction Officer Dharma',
    directorAgentId: 'agent_legal_01_director',
    purpose: 'India DPDP Act 2023 compliance, MeitY cloud standards, open license tracking & AI ethics oversight (30 Legal Counsel + 20 Sovereign Governance Auditors)',
    keySpecialties: ['DPDP Act 2023', 'MeitY Guidelines', 'Open-Source Licensing', 'Data Residency Law'],
    budgetCapUSD: 40.00,
    spentUSD: 4.10
  }
];

// Helper to generate the exact 1,000 agents deterministically with all 24 required fields
export function generateExactThousandAgents(): DetailedAIAgent[] {
  const agents: DetailedAIAgent[] = [];

  const seniorities: DetailedAIAgent['seniority'][] = [
    'Department Director',
    'Principal Fellow',
    'Lead Specialist',
    'Senior Specialist',
    'Specialist',
    'Associate Specialist'
  ];

  const models = [
    { provider: 'Google AI (Gemini 2.0 Flash)', model: 'gemini-2.0-flash' },
    { provider: 'Google AI (Gemini 1.5 Flash)', model: 'gemini-1.5-flash' },
    { provider: 'Google AI (Gemini 1.5 Pro)', model: 'gemini-1.5-pro' },
    { provider: 'MII Sovereign Host (Local 8B)', model: 'local-specialized-8b' }
  ];

  INITIAL_DEPARTMENTS.forEach(dept => {
    for (let i = 1; i <= dept.targetCapacity; i++) {
      const isDirector = i === 1;
      const isTopFellow = i === 2 || i === 3;
      const isSenior = i >= 4 && i <= Math.min(15, Math.floor(dept.targetCapacity * 0.2));
      const isSpecialist = !isDirector && !isTopFellow && !isSenior;

      let seniority: DetailedAIAgent['seniority'] = 'Specialist';
      if (dept.id === 'dept_executive_orchestration' && isDirector) {
        seniority = 'Executive Orchestrator';
      } else if (isDirector) {
        seniority = 'Department Director';
      } else if (isTopFellow) {
        seniority = 'Principal Fellow';
      } else if (isSenior) {
        seniority = 'Senior Specialist';
      }

      const agentId = `agent_${dept.id.replace('dept_', '')}_${String(i).padStart(3, '0')}`;
      
      // Determine realistic state: only few active, majority sleeping
      let currentState: DetailedAIAgent['current_state'] = 'SLEEPING';
      let currentTask: string | null = null;
      let lastActive = `${(i * 7) % 60 + 5}m ago`;

      if (isDirector || i <= dept.activeCount) {
        currentState = i % 3 === 0 ? 'EXECUTING' : (i % 2 === 0 ? 'VERIFYING' : 'ACTIVE');
        currentTask = `Running scheduled cycle for ${dept.name} [Subtask #${i}]`;
        lastActive = 'Just now';
      } else if (i === dept.activeCount + 1) {
        currentState = 'QUEUED';
        currentTask = `Awaiting event trigger in ${dept.shortName} queue`;
        lastActive = '12m ago';
      } else if (dept.blockedCount > 0 && i === dept.targetCapacity) {
        currentState = 'AWAITING_APPROVAL';
        currentTask = `Requires L5 Owner approval: high impact operation`;
        lastActive = '2m ago';
      }

      // Governance levels
      const governanceLevel: DetailedAIAgent['governance_level'] = isDirector
        ? 'L4_APPROVED_WORKFLOW'
        : isTopFellow
        ? 'L3_REVERSIBLE_EXECUTION'
        : isSenior
        ? 'L2_DRAFT'
        : 'L1_SUGGEST';

      const riskLevel: DetailedAIAgent['risk_level'] =
        dept.id === 'dept_security_privacy_trust' || dept.id === 'dept_payments_crypto_blockchain'
          ? (isDirector ? 'Critical' : 'High')
          : isDirector
          ? 'High'
          : 'Low';

      const approvalReq: DetailedAIAgent['approval_requirement'] =
        riskLevel === 'Critical'
          ? 'OWNER_ADMIN_REQUIRED'
          : isDirector
          ? 'DIRECTOR_APPROVAL'
          : 'SUPERVISOR_VERIFY';

      const dataAccess: DetailedAIAgent['data_access_level'] =
        dept.id === 'dept_security_privacy_trust'
          ? 'L4_RESTRICTED_VAULT'
          : dept.id === 'dept_finance_pricing_economics'
          ? 'L1_INTERNAL_METRICS'
          : 'L2_ANONYMIZED_RESEARCH';

      const modelPick = models[i % models.length];

      agents.push({
        agent_id: agentId,
        department: dept.id,
        role: isDirector
          ? `${dept.name} Director`
          : `${dept.shortName} Specialist #${i}`,
        specialty: dept.keySpecialties[(i - 1) % dept.keySpecialties.length],
        seniority,
        capabilities: [
          `Event-driven ${dept.shortName} worker`,
          `Role-scoped task execution`,
          `Cryptographic audit logging`,
          `Budget-bounded invocation`
        ],
        model_provider: `${modelPick.model} via ${modelPick.provider}`,
        tools_allowed: [
          'read_telemetry',
          'write_scratchpad',
          'evaluate_ast',
          isDirector ? 'delegate_subtask' : 'submit_result'
        ],
        data_access_level: dataAccess,
        permissions: [
          `read:${dept.shortName.toLowerCase()}`,
          isDirector ? `manage:${dept.shortName.toLowerCase()}` : `execute:scoped_task`
        ],
        budget: isDirector ? 10.00 : 2.50,
        token_budget: isDirector ? 64000 : 16000,
        task_types: [
          `${dept.shortName}_routine_audit`,
          `${dept.shortName}_diagnostic`,
          `${dept.shortName}_verification`
        ],
        risk_level: riskLevel,
        approval_requirement: approvalReq,
        governance_level: governanceLevel,
        current_state: currentState,
        current_task: currentTask,
        parent_agent: isDirector
          ? (dept.id === 'dept_executive_orchestration' ? null : 'agent_exec_orchestration_001')
          : dept.directorAgentId,
        dependencies: isDirector ? [] : [dept.directorAgentId],
        performance: {
          evalScorePct: 96.5 + ((i * 3) % 35) / 10,
          rating: 4.8
        },
        success_rate: 98.2 + ((i * 7) % 18) / 10,
        average_latency: 280 + (i % 20) * 15,
        estimated_cost: parseFloat((0.05 + ((i * 13) % 150) / 100).toFixed(2)),
        last_active_timestamp: lastActive,
        audit_history: [
          {
            timestamp: '2026-09-20 06:15 IST',
            action: `Initialized event listener for ${dept.shortName}`,
            outcome: 'SUCCESS',
            costUSD: 0.002,
            verifier: 'agent_exec_orchestration_001'
          },
          {
            timestamp: '2026-09-20 06:40 IST',
            action: `Scoped evaluation cycle #${i}`,
            outcome: 'SUCCESS',
            costUSD: 0.008,
            verifier: dept.directorAgentId
          }
        ]
      });
    }
  });

  return agents;
}

export const INITIAL_ORCHESTRATION_TASKS: OrchestrationTaskItem[] = [
  {
    id: 'task_orch_001',
    title: 'Distributed DDP AllReduce Tensor Comm Latency Profiling',
    description: 'Inspect Ring AllReduce communication bottlenecks across 8x H100 SXM5 nodes with InfiniBand RoCE v2.',
    department: 'dept_compute_hpc_infra',
    requester: 'MII Executive Orchestrator',
    assignedAgentIds: ['agent_compute_hpc_infra_001', 'agent_compute_hpc_infra_002', 'agent_qa_testing_reliability_001'],
    assignedAgentNames: ['Infra Commander Volta', 'CUDA Kernel Specialist #2', 'Chaos Director Verifier'],
    currentStage: 'VERIFY',
    status: 'VERIFYING',
    riskLevel: 'Medium',
    governanceLevel: 'L3_REVERSIBLE_EXECUTION',
    estimatedCostUSD: 0.45,
    actualCostUSD: 0.41,
    tokensConsumed: 124500,
    modelUsed: 'gemini-2.0-flash',
    subtasks: [
      { id: 'sub_1', title: 'Capture NCCL comm trace logs', assignedTo: 'agent_compute_hpc_infra_002', status: 'DONE' },
      { id: 'sub_2', title: 'Calculate gradient synchronization overlap', assignedTo: 'agent_compute_hpc_infra_001', status: 'DONE' },
      { id: 'sub_3', title: 'Verify zero gradient corruption across ring', assignedTo: 'agent_qa_testing_reliability_001', status: 'DOING' }
    ],
    verificationNotes: 'Independent verifier confirming latency jitter is within <4% threshold under sustained load.',
    verifierAgentId: 'agent_qa_testing_reliability_001',
    confidenceScorePct: 99.2,
    approvalState: 'NONE_NEEDED',
    startedAt: '2026-09-20 06:20 IST',
    provenanceCitations: ['NCCL 2.19 Specification', 'InfiniBand Architecture Rel 1.5']
  },
  {
    id: 'task_orch_002',
    title: 'Customer Data Firewall Zero-Egress Audit (DPDP Act Compliance)',
    description: 'Verify that zero tenant private weights, notebook cells, or user datasets are ingested into collective training.',
    department: 'dept_security_privacy_trust',
    requester: 'Owner / Admin Security Directive',
    assignedAgentIds: ['agent_security_privacy_trust_001', 'agent_legal_compliance_governance_001'],
    assignedAgentNames: ['Trust Sentinel Cipher', 'Jurisdiction Officer Dharma'],
    currentStage: 'COMMIT',
    status: 'COMPLETED',
    riskLevel: 'Critical',
    governanceLevel: 'L5_RESTRICTED_HIGH_IMPACT',
    estimatedCostUSD: 0.85,
    actualCostUSD: 0.78,
    tokensConsumed: 210000,
    modelUsed: 'gemini-1.5-pro',
    subtasks: [
      { id: 'sub_4', title: 'Static code audit on data pipelines', assignedTo: 'agent_security_privacy_trust_001', status: 'DONE' },
      { id: 'sub_5', title: 'Affirmative consent cryptographic gating check', assignedTo: 'agent_security_privacy_trust_001', status: 'DONE' },
      { id: 'sub_6', title: 'DPDP Act Section 6 & 8 compliance validation', assignedTo: 'agent_legal_compliance_governance_001', status: 'DONE' }
    ],
    verificationNotes: 'Strict affirmative consent gate validated. 100% hard quarantine enforced by default. HTTP 403 verified.',
    verifierAgentId: 'agent_legal_compliance_governance_001',
    confidenceScorePct: 99.8,
    approvalState: 'APPROVED_BY_OWNER',
    startedAt: '2026-09-20 05:45 IST',
    completedAt: '2026-09-20 06:12 IST',
    provenanceCitations: ['DPDP Act 2023 Gazette of India', 'MII Security Architecture v3.4']
  },
  {
    id: 'task_orch_003',
    title: 'Autonomous Margin Reconciliation vs Global Wholesale Spot Prices',
    description: 'Audit spot GPU wholesale prices across 4 provider regions and ensure sovereign developer subsidy keeps 34% margin.',
    department: 'dept_finance_pricing_economics',
    requester: 'MII Executive Orchestrator',
    assignedAgentIds: ['agent_finance_pricing_economics_001', 'agent_payments_crypto_blockchain_001'],
    assignedAgentNames: ['Economics Analyst Kautilya', 'Settlement Architect Ledger'],
    currentStage: 'EXECUTE',
    status: 'IN_PROGRESS',
    riskLevel: 'Low',
    governanceLevel: 'L2_DRAFT',
    estimatedCostUSD: 0.20,
    actualCostUSD: 0.16,
    tokensConsumed: 48000,
    modelUsed: 'gemini-1.5-flash',
    subtasks: [
      { id: 'sub_7', title: 'Pull wholesale telemetry feeds', assignedTo: 'agent_finance_pricing_economics_001', status: 'DONE' },
      { id: 'sub_8', title: 'Calculate India AI Mission 50% subsidy delta', assignedTo: 'agent_finance_pricing_economics_001', status: 'DOING' },
      { id: 'sub_9', title: 'Verify YGO/YUSD crypto escrow stability', assignedTo: 'agent_payments_crypto_blockchain_001', status: 'QUEUED' }
    ],
    confidenceScorePct: 98.5,
    approvalState: 'NONE_NEEDED',
    startedAt: '2026-09-20 06:35 IST',
    provenanceCitations: ['Wholesale Arbitrage Ledger', 'India AI Mission Guideline 2024']
  }
];

export const INITIAL_OWNER_APPROVALS: OwnerApprovalRequest[] = [
  {
    id: 'appr_req_001',
    taskId: 'task_orch_ad_01',
    title: 'Ad Campaign Budget Allocation ($250 USD) for Developer AI Mission',
    category: 'AD_SPEND',
    description: 'Growth department has prepared an honest developer campaign focusing on zero-slop GPU pricing. Proposing $250 initial budget.',
    requestedByAgentId: 'agent_marketing_advertising_growth_001',
    requestedByAgentName: 'Growth Strategist Vector',
    department: 'dept_marketing_advertising_growth',
    estimatedCostUSD: 250.00,
    risk: 'High',
    status: 'PENDING',
    timestamp: '2026-09-20 06:28 IST',
    justification: 'Campaign contains zero hype, zero fake engagement, and passes all 13 anti-spam guidelines.',
    reversible: false,
    blastRadius: 'Public developer advertising channel; strictly owner-gated per Policy §10'
  },
  {
    id: 'appr_req_002',
    taskId: 'task_orch_sec_02',
    title: 'Update Cross-Tenant Cryptographic Vault Rotation Policy',
    category: 'SECURITY_POLICY',
    description: 'Security department proposes reducing automated key rotation interval from 30 days to 7 days for heightened DPDP posture.',
    requestedByAgentId: 'agent_security_privacy_trust_001',
    requestedByAgentName: 'Trust Sentinel Cipher',
    department: 'dept_security_privacy_trust',
    estimatedCostUSD: 0.00,
    risk: 'Critical',
    status: 'PENDING',
    timestamp: '2026-09-20 06:10 IST',
    justification: 'Hardens tenant secret containment against memory-scraping attacks in shared worker pools.',
    reversible: true,
    blastRadius: 'All active tenant keyrings; requires owner sign-off'
  }
];

export const INITIAL_AUDIT_LOG_RECORDS: ImmutableAuditLogRecord[] = [
  {
    id: 'log_imm_001',
    timestamp: '2026-09-20 06:48 IST',
    who: 'Executive Orchestrator Alpha',
    roleOrSeniority: 'Chief AI Orchestrator',
    what: 'Dispatched event-driven health audit to 15 Department Directors',
    why: 'Routine operational telemetry verification before release gate',
    agentId: 'agent_exec_orchestration_001',
    taskId: 'task_orch_001',
    toolUsed: 'dispatch_event_queue',
    dataAccessed: 'Internal node telemetry & worker queue depth',
    resultStatus: 'SUCCESS',
    approvalRequirementMet: true,
    costUSD: 0.012,
    immutableHash: 'sha256:7f83b1657ff1fc53b92dc18148a1d65dfc2d4b1fa3d677284addd200126d9069'
  },
  {
    id: 'log_imm_002',
    timestamp: '2026-09-20 06:30 IST',
    who: 'Trust Sentinel Cipher',
    roleOrSeniority: 'Security Director',
    what: 'Enforced DPDP quarantine on incoming dataset manifest',
    why: 'Tenant data isolation rule: No customer weights into collective training',
    agentId: 'agent_security_privacy_trust_001',
    toolUsed: 'quarantine_isolate_vault',
    dataAccessed: 'Object metadata hash (Payload quarantined)',
    resultStatus: 'SUCCESS',
    approvalRequirementMet: true,
    costUSD: 0.005,
    immutableHash: 'sha256:4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a'
  },
  {
    id: 'log_imm_003',
    timestamp: '2026-09-20 06:14 IST',
    who: 'Owner (Dhaval Batwal)',
    roleOrSeniority: 'Owner / System Administrator',
    what: 'Granted approval for DPDP Section 6 Cryptographic Verification',
    why: 'Mandatory high-impact gate approval',
    taskId: 'task_orch_002',
    resultStatus: 'SUCCESS',
    approvalRequirementMet: true,
    costUSD: 0.00,
    immutableHash: 'sha256:ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d'
  }
];

export const INITIAL_SELF_OPTIMIZATIONS: AutonomousSelfOptimizationProposal[] = [
  {
    id: 'opt_prop_001',
    type: 'MODEL_ROUTING_CHANGE',
    title: 'Route AST Linting and Schema Validation to Gemini 2.0 Flash',
    department: 'dept_software_engineering',
    currentBottleneck: 'Using Gemini 1.5 Pro for simple Python syntax verification is generating unnecessary inference cost.',
    proposedChange: 'Auto-route AST validation & typing checks to Gemini 2.0 Flash; reserve Pro exclusively for distributed systems architecture.',
    projectedCostSavingsPct: 68.4,
    projectedLatencyImprovementPct: 54.0,
    risk: 'Low',
    governanceStatus: 'APPROVED_READY',
    submittedBy: 'Chief Architect Turing',
    timestamp: '2026-09-20 05:30 IST'
  },
  {
    id: 'opt_prop_002',
    type: 'WORKLOAD_REDISTRIBUTION',
    title: 'Batch InfiniBand RoCE Telemetry Sweeps Every 30s Instead of 5s',
    department: 'dept_compute_hpc_infra',
    currentBottleneck: 'Continuous 5-second polling of idle worker nodes causes excess message bus traffic.',
    proposedChange: 'Switch to event-driven wakeup with 30s background heartbeat for dormant nodes.',
    projectedCostSavingsPct: 32.0,
    projectedLatencyImprovementPct: 18.5,
    risk: 'Low',
    governanceStatus: 'L1_PROPOSED',
    submittedBy: 'Infra Commander Volta',
    timestamp: '2026-09-20 06:05 IST'
  }
];

export const INITIAL_COMPANY_KNOWLEDGE_MEMORY: CompanyKnowledgeMemoryItem[] = [
  {
    id: 'mem_001',
    category: 'APPROVED_DECISION',
    title: 'Capacity Allocation Architecture vs Simultaneous Model Burn',
    contentSummary: 'Established that 1,000 AI agents represents operational capacity with event-driven specialist activation, not 1,000 continuously burning LLM instances.',
    provenance: 'MII Architecture Policy §0 & §3',
    confidenceScorePct: 100,
    source: 'Owner & Executive Orchestration Consensus',
    timestamp: '2026-09-20 05:00 IST',
    owner: 'Executive Orchestrator Alpha',
    sensitivity: 'INTERNAL_CONFIDENTIAL',
    retentionPolicy: 'PERMANENT',
    validationState: 'SUPERVISOR_SIGNED'
  },
  {
    id: 'mem_002',
    category: 'INCIDENT_LESSON',
    title: 'InfiniBand Ring AllReduce Dropouts Under Worker Preemption',
    contentSummary: 'Discovered that worker node failure during tensor sync requires immediate sub-ring reconstitution rather than blocking the master scheduler.',
    provenance: 'Chaos Testing Experiment #HPC-441',
    confidenceScorePct: 99.4,
    source: 'Compute & Chaos QA Division',
    timestamp: '2026-09-20 04:30 IST',
    owner: 'Infra Commander Volta',
    sensitivity: 'INTERNAL_CONFIDENTIAL',
    retentionPolicy: '3_YEARS',
    validationState: 'EMPIRICALLY_VERIFIED'
  },
  {
    id: 'mem_003',
    category: 'PRODUCT_FINDING',
    title: 'DPDP Act Strict Affirmative Consent Increases Institutional Trust',
    contentSummary: 'Enterprise and academic labs consistently favor platforms that enforce hard quarantine by default over opt-out learning loops.',
    provenance: 'Loop 4 Security & Privacy Circular Re-Audit',
    confidenceScorePct: 99.9,
    source: 'Security & Legal Division',
    timestamp: '2026-09-20 06:00 IST',
    owner: 'Trust Sentinel Cipher',
    sensitivity: 'ANONYMIZED_PUBLIC',
    retentionPolicy: 'PERMANENT',
    validationState: 'PEER_REVIEWED'
  }
];

export const INITIAL_AI_ORG_STATE: AiOrganizationState = {
  totalCapacity: 1000,
  currentlyActive: 38,
  currentlySleeping: 932,
  currentlyQueued: 22,
  currentlyBlocked: 6,
  currentlyAwaitingApproval: 2,
  dailyCostUSD: 14.85,
  monthlyCostUSD: 242.60,
  globalAiPause: false,
  emergencyStop: false,
  emergencyStopTimestamp: null,
  emergencyStopReason: null,
  executiveOrchestratorStatus: 'HEALTHY'
};
